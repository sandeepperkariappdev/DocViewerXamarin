export class AppSettings {

     // Local
      public static API_ENDPOINT='http://localhost:62265/api/'; // -- Local
      public static API_I18N_ENDPOINT='http://localhost:62265/assets/i18n'; 
    //Dev
    // public static API_ENDPOINT='http://ahdeviis01.eagleottawa.com/LPADevServices/api/'; // -- Dev
    // public static API_I18N_ENDPOINT='http://ahdeviis01.eagleottawa.com/LPADevServices/assets/i18n'; 
   
    // this is used to get the I18N json files http://ahdeviis01/LPADevServices/assets/i18n/fr.json

    // Test
    //public static API_ENDPOINT="http://ahdeviis01.eagleottawa.com/LPATestServices/api/"; // -- Test
    //public static API_I18N_ENDPOINT='http://ahdeviis01.eagleottawa.com/LPATestServices/assets/i18n';

    // Pre Prod server
    //  public static API_ENDPOINT='http://ahdeviis01.eagleottawa.com/LPAProdServices/api/'; // -- Dev
    //  public static API_I18N_ENDPOINT='http://ahdeviis01.eagleottawa.com/LPAProdServices/assets/i18n'; 
    
    // Prod
    
    //    public static API_ENDPOINT= "http://usdca-lpa01.corp.lear.com/LPAServices/api/";    // -- Prod site  
    //    public static API_I18N_ENDPOINT='http://usdca-lpa01.corp.lear.com/LPAServices/assets/i18n';
          
     /*
     Server=tcp:rsrittestdb2servername.database.windows.net,1433;
     Initial Catalog=rsrittestdb2;
     Persist Security Info=False;
     User ID={your_username};
     Password={your_password};
     MultipleActiveResultSets=False;
     Encrypt=True;
     TrustServerCertificate=False;
     Connection Timeout=30;
     
     
     */  
}

export class MethodConstants{
    public static getUserDetails ='Users/getUserDetails?';
    public static getAllLevels ='AuditLevels/getLevel?auditLeve=0';//[{"$id":"1","AUDIT_LEVEL":2,"AUDIT_LEVEL_DESC":"Plant Level Audit"}]
    public static getAllRoles ='Roles/getRole?roleID=0';
    public static getAllLayers ='Layers/getLayer?auditLayer=0';
    public static getAllLanguages ="Languages/getAllLanguages";//[{"$id":"1","LANGUAGE_CODE":"CHN","LANGUAGE_NAME":"CHINESE"}]
    public static GetAllCategories = "Categories/getAllCategories?";
    public static getAllProductGroups ='ProductGroups/getAllPG';
    public static getProductGroup ='ProductGroups/getPG?';
    public static getOperationByProductGroup ='Operations/getOpByPG?';
    public static getProcessByOperation ='Processes/getProByOp?';
    public static GetProcessByPgPlant ='ProcessByPG/GetProcessByPgPlant?';// Task # 359 http://ahdeviis01.eagleottawa.com/LPADevServices/api/ProcessByPG/getProcessByPG?pgNum=0
    public static GetQuesFailCodesByLangCat ='FailureCodes/getQuesFailCodesByLangCat?';
    public static CreateQuesFailCodesByLangCat ='FailureCodes/CreateQuesFailCodesByLangCat'; // Task # 66 This is used to get the AUdits list for a single day. so this is not used
    public static GetActiveAuditListByPlantDate = 'Processes/GetActiveAuditListByPlantDate?'; // Task #94 plant_id=2&date=05-19-2017&processId=0&level=0 
    public static CreateAuditbyProcOpPG ='Processes/createAuditByProcOpPG';// Task 85 This is used to create a new Audit with the List of Questions.// this is replaced by processQuestions/addAdditionalQuesToPlantAudit
    public static GetAuditListByOpPg ='AuditList/getAuditListByOpPg?';// Task 86 http://ahdeviis01/LPADevServices/api/AuditList/getAuditListByOpPg?pgNum=5&operationNum=1&auditLevel=5&isPlantAdmin=1
    //public static GetAuditQuesFailCode ='Processes/getAuditQuesFailCode?';
    // implementation of new features
    public static GetAuditQuesFailCode ='AuditQuestions/getAuditQuesFailCodeProcessLevel?';
    public static GetSavedAuditQuesFailCode ='Processes/getSavedAuditQuesFailCode?';
    public static GetAcceptedActiveAuditListForPlant = 'UsersAccepted/getAcceptedActiveAuditListForPlant?'; // Task #254 http://ahdeviis01/LPADevServices/api/UsersAccepted/getAcceptedActiveAuditListForPlant?plantId=2&processId=0&level=0&startDate=05-19-2017&endDate=05-29-2017
    public static GetAllActiveAuditListForPlant = 'Users/getAllActiveAuditListForPlant?';
    public static GetAllActiveAuditListForUser = 'AllActiveAuditsForUser/getAllActiveAuditsForUser?';  //Task 117
    public static GetAllUserInPlant = "Users/getAllUserInPlant?";  
    public static CreateActiveAudits = "AuditLevels/createActiveAudits";  
    public static ScheduleAuditToUser = "ScheduleAudits/scheduleAuditToUser";
    public static GetPlantsByProcess = "?";  
    public static CreateQuesFailCodeByLangCat = "Questions/createQuesFailCodeByLangCat?";
    public static UpdateQuesFailCodeByLangCat = "Questions/updateQuesFailCodeByLangCat";
    public static RequestAddNewQueFailCode = "RequestAddNewQueFailCode/requestAddNewQueFailCode"; // Task #111
    public static DeleteAFailureCode = "FailureCodes/DeleteAFailureCode?";
    public static DeleteAQuestion = "Questions/deleteAQuestion?";
    public static GetAddNewQueToAuditReqLis = "AddNewQueToAuditReqList/getAddNewQueToAuditReqLis?"; // Task #198
    public static addAdditionalQuesToPlantAudit = "ProcessQuestions/addAdditionalQuesToPlantAudit"; //Task 85 this iwll be used to insert new Questions to the Audit for Plant and corporate, for corporate send the plantId as 0.
    public static SubmitAudit = "AuditFalures/submitAudit";   //Task 223
    public static SubmitAdhocAudit = "AdhocAudit/submitAdhocAudit";//http://ahdeviis01/LPATestServices/api/AdhocAudit/submitAdhocAudit
    public static ApproveRequestedQues = "QuestionFailureCodes/approveRequestedQues";//http://ahdeviis01/LPADevServices/api/QuestionFailureCodes/approveRequestedQues
    public static InsertCategory ="Categories/insertCategory?";
    public static ListOfMachinesfromPlants = "ListOfMachinesfromPlants/getListOfMachinesfromPlants?";
    public static AddNewMachineToPlant  = "Machines/addNewMachineToPlant";
    public static CreateNewUser = "Users/insertUser";
    public static AddNewUserToPlant = "Users/addNewUserToPlant?";    
    public static AssigningMultiplePlantsToUser = "Plants/assigningMultiplePlantsToUser";// http://ahdeviis01/LPADevServices/api/Plants/assigningMultiplePlantsToUser?plantIds=4&userId=596&shift=2&wLogin=CORPLEAR\SPerkari
    public static AssignReviewerAssigneeToFailureCode = "FalureCodeSettings/assignReviewerAssigneeToFailureCode";
    public static GetFailCodesListByLangCat = "FailureCodeLangCats/getFailCodesListByLangCat?"; // Task # 250 http://ahdeviis01/LPADevServices/api/FailureCodeLangCats/getFailCodesListByLangCat?langCode=ENG&catId=0&blnAll=1&requested=2
    public static InactivateQuestion = "InActiveQuestions/inactivateQuestion?"; // Task # 225 //http://ahdeviis01/LPADevServices/api/InActiveQuestions/inactivateQuestion?queId=1&active=false&wLogin=CORPLEAR\DDAI
    public static GetFinishedActiveAuditsForUser = "FinishedActiveAuditsForUser/getFinishedActiveAuditsForUser?"; // Task # 118 //http://localhost/LPAServices/api/FinishedActiveAuditsForUser/getFinishedActiveAuditsForUser?startDate=05-01-2017&endDate=08-31-2017&plantId=2&level=0&processId=0&userId=32
    public static GetFinishedActiveAuditListForPlant = "FinishedActiveAuditListForPlant/getFinishedActiveAuditListForPlant?"; //http://localhost/LPAServices/api/FinishedActiveAuditListForPlant/getFinishedActiveAuditListForPlant?startDate=05-01-2017&endDate=08-31-2017&plantId=2&level=0&processId=0
    public static ScheduleAcceptedAuditToUser = "ScheduleAcceptedAudits/scheduleAcceptedAuditToUser";//Task # 266http://ahdeviis01/LPADevServices/api/ScheduleAcceptedAudits/scheduleAcceptedAuditToUser Input: { "auditId": 29, "auditorId": 605, "lotNum": "0000", "machineNums": [ "10", "11", "12" ], "shift": "1", "comments": "asdfasd ", "wlogin": "0" }
    public static GetScheduledAuditForUserByPlantId = "ScheduleAcceptedAudits/getScheduledAuditForUserByPlantId?";// Task 273 http://localhost/LPAServices/api/ScheduleAcceptedAudits/getScheduledAuditForUserByPlantId?plantId=4&processId=0&level=0&auditorId=0&startDate=07-01-2017&endDate=07-30-2017
    public static ModifyAcceptedAuditForUser = "ScheduleAcceptedAudits/modifyAcceptedAuditForUser"; //Task 271 http://ahdeviis01/LPADevServices/api/ScheduleAcceptedAudits/modifyAcceptedAuditForUser  sau.auditId, sau.auditorId, sau.lotNum, sau.shift, sau.machineNum, sau.comments, sau.wlogin 
    public static DeleteScheduleAcceptedAuditForUser = "ScheduleAcceptedAudits/deleteScheduleAcceptedAuditForUser?";//Task #270 http://ahdeviis01/LPADevServices/api/ScheduleAcceptedAudits/deleteScheduleAcceptedAuditForUser?auditId=0&auditorId=0
    public static SubmitAssignmentReviewer = "AssignmentReviewer/submitAssignmentReviewer";    //Task #263 http://ahdeviis01/LPADevServices/api/AssignmentReviewer/submitAssignmentReviewer?auditDetailId=0&failCode=0&reviewerCompletion=02-20-2017&reviewerComments=Testing&wlogin=kloi
    public static SubmitAssignmentByAssignee = "AssignmentAssignees/submitAssignmentByAssignee"; //Task #262  http://localhost/LPAServices/api/AssignmentAssignees/submitAssignmentByAssignee?auditDetailId=0&failCode=0&assigneeCompletionDate=02-20-2017&assigneeComments=Testing&wlogin=kloi
    public static AssignedFailureCodesForPlant = "AssignedFailuresCodes/AssignedFailureCodesForPlant?"//Task 237 238 http://ahdeviis01/LPADevServices/api/AssignedFailuresCodes/AssignedFailureCodesForPlant?plantId=4&userId=605&assigneeOrReviewer=1&langCode=ENG&startDate=2017-07-18&endDate=2017-07-18
    public static AcceptedAuditsForUserOrPlantByCondition = "AcceptedAuditUsers/acceptedAuditsForUserOrPlantByCondition?";// Task 291 http://ahdeviis01/LPADevServices/api/AcceptedAuditUsers/acceptedAuditsForUserOrPlantByCondition?plantId=4&processId=0&level=5&auditorId=605&startDate=2017-06-11&endDate=2017-08-11&condition=2    
    public static GetSchUnSchCorrectActionCount = "SchUnSchCorrectActionCount/getSchUnSchCorrectActionCount?"// Task # 296 http://ahdeviis01/LPADevServices/api/SchUnSchCorrectActionCount/getSchUnSchCorrectActionCount?plantId=4&&level=5&startDate=2017-06-11&endDate=2017-08-11&userId=0&langCode=ENG
    public static CreateUpdateFailureCode = "FailureCodes/createUpdateFailureCode";// Task 313 http://ahdeviis01/LPADevServices/api/FailureCodes/createUpdateFailureCode
    public static GetAllAvailableUsers = "Users/getAllAvailableUsers";// Task 327 http://ahdeviis01/LPADevServices/api/Users/getAllAvailableUsers 
    public static GetSubmittedAuditQuesFailCode = "SubmittedAuditQuesFailCodes/GetSubmittedAuditQuesFailCode?";//Task #315 http://ahdeviis01/LPADevServices/api/SubmittedAuditQuesFailCodes/GetSubmittedAuditQuesFailCode?auditId=29&langCd=ENG&machineNum=10&shift=1
    public static GetShiftForPlant = "Shifts/getShiftForPlant?"; //Task #346http://ahdeviis01/LPADevServices/api/Shifts/getShiftForPlant?plantId=1
    public static postShiftForPlant = "Shifts/postShiftForPlant"; //Task  #346http://ahdeviis01/LPADevServices/api/Shifts/postShiftForPlant //{ "plantId": 10, "shift": "2", "wlogin": "klou" }
    public static GetAvailableMachinesToScheduledAudits = "ScheduledMachines/getMachinesFromScheduledAudits?"; // Task 348 http://ahdeviis01/LPADevServices/api/ScheduledMachines/getMachinesFromScheduledAudits?plantId=1&processId=1&levelId=1&startDate=01/01/2000&endDate=12/30/2017
    public static GetMachinesFromScheduledAudits =  "MachinesFromSchedule/getMachinesFromScheduledAudits?";// Task #349 http://ahdeviis01/LPADevServices/api/MachinesFromSchedule/getMachinesFromcheduledAudits?plantId=1&processId=1&levelId=1&startDate=01/01/2000&endDate=12/30/2017
    public static GetAllAvailablePlants =  "AllPlants/getAllAvailablePlants?"// Task # 355 http://ahdeviis01/LPADevServices/api/AllPlants/getAllAvailablePlants?plantId=0    
    public static GetQuestFailCodeByLangPg =  "QuestFailCodeByLangPgs/getQuestFailCodeByLangPg?";//http://ahdeviis01/LPADevServices/api/QuestFailCodeByLangPgs/getQuestFailCodeByLangPg?langCode=ENG&all=2&requested=true&pgNum=5&processSpecificQue
    public static CreateFailureCodes = "NewFailureCodes/createFailureCodes";// Task 378 http://ahdeviis01/LPADevServices/api/NewFailureCodes/createFailureCodes
    public static GetFailureCodeCateories = "FailureCodeCateories/getFailureCodeCateories?";//http://ahdeviis01/LPADevServices/api/FailureCodeCateories/getFailureCodeCateories?failureCdCatId=0
    public static CreateNewFailureCodeCategory = "FailureCodeCateories/createNewFailureCodeCategory"; //http://ahdeviis01/LPADevServices/api/FailureCodeCateories/assignPlantAssigneeReviewerToFailCodeCategory 
    public static AssignAssigneeToPlantFailCodeCategory = "AssigneeToPlantFailCodeCategory/assignAssigneeToPlantFailCodeCategory";// Task 388 http://ahdeviis01/LPADevServices/api/AssigneeToPlantFailCodeCategory/assignAssigneeToPlantFailCodeCategory
    public static GetPlantFailCodeCat = "PlantFailCodeCat/getPlantFailCodeCat?"// Task #400 http://ahdeviis01/LPADevServices/api/PlantFailCodeCat/getPlantFailCodeCat?plantId=2
    public static insertAuditHeader = "AuditHeader/insertAuditHeader";
    public static GetSWIFilePDFPathFromServer = "SWIFiles/getSWIFilePDFPathFromServer";
    public static DeleteShiftForPlant =  "ShiftForPlant/deleteShiftForPlant";//http://ahdeviis01.eagleottawa.com/LPAtestServices/api/ShiftForPlant/deleteShiftForPlant?plantId=2&shift=3
    public static GetMachineSWI = "MachineSWI/getMachineSWI";  //http://ahdeviis01.eagleottawa.com/LPAtestServices/api/MachineSWI/getMachineSWI?plantId=2&procId=2&machineNum=3
    public static SaveAudit = "AuditFaluresSave/saveAudit";//http://ahdeviis01/LPADevServices/api/AuditFaluresSave/saveAudit
    public static SaveAdhocAudit = "AdhocAuditSave/saveAdhocAudit"; //http://ahdeviis01/LPADevServices/api/AdhocAuditSave/saveAdhocAudit
    public static UpdateMachineToPlant = "MachinePlants/updateMachineToPlant"; //http://ahdeviis01/LPADevServices/api/MachinePlants/updateMachineToPlant
    public static UpdateMachineSequence = "MachineSequence/UpdateMachineSequence"; //http://localhost/LPAServices/api/MachineSequence/UpdateMachineSequence  // Task #546
    //public static InsertPlantFailCodeAssignee = "PlantFailCodeAssignees/insertPlantFailCodeAssignee";//http://localhost/LPAServices/api/PlantFailCodeAssignees/insertPlantFailCodeAssignee // Task 512
    // Implementation fo new features
    public static InsertPlantFailCodeAssignee = "PlantFailCodeProcessAssignees/insertPlantFailCodeProcessAssignee";//http://localhost/LPAServices/api/PlantFailCodeAssignees/insertPlantFailCodeAssignee // Task 512    
    public static ReassignBackAssignmentByReviewer = "ActionAssignmentReviewer/reassignBackAssignmentByReviewer";
    public static GetPGByPlant = "PGPlants/getPGByPlant?";//PGPlants/getPGByPlant?plantId=0 // Task 503
    public static AuditFailureRouting = "AuditFailureRouting/SaveAuditFailureRouting";
    public static GetCorrectiveActionHistory = "CorrectiveActionHistory/GetCorrectiveActionHistory"; //http://<server_name>/api/CorrectiveActionHistory/GetCorrectiveActionHistory?failureCdCatId=600&langCd=CHN
    public static UpdateProcessForMachine = "MachineProcess/UpdateProcessForMachine";//http://localhost:62265/api/MachineProcess/UpdateProcessForMachine // Task 715
    public static CorrectiveActionAssignmentReassign ="CorrectiveActionAssignmentReassign/correctiveActionAssignmentReassign";
    public static SubmitAuditFalureCode = "AuditFalureCodes/submitAuditFalureCode";
    public static CreateAdhocAuditIDForSave  = "InsertSubmitAdhocAudit/createAdhocAuditIDForSave";
    public static CreateAdhocAuditIDForSubmit  = "InsertSaveAdhocAudit/createAdhocAuditIDForSubmit";
}
export class Messages{
    public static message = {
        "auditDetailsNull":"Questions for the audits is not available, Server retured empty response",
        "error":"Error Occurred"
    };
}

export class I18n{
    public static en = {
        "questionsMaster":"QuestionsMaster"
    }
}