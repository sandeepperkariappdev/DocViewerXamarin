export const availableLaguages = [{
    code:'en',
    name:'ENGLISH',
    langCode:'ENG'
}, {
    code:'fr',
    name:'FRENCH',
    langCode:'FRE'
},{
    code:'es',
    name:'SPANISH (LATIN AMERICA)',
    langCode:'SPA'
},{
    code:'de',
    name:'GERMAN',
    langCode:'GER'
}];

export const defaultLanguage = 'en';

export const sysOptions = {
    systemLanguage:defaultLanguage
}