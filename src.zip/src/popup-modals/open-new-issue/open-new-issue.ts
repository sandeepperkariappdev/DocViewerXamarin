import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';

/**
 * Generated class for the OpenNewIssue page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-open-new-issue',
  templateUrl: 'open-new-issue.html',
})
export class OpenNewIssue {

  constructor(public navCtrl: NavController, public navParams: NavParams, private viewCtrl: ViewController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad OpenNewIssue');
  }
  dismissModal(){
    this.viewCtrl.dismiss();
  }
}
