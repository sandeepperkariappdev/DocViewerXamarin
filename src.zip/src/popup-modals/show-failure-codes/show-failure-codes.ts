import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, ModalController } from 'ionic-angular';
import { Privileges } from '../../providers/privileges';
import { User } from '../../models/User';
import { UtilService } from '../../providers/util-service';
import { UserService } from '../../providers/user-service';
import { TempFailureCodes, UserObject, UsersInPlant } from '../../models/QuestionItem';
import { SearchUsersInPlant } from '../search-users-in-plant/search-users-in-plant';
import { TranslateService } from 'ng2-translate';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { AnnotatePicturePage } from '../annotate-picture/annotate-picture';
import * as moment from 'moment';
import * as _ from 'lodash';

/**
 * Generated class for the ShowFailureCodes page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
    selector: 'page-show-failure-codes',
    templateUrl: 'show-failure-codes.html',
})
export class ShowFailureCodes {
    public queFailCodes: Array<TempFailureCodes>;
    public failAssignee: string;
    public failReviewer: string;
    public failComments: string;
    public shownGroupas = null;
    public isReadOnly: boolean;
    public isMobile: boolean;
    public AssigneeCompletionDays: Array<string>;
    public ReviewerCompletionDays: Array<string>;
    public FailureCompletionDays: Array<string>;
    public user: User;
    public isFileAdded: boolean;
    public isLPAAudit: boolean;
    constructor(public navCtrl: NavController, private translate: TranslateService, private camera: Camera, private privileges: Privileges, private userService: UserService, private utilService: UtilService, public navParams: NavParams, private viewCtrl: ViewController, private modalCtrl: ModalController) {
        this.AssigneeCompletionDays = [""];
        this.ReviewerCompletionDays = [""];
        this.FailureCompletionDays = [""];
        this.isReadOnly = false;
        this.isMobile = false;
        this.isLPAAudit = true;
        this.isFileAdded = false;        
    }

    ionViewDidEnter() {
        this.isMobile = this.utilService.isMobileApp;
        const navParams = this.navParams.data;
        if (navParams !== undefined && navParams.questionObj !== undefined && navParams.questionObj.failCodes !== undefined) {
            this.queFailCodes = navParams.questionObj.failCodes;
            // by defualt selecting the failure code if there is only one failure code available
            if (this.queFailCodes.length === 1) {
                this.queFailCodes[0].failCodeSelected = true;
            }
        }
        if (navParams.isLPAAudit !== undefined) {
            this.isLPAAudit = (navParams.isLPAAudit === "true");
        }
        if (navParams !== undefined && navParams.isReadOnly !== undefined) {
            this.isReadOnly = (navParams.isReadOnly === "true")
        }
        this.user = this.userService.getUser();
        const thisPage = this.privileges.getPageObject(this.user.roleName, "Rules")["ShowFailureCodes"];
        if (thisPage) {
            this.AssigneeCompletionDays = thisPage["AssigneeCompletionDays"];
            this.ReviewerCompletionDays = thisPage["ReviewerCompletionDays"];
            this.FailureCompletionDays = thisPage["FailureCompletionDays"];
        }
    }


    fileInputChange(e: any, failCode: TempFailureCodes) {
        e.preventDefault();
        e.stopPropagation();

        const file = e.target.files[0];
        const imageType = /image.*/;
        failCode.imageFilePath = file.name;
        const _that = this;
        const fileType = file.type;
        if (file.type.match(imageType)) {
            var reader = new FileReader();
            reader.onload = function (e) {
                failCode.imageData =  reader.result;
                failCode.imageType = "data:"+fileType+";base64";	
                _that.isFileAdded = true;
               /* let img = new Image();
                img.width = 5000;
                img.height = 5000;
                let base64Image = reader.result;
                img.src = base64Image;                
                img.onload = function (imageEvent) {
                    // Resize the image
                    var canvas = document.createElement('canvas'),
                        max_size = 400,//544,// TODO : pull max size from a site config
                        width = img.width,
                        height = img.height;
                    if (width > height) {
                        if (width > max_size) {
                            height *= max_size / width;
                            width = max_size;
                        }
                    } else {
                        if (height > max_size) {
                            width *= max_size / height;
                            height = max_size;
                        }
                    }
                    canvas.width = width;
                    canvas.height = height;
                    canvas.getContext('2d').drawImage(img, 0, 0, width, height);
                    //  var dataUrl = canvas.toDataURL('image/jpeg');
                    var dataUrl = canvas.toDataURL('image/png');
                    console.log("compressed image length - " + dataUrl.length);
                    failCode.imageData = dataUrl; //that.downScaleImage(img, 0.5);//base64Image;
                    failCode.imageType = "data:" + fileType + ";base64";
                    _that.isFileAdded = true;
                }*/
            }
            reader.readAsDataURL(file);
        } else {
        }
    }

    removePictureAttached(failCode: TempFailureCodes){
        failCode.imageData = ""; //that.downScaleImage(img, 0.5);//base64Image;
        failCode.imageType = "";
        failCode.imageFilePath = "";
        this.isFileAdded = false;
    }

    dismissModal() {
        this.viewCtrl.dismiss();
    }

    checkSelSubmittedFailCodes() {
        return _.filter(this.queFailCodes, (item) => {
            if (item.failCodeSelected && item.assignee.name !== "" && item.reviewer.name !== "" && item.assigneeCompletionDate !== "" && item.reviewerCompletionDate !== "" && item.severity !== 0 && item.failureCompletionDate !== "") {
                return true;
            } else {
                return false;
            }
        });
    }
    private assigneeCompletionDaysChange(failCode: TempFailureCodes): void {
        if (failCode.assigneeCompletionDays.toString() !== "") {
            failCode.assigneeCompletionDate = moment().add(+failCode.assigneeCompletionDays, "days").format("dddd MMMM Do YYYY");
        }
    }
    private failureCompletionDaysChange(failCode: TempFailureCodes) {
        if (failCode.failureCompletionDays.toString() !== "") {
            failCode.failureCompletionDate = moment().add(+failCode.failureCompletionDays, "days").format("dddd MMMM Do YYYY");
        }
    }
    private reviewerCompletionDaysChange(failCode: TempFailureCodes) {
        if (failCode.reviewerCompletionDays.toString() !== "") {
            failCode.reviewerCompletionDate = moment().add(+failCode.reviewerCompletionDays, "days").format("dddd MMMM Do YYYY");
        }
    }
  
    failCodeSelectedChanged(event: any, item: TempFailureCodes) {
        if (item.assignee.name !== "" && item.reviewer.name !== "" && item.assigneeCompletionDate !== "" &&
            item.reviewerCompletionDate !== "" && item.severity !== 0 && item.failureCompletionDate !== "") {
        } else {
            event.checked = false;
            this.utilService.showToast("fillFailureFields", "");
        }
    }
    getSelFailCodes() {
        return _.filter(this.queFailCodes, (item) => {
            return item.failCodeSelected;
        });
    }

    submitFailureCodesModal() {
        let selFailureCodes: Array<TempFailureCodes> = this.getSelFailCodes();
        if (selFailureCodes.length > 0) {
            if (this.isLPAAudit) { /// for LPA audit select only one failure code
                if (selFailureCodes.length === 1) {
                    if (this.checkSelSubmittedFailCodes().length === selFailureCodes.length) {
                        this.viewCtrl.dismiss({ "failCodes": selFailureCodes });
                    } else {
                        // this.utilService.showToast("FailCodesNotCompleted","");                                        
                        this.utilService.showToast("assignee_not_defined", "");
                    }
                } else {
                    this.utilService.showToast("FailCodesSelMore", "");
                }
            } else {// if it is not LPA audit you can select multiple failure codes
                if (this.checkSelSubmittedFailCodes().length === selFailureCodes.length) {
                    this.viewCtrl.dismiss({ "failCodes": selFailureCodes });
                } else {
                    // this.utilService.showToast("FailCodesNotCompleted","");                                        
                    this.utilService.showToast("assignee_not_defined", "");
                }
            }

        } else {
            this.utilService.showToast("NoFailureCodeSelected", "");
        }
    }
    showMoreInfoForAns() {

    }
    toggleGroup(group, item: TempFailureCodes) {
        if (this.isGroupShown(group)) {
            this.shownGroupas = null;
        } else {
            this.shownGroupas = group;
        }
        this.isFileAdded = false;
        if (this.isLPAAudit) {
            this.queFailCodes.forEach((item) => {
                item.failCodeSelected = false; /// resetting all the previously selected  failure codes to false.
            })
        }
        item.failCodeSelected = true;
    };
    isGroupShown(group) {
        return this.shownGroupas === group;
    };
    addFailure() {
        let failureCode = {
            "failAssign": this.failAssignee,
            "failReviewer": this.failReviewer,
            "failComments": this.failComments,
            "picture": "",
            "failureCodes": ["", "", ""],
            "selFailureCode": "failed due to option 1"
        }
    }
    public searchUsers(fcObject): void {
        let modal = this.modalCtrl.create(SearchUsersInPlant);
        modal.onDidDismiss((data: UsersInPlant) => {
            if (data !== undefined && data.userId !== undefined) {
                fcObject.id = data.userId;
                fcObject.name = data.firstName + "," + data.lastName;
            }
        });
        modal.present();
    }
    public takePicture(failCode: TempFailureCodes): void {
        if (failCode.imageData !== undefined) {
            if (failCode.imageData !== "") { //
                let modal = this.modalCtrl.create(AnnotatePicturePage, { "isFromPage": "ShowFailureCodes", "isAnnotatePicture": "true" }, { enableBackdropDismiss: false, cssClass:'annotatePicture' });
                modal.onDidDismiss((data) => {
                    if (data.isTakePicture) {
                        this.capturePicturefromCamera().then((imageData: string) => {
                            // imageData is either a base64 encoded string or a file URI
                            // If it's base64:
                            this.utilService.showToast("imagedataReceived" + imageData.substring(0, 20), "");
                            if (imageData !== undefined && imageData !== "") {
                                let base64Image = 'data:image/png;base64,' + imageData;
                                failCode.imageData = base64Image;
                                failCode.imageType = "data:image/png;base64";
                            } else {
                                this.utilService.showToast("imagedata is empty", "");
                            }
                        }, (err) => {
                        });
                    }
                });
                modal.present();
            } else {
                this.capturePicturefromCamera().then((imageData) => {
                    // imageData is either a base64 encoded string or a file URI
                    // If it's base64:
                    let base64Image = 'data:image/png;base64,' + imageData;
                    failCode.imageData = base64Image;
                    failCode.imageType = "data:image/png;base64";
                }, (err) => {
                });
            }
        }
    }
    private capturePicturefromCamera(): Promise<Object> {
        const options: CameraOptions = {
            quality: 1,
            destinationType: this.camera.DestinationType.DATA_URL,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        }
        return this.camera.getPicture(options);
    }
    public annotatePicture(failCode: TempFailureCodes): void {
        if (failCode.imageData !== undefined && failCode.imageData !== "") {
            //console.log("image Data:-  "+ failCode.imageData);
            let modal = this.modalCtrl.create(AnnotatePicturePage, {
                "isFromPage": "ShowFailureCodes",
                "isAnnotatePicture": "true",
                "imageData": failCode.imageData
            }, { enableBackdropDismiss: false });
            modal.onDidDismiss((data) => {
                if (data !== undefined) {
                    if (data.isTakePicture !== undefined && data.isTakePicture) {
                        this.capturePicturefromCamera().then((imageData) => {
                            // imageData is either a base64 encoded string or a file URI 
                            // If it's base64:

                            let base64Image = 'data:image/png;base64,' + imageData;
                            failCode.imageData = base64Image;
                            failCode.imageType = "data:image/png;base64";
                        }, (err) => {
                        });
                    }
                    if (data.imageData !== undefined && data.imageData !== "") {
                        if (data.imageData.indexOf("data:image/jpeg") === -1 && data.imageData.indexOf("data:image/png") === -1) {
                            data.imageData = 'data:image/jpeg;base64,' + data.imageData;
                        }
                        //let base64Image = 'data:image/jpeg;base64,' + data.imageData;
                        failCode.imageData = data.imageData;
                        failCode.imageType = data.imageData.indexOf("image/png") === -1 ? "data:image/jpeg;base64" : "data:image/png;base64";
                    }
                }
            });
            modal.present();
        } else {
            this.translate.get(["noImageToAnnotate"]).subscribe((values) => {
                this.utilService.showToast(values["noImageToAnnotate"], "")
            })
        }
    }
    showFailurReason() {

    }
    cancelFailure() {

    }
}
