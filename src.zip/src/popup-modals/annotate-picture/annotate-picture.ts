import { Component,  ViewChildren,ViewChild,ElementRef, QueryList } from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';
import { IonicPage, NavController, NavParams, ActionSheetController, ViewController, FabContainer, Platform  } from 'ionic-angular';
import { UtilService} from '../../providers/util-service';
import { TranslateService } from 'ng2-translate';
import { AnnotatePictureProvider }  from "./annotate-picture-service";
/**
 * Generated class for the AnnotatePicturePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-annotate-picture',
  templateUrl: 'annotate-picture.html',
})
export class AnnotatePicturePage {
   @ViewChildren('drawingCanvas') drawingCanvas:QueryList<ElementRef>;
   @ViewChildren('imagePicture') imagePicture:QueryList<ElementRef>;
   private canvasElement: any;
    lastX: number;
    lastY: number;
    showImage:boolean;
    currentColour: string = '#fcf513'; // using
    brushSize: number = 10; // using
  public imageData:string;
  public pageTitle:string;
  public isAnnotatePicture:boolean;
  private isStartSketch:boolean;
  public isMobile:boolean;
  private sketchObject : any;
  private strokeStyle : string;
  private lineWidth : number;
  private isIPad:boolean;
  private isIPhone:boolean;
   private isIPadPortrait:boolean;
  private isIPhonePortrait:boolean;
  private isIPadLandscape:boolean;
  private isIPhoneLandscape:boolean;
  private isMouseEventActive:boolean;
  constructor(private navCtrl: NavController,
    private translate: TranslateService,
  private annotatePictureService:AnnotatePictureProvider,
  public domSanitizer: DomSanitizer, 
  private utilService:UtilService, public platform: Platform,
  private viewCtrl:ViewController, 
  private navParams: NavParams, private actionSheetCtrl: ActionSheetController) {
     this.imageData = "";
     this.isMobile = false;
     this.pageTitle ="";
     this.isAnnotatePicture = false;
     this.isStartSketch = false;
     this.strokeStyle = "#ffff00"; // not using
     this.lineWidth = 10; // not using
     this.showImage = true;
     this.isMouseEventActive = false;
     this.isIPad = window.innerHeight > 700;
     this.isIPhone = window.innerHeight < 700;
     this.isIPadLandscape = window.innerHeight > 700 && window.innerHeight < 900;
     this.isIPadPortrait = window.innerHeight > 900 ;
     this.isIPhoneLandscape = window.innerHeight < 600 ;
     this.isIPhonePortrait =   window.innerHeight < 700 && window.innerHeight > 400;
  }
  
  ionViewWillEnter(){
  }

  public onImageLoad(){
    if(this.isAnnotatePicture){    
        let imagePicture = this.imagePicture.toArray()[0].nativeElement
        this.canvasElement = this.drawingCanvas.toArray()[0].nativeElement;
        let context = this.canvasElement.getContext('2d');
        this.canvasElement.height = imagePicture.height;
        this.canvasElement.width = imagePicture.width;
        //context.drawImage(imagePicture,0,0, imagePicture.width, imagePicture.height, 0,0,400, 400); 
        //context.drawImage(imagePicture, 20,10,500,500);   
        //context.rotate(90*Math.PI/180);
        // if(this.isIPhone){
        //     this.showImage = false;  
        //     context.drawImage(imagePicture, 0,0,350,550); //-- iphone
        // }
        // if(this.isIPad){
        //     this.showImage = false;  
        //     context.drawImage(imagePicture, 0,0,600,800); //-- ipad
        // }  
          if(this.isIPhonePortrait){
            this.showImage = false; 
            context.drawImage(imagePicture, 0,0,350,550); //-- iphone portrait          
        }
        if(this.isIPhoneLandscape){
              this.showImage = false; 
              context.drawImage(imagePicture, 0,0,650,280); //-- iphone landscape
        }
        if(this.isIPadPortrait){
           this.showImage = false; 
            //context.drawImage(imagePicture, 0,0,600,800); //-- ipad portrait
           // context.drawImage(imagePicture, 0,0,600,800); //-- ipad landscape
           context.drawImage(imagePicture, 0,0,750,950); //-- ipad Portrait
          //context.drawImage(imagePicture, 0,0,650,1150); //-- ipad Portrait (T, L, W, H)
        }  
        if(this.isIPadLandscape){
          this.showImage = false; 
          context.drawImage(imagePicture, 0,0,1000,700); //-- ipad landscape
        }                          
      }
  }


    ngAfterViewInit(){  }
 
    //   this.canvasElement = this.drawingCanvas.toArray()[0].nativeElement;
    //   let context = this.canvasElement.getContext('2d');

    // let source = new Image(); 
    // source.crossOrigin = 'Anonymous';
    //   source.onload = () => {
    //     this.canvasElement.height = source.height;
    //     this.canvasElement.width = source.width;
    //     context.drawImage(source, 0, 0); 
    //   }

  
  ionViewDidLoad() { // wait for the view to init before using the element
   /*   
      let canvas = this.drawingCanvas.toArray()[0].nativeElement
      let context: CanvasRenderingContext2D = canvas.getContext("2d");
      // happy drawing from here on
    //  context.fillStyle = 'blue';
    //  context.fillRect(10, 10, 150, 150);
      var base_image = new Image();
      base_image.src = this.imageData;
      //base_image.onload = function(){
         var W = base_image.width;
          var H = base_image.height;
          canvas.width = W;
          canvas.height = H;
          context.drawImage(base_image, 0, 0); //draw image
          //_that.annotatePictureService.resample_single(canvas,W,H, true);
     // }
      base_image.src = this.imageData;*/
      // const _that  = this;
      // let imagePicture = this.imagePicture.toArray()[0].nativeElement;
      // let canvas = this.canvasElement;
      // let context: CanvasRenderingContext2D = canvas.getContext("2d");
      // //context.ImageSmoothingEnabled = false;
      // context.webkitImageSmoothingEnabled = false;
      // context.mozImageSmoothingEnabled = false;

      // context.fillStyle = '#000';
      // context.fillRect(0, 0, 2000, 2000);
      //context.drawImage(imagePicture,0,0);
      //context.drawImage(_that.annotatePictureService.downScaleImage(imagePicture, 0.3), 287, 10);
    //  context.putImageData(this.imageData, 0,0)
  }
 handleTouchStart(ev){ 
  //   if(this.isIPhone){
  //      this.lastX = ev.touches[0].pageX -20; // iphone
  //      this.lastY = ev.touches[0].pageY -90; // iphone      
  //  }
  //     if(this.isIPad){
  //         this.lastX = ev.touches[0].pageX -100; // ipad
  //         this.lastY = ev.touches[0].pageY - 230; // ipad
  //     }    
          if(this.isIPhonePortrait || this.isIPhoneLandscape){
              this.lastX = ev.touches[0].pageX -20; // iphone
              this.lastY = ev.touches[0].pageY -90; // iphone      
          }
          if(this.isIPadLandscape){
                  //this.lastX = ev.touches[0].pageX - 225; // ipad landscape
                  //this.lastY = ev.touches[0].pageY - 120; // ipad landscape
                  this.lastX = ev.touches[0].pageX - 20; // ipad landscape
                  this.lastY = ev.touches[0].pageY - 80; // ipad landscape
          }
          if(this.isIPadPortrait){
                  //this.lastX = ev.touches[0].pageX -100; // ipad portrait
                //this.lastY = ev.touches[0].pageY - 230; // ipad portrait
                this.lastX = ev.touches[0].pageX - 15; // ipad portrait
                this.lastY = ev.touches[0].pageY - 70; // ipad portrait
          }              
    }
 
    handleTouchMove(ev){ 
        let ctx = this.canvasElement.getContext('2d');
        let currentX;
        let currentY;
      //    if(this.isIPhone){
      //       currentX   = ev.touches[0].pageX -20;// iphone
      //       currentY   = ev.touches[0].pageY -90;// iphone
      // }
      // if(this.isIPad){
      //       currentX = ev.touches[0].pageX -100; // ipad
      //       currentY = ev.touches[0].pageY - 230; // ipad
      // }
      if(this.isIPhonePortrait || this.isIPhoneLandscape){
            currentX   = ev.touches[0].pageX -20;// iphone portrait
            currentY   = ev.touches[0].pageY -90;// iphone portrait
        }
      // if(this.isIPad){
      //     //  currentX = ev.touches[0].pageX -100; // ipad portrait
      //     //  currentY = ev.touches[0].pageY - 230; // ipad portrait
      //       currentX = ev.touches[0].pageX - 225; // ipad landscape
      //       currentY = ev.touches[0].pageY - 120; // ipad landscape
      // }
          if(this.isIPadLandscape){
                  currentX  = ev.touches[0].pageX - 20; // ipad landscape
                  currentY = ev.touches[0].pageY - 80; // ipad landscape
          }
          if(this.isIPadPortrait){
                  //currentX  = ev.touches[0].pageX -100; // ipad portrait
                  //currentY = ev.touches[0].pageY - 230; // ipad portrait
                  currentX  = ev.touches[0].pageX -15; // ipad portrait
                  currentY = ev.touches[0].pageY - 70; // ipad portrait
          }
        ctx.beginPath();
        ctx.lineJoin = "round";
        ctx.moveTo(this.lastX, this.lastY);
        ctx.lineTo(currentX, currentY);
        ctx.closePath();
        ctx.strokeStyle = this.currentColour;
        ctx.lineWidth = this.brushSize;
        ctx.stroke();        
        this.lastX = currentX;
        this.lastY = currentY; 
    }
    handleMouseStart(ev){              
        this.lastX = ev.pageX -500;
        this.lastY = ev.pageY - 500;
        this.isMouseEventActive = !this.isMouseEventActive;
    }
 
    handleMouseMove(ev){ 
        if(this.isMouseEventActive){
                let ctx = this.canvasElement.getContext('2d');     
                let currentX = ev.pageX -500; 
                let currentY = ev.pageY -500; 
                ctx.beginPath();
                ctx.lineJoin = "round";
                ctx.moveTo(this.lastX, this.lastY);
                ctx.lineTo(currentX, currentY);
                ctx.closePath();
                ctx.strokeStyle = this.currentColour;
                ctx.lineWidth = this.brushSize;
                ctx.stroke();        
                this.lastX = currentX;
                this.lastY = currentY; 
        }        
    }

  ionViewDidEnter() {
    this.isMobile = this.utilService.isMobileApp;
    const navParams = this.navParams.data
    if(navParams !== undefined && (navParams.isFromPage === "ShowFailureCodes" || navParams.isFromPage === "CorrectiveActionAssignments")){
        if(navParams.imageData!==""){
          this.imageData = navParams.imageData;          
        }
        if(navParams.isAnnotatePicture !== undefined){
          this.isAnnotatePicture  = (navParams.isAnnotatePicture === "true");          
        }
        this.translate.get(['annotate_picture', 'failcode_picture']).subscribe((values)=>{
          this.pageTitle = this.isAnnotatePicture ? values["annotate_picture"] : values["failcode_picture"];
        });
        
    }
   // this.annotatePictureService.resample_single().subscribe((imageData)=>{
   //   this.startSketch();
   // });    
  }

  public showActionSheet(){
      let actionSheet = this.actionSheetCtrl.create({
      title: 'Select Action',
      buttons: [
        {
          text: 'Take New Picture',
          role: 'destructive',
          handler: () => {
            this.viewCtrl.dismiss({"isTakePicture":true}); 
          }
        },{
          text: 'Annotate picture',
          handler: () => {
           this.isAnnotatePicture = true;
          }
        },{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
         
          }
        }
      ]
    });
    actionSheet.present();
  }
  public submitAnnotatePictureModal():void{
   // if(this.sketchObject !== undefined){
        //this.imageData = this.sketchObject.canvas.toDataURL();
         this.imageData = this.canvasElement.toDataURL();
  //  }    
    this.viewCtrl.dismiss({"isTakePicture":false, "imageData":this.imageData});
  }
  public dismissAnnotatePictureModal():void{
    this.viewCtrl.dismiss();
  }
  annotatePicture(){
       const DestinationType = {
        DATA_URL: 0,
        FILE_URI: 1,
      };
      const EncodingType = {
        JPEG: 0,
        PNG: 1,
      };
    const options ={
      destinationType:DestinationType.DATA_URL,
      encodingType:EncodingType.JPEG,
      inputType:DestinationType.FILE_URI,
      inputData:this.imageData
    };
    const that = this;
    (<any>navigator).sketch.getSketch(function(imageData) {                                                            
                                                                if(imageData == null) {                                                                 
                                                                      return;                   
                                                                  }
                                                                  setTimeout(function() {                                                                          
                                                                      if(imageData.indexOf("data:image") >= 0 ) {
                                                                          that.imageData = "";
                                                                          that.imageData = imageData;
                                                                      } else {
                                                                          that.imageData = "";
                                                                          that.imageData = "data:image/png;base64," + imageData;
                                                                      }
                                                                  }, 0);
                                                              }
                                                  , function(message) {
                                                                setTimeout(function() {
                                                                    console.log('plugin message: ' + message);
                                                                }, 0); 
                                                              },{
                                                                  destinationType:DestinationType.DATA_URL,
                                                                  encodingType:EncodingType.JPEG,
                                                                  inputType:DestinationType.FILE_URI,
                                                                  inputData:this.imageData
                                                                });       
  }

  startSketchButtonClicked(){
      this.isStartSketch = !this.isStartSketch;
  }


  stopSketchButtonClicked(){
      this.isStartSketch = false;
  }


  clearSketchButtonClicked(){
    if(this.sketchObject !== undefined){
        this.sketchObject.clear();
        this.sketchObject.setup();
    }   else {
      const _that = this;
         var base_image = new Image();
          base_image.src = this.imageData;
          base_image.onload = function(){
                 _that.canvasElement = _that.drawingCanvas.toArray()[0].nativeElement;
        let context = _that.canvasElement.getContext('2d');
        _that.canvasElement.height = base_image.height;
        _that.canvasElement.width = base_image.width;
        //context.drawImage(imagePicture,0,0, imagePicture.width, imagePicture.height, 0,0,400, 400); 
        //context.drawImage(imagePicture, 20,10,500,500);   
        //context.rotate(90*Math.PI/180);
        if(_that.isIPhone){
            context.drawImage(base_image, 0,0,350,550); //-- iphone
        }
        if(_that.isIPad){
            context.drawImage(base_image, 0,0,600,650); //-- ipad
        }
          }
    }
  }


  updateLineWidthButtonClicked(width:number, fab: FabContainer){
    if(this.sketchObject !== undefined){
      //this.sketchObject.lineWidth = +width;
      this.lineWidth = width;
    }
    fab.close();
  }


  updateStrokeColorButtonClicked(color:string,fab: FabContainer){
      if(this.sketchObject !== undefined){
          //this.sketchObject.fillStyle = color;
          //this.sketchObject.strokeStyle = color;
          this.strokeStyle = color;
      }
      fab.close();
  }


  private startSketch(){
    var COLOURS = ['#E3EB64', '#A7EBCA', '#FFFFFF', '#D8EBA7', '#868E80'];
    var radius = 10;
    var strokeColor = "#ffff00";
    const _that = this;
    const start= this.isStartSketch;
    const imgData = this.imageData;
    this.sketchObject = new (<any>window).Sketch.create({
              container: document.getElementById('simple_sketch'),
              autoclear: false,
              autostart:false,
              fullscreen:true,                                       
              retina: 'auto',            
              setup: function() {        
                  let context = this.canvas.getContext('2d');
                   var base_image = new Image();
                   base_image.src = _that.imageData;
                   //var sampled_image = new Image();
                  // sampled_image.src = _that.imageData;
                   // _that.annotatePictureService.resample_single(this.canvas,this.canvas.width, this.canvas.height, true);
                   // var sampled_image = _that.annotatePictureService.downScaleImage(base_image, 0.3);
                    base_image.onload = function(){
                        //sampled_image.onload = function(){
                        context.drawImage(base_image,0,0);  
                       // context.putImageData(_that.annotatePictureService.downScaleImage(sampled_image, 0.3), 0, 0);
                    }                   
              },
              update: function() {        
                  radius = 10; 
                  var base_image = new Image();
                  base_image.src = _that.imageData;
                  // _that.annotatePictureService.resample_single(this.canvas, 439, 222, true);
                  this.canvas = _that.annotatePictureService.downScaleImage(base_image,0.3);
              },
            
              // Event handlers
              keydown: function() {
                  if (this.keys.C) this.clear();
              },
              // Mouse & touch events are merged, so handling touch events by default
              // and powering sketches using the touches array is recommended for easy
              // scalability. If you only need to handle the mouse / desktop browsers,
              // use the 0th touch element and you get wider device support for free.
              touchmove: function() {
                if(_that.isStartSketch){
                    for (var i = this.touches.length - 1, touch; i >= 0; i--) {
                      touch = this.touches[i];
                      this.lineCap = 'round';
                      this.lineJoin = 'round';
                      this.fillStyle = this.strokeStyle = _that.strokeStyle;//COLOURS[i % COLOURS.length];
                      this.lineWidth = _that.lineWidth;
                      this.beginPath();
                      this.moveTo(touch.ox, touch.oy);
                      this.lineTo(touch.x, touch.y);
                      this.stroke();
                  }
                }                  
              }
  });
  this.sketchObject.update();
  }

  private onSuccess(imageData) {
    const that = this;
        if(imageData == null) {
           // this.utilService.showToast("","received imageData as null");
           return;                   
      }
      setTimeout(function() {
               
          if(imageData.indexOf("data:image") >= 0 ) {
              that.imageData = "";
              that.imageData = imageData;
          } else {
              that.imageData = "";
              that.imageData = "data:image/png;base64," + imageData;
          }
       }, 0);
      }

      private onFail(message) {
         setTimeout(function() {
            console.log('plugin message: ' + message);
         }, 0);
      }
}
