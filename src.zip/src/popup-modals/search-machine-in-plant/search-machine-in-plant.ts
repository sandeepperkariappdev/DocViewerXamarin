import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ViewController } from 'ionic-angular';
import { UserService} from '../../providers/user-service';
import { UtilService} from '../../providers/util-service';
import { Machine } from '../../models/Level';
import { User } from '../../models/User';
import  { TranslateService }  from 'ng2-translate';
import * as _ from 'lodash';

/**
 * Generated class for the SearchMachineInPlantPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */


@Component({
  selector: 'page-search-machine-in-plant',
  templateUrl: 'search-machine-in-plant.html',
})
export class SearchMachineInPlant {
  private machinesList:Array<Machine>;
  private machinesListInitial:Array<Machine>; 
  private user:User;
  private pageTitle:string;
  private machineSelected:string;
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              private translate: TranslateService,    
              private utilService: UtilService,
              private viewCtrl:ViewController,
              private userService:UserService) {      
      this.machinesList = [];
      this.machinesListInitial = [];
      this.machineSelected = "";
  }
 
  ngOnInit(){    
    const navParams = this.navParams.data || {isFromPage : ""};
    this.pageTitle =  "Select Machine/WorkStation";          
    if(navParams.machinesList !== undefined){
      this.machinesList =  navParams.machinesList;
      this.machinesListInitial = navParams.machinesList;
    } 
  }

  ionViewDidLoad() {
  }
  getItems(ev) {    
    this.machinesList = Object.assign([], this.machinesListInitial);
    // set val to the value of the ev target
    var val = ev.target.value;
    // if the value is an empty string don't filter the items  
    if (val && val.trim() != '') {      
      this.machinesList = this.machinesList.filter((item) => {       
        return (item.name.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
  }
  public searchMachinesCancelClicked(){
    this.machinesList = Object.assign([], this.machinesListInitial);    
  }
  private dismissModal():void{
    this.viewCtrl.dismiss();   
  }
  private dismissModalOnSelectedMachine():void{    
    if(this.machineSelected !== ""){
      this.viewCtrl.dismiss(_.find(this.machinesList,(i)=>{ return i.name.toString() === this.machineSelected.toString();}));
    }                    
  }

}
