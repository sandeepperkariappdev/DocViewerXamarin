import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { UserService} from '../../providers/user-service';
import { UtilService} from '../../providers/util-service';
import { UserPlants, UsersInPlant, FailCodeCategoryList,FailCodeCategoryAssigningList, PlantUsers, AllAvailableUsers, ResponseObject} from '../../models/QuestionItem';
import { Plant } from '../../models/Level';
import { User } from '../../models/User';
import  { TranslateService }  from 'ng2-translate';
import * as _ from 'lodash';
/**
 * Generated class for the SearchUsersInPlant page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-search-users-in-plant',
  templateUrl: 'search-users-in-plant.html',
})
export class SearchUsersInPlant implements OnInit{
  items:Array<UsersInPlant>;
  private usersItems:Array<UsersInPlant>;
  plantsList:Array<UserPlants>;
  selPlantsList:Array<Plant>;
  initialPlantsList:Array<UserPlants>;
  selUserId:string;
  selPlantId:string;
  searchPlaceholder:string;
  pageTitle:string;
  private User:User;
  searchPlants:boolean;
  isSearchCategory:boolean;
  isSelectMultiple:boolean;
  private translate:TranslateService;
  public failCodeCatList:Array<FailCodeCategoryAssigningList>;
  public failureCdCatId:string;
  constructor(public navCtrl: NavController,
          private translateService: TranslateService,
          public navParams: NavParams,
          private utilService: UtilService,
          private viewCtrl:ViewController,
          private userService:UserService) {
    this.selUserId = "";
    this.pageTitle = "Search Users In Plant";    
    this.searchPlaceholder = "SearchBarPlaceholder";
    this.plantsList = [];
    this.selPlantsList=[];
    this.isSelectMultiple = false;
    this.isSearchCategory =  false;
    this.searchPlants = false;
  }
  initializeItemsForUsers() {
     const navParams = this.navParams.data || {isFromPage : ""};   
    if(this.searchPlants){      
     
      if(navParams.isFromPage === "manageUser"){
        if(navParams.selectedProductGroup !== undefined && navParams.selectedProductGroup !== 0){
          // navParams.selectedProductGroup
            this.plantsList = this.initialPlantsList.filter((item) => {
              return _.map(item.productGroups, "pgId").indexOf(+navParams.selectedProductGroup) !== -1;
            });
        }        
      } else{
        this.plantsList = this.initialPlantsList;  
      }
    } else{
      if(this.User.roleId === 1){ // load all available users
        this.pageTitle = "Search All Availabel Users";
        // this will return only users that are already assigned to a plant.
        // TODO return all the availble users in the users table
        this.userService.getAllAvailableUsers().subscribe((data:ResponseObject)=>{
              if(this.utilService.checkValidData(data)){                  
                  const usersList:Array<UsersInPlant> =  data.Response;//this.getUsersListFromResponse(data.Response);   
                  this.items = usersList
                  this.usersItems = usersList;
              }
          });
      } else{               
          const usersList:Array<UsersInPlant> = this.userService.getUsersInPlant();
          this.items = usersList;
          this.usersItems = usersList;
           if(navParams.isFromPage === "weeklySchedulingAudits"){
              if(navParams.loadUsersByLevel === "true" && navParams.selectedLevel !== undefined){
                    const selectedLevel = navParams.selectedLevel; //this.selLevelId 
                    let levelsIds = _.map(this.utilService.getAllLevels(), 'id'); 
                    if(levelsIds.indexOf(selectedLevel) !== -1){
                        // load the users only for the level id belongs to available levels 
                        // for general audit level is greater then 10
                        this.items = usersList.filter(item => item.level.toString() === selectedLevel.toString());
                        this.usersItems = usersList.filter(item => item.level.toString() === selectedLevel.toString());
                    } else{
                        this.items = usersList;  
                        this.usersItems = usersList;
                    }                    
              }              
          } 
      }            
    }    
  }
  ngOnInit(){
    this.translate = this.translateService;
    const navParams = this.navParams.data || {isFromPage : ""};
    this.User = this.userService.getUser();
    if(navParams.isFromPage === "AuditDetailsCategoryChange"){
          this.isSearchCategory = true;
           this.pageTitle =  "Select Category";
          // this.failCodeCatList = this.utilService.getAllFailureCodeCategories();
           this.failCodeCatList = this.utilService.getFailCodeCategoryAssigningList();

    } else{
        if((navParams.isFromPage === "plants" || navParams.isFromPage === "manageUser")){
            this.searchPlants = true;
            this.pageTitle = "Search Plants";
            if(navParams.plantsArray !== undefined){
                this.initialPlantsList =  navParams.plantsArray;
            } 
            if(navParams.isMultipleSelect === "true"){
                this.isSelectMultiple = true;
            }     
          } 
            this.initializeItemsForUsers();           
    }
    
  }
  searchSelection(){
    
  }
  getUsersListFromResponse(data:Array<PlantUsers>):Array<UsersInPlant>{
    return data.reduce((prev, items) => {
            if(items.users.length > 0){
                prev = prev.concat(items.users);  
            }        
            return prev;
          }, []);
  }
  getItems(ev) {
    // Reset items back to all of the items
  //  this.initializeItemsForUsers();
    const usersList:Array<UsersInPlant> = this.usersItems;
    this.items = usersList;
          
    // set val to the value of the ev target
    var val = ev.target.value;
    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {      
      this.items = this.items.filter((item) => {
        return (item.firstName.toLowerCase().indexOf(val.toLowerCase()) > -1 || item.lastName.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
  }

getPlantItems(ev) {

    // Reset items back to all of the items
    this.initializeItemsForUsers();
    // set val to the value of the ev target
    var val = ev.target.value;
    // if the value is an empty string don't filter the items  
    if (val && val.trim() != '') {      
      this.plantsList = this.plantsList.filter((item) => {
        return (item.plantName.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
  }

  private dismissModal():void{
     this.viewCtrl.dismiss();   
  }

  private dismissModalOnSelectCategory():void{
    if(this.isSearchCategory){
          if(this.failureCdCatId !== undefined){
              this.viewCtrl.dismiss(_.find(this.failCodeCatList,(i)=>{ return i.failureCdCatId.toString() === this.failureCdCatId.toString();}));
          }         
    }       
  }

  private dismissModalOnSelectUser():void{
    if(this.searchPlants && !this.isSelectMultiple){
          this.viewCtrl.dismiss(_.find(this.plantsList,(i)=>{ return i.plantId.toString() === this.selPlantId;}));
    } else if(this.searchPlants && this.isSelectMultiple){
          this.viewCtrl.dismiss(this.selPlantsList);
    } else{
      if(this.selUserId){
        this.viewCtrl.dismiss(_.find(this.items,(i)=>{ return i.userId.toString() === this.selUserId;}));
      }
    }      
  }
  ionViewDidLoad() {
    
  }
  selectPlant(event:any, item:Plant){
      if(event.checked){
        this.selPlantsList.push(item);
      } else{
        const index = _.findIndex(this.selPlantsList,(i)=>{ return i.plantId.toString() === item.plantId.toString();});
        if(index !== -1){
            this.selPlantsList.splice(index, 1);
        }
      }
  }   

}
