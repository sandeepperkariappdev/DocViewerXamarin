import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, AlertController } from 'ionic-angular';

/**
 * Generated class for the AssignmentDetails page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-assignment-details',
  templateUrl: 'assignment-details.html',
})
export class AssignmentDetails {

  constructor(public navCtrl: NavController, public navParams: NavParams, private viewCtrl:ViewController, private alertCtrl :AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AssignmentDetails');
  }
  dismissModal(){
    this.viewCtrl.dismiss();
  }
  resolveAssignment(){
     let prompt = this.alertCtrl.create({
            title: 'Confirm',
            message: "You're about to resolve the Issue?",            
            buttons: [
              {
                text: 'No',
                handler: data => {
                  console.log('Cancel clicked');
                  prompt.dismiss();
                }
              },
              {
                text: 'Yes',
                handler: data => {
                  console.log('Saved clicked');                  
                  prompt.dismiss();                  
                 }
              }
            ]
          });
          prompt.present();
    this.viewCtrl.dismiss();
  }

}
