import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';

/**
 * Generated class for the MoreInfoModal page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-more-info-modal',
  templateUrl: 'more-info-modal.html',
})
export class MoreInfoModal {
  showModal:boolean;
  title:String;
  criteria:Array<string>;
  imageData:string;
  constructor(public navCtrl: NavController, public navParams: NavParams, private viewCtrl: ViewController) {
    this.title = navParams.get('title');
    this.criteria = navParams.get('criteriaData');
    this.imageData = navParams.get('imageData');    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MoreInfoModal');
  }
  dismissModal(){
      this.viewCtrl.dismiss();
  }
}
