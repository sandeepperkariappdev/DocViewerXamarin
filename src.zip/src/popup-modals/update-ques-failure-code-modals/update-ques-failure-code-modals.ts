import { Component,OnInit } from '@angular/core';
import { NavController, ModalController, NavParams, ViewController, ActionSheetController } from 'ionic-angular';
import { Language } from '../../models/Level';
import { Category } from '../../models/Level';
import { UserService} from '../../providers/user-service';
import { UtilService} from '../../providers/util-service';
import { CreateFailureCodePage } from '../../pages/create-failure-code/create-failure-code';
import { Questions, Question, FailureCode, FailCodeCategoryList } from '../../models/QuestionItem';
import { AdminManageQuesServiceProvider} from '../../pages/admin/admin-manage-questions/admin-manage-ques-service';
import { AdminManageFailureCodesPage } from '../../pages/admin-manage-failure-codes/admin-manage-failure-codes';

/**
 * Generated class for the UpdateQuesFailureCodeModals page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */



@Component({
  selector: 'page-update-ques-failure-code-modals',
  templateUrl: 'update-ques-failure-code-modals.html',
})
export class UpdateQuesFailureCodeModals implements OnInit{
  private onLanguageSelected:boolean;
  private selLangQue:string = "all";
 public failCodeCatList:Array<FailCodeCategoryList>;
  private questionList:Array<Question>;
  private newQuestionsList:Questions;
  private initialQuestionsList:Questions;
  private shownGroupas = null;//to show or hide used for accordion
  private selLanguage = {id:"all"};// for language checkbox modal
  private selCategories = {id:""};// for categories checkbox modal
  private languagesList:Array<Language>;// for language checkbox List
  private catList:Array<Category>;// for categories checkbox List
  private reqAuditDtsAddNewQues:boolean; // to check if the Question is requested by the Plant Admin to add to Question Master by the Corporate Admin
  private isFromAuditDetails:boolean;
  private showInComplete:boolean;

  constructor(private navCtrl: NavController, 
              private userService: UserService,
              private adminManageQuesService:AdminManageQuesServiceProvider,
              private navParams: NavParams, 
              private actionSheet:ActionSheetController, 
              private modalCtrl:ModalController, 
              private viewCtrl: ViewController, 
              private utilService:UtilService) {    

        this.reqAuditDtsAddNewQues = false;
        let fc= new FailureCode(0,0,0,0,1,"","",true, "");
        let que = new Question("ENG","ENGLISH","","","" ,"",false, false, false,false,false,[]);
        this.questionList = new Array(que);
        this.newQuestionsList = new Questions("select",0,this.questionList);  
        this.failCodeCatList = this.utilService.getAllFailureCodeCategories();                    
    }

    ngOnInit(){
        const navParams = this.navParams.data;
            if(navParams !== undefined && navParams.isFromAuditDetails){
            this.isFromAuditDetails = navParams.isFromAuditDetails;
        }
        if(navParams !== undefined && navParams.reqAuditDtsAddNewQues){
            this.reqAuditDtsAddNewQues  = navParams.reqAuditDtsAddNewQues === "true";
        }   
      
      this.languagesList = this.utilService.getAllLanguages();
      this.catList = this.utilService.getAllCategoriesByProductGroups(this.userService.getUserSelection().selPGId);
      this.languagesList.forEach((v,i) =>{
        if(v.langCode !== 'ENG'){
            let fc= new FailureCode(0,0,0,0,1,"","",true, "");
            let que = new Question(v.langCode,v.langDesc,"","","" , "",false,true, false,false,true,[fc]);
            this.questionList.push(que);
        }        
      });
      this.newQuestionsList = new Questions("",0,this.questionList);  
      this.newQuestionsList.catId = 0;
      this.initialQuestionsList =  new Questions("",0,this.questionList);  
      this.selLanguage.id = this.userService.getUser().languageCode;
      this.onLanguageChange(false);
  }
  dismiss() {
    this.viewCtrl.dismiss();
  }
  ionViewDidLoad() {
    
  }
  private checkQuestionFailureCodesNotInComplete(){
    return this.newQuestionsList.questions.reduce((prev, item)=>{
            const fcList = item.failCodes.filter(itm => (itm.failDesc !== "" && itm.failureCdCatId !== 0));
            if(fcList.length === item.failCodes.length && item.queDesc && item.queDesc != ""){
                    prev.push(item);
            }
        return prev;
    },[])
  }
  // This is called on click of the Done button in the model pop up
  private addNewQuesFailureCodes():void{      
      if(this.checkQuestionFailureCodesNotInComplete().length > 0){
          if(this.newQuestionsList.catId !== 0){
                // returning the date to submit to the server from the controller
                this.viewCtrl.dismiss({"submitedData":this.newQuestionsList});
          } else{
              this.utilService.showToast("EmptyCategoryName","");
          }            
      } else{
          this.utilService.showToast("EmptyQuesFailCodes","");
      }    
  }


  addNewFailureCode(item){
    this.newQuestionsList.questions.forEach((v,i)=>{
        v.failCodes.push(new FailureCode(0,0,0,0,1,"","",true, ""));
    });
  }
  removeNewFailureCode(index, item){
    this.newQuestionsList.questions.forEach((v,i)=>{
        v.failCodes.splice(index,1);
    });
  }
  toggleGroup(group) {
      if (this.isGroupShown(group)) {
          this.shownGroupas = null;
      } else {
          this.shownGroupas = group;
      }
    };
    isGroupShown(group) {       
        if(this.selLanguage.id === "all"){
            return this.shownGroupas === group;
        } else{
            return true;
        } 
    };

    onLanguageChange(flag:boolean = true){        
            if(this.newQuestionsList.questions.length >1){
                if(flag){
                    this.initialQuestionsList.questions.forEach((itm)=>{
                        this.newQuestionsList.questions.forEach((i)=>{
                                if(itm.lngCode === i.lngCode ){
                                    itm = i;
                                }
                        });                    
                    });
                }                    
            } else{
                this.initialQuestionsList.questions.forEach((itm)=>{
                    if(itm.lngCode === this.newQuestionsList.questions[0].lngCode ){
                        itm = this.newQuestionsList.questions[0];
                    }
                });
            }                            

        this.newQuestionsList.questions = this.initialQuestionsList.questions.reduce((prev, item)=>{
            if(this.selLanguage.id !== "all" && item.lngCode === this.selLanguage.id){
                prev.push(item);
            } else if(this.selLanguage.id === "all") {
                prev.push(item);
            }
            return prev;
        }, []);
    }
    private onCategoryChange(item){

    }
    private onNAChange(item){

    }
    private onFailActiveChange(item){

    }
    private addFailureCodeClick(item:Question){
        let modal = this.modalCtrl.create(AdminManageFailureCodesPage, {"isFromPage": "UpdateQuestions"});
        modal.onDidDismiss((data:Array<FailureCode>)=>{ // question object is returned from the model window.
            if(data !== undefined){// return the array of Failure Code Objects               
                item.failCodes = item.failCodes.reduce((prev, itm)=>{
                    if(itm.failDesc !== ""){
                        prev.push(itm);
                    }                                        
                    return prev;
                },[]);  // updating the new add failure codes
                item.failCodes= item.failCodes.concat(data);
            }            
        });
        modal.present();
    }
}
