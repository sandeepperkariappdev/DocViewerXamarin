import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers} from '@angular/http';
import { AppSettings, MethodConstants } from '../constants/AppSettings';
import {User} from '../models/User';
import {UserDetailsResponse} from '../models/UserDetailsResponse';
import {UserSelectionData,CreateNewUser, PlantInfo, UsersInPlant,UserObject, URL, AssignPlantsRequest} from '../models/QuestionItem';
import {UtilService} from './util-service';
import {CallService} from './call-service';
import {HttpService} from './http-service';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { Observable }from 'rxjs/observable';
import { LoginPage } from '../pages/login-page/login-page';
import * as _ from 'lodash';
import * as storage from "./local-Storage";
import { Lot, Machine, Shift, ProductGroup } from '../models/Level';
/*
  Generated class for the UserService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class UserService {
  private user:User;
  private userSelData:UserSelectionData;
  private usersInPlant:Array<UsersInPlant>;
  constructor(public http: HttpService, private utilityService:UtilService, private callService:CallService) {
    
  }
  public setUser(userData :User){
    this.user = userData;
  }
  public  getUser():User{
    return this.user;
  }
  public setUserSelection(data:UserSelectionData){
    this.userSelData = data;
  }
  public  getUserSelection():UserSelectionData{
    if(this.userSelData !== undefined){
        return Object.assign({},this.userSelData);
    } else{
        return undefined;
    }    
  }
  public  getUsersInPlant():Array<UsersInPlant>{    
    return  this.usersInPlant;       
  }
public retrieveUsersByPlant(plantId:number, pgNum:number){    
      if(plantId !== undefined){
          const url =  (AppSettings.API_ENDPOINT+ MethodConstants.GetAllUserInPlant+"plantId="+plantId+"&pgNum="+pgNum)
          //const url =  (AppSettings.API_ENDPOINT+ MethodConstants.GetAllUserInPlant+"plantId="+plantId);
          return this.callService.callServerForGet(url);
      } else{
        console.error('values cannot be null');
      } 
  }
  public retrieveUsersForPlant(plantId:number, pgNum:number){    
    if(plantId !== undefined){
      const url =  (AppSettings.API_ENDPOINT+ MethodConstants.GetAllUserInPlant+"plantId="+plantId+"&pgNum="+pgNum)
      //const url =  (AppSettings.API_ENDPOINT+ MethodConstants.GetAllUserInPlant+"plantId="+plantId);
      this.callService.callServerForGet(url).subscribe((data)=>{
            if(this.utilityService.checkValidData(data)){          
                  if(data.Response !== undefined && _.isArray(data.Response) && data.Response.length > 0){
                      this.usersInPlant = data.Response[0]["users"];      
                  } else{
                    console.error("Error receiving response from server.Users cannot be empty")
                  }            
            }
          });
      } else{
        console.error('plantId && plantId !==0 values cannot be null');
      }
  }

/**
 * name
 */
public createNewUser(newUser: CreateNewUser) {
  /*http://ahdeviis01/LPADevServices/api/
  Users/insertUser?
  userId=0&lastName=lastName
  &firstName=firstName&userWLogin=userWLogin
  &email=mail&roleId=1&level=1&layer=1&active=true
  &certified=true&pgNum=5&langCd=ENG&wLogin=klou*/
  const url =  AppSettings.API_ENDPOINT+ MethodConstants.CreateNewUser;
  return this.callService.callServerForPost(url,"",newUser);
}

public addNewUserToPlant(plantId:number, userId:number, wLogin:string){
    //http://localhost/LPAServices/api/Users/addNewUserToPlant?plantId=1&userId=10&wLogin=klou
    if(plantId !== 0 && userId !==0 && wLogin!==""){
      const url =  (AppSettings.API_ENDPOINT+ MethodConstants.CreateNewUser+"plantId="+plantId+"&userId="+userId+"&wLogin="+wLogin)
      return this.callService.callServerForPost(url,"","");
    }    
}

/**
 * @method assignMulitpleUserToPlant
 * @param plantId 
 *    @type arrayof aplant id's
 * @param userId 
 *   @type number
 * @param wLogin 
 *  @type string
 * 
 * 
 */
public assignMulitplePlantsToUser(request:AssignPlantsRequest){
  //plantId:Array<string>, userId:number, shift:string, wLogin:string    
  //"plantIds="+[plantId]+"&userId="+userId+"&shift="+shift+"&wLogin="+wLogin
  // http://ahdeviis01/LPADevServices/api/Plants/assigningMultiplePlantsToUser?plantIds=4&userId=596&shift=2&wLogin=CORPLEAR\SPerkari    
      const url =  (AppSettings.API_ENDPOINT+ MethodConstants.AssigningMultiplePlantsToUser);
      return this.callService.callServerForPost(url,"",request);    
}
    public getAllAvailableUsers(){    
   // Task 327 http://ahdeviis01/LPADevServices/api/Users/getAllAvailableUsers     
      const url =  (AppSettings.API_ENDPOINT+ MethodConstants.GetAllAvailableUsers)
      return this.callService.callServerForGet(url,"");        
    }

    public getAllUserFromService(wLogin:string):Observable<UserDetailsResponse>{    
      const url = (AppSettings.API_ENDPOINT + MethodConstants.getUserDetails+"userId=0&active=2&wLogin="+wLogin);      
      const msgTxt:string='';      
        return this.callService.callServerForGet(url,msgTxt).map((data) => {  
                if(this.utilityService.checkValidData(data)){
                    if(Array.isArray(data.Response) && data.Response.length > 0){     
                        return data.Response[0];         
                    } else{      
                      this.utilityService.showToast("User information not received from server.");
                       this.utilityService.hideLoading(); 
                      return {};
                    }
                }    
            }).map(({userId, lastName, firstName,wLogin, email,roleId,levelId,layerId, active, certified, langCode, pgId, pgName,plants}) => 
                  {      
                    return  new UserDetailsResponse(userId, lastName, firstName,wLogin, 
                                      email,roleId,levelId,layerId, active, certified, 
                                      langCode, pgId, pgName,plants,levelId !== null && levelId !== undefined  ? this.utilityService.getLevelDescById(levelId):"",
                                      layerId ? this.utilityService.getLayerDescById(layerId) : "",
                                      true,roleId ? this.utilityService.getRoleDescById(roleId):"");      
                  });
     }
  public getUserFromService(wLogin:string):Observable<UserDetailsResponse>{    
      const url = (AppSettings.API_ENDPOINT + MethodConstants.getUserDetails+"userId=0&active=1&wLogin="+wLogin);      
      const msgTxt:string='';      
        return this.callService.callServerForGet(url,msgTxt).map((data) => {  
                if(this.utilityService.checkValidData(data)){
                    if(Array.isArray(data.Response) && data.Response.length > 0){     
                        return data.Response[0];         
                    } else{      
                      this.utilityService.showToast("User information not received from server.");
                       this.utilityService.hideLoading(); 
                      return {};
                    }
                }    
            }).map(({userId, lastName, firstName,wLogin, email,roleId,levelId,layerId, active, certified, langCode, pgId, pgName,plants}) => 
                  {      
                    return  new UserDetailsResponse(userId, lastName, firstName,wLogin, 
                                      email,roleId,levelId,layerId, active, certified, 
                                      langCode, pgId, pgName,plants,levelId !== null && levelId !== undefined  ? this.utilityService.getLevelDescById(levelId):"",
                                      layerId ? this.utilityService.getLayerDescById(layerId) : "",
                                      true,roleId ? this.utilityService.getRoleDescById(roleId):"");      
                  });
     }
     checkValidUserPreferencesResponse(data:UserDetailsResponse, checkMultiplePlants:boolean){
   // this is available in home.ts 
   // any changes here shoudl also be done in home.ts
     // return false when there are multiple Plants for the User.     
            let levelName = this.utilityService.getLevelDescById(data.levelId);
            let roleName = this.utilityService.getRoleDescById(data.roleId);
            let langName = this.utilityService.getLanguageDesc(data.languageCode);
            if(data !== undefined && data.roleId !== undefined && data.roleId === 0){
                  this.utilityService.showToast("noValidresponsefromServer","Role cannot be 0 for the user");
                return false;
            }
            if(data.roleId === 1){ // Super Admin
                    const usrSelData  = new UserSelectionData(0,"", 0, "",0, "", 0, "",0, "",data.roleId,  roleName,  
                                                            data.languageCode, langName,"","",data.userId.toString(), 
                                                            new Lot(0, ""),new Machine("0","","", true),new Shift("0",""), 
                                                            new UserObject(0, ""),"","","","","","","");
                                let userObj:User = _.extend({},data);
                                userObj.plants = new Array();
                                userObj.roleName = roleName;
                                userObj.levelName = levelName; 
                                this.setUserSelection(usrSelData); 
                                this.setUser(userObj);                       
                                ///localStorage.saveUserSelection = JSON.stringify(usrSelData);
                                return true;
                } else if(data.roleId === 2){
                        //TODO Corp admin will not have plants so how to figure out the product group?
                        // this is available in home.ts 
                        // any changes here shoudl also be done in home.ts   
                        if((data.pgId !== undefined && data.pgId  !== 0) &&
                        (data.pgName !== undefined && data.pgName !== "")){
                                const usrSelData  = new UserSelectionData(0, "", data.pgId, data.pgName,
                                                                        0, "",0, "",0,"",data.roleId,  roleName,  
                                                                        data.languageCode, langName,"","",data.userId.toString(), 
                                                                        new Lot(0, ""),new Machine("0","","", true),new Shift("0",""), 
                                                                        new UserObject(0, ""),"","","","","","","");
                                let userObj:User = _.extend({},data);
                                userObj.plants = new Array();
                                userObj.roleName = roleName;
                                userObj.levelName = levelName; 
                                this.setUserSelection(usrSelData); 
                                this.setUser(userObj); 
                                //localStorage.saveUserSelection = JSON.stringify(usrSelData);
                                return true;                                            
                        } else{          
                                this.utilityService.showToast("noValidresponsefromServer","Product Group is not set to the user");
                                return false;
                        } 
                  } else if(data.roleId === 5){
                    // Handling the Read Only User, ReadOnly will have only the reports to view
                    if((data.pgId !== undefined && data.pgId  !== 0) &&
                    (data.pgName !== undefined && data.pgName !== "")){
                            const usrSelData  = new UserSelectionData(0, "", data.pgId, data.pgName,
                                                                    0, "",0, "",0,"",data.roleId,  roleName,  
                                                                    data.languageCode, langName,"","",data.userId.toString(), 
                                                                    new Lot(0, ""),new Machine("0","","", true),new Shift("0",""), 
                                                                    new UserObject(0, ""),"","","","","","","");
                            let userObj:User = _.extend({},data);
                            userObj.plants = new Array();
                            userObj.roleName = roleName;
                            userObj.levelName = levelName; 
                            this.setUserSelection(usrSelData); 
                            this.setUser(userObj); 
                            //localStorage.saveUserSelection = JSON.stringify(usrSelData);
                            return true;                                            
                    } else{          
                            this.utilityService.showToast("noValidresponsefromServer","Product Group is not set to the user");
                            return false;
                    }                     
                  }else { // Plant Admin or Auditor or Guest
                    // this is available in home.ts 
                    // any changes here should also be done in home.ts
                     if(data.plants !== undefined){
                                if(checkMultiplePlants){
                                        if(data.plants.length > 1){                                            
                                            return false;// need to make selection if the User has more than 1 Plant.
                                        }
                                        if(data.plants.length > 0 && data.plants[0].productGroups !== undefined && data.plants[0].productGroups.length > 1){                                            
                                            return false;// need to make selection if the plant has more than 1 product group
                                        }
                                }                                
                                if(data.levelId !== undefined && data.levelId === 0){
                                    this.utilityService.showToast("noValidresponsefromServer"," Level cannot be 0 for the user");
                                    return false;
                                }
                            if(data.plants.length > 0 &&
                                    (data.plants[0].plantId !== undefined && data.plants[0].plantId !== 0 ) &&
                                    (data.plants[0].plantName !== undefined && data.plants[0].plantName !== "")&&
                                    (data.plants[0].productGroups[0].pgId !== undefined && data.plants[0].productGroups[0].pgId  !== 0) &&
                                    (data.plants[0].productGroups[0].pgName !== undefined && data.plants[0].productGroups[0].pgName !== "")){
                                        // data.plants[0].opId = data.plants[0].opId === undefined ? 0 : data.plants[0].opId; // setting the default value for opId and opName
                                    // data.plants[0].opName = data.plants[0].opName  === undefined ? data.plants[0].pgName :  data.plants[0].opName;                                                  
                                    const usrSelData  = new UserSelectionData(+data.plants[0].plantId, data.plants[0].plantName, 
                                                                                data.plants[0].productGroups[0].pgId, data.plants[0].productGroups[0].pgName,
                                                                                0, "",
                                                                                0, "",data.levelId, levelName,data.roleId,  roleName,  
                                                                                data.languageCode, langName,"","",data.userId.toString(), 
                                                                                new Lot(0, ""),new Machine("0","","", true),new Shift("0",""), 
                                                                                new UserObject(0, ""),"","","","","","","");
                                        this.setUserSelection(usrSelData);                      
                                        localStorage.saveUserSelection = JSON.stringify(usrSelData);
                                        return true;
                            } else{          
                                this.utilityService.showToast("noValidresponsefromServer"," Plant Name or Product Group is not set");
                                 return false;
                            } 
                     } else{          
                                this.utilityService.showToast("noValidresponsefromServer"," Plant Name or Product Group is not set");
                                 return false;
                    } 
                }                 
            }

            public updateUserAndUserSelData(userDetailsData:UserDetailsResponse, userSelData:UserSelectionData,updateLang?:boolean):boolean{
                let levelName = this.utilityService.getLevelDescById(userDetailsData.levelId);
                let roleName = this.utilityService.getRoleDescById(userDetailsData.roleId);

                userSelData.selOpId = userSelData.selOpId || 0;
                userSelData.selOpName =  userSelData.selOpName || userSelData.selPGName;                
                userSelData.selLevelId = userDetailsData.levelId;                
                userSelData.selRoleId = userDetailsData.roleId;                             
                userSelData.selLevelName = levelName;
                userSelData.selRoleName =  roleName;
               if(!updateLang){
                  userSelData.selLangCode = userDetailsData.languageCode;
                }
                
                
                let userObj:User = _.extend({},userDetailsData);
                userObj.plants = new Array();
                userDetailsData.plants.forEach((item)=>{
                        item.productGroups.forEach((i)=>{
                            if(i.pgId === userSelData.selPGId){
                                    userObj.plants.push(new PlantInfo(item.plantId, item.plantName,0,"", i.pgId, i.pgName));    
                            }
                        });                                    
                });                
                userObj.pgId = userSelData.selPGId;
                userObj.pgName = userSelData.selPGName;                
                userObj.roleName = roleName;
                userObj.levelName = levelName;               
                //this.selectionData = userSelData;
                //this.roleEntered = userSelData.selRoleName; 
                if(this.checkValidUserPreferencesResponse(userDetailsData,false)){ 
                   // save the user selection done
                   let selectionObj = { 
                     "selPGId": userSelData.selPGId, 
                     "selPGName":userSelData.selPGName, 
                     "selPltId":userSelData.selPltId,  
                      "selPltName":userSelData.selPltName
                    };
                   storage.saveData(userObj.wLogin,"multiplePlantProductGroupSel", selectionObj, true);
                    this.setUser(userObj);                                  
                    this.setUserSelection(userSelData); 
                    return true;
                } else{
                  return false;
                }
            }
}
     //.map(()=>{return new User(605,"Perkari","Sandeep","CORPLEAR\SPerkari", "",1,0,0,true,"",5,"ENG",[{"plantId":4,"opId":1,"pgId":5}],"","",true,"");});
     
     
     
     /*.map(({userId, lastName, firstName,wLogin, email,roleId,levelId,layerId, active, certified, pgId, langCode, plants}) => 
    { 
      return  new User(userId, lastName, firstName,wLogin, email,roleId,levelId,layerId, active, certified, pgId, langCode, plants,levelId !== null && levelId !== undefined  ? this.utilityService.getLevelDescById(levelId):"",layerId ? this.utilityService.getLayerDescById(layerId) : "",true,roleId ? this.utilityService.getRoleDescById(roleId):"")
      //return  new User(USER_ID, LAST_NAME, FIRST_NAME,WLOGIN, EMAIL,ROLE_ID,LEVEL,LAYER, ACTIVE, CERTIFIED, PG_NUM, LANGUAGE_CODE,"","",true,"")
    })*/
     /* let opt: RequestOptions;
      let headers  = new Headers();
      headers.append('Content-Type', 'application/json');
      headers.append('Authorization', 'Basic U3Blcmthcmk6cGFzc3dvcmQ=');
      opt = new RequestOptions({headers : headers});*/
      /*return this.http.get(url).map((res:Response, index) =>{                
        let response = res.json();
        if(response.IsSuccess && response.Message.length === 0){
              return response.Response[0];
        } else{
           this.utilityService.showToast(" Get User Details  : " + response.Message);              
              return response.Response[0];             
        }    
                     
    }).map(({userId, lastName, firstName,wLogin, email,roleId,level,layer, active, certified, pgId, langCode}) => 
    { 
      return  new User(userId, lastName, firstName,wLogin, email,roleId,level,layer, active, certified, pgId, langCode, level !== null && level !== undefined  ? this.utilityService.getLevelDescById(level):"",layer ? this.utilityService.getLayerDescById(layer) : "",true,roleId ? this.utilityService.getRoleDescById(roleId):"")
      //return  new User(USER_ID, LAST_NAME, FIRST_NAME,WLOGIN, EMAIL,ROLE_ID,LEVEL,LAYER, ACTIVE, CERTIFIED, PG_NUM, LANGUAGE_CODE,"","",true,"")
    });*/
  
// let opt: RequestOptions;
//       let headers  = new Headers();
//       headers.append('Content-Type', 'application/json');
//       headers.append('Authorization', 'Basic U3Blcmthcmk6cGFzc3dvcmQ=');
//       opt = new RequestOptions({headers : headers});
//       //http://SFL-20-3064/LPAServices/api/Questions/getQuestionsByLangCat?langCode=CHN&catId=1
//       this.http.get('http://ahdeviis01/LPAServices/api/Questions/getQuestionsByLangCat?langCode=CHN&catId=1',opt).map(res => res.json()).subscribe(data => {
//           console.log("data received"+data);
//         });