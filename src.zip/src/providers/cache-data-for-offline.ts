import { Injectable } from '@angular/core';
import { AcceptedAuditItem, ResponseObject, AuditDetailsQuestion, TempAudit } from '../models/QuestionItem';
import * as storage from "./local-Storage";
import { UtilService } from './util-service';
import { UserService } from './user-service';
import { AuditStartResultsProvider } from '../pages/audit-start-results/audit-start-results-service';
import 'rxjs/add/operator/map';
import { Observable }from 'rxjs/Rx';
import { User} from '../models/User';
/*
  Generated class for the CacheDataForOfflineProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
@Injectable()
export class CacheDataForOfflineProvider {
  private user:User;
  private wLogin:string;
  constructor(private auditResultsService:AuditStartResultsProvider,
              private utilService:UtilService, public userService:UserService) {    
                this.user = this.userService.getUser();
                if(this.user !== undefined){
                    this.wLogin = this.user.wLogin;
                }
  }

  public saveUnSchAuditslistDetails(isScheduled:boolean,stDate:string, edDate:string, pltId:number,  levId:number,  prId:number, langCode:string, data:Array<AcceptedAuditItem>){
      let saveObject:object = {};  
      const wLogin = this.user.wLogin;                      
      saveObject[stDate+":"+stDate+"-"+prId.toString()+levId.toString()+pltId.toString()] = data;
      storage.saveData(wLogin, (isScheduled ? "schAuditsList":"unSchAuditsList"), data, true);
      const that = this;
      this.getObservableForkJoin(that.getObservableList(langCode, data)).subscribe((response)=>{
        storage.saveData(wLogin, (isScheduled ? "schAuditsDetails":"unSchAuditsDetails"),this.generateSaveObj(response, langCode), true);                   
      })
  }
   
  private generateSaveObj(data,langCode){
      return data.reduce((prev, item:Array<TempAudit>)=>{      
                        if(item !== undefined && item.length > 0){
                            const pgId = item[0].pgId.toString(); const levId =  item[0].level.toString();
                            const prId = item[0].procId.toString();
                            const macNum = item[0].machineNum;
                            const machineNum = (macNum !== undefined && macNum.length > 0) ? macNum : "0";
                            const shfNum = item[0].shift;
                            const shiftNum = (shfNum!== undefined && shfNum.toString().length) > 0 ? shfNum : "0";
                            let saveAuditWithName = pgId+prId+levId+langCode+machineNum+shiftNum;
                            saveAuditWithName = saveAuditWithName.replace(/[^A-Z0-9]+/ig, "_");// replace white spaces in string with _
                            prev[saveAuditWithName] = item;
                        }                        
                    return prev;
              },{})
  }

  private getObservableForkJoin(observableList){
    return Observable.forkJoin(observableList);
  }

  private getObservableList(langCode:string, data:Array<AcceptedAuditItem>){
    return data.reduce((prev,item:AcceptedAuditItem)=>{
        prev.push(this.getAuditDetailsObservable(item.procId, item.levelId, langCode,item.plantId, 
                                                    item.machineNum, item.shift, item.lotNum));
        return prev;
      }, []);
  }
  private getAuditDetailsObservable(procId:number, levelId:number, langCode:string, pltId:number, machineNum:string, shiftNum:string, lotNum:string){
        return this.auditResultsService.getAuditQuesFailCode(procId, levelId, langCode,pltId ,2, machineNum, shiftNum, lotNum);        
    }  
}
