import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers} from '@angular/http';
import { AppSettings, MethodConstants } from '../constants/AppSettings';
import {User} from '../models/user';
import {UtilService} from './util-service';
import {CallService} from './call-service';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { Observable }from 'rxjs/Rx';
import {ResponseObject} from "../models/QuestionItem";
import { Subscribe }from 'rxjs/Subscribe';
//import { of } from 'rxjs/observable/of';
//import  'rxjs/add/observable/of';
/*
  Generated class for the InitialDataService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class InitialDataService {

  constructor(public callService: CallService, private utilityService:UtilService) {
    
  }

  public getInitialData(){
      return Observable.forkJoin(
        this.getAllLevels(),
        this.getAllRoles(),
        this.getAllLayers(),
        this.getAllLanguages(),
        this.getAllProductGroups(),     
        this.getAllAvailabelPlants(),
        this.getAllFailureCodeCategories()
      );  
  }
    private getAllLevels():Observable<any>{
        //'AuditLevels/getAllLevels?';
        //[{"$id":"1","AUDIT_LEVEL":2,"AUDIT_LEVEL_DESC":"Plant Level Audit"}]
        const url = AppSettings.API_ENDPOINT + MethodConstants.getAllLevels;        
        return this.callService.callServerForGet(url,"");
    }
    
    private getAllRoles():Observable<any>{
        //'Roles/getRole?';
        const url = AppSettings.API_ENDPOINT + MethodConstants.getAllRoles;
          return this.callService.callServerForGet(url,"");
    } 
    private getAllLayers():Observable<any>{
        //'Layers/getLayer?';
        const url = AppSettings.API_ENDPOINT + MethodConstants.getAllLayers;
        return this.callService.callServerForGet(url,"");
    //    return Observable.create((observer)=>{
    //                     observer.next(new ResponseObject(true, "",[],""))                        
    //                 });
    }
    private getAllAvailabelPlants():Observable<any>{        
        const url = AppSettings.API_ENDPOINT + MethodConstants.GetAllAvailablePlants+"plantId=0";
        return this.callService.callServerForGet(url,"");
    }
    private getAllLanguages():Observable<any>{
        //'Languages/getLanguages?';
        const url = AppSettings.API_ENDPOINT + MethodConstants.getAllLanguages;
        return this.callService.callServerForGet(url,"");
    } 
    public getAllCategories(pgNumber:number):Observable<any>{        
        const url = AppSettings.API_ENDPOINT + MethodConstants.GetAllCategories +"pgNumber="+pgNumber;
        return this.callService.callServerForGet(url,"");
   } 
    public getPGByPlant(plantNumber:number):Observable<any>{        
        const url = AppSettings.API_ENDPOINT + MethodConstants.GetPGByPlant +"plantId="+plantNumber;
        return this.callService.callServerForGet(url,"");
   } 
   public getAllFailureCodeCategories():Observable<any>{        
        const url = AppSettings.API_ENDPOINT + MethodConstants.GetFailureCodeCateories+"failureCdCatId=0";
        return this.callService.callServerForGet(url,"");
   } 
    //[{"$id":"1","LANGUAGE_CODE":"CHN","LANGUAGE_NAME":"CHINESE"}]
    private getAllProductGroups():Observable<any>{
        //'ProductGroups/getAllPG?';
        const url = AppSettings.API_ENDPOINT + MethodConstants.getAllProductGroups;
        return this.callService.callServerForGet(url,"");
    }
    private getProductGroup(pgNum:number){
        //'ProductGroups/getPG?';
        const url = AppSettings.API_ENDPOINT + MethodConstants.getProductGroup+"pgNum="+pgNum;
        return this.callService.callServerForGet(url,"");
    }
    public getOperationByProductGroup(pgNum:number){
        //'Operations/getOpByPG?';
        const url = AppSettings.API_ENDPOINT + MethodConstants.getOperationByProductGroup+"pgNum="+pgNum;
          return this.callService.callServerForGet(url,"");
    } 
    public getProcessByOperation(opNum:number){
        //'Processes/getProByOp?';
        const url = AppSettings.API_ENDPOINT + MethodConstants.getProcessByOperation+"operationNum="+opNum;
        return this.callService.callServerForGet(url,"");
    }
     public getProcessByProductGroup(pgNum:number, plantId:number){        
        const url = AppSettings.API_ENDPOINT + MethodConstants.GetProcessByPgPlant+"pgNum="+pgNum+"&plantNum="+plantId;
        return this.callService.callServerForGet(url,"");
    } 
    
    public getPlantsByProcess(procNum:number){
        //'Processes/getProByOp?';
        const url = AppSettings.API_ENDPOINT + MethodConstants.getProcessByOperation+"operationNum="+procNum;
        return this.callService.callServerForGet(url,"");
    } 
}
