export const loadSavedData = (wLogin:string = "", key:string = "") =>{
    try{        
       if(wLogin !== "" && key !== ""){
            const serializedData = localStorage.getItem(wLogin);
            if(serializedData === null){
                return undefined;
            }
            let keyObjString = JSON.parse(serializedData)[key];
            try{
                if(JSON.parse(keyObjString)){
                    return JSON.parse(keyObjString);
                }
            } catch(ex){
                
                return keyObjString;
            }            
        } 
        return undefined;        
    } catch(err){
        console.error(err);
        return undefined;
    }
}

export const saveData = (wLogin:string ="", key:string ="", data:object={}, isReset:boolean=false)=>{
    try{  
        if(wLogin !== "" && key !==""){ 
                let userObject = localStorage.getItem(wLogin)||"{}";
                if(userObject !== undefined && userObject !== null){
                        savedToUserObject(JSON.parse(userObject),key,data, wLogin, isReset);
                } else{                
                        savedToUserObject({},key,data, wLogin, false);
                }
                // below is the previous code with out uisign the user wlogin for the reference int he saved data
                // const keyExists = localStorage.getItem(key);
                // if(keyExists !== undefined && isReset){
                //     localStorage.removeItem(key);
                //     const serializedData = JSON.stringify(data);
                //     localStorage.setItem(key, serializedData);
                // } else{
                //     const serializedData = JSON.stringify(data);
                //     localStorage.setItem(key, serializedData);
                // }
        } else{
            return undefined;
        }               
    } catch(err){
        console.error(err);
    }
}

const savedToUserObject = (userObject, key:string, data:object, wLogin:string, isReset:boolean)=>{
        if(userObject !== undefined){
             const serializedData = JSON.stringify(data);
             if(isReset){
                delete userObject[key];    
             }
             userObject[key] =  serializedData;
             const serializedUserObjectData = JSON.stringify(userObject);
             localStorage.setItem(wLogin, serializedUserObjectData); 
        }
}

// const getUsers = ({ usersById }) => {
//   return Object.keys(usersById).map((id) => usersById[id]);
// }
// const getSelectedUsers = ({ selectedUserIds, usersById }) => {
//   return selectedUserIds.map((id) => usersById[id]);
// }