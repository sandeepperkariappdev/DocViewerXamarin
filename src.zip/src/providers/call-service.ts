import { Injectable } from '@angular/core';
import { LoadingController} from 'ionic-angular';
import { Http, Response, RequestOptions, Headers} from '@angular/http';
import { AppSettings, MethodConstants } from '../constants/AppSettings';
import { UtilService } from './util-service';
import { HttpService } from './http-service';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { Observable }from 'rxjs/observable';
import { Network } from '@ionic-native/network';
import {ResponseObject} from "../models/QuestionItem";
/*
  Generated class for the CallService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class CallService {
    private loadingProp;
  constructor(public http: HttpService,private loadingCtrl:LoadingController,private network: Network,public httpPost:Http, private utilityService:UtilService) {

  }
  public checkNetworkConnectivity(){
      return this.utilityService.isNetworkConnected;      
  }
  public callServerForDelete(url:string, msgTxt:String = ''):Observable<any>{  
        if(this.checkNetworkConnectivity()){
                return this.http.delete(url.toString()).map((res:Response, index) =>{                
                    let response = res.json();
                         return response;
                });
        } else{
            return Observable.create((observer)=>{
                        observer.next(new ResponseObject(false, "",["1014"],"1014"))                        
                    });                
        }       
  }
 public callServerForGet(url:string, msgTxt:String = ''):Observable<any>{
     if(this.checkNetworkConnectivity()){         
            return this.http.get(url.toString()).map((res:Response, index) =>{                
                let response = res.json();   
                    return response;                           
            });
        } else{           
            this.utilityService.hideLoading();
            this.utilityService.showToast("1014","");                    
            return Observable.create((observer)=>{
                        observer.next(new ResponseObject(false, "",["1014"],"1014"))                        
                    });                
        }       
  }
  public callServerForPost(url:string, msgTxt:string = '',data:Object):Observable<any>{
    if(this.checkNetworkConnectivity()){            
        let token = this.utilityService.getServiceToken();
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
         options.headers.set('Authorization', `Basic ${token}`);
     
        return this.httpPost.post(url.toString(), data, options).map((res:Response, index) =>{                
            let response = res.json();
                return response;                                          
            });
    } else{
        return Observable.create((observer)=>{
                    observer.next(new ResponseObject(false, "",["1014"],"1014"))                        
                });                
    }
  }
   public callServerForPut(url:string, msgTxt:String = '',data:Object):Observable<any>{
    if(this.checkNetworkConnectivity()){         
            let token = this.utilityService.getServiceToken();
            let headers = new Headers({ 'Content-Type': 'application/json' });
            let options = new RequestOptions({ headers: headers });
            options.headers.set('Authorization', `Basic ${token}`);            
            return this.httpPost.put(url.toString(), data, options).map((res:Response, index) =>{                
                let response = res.json();
                    return response;                                 
            });
    } else{
        return Observable.create((observer)=>{
                    observer.next(new ResponseObject(false, "",["1014"],"1014"))                        
                });                
    }
  }
  private logResponse(res:Response){
      console.log(res);
  }
}


