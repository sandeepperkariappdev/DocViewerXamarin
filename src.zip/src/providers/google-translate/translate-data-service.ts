import { Injectable } from '@angular/core';
//import {languages} from './languages';
//import {translate, languages} from './index';
import {translate, languages} from 'google-translate-api';
import {UtilService}from '../util-service';


@Injectable()
export class TranslateDataService {  

  constructor(private utilService:UtilService) {
  }

  public  getTranslatedText(translateText:string = "", fromLanguage:string = "", toLanguage:string = ""){
//          if(this.utilService.itemDefined(translateText) && this.utilService.itemDefined(fromLanguage) && this.utilService.itemDefined(toLanguage)){
//             if(languages.isSupported(fromLanguage) && languages.isSupported(toLanguage)){
//                 return translate('something', {from: 'js', to: 'en'}).then(res=>{
//                     return res
//                 });                
//             } else{
//                 return undefined;
//             }             
//         } else{
//             return undefined;
//         }
  }
}









