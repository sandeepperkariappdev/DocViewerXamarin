import { Injectable } from '@angular/core';
import {UtilService} from './util-service';
/*
  Generated class for the Privileges provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class Privileges {

  constructor(private utilService:UtilService) {
   
  }

  // expected path to look for 
  // Name of the Key
 public getObject(userRole,pageName, key){    
    if(userRole !=='' && pageName !== ''){
        if(key === '' && this.getRolePrivilegesData(userRole)["SideMenu"][pageName]){
         return this.getRolePrivilegesData(userRole)["SideMenu"][pageName]
      } else {

      }
    } else{

    }          
  }
 public  getPageObject(userRole,pageName){
    if(userRole !=='' && pageName !== ''){
      return this.getRolePrivilegesData(userRole)[pageName]; 
    }      
  }
 public  getStartPage(userRole){
    if(userRole !=='' ){
      return this.getRolePrivilegesData(userRole)["StartPage"];
    }
  }
  public havePageAccess(userRole,pageName){
    if(userRole !=='' && pageName !== ''){
      const page =  this.getRolePrivilegesData(userRole)["SideMenu"][pageName];
      if(page){
           return page["thisShow"];   
      }     
    }
  }
  public getRolePrivilegesData(role){
      let privileges={
                "plantadmin" : {  // Any change done here should also be done in the loginpage loadNext()
                  "StartPage":"4",//[HomePage,Admin,AuditStart,LoginPage, AdminManagementPage];
                    "login":{"showPreference":"false",
                                    "search":{  "showPlant":"false",
                                                "showRole":"false",
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }
                                            },
                    "Home":{
                      "MyAudits":{"thisShow":"true", "showPlant":"true"},
                      "AdhocAudits":{"thisShow":"true"},
                      "GuestAudits":{"thisShow":"false"},
                      "CorrectiveActions":{"thisShow":"true","showPlant":"true"},
                      "AuditsHistory":{"thisShow":"true","showSelf":"true"},
                      "WasteWalk":{"thisShow":"true"},
                      "PlantAdmin":{"thisShow":"true"},                                            
                    },
                    "Admin":{
                        "AuditTab":{
                          "thisShow":"true",
                          "showAddnewAudit":"false",  
                          "AuditDetails":{"thisShow":"true",
                                          "showAddnewQues":"true",
                                          "addnewQueRequest":"true",
                                          "showAcceptAuditButton":"true",
                                          "showPlantAudits":"true",
                                          "showAddNewQueToQueMaster":"false",
                                          "addProductGroupSpecificQuestions":"true"}
                        },
                       "MachinesTab":{"thisShow":"false"},
                        "QuestionsTab":{"thisShow":"false","isEditExistingQue":"false","showAddNewQues":"false","reqAddNewQuesToAudit":"false","addQuesToexistingAudit":"false"},
                        "UsersTab":{"thisShow":"false","isCreateNewUser":"false","isAddPlantsToUser":"false","showAllPlants":"false","showAddNewUser":"false"},
                        "RequestsListTab":{"thisShow":"false",  "isEditExistingQue":"false"},
                        "showFailureCodeListTab":{"thisShow":"false","isCreateNewFailureCode":"false"},
                    },
                    "Audits":{
                      "thisShow":"true",
                      "selfAudits":{"thisShow":"true",
                                    "search":{
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }
                                    },
                      "plantAudits":{"thisShow":"true", 
                                      "search":{
                                                "showLevel":"true", 
                                                "showProcess":"true",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }
                                    }
                    },
                    "AuditsHistory":{
                      "thisShow":"true",
                      "selfAudits":{"thisShow":"true",
                                    "search":{
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }
                                    },
                      "plantAudits":{"thisShow":"true", 
                                      "search":{
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }
                                    }
                    },
                    "SideMenu":{// any changes here should also update in the app.components page in the components list
                      // even the order fo the pages shoudl not be changed
                      "Audits":{"thisShow":"true","component":"HomePage", "trnskey":"audits" },
                      "AdminManagement":{"thisShow":"true","component":"AdminManagementPage","trnskey":"admin"},                     
                      "ResourcesManagement":{"thisShow":"false","component":"ResourcesManagementPage"},
                      "AuditsOld":{"thisShow":"false","component":"AuditsListPage"},
                      "AdminOld":{"thisShow":"false","component":"Admin","trnskey":"admin"},
                      "Reports":{"thisShow":"true","component":"Reports", "trnskey":"reports"},
                      //"SchedulerOld":{"thisShow":"true","component":"Schedular"},
                      "Scheduler":{"thisShow":"true","component":"AuditSchedularPage","trnskey":"scheduler"},
                      "ReportIssue":{"thisShow":"false","component":"ReportNewIssue"},
                      "AuditsHistory":{"thisShow":"false","component":"AuditsHistory"},
                      "Preferences":{"thisShow":"true","component":"Preferences","trnskey":"preferences"},
                      "LogOut":{"thisShow":"true","component":"LoginPage","trnskey":"logout"},                      
                    },
                    "Rules" : {
                      "ShowFailureCodes" : {
                          "AssigneeCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                          "ReviewerCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                          "FailureCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"]
                      },
                      "Preferences":{
                        "PlantLimited":"true",
                        "ProductGroupLimited":"true",
                        "OperationGroupLimited":"true",
                        "ProcessLimited":"true",
                        "LevelLimited":"true",
                        }
                    }
                },
                "corporatequalityadmin" : {  
                  "StartPage":"1",//[HomePage,Admin, AuditStart,LoginPage];
                  "login":{"showPreference":"false",
                                    "search":{  "showPlant":"false",
                                                "showRole":"false",
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }},
                      "Home":{
                        "MyAudits":{"thisShow":"false", "showPlant":"true"},
                        "AdhocAudits":{"thisShow":"false"},
                        "GuestAudits":{"thisShow":"false"},
                        "CorrectiveActions":{"thisShow":"false","showPlant":"true"},
                        "AuditsHistory":{"thisShow":"false","showSelf":"true"},
                        "WasteWalk":{"thisShow":"false"},
                        "PlantAdmin":{"thisShow":"false"},
                      },
                      "Admin":{
                          "AuditTab":{
                            "thisShow":"true",
                            "showAddnewAudit":"true",  
                            "AuditDetails":{"thisShow":"true",
                                            "showAddnewQues":"true",
                                            "addnewQueRequest":"true",
                                            "showPlantAudits":"false",
                                            "showAddNewQueToQueMaster":"false",
                                          "addProductGroupSpecificQuestions":"true"}          
                          },
                          "MachinesTab":{"thisShow":"false"},
                          "QuestionsTab":{"thisShow":"true", "isEditExistingQue":"true", "showAddNewQues":"true","reqAddNewQuesToAudit":"false","addQuesToexistingAudit":"true"},
                          "UsersTab":{"thisShow":"false","isCreateNewUser":"false","isAddPlantsToUser":"false","showAllPlants":"false","showAddNewUser":"false"},
                          "RequestsListTab":{"thisShow":"false", "isEditExistingQue":"true"},
                          "showFailureCodeListTab":{"thisShow":"false", "isCreateNewFailureCode":"false"},
                      },
                      "Audits":{
                        "thisShow":"false",
                          "selfAudits":{"thisShow":"false",
                                    "search":{
                                                "showLevel":"false", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }},
                          "plantAudits":{"thisShow":"false", 
                                      "search":{
                                                "showLevel":"true", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }}
                      },
                      "AuditsHistory":{
                        "thisShow":"false",
                          "selfAudits":{"thisShow":"false",
                                    "search":{
                                                "showLevel":"false", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }},
                          "plantAudits":{"thisShow":"false", 
                                      "search":{
                                                "showLevel":"true", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }}
                      },
                      "SideMenu":{
                        "Home":{"thisShow":"false","component":"HomePage"},
                        "AdminManagement":{"thisShow":"false","component":"AdminManagementPage"},
                      "ResourcesManagement":{"thisShow":"false","component":"ResourcesManagementPage"},
                      "Audits":{"thisShow":"false","component":"AuditsListPage","trnskey":"audits"},
                      "Admin":{"thisShow":"true","component":"Admin", "trnskey":"admin"},
                        "Reports":{"thisShow":"true","component":"Reports", "trnskey":"reports"},
                        "Scheduler":{"thisShow":"false","component":"Schedular","trnskey":"scheduler"},
                        "ReportIssue":{"thisShow":"false","component":"ReportNewIssue"},
                        "AuditsHistory":{"thisShow":"false","component":"AuditsHistory"},
                        "Preferences":{"thisShow":"true","component":"Preferences","trnskey":"preferences"},
                        "LogOut":{"thisShow":"true","component":"LoginPage","trnskey":"logout"},       
                      },
                      "Rules":{
                        "ShowFailureCodes":{
                            "AssigneeCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                            "ReviewerCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                            "FailureCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"]
                        }
                      },
                      "Preferences":{
                        "PlantLimited":"false",
                        "ProductGroupLimited":"true",
                        "OperationGroupLimited":"true",
                        "ProcessLimited":"true",
                        "LevelLimited":"true",
                        }
                },
                "auditor" : {  
                  "StartPage":"0",//[HomePage,Admin,AuditStart,LoginPage];
                  "login":{"showPreference":"false",
                                    "search":{  "showPlant":"false",
                                                "showRole":"false",
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }},
                      "Home":{
                        "MyAudits":{"thisShow":"true", "showPlant":"false"},
                        "AdhocAudits":{"thisShow":"true"},
                        "GuestAudits":{"thisShow":"false"},
                        "CorrectiveActions":{"thisShow":"true","showPlant":"true"},
                        "AuditsHistory":{"thisShow":"true","showSelf":"true"},
                        "WasteWalk":{"thisShow":"true"},
                        "PlantAdmin":{"thisShow":"false"},
                      },
                      "Admin":{
                          "AuditTab":{
                            "thisShow":"false",
                            "showAddnewAudit":"false",  
                          "AuditDetails":{"thisShow":"true",
                                            "showAddnewQues":"false",
                                            "addnewQueRequest":"false",
                                            "showPlantAudits":"false",
                                            "showAcceptAuditButton":"false",
                                            "showAddNewQueToQueMaster":"false",
                                          "addProductGroupSpecificQuestions":"true"}           
                          },
                         "MachinesTab":{"thisShow":"false"},
                          "QuestionsTab":{"thisShow":"false","isEditExistingQue":"false","showAddNewQues":"false","reqAddNewQuesToAudit":"false","addQuesToexistingAudit":"false" },
                          "UsersTab":{"thisShow":"false","isCreateNewUser":"false","isAddPlantsToUser":"false","showAllPlants":"false","showAddNewUser":"false"},
                          "RequestsListTab":{"thisShow":"false", "isEditExistingQue":"false"},
                          "showFailureCodeListTab":{"thisShow":"false","isCreateNewFailureCode":"false"},
                      },
                      "Audits":{
                          "thisShow":"false",
                          "selfAudits":{"thisShow":"true", "search":{
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }},
                          "plantAudits":{"thisShow":"false", 
                                      "search":{
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }
                                      }
                      },
                      "AuditsHistory":{
                          "thisShow":"false",
                          "selfAudits":{"thisShow":"true"},
                          "plantAudits":{"thisShow":"false", 
                                      "search":{
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }
                                      }
                      },
                      "SideMenu":{
                     "Audits":{"thisShow":"true","component":"HomePage","trnskey":"audits"},
                        "AdminManagement":{"thisShow":"false","component":"AdminManagementPage","trnskey":"admin"},                     
                        "ResourcesManagement":{"thisShow":"false","component":"ResourcesManagementPage"},
                        "AuditsOld":{"thisShow":"false","component":"AuditsListPage"},
                        "AdminOld":{"thisShow":"false","component":"Admin"},
                        "Reports":{"thisShow":"true","component":"Reports", "trnskey":"reports"},
                        "Scheduler":{"thisShow":"false","component":"AuditSchedularPage","trnskey":"scheduler"},                        
                        "ReportIssue":{"thisShow":"false","component":"ReportNewIssue"},
                        "AuditsHistory":{"thisShow":"false","component":"AuditsHistory"},
                        "Preferences":{"thisShow":"true","component":"Preferences","trnskey":"preferences"},
                        "LogOut":{"thisShow":"true","component":"LoginPage","trnskey":"logout"},                    
                      },
                      "Rules":{
                        "ShowFailureCodes":{
                            "AssigneeCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                            "ReviewerCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                            "FailureCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"]
                        }
                      },
                      "Preferences":{
                        "PlantLimited":"true",
                        "ProductGroupLimited":"true",
                        "OperationGroupLimited":"true",
                        "ProcessLimited":"true",
                        "LevelLimited":"true",
                        }
                },
                "superadmin" : {  
                  "StartPage":"1",//[HomePage,Admin,AuditStart,LoginPage];
                  "login":{"showPreference":"false",
                                    "search":{  "showPlant":"false",
                                                "showRole":"true",
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }},
                      "Home":{
                        "MyAudits":{"thisShow":"false", "showPlant":"false"},
                        "AdhocAudits":{"thisShow":"false"},
                        "GuestAudits":{"thisShow":"false"},
                        "CorrectiveActions":{"thisShow":"false","showPlant":"true"},
                        "AuditsHistory":{"thisShow":"false","showSelf":"true"},
                        "WasteWalk":{"thisShow":"false"},
                        "PlantAdmin":{"thisShow":"false"},
                      },
                      "Admin":{
                          "AuditTab":{
                            "thisShow":"false",
                            "showAddnewAudit":"false",     
                            "AuditDetails":{"thisShow":"true",
                                            "showAddnewQues":"false",
                                            "addnewQueRequest":"false",
                                            "showPlantAudits":"false",
                                            "showAcceptAuditButton":"false",
                                            "showAddNewQueToQueMaster":"false",
                                          "addProductGroupSpecificQuestions":"true"}      
                          },
                         "MachinesTab":{"thisShow":"false"},
                          "QuestionsTab":{"thisShow":"false","isEditExistingQue":"false","showAddNewQues":"false","reqAddNewQuesToAudit":"false","addQuesToexistingAudit":"true" },
                          "UsersTab":{"thisShow":"true","isCreateNewUser":"true","isAddPlantsToUser":"true","showAllPlants":"true","showAddNewUser":"true"},
                          "RequestsListTab":{"thisShow":"false", "isEditExistingQue":"false"},
                        "showFailureCodeListTab":{"thisShow":"false","isCreateNewFailureCode":"false"},
                      },
                      "Audits":{
                        "thisShow":"false",
                          "selfAudits":{"thisShow":"true",
                                    "search":{
                                                "showLevel":"false", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }},
                          "plantAudits":{"thisShow":"true", 
                                      "search":{
                                                "showLevel":"true", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }
                                            }
                      },
                      "AuditsHistory":{
                        "thisShow":"false",
                          "selfAudits":{"thisShow":"true",
                                    "search":{
                                                "showLevel":"false", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }},
                          "plantAudits":{"thisShow":"true", 
                                      "search":{
                                                "showLevel":"true", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }
                                            }
                      },
                      "SideMenu":{
                        "Home":{"thisShow":"false","component":"HomePage"},
                        "AdminManagement":{"thisShow":"false","component":"AdminManagementPage","trnskey":"admin"},
                        "ResourcesManagement":{"thisShow":"false","component":"ResourcesManagementPage"},
                        "Audits":{"thisShow":"false","component":"AuditsListPage","trnskey":"audits"},
                        "Admin":{"thisShow":"true","component":"Admin","trnskey":"admin"},
                        "Reports":{"thisShow":"true","component":"Reports", "trnskey":"reports"},
                        "Scheduler":{"thisShow":"false","component":"Schedular","trnskey":"scheduler"},                        
                        "ReportIssue":{"thisShow":"false","component":"ReportNewIssue"},
                        "AuditsHistory":{"thisShow":"false","component":"AuditsHistory"},
                        "Preferences":{"thisShow":"false","component":"Preferences","trnskey":"preferences"},
                        "LogOut":{"thisShow":"true","component":"LoginPage","trnskey":"logout"},       
                      },
                    "Rules":{
                      "ShowFailureCodes":{
                          "AssigneeCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                            "ReviewerCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                            "FailureCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"]
                      }
                    },
                      "Preferences":{
                        "PlantLimited":"false",
                        "ProductGroupLimited":"false",
                        "OperationGroupLimited":"false",
                        "ProcessLimited":"false",
                        "LevelLimited":"false",
                        }
                },
                "readonly" : {  
                  "StartPage":"5",//"StartPage":"5",//[HomePage,Admin,AuditsListPage,LoginPage, AdminManagementPage, Reports];                  
                      "login":{"showPreference":"false",
                                    "search":{  "showPlant":"false",
                                                "showRole":"false",
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }},
                      "Home":{
                        "MyAudits":{"thisShow":"false", "showPlant":"false"},
                        "AdhocAudits":{"thisShow":"false"},
                        "GuestAudits":{"thisShow":"false"},
                        "CorrectiveActions":{"thisShow":"false","showPlant":"true"},
                        "AuditsHistory":{"thisShow":"false","showSelf":"true"},
                        "WasteWalk":{"thisShow":"false"},
                        "PlantAdmin":{"thisShow":"false"},
                      },
                      "Admin":{
                          "AuditTab":{
                            "thisShow":"false",
                            "showAddnewAudit":"false",  
                            "AuditDetails":{"thisShow":"true","showAddnewQues":"false","addnewQueRequest":"false",
                                            "showAcceptAuditButton":"false",
                                            "showPlantAudits":"false",
                                            "showAddNewQueToQueMaster":"false",
                                          "addProductGroupSpecificQuestions":"true"}          
                          },
                          "MachinesTab":{"thisShow":"false"},
                          "QuestionsTab":{"thisShow":"false","isEditExistingQue":"false","showAddNewQues":"false","reqAddNewQuesToAudit":"false","addQuesToexistingAudit":"false" },
                          "UsersTab":{"thisShow":"false","isCreateNewUser":"false","isAddPlantsToUser":"false","showAllPlants":"false","showAddNewUser":"false"},
                          "RequestsListTab":{"thisShow":"false", "isEditExistingQue":"false"},
                        "showFailureCodeListTab":{"thisShow":"false","isCreateNewFailureCode":"false"},
                      },
                      "Audits":{
                        "thisShow":"false",
                          "selfAudits":{"thisShow":"false",
                                    "search":{
                                                "showLevel":"false", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }},
                          "plantAudits":{"thisShow":"false", 
                                      "search":{
                                                "showLevel":"true", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }}
                      },
                      "AuditsHistory":{
                        "thisShow":"false",
                          "selfAudits":{"thisShow":"false",
                                    "search":{
                                                "showLevel":"false", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }},
                          "plantAudits":{"thisShow":"false", 
                                      "search":{
                                                "showLevel":"true", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }}
                      },
                      "SideMenu":{
                        "Home":{"thisShow":"false","component":"HomePage"},
                       "AdminManagement":{"thisShow":"false","component":"AdminManagementPage","trnskey":"admin"},
                        "ResourcesManagement":{"thisShow":"false","component":"ResourcesManagementPage"},
                        "Audits":{"thisShow":"false","component":"AuditsListPage","trnskey":"audits"},
                       "Admin":{"thisShow":"false","component":"Admin","trnskey":"admin"},
                        "Reports":{"thisShow":"true","component":"Reports", "trnskey":"reports" },
                        "Scheduler":{"thisShow":"false","component":"Schedular","trnskey":"scheduler" },                        
                        "ReportIssue":{"thisShow":"false","component":"ReportNewIssue"},
                        "AuditsHistory":{"thisShow":"false","component":"AuditsHistory"},
                        "Preferences":{"thisShow":"true","component":"Preferences","trnskey":"preferences" },
                        "LogOut":{"thisShow":"true","component":"LoginPage","trnskey":"logout"},       
                      },
                      "Rules":{
                        "ShowFailureCodes":{
                            "AssigneeCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                            "ReviewerCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                            "FailureCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"]
                        }
                      },
                      "Preferences":{
                        "PlantLimited":"true",
                        "ProductGroupLimited":"true",
                        "OperationGroupLimited":"true",
                        "ProcessLimited":"true",
                        "LevelLimited":"true",
                        }
                },
                "guestauditor" : {  
                  "StartPage":"0",//[HomePage,Admin,AuditStart,LoginPage];
                  "login":{"showPreference":"false",
                                    "search":{  "showPlant":"false",
                                                "showRole":"false",
                                                "showLevel":"false", 
                                                "showProcess":"false",
                                                "showOperation":"false",
                                                "showProductGroup":"false"
                                              }},
                      "Home":{
                        "MyAudits":{"thisShow":"false", "showPlant":"false"},
                        "AdhocAudits":{"thisShow":"false"},
                        "GuestAudits":{"thisShow":"true"},
                        "CorrectiveActions":{"thisShow":"false","showPlant":"true"},
                        "AuditsHistory":{"thisShow":"false","showSelf":"true"},
                        "WasteWalk":{"thisShow":"false"},
                        "PlantAdmin":{"thisShow":"false"},
                      },
                      "Admin":{
                          "AuditTab":{
                            "thisShow":"false",
                            "showAddnewAudit":"false",  
                            "AuditDetails":{"thisShow":"true","showAddnewQues":"false","addnewQueRequest":"false",
                                            "showAcceptAuditButton":"false",
                                            "showPlantAudits":"false",
                                            "showAddNewQueToQueMaster":"false",
                                          "addProductGroupSpecificQuestions":"true"}          
                          },
                          "MachinesTab":{"thisShow":"false"},
                          "QuestionsTab":{"thisShow":"false","isEditExistingQue":"false","showAddNewQues":"false","reqAddNewQuesToAudit":"false","addQuesToexistingAudit":"false"},
                          "UsersTab":{"thisShow":"false","isCreateNewUser":"false","isAddPlantsToUser":"false","showAllPlants":"false","showAddNewUser":"false"},
                          "RequestsListTab":{"thisShow":"false", "isEditExistingQue":"false"},
                        "showFailureCodeListTab":{"thisShow":"false","isCreateNewFailureCode":"false"},
                      },
                      "Audits":{
                        "thisShow":"false",
                          "selfAudits":{"thisShow":"false",
                                    "search":{
                                                "showLevel":"false", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }},
                          "plantAudits":{"thisShow":"false", 
                                      "search":{
                                                "showLevel":"false", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }
                                            }
                      },
                      "AuditsHistory":{
                        "thisShow":"false",
                          "selfAudits":{"thisShow":"false",
                                    "search":{
                                                "showLevel":"false", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }},
                          "plantAudits":{"thisShow":"false", 
                                      "search":{
                                                "showLevel":"false", 
                                                "showProcess":"true",
                                                "showOperation":"true",
                                                "showProductGroup":"false"
                                              }
                                            }
                      },
                      "SideMenu":{
                        "Home":{"thisShow":"true","component":"HomePage"},
                        "AdminManagement":{"thisShow":"false","component":"AdminManagementPage","trnskey":"admin"},
                        "ResourcesManagement":{"thisShow":"false","component":"ResourcesManagementPage"},
                        "Audits":{"thisShow":"false","component":"AuditsListPage","trnskey":"audits"},
                        "Admin":{"thisShow":"false","component":"Admin","trnskey":"admin"},
                        "Reports":{"thisShow":"false","component":"Reports", "trnskey":"reports"},
                        "Scheduler":{"thisShow":"false","component":"Schedular","trnskey":"scheduler"},                        
                        "ReportIssue":{"thisShow":"false","component":"ReportNewIssue"},
                        "AuditsHistory":{"thisShow":"false","component":"AuditsHistory"},
                        "Preferences":{"thisShow":"true","component":"Preferences","trnskey":"preferences"},
                        "LogOut":{"thisShow":"true","component":"LoginPage","trnskey":"logout"},       
                      },
                      "Rules":{
                        "ShowFailureCodes":{
                            "AssigneeCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                            "ReviewerCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"],
                            "FailureCompletionDays": ["1","2","3","4","5","10","12","15","18","21","30"]
                        }
                      },
                      "Preferences":{
                        "PlantLimited":"false",
                        "ProductGroupLimited":"false",
                        "OperationGroupLimited":"false",
                        "ProcessLimited":"false",
                        "LevelLimited":"false",
                        }
                }
       };
      return privileges[this.utilService.removeSpaceInString(role).toLowerCase()];
  }
}