import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Network } from '@ionic-native/network';
import { Platform, ToastController, LoadingController, AlertController } from 'ionic-angular';
import { Messages } from '../constants/AppSettings';
import { TranslateService }  from 'ng2-translate';
import { Level, Layer,Category, Role, Language, ProductGroup, Lot, Machine, Shift } from '../models/Level';
import { UserDetailsResponse} from '../models/UserDetailsResponse';
import {  UserPlants, ResponseObject, PlantInfo, FailCodeCategoryAssigningList, UserSelectionData,UserObject, FailCodeCategoryList, MachinesList,  } from "../models/QuestionItem";
import { Observable }from 'rxjs/observable';
import {defaultLanguage, availableLaguages, sysOptions}  from '../constants/i18n.constants'; 
import * as _ from 'lodash';
import 'rxjs/add/operator/map';
import * as moment from  'moment';
import { User} from '../models/User';
//import { AuditStartResultsProvider } from '   ../pages/audit-start-results/audit-start-results-service';

/*
  Generated class for the UtilService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class UtilService {
    private machinesList:Array<MachinesList>;
    private shiftList:Array<Shift>;
    private errorMessage:Object;
    private loadingProp:any;
    private categoryList:Array<Category>;
    public failCodeCategoryAssigningList:Array<FailCodeCategoryAssigningList>; 
    private failCodeCategoryList:Array<FailCodeCategoryList>;
    private levelsList:Array<Level>;
    private layersList:Array<Layer>;
    private rolesList:Array<Role>;
    private plantsList:Array<UserPlants>;
    private userDetailsResponseObj:UserDetailsResponse;    
    private rolesObject;
    private languageList:Array<Language>;
    private languageObj:{}
    usernameEntered:string;
    private serviceToken:string;
    private plantPGList:Array<ProductGroup>;
    private productGroupList:Array<ProductGroup>;
      private appVersion:string;
      public isNetworkConnected:boolean;
      public isMobileApp:boolean;
    private translate:TranslateService;
  constructor(public http: Http,
                private platform:Platform,
                private network:Network,
                private translateService: TranslateService,
                private toastCtrl:ToastController, 
                private loadingCtrl:LoadingController,
                private alertCtrl:AlertController) {
                this.languageObj = {};
                this.errorMessage = {};
                this.plantsList = [];
                this.isNetworkConnected = true;
                this.translate = translateService;
                this.appVersion =  "1.7.3.0";  
                this.isMobileApp = false;
                this.usernameEntered = "";
                this.serviceToken = "";
  }
  public getAppVersion():string{
        return this.appVersion;
  }

  setFailCodeCategoryAssigningList(data:Array<FailCodeCategoryAssigningList>){
        this.failCodeCategoryAssigningList = data;
  }
  getFailCodeCategoryAssigningList():Array<FailCodeCategoryAssigningList>{
        return this.failCodeCategoryAssigningList;
  }
   setLevelDescById(levelsLst:Array<Level>){
        this.levelsList = levelsLst; 
    }
    setServiceToken(value:string){
        if(value !== ""){
            this.serviceToken = btoa(value+":password");
            if(localStorage.getItem('auth_token') === undefined){
                localStorage.setItem('auth_token', this.serviceToken);
            } else{
                localStorage.removeItem('auth_token');
                localStorage.setItem('auth_token', this.serviceToken);
            }           
        }        
    }

    setPlantsMachinesList(machinesList:Array<MachinesList>){
        this.machinesList = machinesList;
    }
    setPlantsShiftsList(shiftList:Array<Shift>){
        this.shiftList = shiftList;
    }
    getPlantsMachinesList():Array<MachinesList>{
        return this.machinesList;
    }

    getPlantsShiftsList():Array<Shift>{
        return this.shiftList;
    }

    getServiceToken(){
        return this.serviceToken;
    }
   setDeviceLanguage(langCode:string){
        // this language will be used as a fallback when a translation isn't found in the current language       
        this.translateService.setDefaultLang(defaultLanguage);
        let browserLanguage = this.translateService.getBrowserLang() || defaultLanguage;
        if(langCode !== ""){
            var language = this.getSuitableLanguage(browserLanguage, false);
            // the lang to use, if the lang isn't available, it will use the current loader to get them
            this.translateService.use(language);
            sysOptions.systemLanguage = language;
        } else{
            const language = this.getSuitableLanguage(langCode, true);
            // the lang to use, if the lang isn't available,  it will use the current loader to get them
            this.translateService.use(language);
            sysOptions.systemLanguage = language;
        }        
   }
   getSuitableLanguage(language, custom) {
       if(!custom){
            language = language.substring(0, 2).toLowerCase();
		    return availableLaguages.some(x => x.code == language) ? language : defaultLanguage;
       } else{
            //language = language.substring(0, 2).toLowerCase();
		    return availableLaguages.some(x => x.langCode == language) ? language : defaultLanguage;
       }		
	}

    getSearchDateToShow(date:string){
        if(date !== ""){
            return moment(date).format("MMM Do YYYY");
        } else{
            return "";
        }        
    }
    getAllLevels(){
        return this.levelsList;
    }
    getLevelDescById(id){        
            const level = _.find(this.levelsList,(o => o.id === id));
            return (level !== undefined ?  level["desc"] : "");                
    }
    setLayerDescById(layersLst:Array<Layer>){
        this.layersList = layersLst;
    }
    getLayerDescById(id){
        const layer =  _.find(this.layersList,(o => o.id === id));
       return (layer !== undefined ?  layer["desc"] : "");
    }
    setRoleDescById(rolesLst:Array<Role>){
        this.rolesList = rolesLst;
    }
    getAllRoles(){
        return this.rolesList;
    }
    getAllLayers(){
        return this.layersList;
    }
    getRoleDescById(id){
        if(this.rolesList){
            const role = _.find(this.rolesList,(o => o.Id === id));
            return  (role !== undefined ? role["desc"] : "");
        }       
    }
    setLanguageDescByCode(languageLst:Array<Language>){
        this.languageList = languageLst;
        if(this.languageList.length > 0){
            this.languageList.forEach((v,i)=>{                
                this.languageObj[v.langCode] = v.langDesc;
            });            
        }        
    }
   
    getAllAvailablePlants():Array<UserPlants>{
        return this.plantsList;
    }

    getLanguageDesc(id:string){
        const lang = this.languageObj[id];;
         return (lang !== undefined ? lang : "");
    }
    getAllLanguages():Array<Language>{
        //Response Format : [{"langCode":"ENG","langDesc":"ENGLISH"},{"langCode":"SPA","langDesc":"SPANISH"},{"langCode":"POR","langDesc":"PORTUGUESE"},{"langCode":"HUN","langDesc":"HUNGARIAN"},{"langCode":"CHN","langDesc":"CHINESE"},{"langCode":"THA","langDesc":"THAI"}]
       return this.languageList;
    }

    getCatByPG(pgId:number):Array<number>{        
        let catObj:Array<Category> = this.categoryList.filter((item)=>{
            return item.pgId === pgId;
        });
        if(catObj.length > 0) {
            return catObj.map(cat => cat.catId);
        } else { return [] };
    }
    getAllCategoriesByProductGroups(pgId:number):Array<Category>{
        return this.categoryList.filter(item => item.pgId === pgId);  
    }
    getAllcategories(){
        return this.categoryList;       
    }
    setAllcategories(data:Array<Category>){
        this.categoryList = data;       
    }
    setPgByPlant(data:Array<ProductGroup>){
        this.plantPGList = data;       
    }
    getPgByPlant(){
        return this.plantPGList;       
    }
    getUserDetailsResponse():UserDetailsResponse{
        return this.userDetailsResponseObj;       
    }
    setUserDetailsResponse(data:UserDetailsResponse){
        this.userDetailsResponseObj = data;       
    }
    getAllFailureCodeCategories(){
        return this.failCodeCategoryList;       
    }
    setAllFailureCodeCategories(data:Array<FailCodeCategoryList>){
        this.failCodeCategoryList = data;       
    }
    setAllAvailablePlants(plantsLst:Array<UserPlants>){
        this.plantsList = plantsLst;
    }
    getLanguageDescByCode(id){
        const language = _.find(this.languageList,(o => o.langCode === id))
       return (language !== undefined ? language["langDesc"] : "");
    }
    setProductGroupById(productGroupLst:Array<ProductGroup>){
        this.productGroupList  = productGroupLst;
    }
    getAllProductGroup(){
        return this.productGroupList;
    }
    getProductGroupById(id){
        const product = _.find(this.productGroupList,(o => o.pgId === id));
       return (product !== undefined ? product["pgDesc"] : "");
    }
  showLoading(){    
    this.loadingProp = this.loadingCtrl.create({
        content:'Please wait..Loading'
    });
    this.loadingProp.present();
  }
  hideLoading(){
      if(this.loadingProp !== undefined){
            this.loadingProp.dismissAll();
      }    
  }
  changeDateFormat(date:string){
      if(date!== ""){
        const dt = date.split("-");
        if(dt.length > 1){
            return dt[1]+"/"+dt[2]+"/"+dt[0]; // return in month/date/year 
        } else{
            return date;
        }        
      } else{
        return "";
      }        
  }

  changeDateFormatFromTicks(timeTicks:number){
    if(this.itemDefined(timeTicks)){
        const dt = new Date(timeTicks);
        return moment(dt).format("MM/DD/YYYY");//(dt.getMonth() +1)+"/"+dt.getDate()+"/"+dt.getFullYear(); // return in month/date/year 
      } else{
        return "";
      }        
  }
  public getWeekEndDateForWeekStart(weekStDate:Date){
      if(weekStDate === undefined){
          weekStDate = new Date();
      }
        return moment(weekStDate).endOf('week').format("MM/DD/YYYY");
  }
  getPastMonthStartDate(pastMonth:number){
      const dt = new Date();
      return moment((dt.getFullYear())+"-"+(dt.getMonth() - (pastMonth-1))+"-"+dt.getDate()).format("YYYY-MM-DD"); // return in YYYY-MM-DD 
  }
  getPastMonthEndDate(date:string){
      if(date !== ""){
        const dt = new Date(date);
        return moment((dt.getFullYear())+"-"+(dt.getMonth()+1)+"-"+(dt.getDate())).format("YYYY-MM-DD"); // return in YYYY-MM-DD 
      } else{
          return moment().format("YYYY-MM-DD");
      }
  }
  getCurrentDateTime(){
     let dateObj = new Date(), getMonth = (dateObj.getMonth() + 1), getYear = dateObj.getFullYear(), month, year;        
  }
  // returns date of previous month of 30 days difference
  defaultPlantAuditStartDate(){
     let dateObj = new Date(), getMonth = dateObj.getMonth(), getYear = dateObj.getFullYear(), month, year;  
     if(getMonth === 0){
        month = 12;
        year = (getYear -1);
     } else{
       year = getYear;
       month = getMonth;
     }
     month  = month.toString().length === 1 ? "0"+month : month;
      return moment(year+"-"+month+"-"+dateObj.getDate()).format('YYYY-MM-DD');
   }
   getWeekStartDate(){
    return moment().startOf('week').format('YYYY-MM-DD');
   }
   getWeekEndDate(){
    return moment().endOf('week').format('YYYY-MM-DD'); 
   }
   getNextWeekEndDate(){
    return moment().add('week',1).endOf('week').format('YYYY-MM-DD'); 
   }
   // returns date of next month of 30 days difference
   defaultPlantAuditEndDate(){
     let dateObj = new Date(), getMonth = dateObj.getMonth(), getYear = dateObj.getFullYear(), month, year;  
        if(getMonth === 11){
          year = (getYear + 1);
          month = 1;
        } else if(getMonth === 0){
          year = (getYear - 1);   
          month = 2;
        } else{
            year = getYear;
            month = (getMonth + 2);
        }
        month  = month.toString().length === 1 ? "0"+month : month;
        return moment(year+"-"+month+"-"+ dateObj.getDate()).format('YYYY-MM-DD');
   }



  revertToSystemDateFormat(date:string){
     if(date!== ""){
        const dt = date.split("/");
        if(dt.length > 1){
            return moment(dt[2]+"-"+dt[0]+"-"+dt[1]).format('YYYY-MM-DD');// return in year-month-date
        } else{
            return date;    
        }        
      } else{
        return moment().format('YYYY-MM-DD');
      }        
  }
 public displayNetworkUpdate(connectionState: string){
        let networkType = this.network.type
        const message = `You are now ${connectionState} via ${networkType}`;
        this.showToast("",message);        
 }
  public showNetworkOnOffNotification(){
        this.network.onConnect().subscribe(data => {            
            this.displayNetworkUpdate(data.type);               
        }, error => console.error(error));        
            this.network.onDisconnect().subscribe(data => {
            console.log(data)
            this.displayNetworkUpdate(data.type);
        }, error => console.error(error));
  }
  public isNetworkOnline(){      
       if(this.platform.is("cordova")){
            // is mobile app
            return this.network.onConnect();
        //    return Observable.create((observer)=>{
        //        observer.next({"type":navigator.onLine ? "online" : "offline"})
        //        observer.next({"type":"online"});
        //     });
       } else{
            return Observable.create((observer)=>{
                    observer.next({"type":navigator.onLine ? "online" : "offline"})
            });
       }
  }
  removeSpaceInString(data:string){
      if(data.length>0){
            return data.replace(/\s/g,'');
      } else {
          return data;
      }
  }
  private executeToastMessage(key:string){  
        let toast = this.toastCtrl.create({
                    message: key,
                    duration:3000,
                    position:'middle',
                    //showCloseButton: true,
                   // closeButtonText:'OK'
                });
                // toast.onDidDismiss(() => {
                //     console.log('Dismissed toast');
                // });
        toast.present(toast);                                                 
    }
  showToast(KeyForMessageToShow:string = '', customMsg:string = ""){       
       if(KeyForMessageToShow !== "" && KeyForMessageToShow !== undefined && KeyForMessageToShow !== null){
            this.translate.get([KeyForMessageToShow, 'Error']).subscribe((value)=>{
                const val = value[KeyForMessageToShow] ? value[KeyForMessageToShow] : value['Error'];                
                this.executeToastMessage(val + customMsg);         
            });
        } else if(customMsg){            
                this.executeToastMessage(customMsg);            
        } else{
            this.translate.get(['Error']).subscribe((value)=>{               
                this.executeToastMessage(value['Error']);
            }); 
        };                    
  }  

  itemDefined(item:any){
    if(item !== undefined && item !== null && item !== ""){
            return true;
    } else{
        return false;
    }
  }

     public checkValidData(data:ResponseObject){
         if(data !== null && data !== undefined){ 
            if(data.Response !== undefined && data.IsSuccess !== undefined &&  data.Message !== undefined){
                if(data.IsSuccess &&  data.Response !== undefined && data.Message.length === 0){
                        if(data.ResponseCode !== undefined && data.ResponseCode !== null && data.ResponseCode.length === 4){
                            this.showToastMessage(data.ResponseCode, "");
                        }
                        return true;
                    } else if(data.IsSuccess && data.Message.length !== 0 && data.Response !== undefined){
                                this.showToastMessage("",data.Message);
                                return true;                        
                    }else{
                        if(!data.IsSuccess && data.Message.length ==0  && (data.Response === null  || data.Response === undefined) && (data.ResponseCode === null  || data.ResponseCode === undefined)){
                                this.showToast("incorrectResponseFromService","")
                        }
                        else if(!data.IsSuccess && data.Message.length > 0 && (data.ResponseCode === null  || data.ResponseCode === undefined)){
                            this.showToast("",data.Message);
                        }
                        else if(!data.IsSuccess  && data.ResponseCode !== null  && data.ResponseCode !== undefined && data.ResponseCode !==""){
                            if(data.ResponseCode.length === 4){
                                this.showToastMessage( data.ResponseCode,data.Message);                      
                            }          
                        }
                        return false;
                    }
                }  else{ 
                    return true;
                }
         } else{
             return false;
         }
      
  }
  public showToastMessage(message:string, key:string){
    if(message !== "" && key !== ""){
      this.translate.get([key]).subscribe((data)=>{
          this.showToast(data[key],message);
      });
    }                        
  }

  public getkeyItemFromData(data, key:string=""){
      if(key ===""){
          return [];
      }  
        let saveAuditWithName = key;
        saveAuditWithName = saveAuditWithName.replace(/[^A-Z0-9]+/ig, "_");// replace white spaces in string with _
            
      if(data !== undefined && typeof data === "object"){
        return _.without(Object.keys(data).map((id)=>{
            if(id.toString() === saveAuditWithName.toString()){
                return data[id];
            }
        }),undefined, null);
      } else{
          console.error("passed in data is not an object");
          return [];
      }      
  }
  public getMappedData(data){
      //key = [pgId+prId+levId+langCode+machineNum+shiftNum]
      if(data !== undefined){
        return _.without(Object.keys(data).map((id)=>{            
                return data[id];            
        }),undefined, null);
      }      
  }

  public checkValidPlantsForPGSel(selPlantsArray, selPgId:number):boolean{
      if(selPgId !== undefined && selPgId !== NaN){
            return (selPlantsArray.filter((item)=>{
                if(item.productGroups !== undefined){
                        return _.map(item.productGroups, "pgId").indexOf(selPgId) === -1;
                } else{
                    return item.pgId !== selPgId.toString();
                }                    
            }).length > 0);
      }       
  }

  public replaceSpecialCharsWithSpace(data:string){
        return data.replace(/[^a-zA-Z0-9 ]/g, "").trim();
  }
}
