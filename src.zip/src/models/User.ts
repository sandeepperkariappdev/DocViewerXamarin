import { PlantInfo } from './QuestionItem';

export class User {
    isLoggedIn:boolean;
    roleName:string;
    roleId:number;
    userId:number;
    layerName:string;
    layerId:number;
    levelName:string;
    levelId:number;
    lastName:string;
    firstName:string;
    languageCode:string;
    wLogin:string;
    email:string;
    active:boolean; 
    certified:string;
    plantName:Array<string>;
    plantId:Array<number>;
    pgName:string;
    pgId:number;
    processId:Array<number>;
    processName:Array<string>;
    appLanguageCode:string;
    appLanguageDesc:String;
    plants:Array<PlantInfo>;
    //USER_ID, LAST_NAME, FIRST_NAME,WLOGIN, EMAIL,ROLE_ID,LEVEL,LAYER, ACTIVE, CERTIFIED, PG_NUM, LANGUAGE_CODE
    constructor( userId:number,lastName:string, firstName:string, wLogin:string,email:string, roleId:number, levelId:number,  layerId:number,active:boolean,
    certified:string,  languageCode:string, pgId:number, pgName:string, plants:Array<PlantInfo>,levelName:string,  layerName:string,  isLoggedIn:boolean, roleName:string){
        this.isLoggedIn = isLoggedIn;        
        this.roleId = roleId;
        this.userId = userId;
        this.layerName = layerName;
        this.layerId =  layerId;
        this.levelName =  levelName;
        this.levelId = levelId;
        this.lastName = lastName;
        this.firstName  = firstName;
        this.languageCode = languageCode;
        this.wLogin = wLogin;
        this.email = email;
        this.active =  active; 
        this.certified = certified;      
        this.roleName = roleName;
        this.plants = plants;
        this.pgId = pgId;
        this.pgName = pgName;        
    }

    setAppLanguageCode(name:string){
        this.appLanguageCode = name;
    }
    getAppLanguageCode(){
        return this.appLanguageCode;
    }
    setAppLanguageDesc(name:string){
        this.appLanguageDesc = name;
    }
    getAppLanguageDesc(){
        return this.appLanguageDesc;
    }

    setUserProcessNameArray(name:Array<string>){
        this.processName = name;
    }
    getUserProcessNameArray(){
        return this.processName;
    }
    setUserPlantNameArray(name:Array<string>){
        this.plantName = name;
    }
    getUserPlantNameArray(){
         return this.plantName;
    }

    setUserProcessIdArray(id:Array<number>){
         this.processId = id;
    }
    getUserProcessIdArray(){
            return this.processId;
    }
    setUserPlantIdArray(id:Array<number>){
        this.plantId = id;
    }
    getUserPlantIdArray(){
         return this.plantId;
    }


}




//let CorporateQualityAdmin = { "ReportsPage":{ reports: true },"AdminPage":{"createQuestions":true}, "Homepage":{ "":false,  }};