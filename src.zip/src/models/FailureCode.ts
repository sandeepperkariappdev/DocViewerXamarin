export interface FailureCodeTemp{
    failCodeId:string;
    failDesc:string;
    failCodeHelp:string;
    seqId:string;
    isActive:boolean;
}