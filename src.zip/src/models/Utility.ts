import * as _ from 'lodash';
import { Level, Layer, Role, Language, ProductGroup } from './Level';
import { User } from './User';

export class Utility{
    levelsList:Array<Level>;
    layersList:Array<Layer>;
    rolesList:Array<Role>;
    languageList:Array<Language>;
    productGroupList:Array<ProductGroup>;

    constructor(){

    }
    setLevelDescById(levelsLst:Array<Level>){
        this.levelsList = levelsLst;
    }
    getLevelDescById(id){
       return _.find(this.levelsList,(o => o.id === id))["desc"];
    }
    setLayerDescById(layersLst:Array<Layer>){
        this.layersList = layersLst;
    }
    getLayerDescById(id){
       return _.find(this.layersList,(o => o.id === id))["desc"];
    }
    setRoleDescById(rolesLst:Array<Role>){
        this.rolesList = rolesLst;
    }
    getRoleDescById(id){
       return _.find(this.rolesList,(o => o.Id === id))["desc"];
    }
    setLanguageDescByCode(languageLst:Array<Language>){
        this.languageList = languageLst;
    }
    getLanguageDescByCode(id){
       return _.find(this.languageList,(o => o.langCode === id))["langDesc"];
    }
    setProductGroupById(productGroupLst:Array<ProductGroup>){
        this.productGroupList  = productGroupLst;
    }
    getProductGroupById(id){
       return _.find(this.productGroupList,(o => o.pgId === id))["pgDesc"];
    }      
}