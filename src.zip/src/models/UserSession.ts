import {User} from './User';
import {Level, Layer} from './Level';

export class  UserSession{
    user:User;
    levels:Array<Level>

}