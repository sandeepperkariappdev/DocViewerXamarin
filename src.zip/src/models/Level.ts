export class Level{
    constructor(public id:string,
    public desc:string){}
}

export class Layer{
    constructor(public id:string,
   public  desc:string){}
}

export class Role{
    constructor(public Id:string,
    public desc:string){}
}

export class Lot{
    constructor(public id:number,
    public name:string){}
}

export class Machine{
    constructor(public id:string,
    public name:any,
    public procDesc:string,public available:boolean){}
}

export class Shift{
    constructor(public id:string,
    public name:string){}
}

export class Language{
    constructor(public langCode:string,
    public langDesc:string){}
}

export class Category{
    constructor(public catId:number,
    public catName:string, public pgId:number,
    public pgName:string){}
}

export class ProductGroup{
    constructor(public pgId:number,
    public pgName:string){}
}

export class Operation{
    constructor(public opId:number,
    public opDesc:string){}
}
export class Process{
    constructor(public prcId:number,
    public prcDesc:string){}
}
export class Plant{
    constructor(public plantId:number,
    public plantName:string,public pgId:number,
    public pgName:string){}
}
export interface FailureCodeInterface{
    assigneeId:number,
    reviewerId:number,
    severity:number,
    failCode:number;
    failureCdCatId:number,
    failDesc:string;
    failCodeHelp:string;
    failActive:boolean;
    failureCdCatDesc:string;
}
export interface QuestionInterface{
  lngCode:string;
  lngDesc:string;
  queId:string;
  queHelp:string;
  queDesc:string;
  queActive:boolean;
  na:boolean;
  isCorpQue:boolean;
  failCodes:Array<FailureCodeInterface>  
}
export interface QuestionsInterface{
    catName:string;
    catId:number;
    isCorpQue?:boolean;
    questions:Array<QuestionInterface>
}
export interface LanguagesQuesFailCodes{
    langId:string;
    data:QuestionInterface;
}

