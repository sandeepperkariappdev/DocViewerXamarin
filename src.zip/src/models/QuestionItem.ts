import { FailureCodeInterface, QuestionInterface, QuestionsInterface, Lot, Machine, Shift, ProductGroup } from './Level';
import {FailureCodeTemp} from './FailureCode';

export class QuestionItem{
  queId:string;
  queDesc:string;
  sequence:string;
  isAlloted:boolean;
  isMandatory:boolean;
  FailureCodes:Array<FailureCodeTemp>
}
export class AddAdditionalQuesToPlantAuditRequest{
  constructor(public procId: number,
  public questionIds: any,
  public levelId: number,
  public plantId: number,
  public wLogin: string){}
}
export class AuditDetailsFailureCode  {  
  constructor(public failCode:number,
              public failDesc:string,
              public assigneeId:number,
              public reviewerId:number,
              public assigneeName:string,
              public reviewerName:string,
              public assignedTo:boolean,
              public severity:number,
              public isAlloted:boolean = false,
              public failCodeHelp:string,              
              public failActive:boolean,
              public assignedQueList:Array<number>,
              public question:Array<AuditDetailsFailureCodeQuestion>){}
}

export class AssignRevAssigneeFailureCodes{
constructor(public plantId:number,
            public failureCd:number,
            public assigneeId:number,
            public reviewerId:number,
            public severity:number,
            public wLogin:string){}
}

export class FailureCode implements FailureCodeInterface {  
  constructor(public assigneeId:number,
              public reviewerId:number,
              public severity:number,
              public failCode:number,
              public failureCdCatId:number,
              public failDesc:string,
              public failCodeHelp:string,
              public failActive:boolean,
              public failureCdCatDesc:string){}
}
export class ReqFCAssgneRvwerChange{
  constructor(public plantId: number,
              public processId: number,
              public failureCd: number,
              public failureCdCatId :number,
              public assigneeId: number,
              public reviewerId: number,
              public wLogin: string,
              public pgNum: number){}
}


export class AuditFailureCode{  
  constructor(public assigneeId:number,
              public reviewerId:number,
              public severity:number,
              public failCode:number,
              public failureCdCatId:number,
              public failDesc:string,
              public failCodeHelp:string,
              public failActive:boolean,
              public failureCdCatDesc:string,
              public failureCompletionDays:number,
              public reviewerCompletionDays:number,
              public assigneeCompletionDays:number,
              public assigneeName:string,
              public reviewerName:string,
              public isEdited?:boolean){}
}
export class ResponseAuditFailureCode{  
  constructor(public assigneeId:number,
              public assigneeIdFCLevel:number,
              public reviewerId:number,
              public reviewerIdFCLevel:number,
              public severity:number,
              public failCode:number,
              public failureCdCatId:number,
              public failDesc:string,
              public failCodeHelp:string,
              public failActive:boolean,
              public failureCdCatDesc:string,
              public failureCompletionDays:number,
              public reviewerCompletionDays:number,
              public assigneeCompletionDays:number,
              public assigneeName:string,
              public assigneeNameFCLevel:string,              
              public reviewerName:string,
              public reviewerNameFCLevel:string,
              public failureCdCatDescFCProcessLevel?:string,
              public failureCdCatIdFCProcessLevel?:number,
              public assigneeCompletionDaysFCProcessLevel?:number,
              public reviewerCompletionDaysFCProcessLevel?:number,
              public failureCompletionDaysFCProcessLevel?:number,
              public isEdited?:boolean){}
}

export class RequestUpdateMachineSequence {  
      constructor(public machinesSequence:Array<UpdateMachineSequence>){}
}
export class UpdateMachineSequence {  
    constructor(public MachineId:number,
                public Sequence: number,
                public UserId:string){}
}
export class UpdateFailureCode {  
  constructor(public failCode:number,
              public failureCdCatId:number,
              public failDesc:string,
              public failCodeHelp:string,
              public failActive:boolean,
              public isCreatOrUpdate:boolean){}
}
export class AuditDetailsFailureCodeQuestion{
  constructor(public lngCode:string,
              public lngDesc:string,
              public queId:string,
              public queHelp:string,
              public queDesc:string,
              public sequence:string,
              public assignedFailureCode:boolean,
              public isAlloted:boolean,
              public isMandatory:boolean,
              public failCode:number,
              public na:string){}
            }

export class Question implements QuestionInterface{
  constructor(public lngCode:string,
              public lngDesc:string,
              public queId:string,
              public queHelp:string,
              public queDesc:string,
              public sequence:string,
              public isAlloted:boolean,
              public queActive:boolean,
              public isMandatory:boolean,
              public isCorpQue:boolean,
              public na:boolean,
              public failCodes:Array<FailureCode>){}
}
// used int he audit details page before accepting the Audit
export class ResponseAuditQuestion{
  constructor(public lngCode:string,
              public lngDesc:string,
              public queId:string,
              public queHelp:string,
              public queDesc:string,
              public sequence:string,
              public isAlloted:boolean,
              public queActive:boolean,
              public isMandatory:boolean,
              public isCorpQue:boolean,              
              public na:string,
              public failCodes:Array<ResponseAuditFailureCode>, public isQueDeletable?:boolean){}
}
export class AuditQuestion{
  constructor(public lngCode:string,
              public lngDesc:string,
              public queId:string,
              public queHelp:string,
              public queDesc:string,
              public sequence:string,
              public isAlloted:boolean,
              public queActive:boolean,
              public isMandatory:boolean,
              public isCorpQue:boolean,              
              public na:string,
              public failCodes:Array<AuditFailureCode>, public isQueDeletable?:boolean){}
}
export class CreateFailureCode{
  constructor(public failCode: number,
              public catId: string,
              public failActive: boolean,
              public requested: boolean,
              public requestedBy: number,
              public isCreatOrUpdate: boolean,
              public langCode: string,
              public failCodeHelp: string,
              public failCodeDesc: string){}
}
export class FailCodeCategoryList{
  constructor(public failureCdCatId : number,
      public failureCdCatDesc : string,
      public daysOfCompletion : number,
      public severity : number,
      public daysOfCompletionAssignee : number,
      public daysOfCompletionReviewee : number){}
}
export class AssignFailCodeCategoryRequest{
  constructor(public plantId : number,
      public wLogin : string,
      public failureCdCatId : number,
      public severity : number,
      public assigneeId:number,
      public reviewerId:number){}
}
export class FailCodeCategoryAssigningList{
  constructor(public failureCdCatId : number,
      public failureCdCatDesc : string,
      public daysOfCompletion : number,
      public severity : number,
      public assigneeId:number,
      public reviewerId:number,
      public assigneeName:string,
      public reviewerName:string,
      public daysOfCompletionAssignee : number,
      public daysOfCompletionReviewee : number){}
}


 export class UpdateQuestion{  
  constructor(public langCode:string,
              public catId:number,
              public queId:string,              
              public queHelp:string,
              public queDesc:string, 
              public na:boolean,  
              public blnActive:boolean,                 
              public requested:boolean,
              public requestedBy:number,
              public failureCodeList:Array<UpdateFailureCode>){}
}

  export class Questions implements QuestionsInterface{
        constructor(public catName:string,
                    public catId:number,                    
                    public questions:Array<Question>,public isCorpQue?:boolean){}    
}
export class ResponseAuditQuestions {
        constructor(public catName:string,
                    public catId:number,                    
                    public questions:Array<ResponseAuditQuestion>,public isCorpQue?:boolean){}    
}
 export class AuditQuestions {
        constructor(public catName:string,
                    public catId:number,                    
                    public questions:Array<AuditQuestion>,public isCorpQue?:boolean){}    
}
 
export class FailureCodeList{
  constructor(public seqId:number,
              public failDesc:string,
              public failCodeHelp:string,
              public failCodeId:number,
              public failCodeCatId:number,
              public isActive:boolean){}
}
export class ReqQuestion{  
  constructor(public langCode:string,
              public catId:number,
              public queId:string,              
              public queHelp:string,
              public queDesc:string, 
              public active:boolean, 
              public na:boolean,                   
              public requested:boolean,
              public requestedBy:number,
              public failureCodeList:Array<FailureCodeList>){}
}
export class RequestQuestion{
  constructor(public userId:string, public plantId:number,
              public question:Array<ReqQuestion>){}  
}
export class RequestUpdateQuestion{
  constructor(public userId:string,
              public plantId: number,
              public question:Array<UpdateQuestion>){}  
}

export class LanguagesQuesFailCodes{
      langId:string;
      data:Questions;
}

export class CreateAuditQuestion{
  constructor(public queId:number,
              public sequence:number){}
  
}
export class CreateAudit{    
    constructor(public procId:number,
                public level:number,
                public userId:string,
                public questions:Array<CreateAuditQuestion>){}
}

export class CreationAudit{
  constructor(public auditName:string,
    public pgId:number,
    public opId:number,
    public procId:number,
    public pgName:string,
    public opName:string,
    public levelId:number,
    public auditLevelDesc:string){}
}

export class ActiveAudit{
constructor(public auditName:string,
    public createdDate:string,
    public opId:number,
    public plantId:number,
    public prId:number,
    public dueDate:string,
    public levelId:number,
    public firstName:string,
    public lastName:string){}
}
export class UserSelectionData{
  constructor(public selPltId:number, 
              public selPltName:string,
              public selPGId:number, 
              public selPGName:string,
              public selOpId:number,
              public selOpName:string,
              public selPrId:number,
              public selPrName:string,
              public selLevelId:number,
              public selLevelName:string,
              public selRoleId:number,
              public selRoleName:string,
              public selLangCode:string,
              public selLangDesc:string,
              public startDate:string,
              public endDate:string,
              public wLogin:string,
              public lot:Lot,
              public machine:Machine,
              public shift:Shift,
              public auditor:UserObject,
              public selFirstName:string,
              public selLastName:string,
              public selwLogin:string,
              public selEmail:string,
              public selCertified:string,
              public selActive:string,public selCommentsTextarea:string){}
}
export class UserSelectionPrivileges{
  constructor(public plt:boolean,
              public pg:boolean,
              public prc:boolean,
              public op:boolean,
              public level:boolean,
              public role:boolean,
              public language:boolean,
              public stDate:boolean,
              public endDate:boolean,
              public wLogin:boolean,
              public lot:boolean,
              public machine:boolean,
              public shift:boolean,
              public auditor:boolean,
              public showFirstNameInput :boolean,
              public showLastNameInput:boolean,
              public showWLoginInput:boolean,
              public showEmailInput:boolean,
              public showCertifiedSelect:boolean,
              public showSavePreference:boolean,
              public showActive:boolean,
              public showComments:boolean){}
}
export class PlantInfo{
  constructor(public plantId:number,public plantName:string,
              public opId:number,public opName:string,
              public pgId:number,public pgName:string){}
}
export class UserPlants{
  constructor(public plantId:number,public plantName:string,              
              public productGroups:Array<ProductGroup>){}
}
export class AssignPlantsRequest{
  constructor(public plantIds:string, public userId:number, 
              public wLogin:string){}
}
export class AuditFailureAF{
  constructor(public faileCode: number,
              public auditFailureId:number,
              public assigneeId: number,
              public assigneeCompletionDate: string,
              public assigneeComments: string,
              public reviewerId: number,
              public reviewerCompletionDate: string,
              public reviewerComments: string,
              public failureCompletionDate: string,
              public failureComments: string,
              public severity: number,
              public imageType: string,               
              public imageAudit: string,              
              public auditFailureStatus: number,
              public wLogin: string,
              public imageAssignee?: string,
              public imageReviewer?: string,
              public changeDateAFR?:string){}
}
export class AuditDetailAF{
  constructor(public queId:number,  
              public auditId:number,
              public machineNum:string,
              public auditDetailId:number,
              public result:number,
              public queComment:string,
              public langCode:string,
              public wLogin:string,
             // public isSaveAudit :boolean,
              public auditFailures:Array<AuditFailureAF>){}
}
export class SubmitFailureCodes{
  constructor(public faileCode: number,
    public auditFailureId:number,
    public assigneeId: number,
    public assigneeCompletionDate: string,
    public assigneeComments: string,
    public reviewerId: number,
    public reviewerCompletionDate: string,
    public reviewerComments: string,
    public failureCompletionDate: string,
    public failureComments: string,
    public severity: number,
    public imageType: string,               
    public imageAudit: string,              
    public auditFailureStatus: number,
    public wLogin: string,
    public imageAssignee?: string,
    public imageReviewer?: string,
    public changeDateAFR?:string){}
}
export class SubmitQuestion{
  constructor(public queId:number,  
  public auditDetailId:number,
  public result:number,
  public queComment:string,
  public wLogin:string,
  public auditFailures:Array<SubmitFailureCodes>){}
}
export class ResponseObject{
  constructor(public IsSuccess:boolean, public Message:string, public Response:any, public ResponseCode:string){}
}
export class SubmitAudit{
  constructor(public auditId:number,                            
              public procId:number,
              public plantId:number = 0,
              public level:number = 0,
              public auditDate:string = "",    
              public auditorId:number = 0,
              public lotNum:string = "",
              public shiftId:string = "",
              public machineNum:string = "",
              public machineId:number = 0,
              public status:string = "",
              public AdHoc:boolean,
              public wLogin:string = "",
              public plantProcessAuditListId:string = "",
              public auditStartTime:string = "",
              public auditEndTime:string = "",                
              public auditTakenStartDate:string = "", 
              public auditTakenEndDate:string = "",
              public comments:string = "",            
              public langCode: string,
              public auditDetails:Array<SubmitQuestion>
            ){}
}
export class MachineInfo{
  constructor(public plantId:number,
              public procId:number,
              public machineNum:string){}
}
export class AuditHeaderForAuditID{
  constructor(public auditId:number,                            
    public procId:number,
    public plantId:number = 0,
    public level:number = 0,
    public auditDate:string = "",    
    public auditorId:number = 0,
    public lotNum:string = "",
    public shiftId:string = "",
    public machineNum:string = "",
    public machineId:number = 0,
    public status:string = "",
    public AdHoc:boolean,
    public wLogin:string = "",
    public plantProcessAuditListId:string = "",
    public auditStartTime:string = "",
    public auditEndTime:string = "",                
    public auditTakenStartDate:string = "", 
    public auditTakenEndDate:string = "",
    public comments:string = "",            
    public langCode: string){}
}
export class SubmitAdhocAudit{
  constructor(public procId:number,
              public auditId:number,                           
              public plantId:number = 0,
              public level:number = 0,
              public auditDate:string = "",    
              public auditorId:number = 0,
              public lotNum:string = "",
              public shiftId:string = "",
              public machineNum:string,
              public machineId:number,
              public status:string = "0",
              public AdHoc:boolean,
              public wLogin:string = "",
              public plantProcessAuditListId:string = "",
              public auditStartTime:string = "",
              public auditEndTime:string = "",
              public auditTakenStartDate:string = "", 
              public auditTakenEndDate:string = "",
              public comments:string = "",
              public langCode: string,
              public auditDetails:Array<SubmitQuestion>
            ){}
}

export class ScheduleAuditToUser{
  constructor(public procId: number,
  public plantId: number,
  public levelId: number,  
  public weekAuditDate: string,
  public status: number,
  public AdHoc: boolean,
  public langCode:string,
  public wLogin: string, public auditors:Array<ScheduleToAuditor>){}  
}
export class ScheduleToAuditor{
  constructor(public auditDate: string,
              public resendEmail:boolean,
              public auditId:number,
              public auditorId:number, 
              public shiftId:number, 
              public machineId:number, 
              public machineNum:string, 
              public comments:string,
              public lotNum:string, 
              public auditStartTime:string, 
              public auditEndTime:string ){}
}
export class UserObject{
  constructor(public id:number, public name:string){}
}
export class CreatePlantShift{
  constructor(public plantId:number, public shift:string, public wlogin:string){}
}
export class CreatePlantMachine{ 
  constructor(public plantId: number,
              public procId: number,
              public machineNum: string,
              public decommission:boolean,
              public swiPath: string,
              public wLogin: string){}
}
export class UpdateProcessForMachine{ 
  constructor(public machineId:number,
              public procId:number,
              public wLogin: string){}
}
export class UpdatePlantMachine{ 
  constructor(public plantId: number,
              public procId: number,
              public oldMachineNum: string,
              public machineNum: string,
              public decommission:boolean,
              public swiPath: string,
              public wLogin: string){}
}

export class TempFailureCodes{
  constructor(public auditDetailId:number = 0, //not needed porperty
              public failCode: number = 0,
              public failCodeSelected: boolean = false,
              public failDesc: string,
              public failCodeHelp: string,
              public assignee: UserObject,
              public assigneeCompletionDays: number,
              public assigneeCompletionDate: string,
              public assigneeComments: string,
              public reviewer: UserObject,
              public reviewerCompletionDays: number,
              public reviewerCompletionDate: string,
              public reviewerComments: string,
              public failureCompletionDays: number,
              public failureCompletionDate: string,
              public failureComments: string,
              public severity: number = 0,
              public imageType: string,
              public imageData: string,
              public imageFilePath: string,
              public auditFailureStatus: number = 0,
              public wLogin: string,
              public auditFailureId?:number, 
              public assigneeIdFCLevel?:number,
              public assigneeNameFCLevel?:string,
              public reviewerIdFCLevel?:number,
              public reviewerNameFCLevel?:string,
              public changeDateAFR?:string){}
}
export class TempQuestion{
  constructor(public auditId:number = 0,  //not needed porperty                   
              public queId:number = 0,
              public index:number = 0,
              public elementRefIndex:number = 0,
              public isDefferred:boolean = false,
              public na:boolean = false,
              public naEntered:boolean = false,
              public pass:boolean = false,
              public fail:boolean = false,
              public defer:boolean = false,
              public queHelp:string = "",
              public queDesc:string = "",
              public result:number = 0,
              public queComment:string = "",
              public wLogin:string = "",
              public langCode:string = "",
              public failCodes:Array<TempFailureCodes>,
              public auditDetailId?:number){}
}
export class CorrectActionAssgnItem{
  constructor(public assgneeId :number, 
              public assigneeComments:string,  
              public assigneeCompDate:string, public auditDate: string,
              public auditEndTime:string, public auditFailStatus:number,
              public auditId:number,public auditDetailId:number, public auditStartTime:number, public comments:string,
              public compDate:string, public email:string, public failCd:number,
              public firstName:string, 
              public lastName:string, public levelId:number, 
              public lotNum:number, public machineNum:number,public plantId:number, 
              public procId:number, public reviewerComments:string, public reviewerCompDate:string, 
              public reviewerId:number, public severity:number, 
              public shift:string, public status:string, 
              public userId:number,public wlogin:string, public AssigneeEmail:string,
              public assigneeFirstName:string, public assigneeLastName:string, 
              public AssigneeName:string, public ReviewerName:string,
              public AssigneeWlogin:string, public ReviewerEmail:string, 
              public reviewerFirstName:string, public reviewerLastName:string, 
              public ReviewerWlogin:string, public auditName:string, 
              public failDesc:string, public procName:string, public plantName:string,
              public pgName:string, public pgId:string,
              public questionDesc:string, public auditFailureId:number,
              public questionId:number, public image?:string,public imageType?:string, public imageFilePath?:string){}
}
export class CorrectiveActionReassign {
  constructor(public questionId:number,
              public langCode:string,
              public machineNum:string,
              public assigneeCompletionDate:string,
              public reviewerCompletionDate:string,
              public userId:number,
              public comments:string,
              public auditFailureStatus:number,
              public auditFailureId:number,
              public failCode:number,
              public severity:number,
              public wLogin:string){}
}
export class SubmitActionAssignmentReviewer{
  constructor(public auditDetailId:number,
              public failCode:number,
              public reviewerCompletionDate:string,
              public reviewerComments:string,
              public wlogin:string,
              public auditFailureId:number,
              public assigneeId:number,
              public assigneeCompletionDate:string,
              public assigneeComments:string,
              public reviewerId:number,
              public langCode:string,
              public questionId:number,
              public machineNum:number, 
              public targetDate:string, 
              public comments:string, 
              public failureCompletionDate:string,
              public failureComments:string,
              public severity:number,
              public auditFailureStatus:number){}
}
export class ReassignActionAssignmentReviewer{
  constructor(public auditDetailId:number,
    public failCode:number,
    public auditFailureStatus:number,
    public auditFailureId:number,
    public reviewerCompletionDate:string,
    public reviewerComments:string,
    public wlogin:string,
    public assigneeId:number,
    public reviewerId:number,
    public questionId:number,
    public langCode:string,
    public machineNum:string,
    public targetDate:string,
    public comments:string){}
}
export class SubmitActionAssignmentAssignee{
  constructor(public auditDetailId:number,
              public failCode:number,
              public assigneeCompletionDate:string,
              public assigneeComments:string,  
              public wlogin:string,            
              public auditFailureId:number,
              public assigneeId:number,
              public reviewerId:number,
              public reviewerCompletionDate:string,
              public reviewerComments:string,
              public failureCompletionDate:string,
              public failureComments:string,
              public severity:number,
              public auditFailureStatus:number,
              public questionId:number,
              public machineNum:number, 
              public targetDate:string, 
              public comments:string, public langCode:string){}
}
export class AuditFailureRouting{
  constructor(public auditFailureId:number,
              public auditFailureStatus:number,
              public changeDate:string,
              public userId:number,
              public completionDate:string,
              public actualCompletionDate:string,
              public comments:string,
              public image:string,
              public imageType:string,
              public wLogin:string){}
}

export class CorrectiveActionItemHistory{
  constructor(public comments: string,
              public image:string,
              public imageType: string,
              public changeDate: string,
              public statusName: string,
              public statusId:number,
              public userId:number,
              public userName:string,
              public modifiedBy:string,
              public dateModified:string,
              public showItem?:boolean,
              public statusField?:string){}
}
export class CorrectiveActionHistoryItemResponse{
  constructor(public queId: number,
      public queDesc: string,
      public failureCode: number,
      public falureDesc: string,
      public auditFailureId: number,
      public auditDetailsId: number,
      public failureHistory:Array<CorrectiveActionItemHistory>){}
}
export class TempAuditData{
  constructor(
    public catId:number = 0,
    public catName:string = "",
    public questions:Array<TempQuestion>
  ){}
}
export class TempAudit{
  constructor(public opId:number = 0,    
    public opName:string = "",
    public pgId:number = 0,
    public procId:number = 0,
    public procName:string = "",
    public plantId:number = 0,
    public level:number = 0,
    public userId:number = 0,
    public userRole:number = 0,
    public auditDate:string = "",
    public startDate:string = "",
    public dueDate:string = "",    
    public auditorId:string = "",
    public auditId:number = 0,
    public lotNum:string = "",
    public shift:string = "",
    public machineNum:string = "",
    public status:number = 0,
    public wLogin:string = "",
    public langCode:string = "",
    public auditName:string = "",    
    public plantProcessAuditListId:string = "",
    public data:Array<TempAuditData>,
    public comments?:string,){}
}
export class CreateAndAssignAuditRequest{
  constructor(public procId: number,
    public plantId: number,
    public level: number,
    public auditDate: string,
    public auditorId: number,
    public lotNum: number,
    public shift: number,
    public machineNum: number,
    public status: number,
    public wLogin:string,
    public plantProcessAuditListId: number,
    public auditStartTime: string,
    public auditEndTime: string){
    }
}
export class ProcessWeeklyAuditsList{
  constructor(public procId: number,
              public procName: string,
              public levelId: number,
              public weeklyAuditsList:Array<WeeklyAuditsList>){}
}
export class RequestSWIPath{
  constructor(public inputPlantSWIURL: string, public folderName:string){
  }
}
export class WeeklyAuditsList{
  constructor(public weekStart: string,
              public weekFormattedStartDate: string,
              public auditsList:Array<AcceptedAuditItem>){}
}
export class AcceptedAuditItem{
  constructor(public auditListId: number,
              public userId: number,
              public firstName: string,
              public lastName: string,
              public startDate: string,
              public endDate: string,
              public createdDate: string,
              public auditName: string,
              public pgId: number,
              public opName: string,
              public pgName: string,
              public opId: number,
              public procId: number,
              public procName: string,
              public plantId: number,
              public plantName: string,
              public levelId: number,
              public lotNum: string,
              public shift: string,
              public machineNum: string,
              public comments: string,
              public status: number,
              public auditStartTime: string,
              public auditEndTime: string,
              public startDateFormatted?:string,
              public endDateFormatted?:string,){}
}
export class SubmitScheduledAudit{
  constructor(public auditId:number, 
              public auditorId:number, 
              public lotNum:string, 
              public machineNums:string,// this will be in Array since we select multiple machine numbers
              public shift:string, 
              public comments:string, 
              public wlogin:string){}              
}


export class UsersInPlant{
  constructor(public userId:number,
              public lastName:string,
              public firstName:string,
              public wLogin:string,
              public email:string,
              public roleId:number,
              public level:number,
              public layer:number,
              public active:boolean,
              public certified:boolean,
              public langCode:string,
              public plantId:number,
              public plantName:string,
              public opId:number,
              public opName:string,
              public pgId:number,
              public pgName:string){}
}

export class AllAvailableUsers{
    constructor(public userId:number,
                public lastName: string,
                public firstName: string,
                public wlogin: string,
                public email: string,
                public roleId: number,
                public levelId: number,
                public layer: number,
                public active: boolean,
                public certified: boolean,
                public pgNum: number,
                public langCode: string){}
}

export class CreateActiveAuditRequest{
   constructor(public plantId:number,
     public startDate:string, 
     public endDate:string,
     public processId:number,
     public level:number,
     public wLogin:string){

   }  
}

export class AuditList{
  constructor(public auditName:string,
              public pgId:number,
              public opId:number,
              public numOfQuesCorp:number,
              public numOfQuesPlant:number,
              public procId:number,
              public pgName:string,
              public opName:string,
              public procName:string,
              public levelId:number,
              public auditLevelDesc:string){}
}

export class RequestedFailureCode{
  constructor(public failDesc: string,
              public failCodeHelp: string,
              public failCode: number){}
}
export class RequestedQuestion{
   constructor(public lngCode:string,
                public queId:string,
                public queHelp:string,
                public queDesc:string,
                public na:boolean, 
                public failureCodeList:Array<RequestedFailureCode>){}
}
export class ReqQuestions {
        constructor(public catName:string,
                    public catId:number,
                    public questions:Array<RequestedQuestion>){}    
}
export class ReqQuestionResponse{
   constructor(public lngCode:string,
               public lngName:string,
               public data:Array<ReqQuestions>){}
}


export class ApproveFailureCodeObject {
    constructor( public failDesc: string,
                 public failCodeHelp: string,
                 public isActive:boolean,
                 public seqId:number){}
}
export class ApproveQuestionObject {
  constructor(public queDesc : string,
              public queHelp : string,        
              public na : boolean,          
              public catId : number,
              public failureCodeList : Array<ApproveFailureCodeObject>){}
              
}
export class ApproveQuestion{
  constructor(public userId:string,
              public queId:number,
              public langCode:string,
              public question:Array<ApproveQuestionObject>){}
}

export class ResponseAuditDetailsQuestion{
constructor(public auditId:number,
            public auditName:string,
            public data:Array<ResponseAuditQuestions>,
            public dueDate:string,
            public langCode:string,
            public level:number,
            public opId:number,
            public opName:string,
            public pgId :number,
            public procId:number,
            public procName:string,
            public userId:number,
            public userRole:number){}
}
export class AuditDetailsQuestion{
constructor(public auditId:number,
            public auditName:string,
            public data:Array<AuditQuestions>,
            public dueDate:string,
            public langCode:string,
            public level:number,
            public opId:number,
            public opName:string,
            public pgId :number,
            public procId:number,
            public procName:string,
            public userId:number,
            public userRole:number){}
}



export class MachinesList{
    constructor(public machineId:number,
                public machineNum:string,
                public plantName:string,
                public plantId:string,
                public procDesc:string,
                public procId:string,
                public swiPath:string,
                public dateModified:string,
                public isActive:string,
                public isSWIPathAvail?:string,
                public isActiveText?:string){}
}
export class CreateNewUser{
  constructor(public userId:number,
              public lastName:string,
              public firstName:string,
              public userWLogin:string,
              public email:string,
              public roleId:number,
              public level:number,
              public layer:number,// Layer will be inserted as 0 for all the new
              // users as the layer will be removed from system later on
              public active:boolean,
              public certified:boolean,
              public pgNum:number,
              public langCd:string,
              public wLogin:string){}
}
export class UsersForPlant{
  constructor(public userId:number,
              public lastName:string,
              public firstName:string,
              public wLogin:string,
              public email:string,
               public shift:string,
              public roleId:number,
              public level:number,
              public layer:number,
              public active:boolean,
              public certified:boolean,
              public langCd:string){}
}
export class PlantUsers{
   constructor(public plantId:number,
                public plantName:string,
                public opId:number,
                public opName:string,
                public pgId:number,
                public pgName:string,
                public users:Array<UsersForPlant>){}
}

export class FailureCodeItem{
  constructor(public failCode:number,
              public failCodeHelp: string,
              public failDesc: string,
              public isAlloted: boolean,
              public sequence: number,
              public failActive: boolean,
              public failRequested: boolean,
              public failRequestedBy: number,
              public isMandatory: boolean){}
}
export class FailureCodesList{
  constructor(public failCatId:number,
              public failCatName:string,
              public failureCodes:Array<FailureCodeItem>){}
}
export class LanguagesFailCodesList{
  constructor(public lngCode:string,
      public data:Array<FailureCodesList>){}
}
export class URL implements URL{
  constructor(public url: string, public base?: string){}
}
