import {QuestionItem} from './QuestionItem'

export class QuestionsList{
  questionSectionName:string;
  questionsArray:Array<QuestionItem>
}
