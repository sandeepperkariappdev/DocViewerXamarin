import { Component, ViewChild } from '@angular/core';
import { Nav, Platform, Events } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
//import { Network } from "@ionic-native/network";
import { HomePage } from '../pages/home/home';
import { AuditSchedularPage} from "../pages/audit-schedular/audit-schedular";
import { MainScheduleAuditsPage } from '../pages/home/main-schedule-audits/main-schedule-audits';
import { AuditsListPage } from '../pages/audits/audits-list';
import { Reports } from '../pages/reports/reports';
import { Schedular } from '../pages/side-menu/schedular/schedular';
import { Admin } from '../pages/admin/admin';
import { SelectionPage } from '../pages/selection/selection';
import { LoginPage } from '../pages/login-page/login-page';
import { ReportNewIssue } from '../pages/side-menu/report-new-issue/report-new-issue';
import { AuditsHistory } from '../pages/side-menu/audits-history/audits-history';
import { Preferences } from '../pages/side-menu/preferences/preferences';
import { UserService } from '../providers/user-service';
import { UtilService } from '../providers/util-service';
import { AuditStartResultsProvider } from '../pages/audit-start-results/audit-start-results-service';
import { ResourcesManagementPage } from "../pages/resources-management/resources-management";
import { AdminManagementPage  } from "../pages/admin-management/admin-management";
import { Privileges } from '../providers/privileges';
import { Network } from '@ionic-native/network';
import { UnScheduledAudits } from '../pages/home/un-scheduled-audits/un-scheduled-audits';
import { TranslateService} from 'ng2-translate';
import {defaultLanguage, availableLaguages, sysOptions}  from '../constants/i18n.constants'; 

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;
 tempPages: Array<{title: string, component: any}>;
  rootPage: any = LoginPage;
  objKeys:Array<string>;
  pages: Array<{title: string, component: any}>;
   appVersion:string;

  constructor(public platform: Platform, 
              private translate:TranslateService, 
              private network: Network,
              public statusBar: StatusBar,
              public splashScreen: SplashScreen, 
              private events:Events, 
              private auditService:AuditStartResultsProvider,
              private privileges:Privileges,
              private userService:UserService,
              private utilService:UtilService) {

    this.initializeApp();
    this.utilService.isMobileApp = this.platform.is("mobile");
    // this language will be used as a fallback when a translation isn't found in the current language       
    translate.setDefaultLang(defaultLanguage);    
    if(this.platform.is("cordova")){
      this.utilService.isMobileApp = true;
        this.network.onchange().subscribe((data) => {
            if(data.type === "offline"){
              this.utilService.showToast("","Network Offline");
                this.utilService.isNetworkConnected = false;
            }
              if(data.type === "online"){
                this.utilService.showToast("","Network Online");
                this.utilService.isNetworkConnected = true;   
                this.auditService.submitCachedCompletedAudits();//submitting the cached Audits;          
            } 
         });  
    } else{
       this.utilService.isNetworkConnected = navigator.onLine;
      // this.utilService.isNetworkConnected = false;
       //const msg = navigator.onLine ?  "Network Online" : "Network Offline";
       //this.utilService.showToast("",msg);
    }
    
    let browserLanguage = translate.getBrowserLang() || defaultLanguage;  
    browserLanguage = "es";
    var language = this.getSuitableLanguage(browserLanguage);   

    // the lang to use, if the lang isn't available, it will use the current loader to get them
    translate.use(language);
    sysOptions.systemLanguage = language;

    // used for an example of ngFor and navigation
    /*this.pages = [
      { title: 'Home', component: HomePage },
      { title: 'Audits', component: MainScheduleAuditsPage },      
      { title: 'Admin', component: Admin },  
      { title: 'Reports', component: Reports },   
      { title: 'Schedular', component: AuditSchedularPage },   //schedular   
      { title: 'ReportIssue', component: ReportNewIssue },  
      { title: 'AuditsHistory', component: AuditsHistory },  
      { title: 'Preferences', component: SelectionPage },                              
      { title: 'LogOut', component: LoginPage }
    ];*/
    let that = this;
    const components = [HomePage, AdminManagementPage, ResourcesManagementPage ,MainScheduleAuditsPage, Admin,  Reports, AuditSchedularPage, ReportNewIssue, AuditsHistory, SelectionPage, LoginPage];
    
    this.events.subscribe("userSideMenu",(data:Object) => {
      that.pages = [];
       that.objKeys = Object.keys(data);
       that.objKeys.forEach((element,index) => {
         if(data[element]["thisShow"] !== "false"){
          var title = data[element]["trnskey"];
            if(element === "AdminManagement"){
                element = "Admin";
                title = data[element] ?  data[element]["trnskey"] : data["AdminManagement"]["trnskey"];
            }
            
            that.pages.push({title:title,component:components[index]});  
         }         
       });                 
    });

    this.appVersion = this.utilService.getAppVersion();
  }
getSuitableLanguage(language) {
		language = language.substring(0, 2).toLowerCase();
		return availableLaguages.some(x => x.code == language) ? language : defaultLanguage;
	}
  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    
      this.platform.registerBackButtonAction(() => {

      });
    });
  }

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    if(this.privileges.havePageAccess(this.userService.getUser().roleName,  page.title) !=="false"){
      if(page.title.toLowerCase() === "logout"){
           this.nav.setRoot(page.component, {
                "isLogOut" : "true"
            });
      } else{
         this.nav.setRoot(page.component);
      }
     
    } else {
      this.utilService.showToast("You don't have access to "+ page.title);
    }
    
  }
}
