import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { HttpModule, RequestOptions, XHRBackend} from '@angular/http';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { Reports } from '../pages/reports/reports';
import { Schedular } from '../pages/side-menu/schedular/schedular';
import { AuditsHistory } from '../pages/side-menu/audits-history/audits-history';
import { Admin } from '../pages/admin/admin';
import { AuditsListPage } from '../pages/audits/audits-list';
import { AuditListUserPage } from '../pages/audits/audit-list-user/audit-list-user';
import { AuditListPlantPage } from '../pages/audits/audit-list-plant/audit-list-plant';
import { AuditService } from '../pages/audits/audit-service';
import { ReportsInquiry } from '../pages/reports-inquiry/reports-inquiry';
import { OperationResults } from '../pages/operation-results/operation-results';
import { AdminAudits } from '../pages/admin/admin-audits/admin-audits';
import { AdminMachines } from '../pages/resources-management/admin-manage-machine/admin-manage-machine';
import { AdminQuestions } from '../pages/admin/admin-manage-questions/admin-manage-questions';
import { RequestsListPage } from '../pages/admin/requests-list/requests-list';
import { OrderByPipe } from '../filters/order-by-pipe';
import { AdminManageUser } from '../pages/resources-management/admin-manage-user/admin-manage-user';
import { AuditStartResults} from '../pages/audit-start-results/audit-start-results';
import { AuditStartResultsProvider} from '../pages/audit-start-results/audit-start-results-service';
import { CreateQuestionsCQA} from '../pages/create-questions-cqa/create-questions-cqa';
import { ScheduledAudits} from '../pages/home/scheduled-audits/scheduled-audits';
import { MainScheduleAuditsPage} from '../pages/home/main-schedule-audits/main-schedule-audits';
import { UnScheduledAudits} from '../pages/home/un-scheduled-audits/un-scheduled-audits';
import { CorrectiveAssignments } from '../pages/home/corrective-assignments/corrective-assignments';
import { MyCorrectiveActionAssignments } from '../pages/home/my-corrective-action-assignments/my-corrective-action-assignments';
import { CorrectiveActionAssignmentDetailsPage } from '../pages/home/corrective-action-assignment-details/corrective-action-assignment-details';
import { LoginPage } from '../pages/login-page/login-page';
import { AdminCreateAudit } from '../pages/admin/admin-create-audit/admin-create-audit';
import { AuditDetails } from '../pages/admin/audit-details/audit-details';
import { UpdateQuesFailureCodeModals } from '../popup-modals/update-ques-failure-code-modals/update-ques-failure-code-modals';
import { UpdateQuesFailureCodeProvider } from '../popup-modals/update-ques-failure-code-modals/update-ques-failure-code-service';
import { ShowFailureCodes } from '../popup-modals/show-failure-codes/show-failure-codes';
import { MoreInfoModal } from '../popup-modals/more-info-modal/more-info-modal';
import { QuestionFailureCodeDetails } from '../pages/admin/question-failure-code-details/question-failure-code-details';
import { EditAuditQuestion } from '../pages/edit-audit-question/edit-audit-question';
import { SearchAudits } from '../pages/search-audits/search-audits';
import { ReportNewIssue } from '../pages/side-menu/report-new-issue/report-new-issue';

import { ReportIssueSearchItems } from '../pages/side-menu/report-new-issue/report-issue-search-items/report-issue-search-items';
import { OpenNewIssue } from '../popup-modals/open-new-issue/open-new-issue';
import { Search } from '../popup-modals/search/search';
import { SearchUsersInPlant } from '../popup-modals/search-users-in-plant/search-users-in-plant';
import { SearchMachineInPlant } from '../popup-modals/search-machine-in-plant/search-machine-in-plant';
import { ReportNewIssueDetails } from '../pages/side-menu/report-new-issue/report-new-issue-details/report-new-issue-details';
import { AssignmentDetails } from '../popup-modals/assignment-details/assignment-details';
import { UserService } from '../providers/user-service';
import { UtilService } from '../providers/util-service';
import { LoginService } from '../providers/login-service';
import { CallService } from '../providers/call-service';
import { HttpService } from '../providers/http-service';
import { Privileges } from '../providers/privileges';
import { TranslateDataService } from '../providers/google-translate/translate-data-service';
import { InitialDataService } from '../providers/initial-data-service';
import { AdhocAuditsPage } from '../pages/adhoc-audits/adhoc-audits';
import { GeneralAuditsPage } from '../pages/general-audits/general-audits';
import { AdhocAuditsServiceProvider } from '../pages/adhoc-audits/adhoc-audits-service';
import { SelectionPage } from '../pages/selection/selection';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { AdminManageQuesServiceProvider } from '../pages/admin/admin-manage-questions/admin-manage-ques-service';
import { AdminAuditProvider } from '../pages/admin/admin-audits/admin-audits-service';
import { AuditDetailsServiceProvider } from '../pages/admin/audit-details/audit-details-service';
import { TranslateModule } from 'ng2-translate';
import { TranslateLoader, TranslateStaticLoader} from 'ng2-translate/src/translate.service';
import { Http } from '@angular/http'; 
import { defaultLanguage, availableLaguages, sysOptions}  from '../constants/i18n.constants';
import { HomeServiceProvider } from '../pages/home/home-service';
import { AdminServiceProvider } from '../pages/admin/admin-service';
import { AdminManageMachineProvider } from '../pages/resources-management/admin-manage-machine/admin-manage-machine-service';
import { AdminManageShiftPage } from '../pages/resources-management/admin-manage-shift/admin-manage-shift';
import { MomentTimezoneModule} from 'angular-moment-timezone';
import { MomentModule} from 'angular2-moment';
import { AdminManageFailureCodesPage } from '../pages/admin-manage-failure-codes/admin-manage-failure-codes';
import { AssignToFailureCodesCategoriesPage } from '../pages/assign-to-failure-codes-categories/assign-to-failure-codes-categories';
import { AssignFailureCodesPage} from '../pages/assign-failure-codes/assign-failure-codes';
import { CreateFailureCodePage } from '../pages/create-failure-code/create-failure-code';
import { AdminManageFailureCodesService } from '../pages/admin-manage-failure-codes/admin-manage-failure-codes-service';
import { AuditsHistoryServiceProvider } from '../pages/side-menu/audits-history/audits-history-service';
import { AuditsHistoryUserPage } from '../pages/side-menu/audits-history/audits-history-user/audits-history-user';
import { AuditsHistoryPlantPage } from '../pages/side-menu/audits-history/audits-history-plant/audits-history-plant';
import { CalendarModule } from "ion2-calendar";
import { CorrectiveActionAssignmentServiceProvider } from '../pages/home/corrective-assignments/corrective-action-assignment-service';
import { UserAssignmentsPage } from "../pages/user-assignments/user-assignments";
import { CacheDataForOfflineProvider } from '../providers/cache-data-for-offline';
import { AppSettings } from '../constants/AppSettings';
import { AnnotatePicturePage} from '../popup-modals/annotate-picture/annotate-picture';
import { Network } from '@ionic-native/network';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { Camera } from '@ionic-native/camera';
import { ScheduleAuditsToGroupPage } from '../pages/schedule-audits-to-group/schedule-audits-to-group';
import { AdminManagementPage } from '../pages/admin-management/admin-management';
import { ResourcesManagementPage } from '../pages/resources-management/resources-management';
import { AuditSchedularPage} from "../pages/audit-schedular/audit-schedular";
import { EditScheduledAuditPage} from "../pages/audit-schedular/edit-scheduled-audit/edit-scheduled-audit";
import { ScheduleNewAuditPage} from "../pages/audit-schedular/schedule-new-audit/schedule-new-audit";
import { EditScheduledAuditServiceProvider } from '../pages/audit-schedular/edit-scheduled-audit/edit-scheduled-audit-service';
import { WeeklySchedulingToAuditorsPage} from "../pages/weekly-scheduling-to-auditors/weekly-scheduling-to-auditors"
import { AnnotatePictureProvider } from '../popup-modals/annotate-picture/annotate-picture-service';

export function createTranslateLoader(httpService:HttpService){
  const url = AppSettings.API_I18N_ENDPOINT;
  //const url = "http://localhost:8100/assets/i18n";
  return new TranslateStaticLoader(httpService, url, '.json');
}

export function useFactoryHttpservice(backend:XHRBackend, options:RequestOptions){
     return new HttpService(backend, options);
}

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    Reports,
    Admin,
    AnnotatePicturePage,
    Schedular,
    AuditsListPage,
    AuditListUserPage,
    AuditListPlantPage,
    ReportsInquiry,
    OperationResults,
    AdminAudits,
    AdminMachines,
    AdminQuestions,
    RequestsListPage,
    AdminManageUser,
    AuditStartResults,
    CreateQuestionsCQA,
    ScheduledAudits,
    UnScheduledAudits,
    MyCorrectiveActionAssignments,
    LoginPage,
    OrderByPipe,
    UpdateQuesFailureCodeModals,
    QuestionFailureCodeDetails,
    AdminCreateAudit,
    AuditDetails,
    EditAuditQuestion,
    ShowFailureCodes,
    MoreInfoModal,
    ReportNewIssue,
    ReportNewIssueDetails,
    OpenNewIssue,
    SearchUsersInPlant,
    SearchMachineInPlant,
    AuditsHistory,
    SearchAudits,
    AssignmentDetails,
    ReportIssueSearchItems,
    Search,
    CorrectiveAssignments,
    CorrectiveActionAssignmentDetailsPage,  
    SelectionPage,
    AssignFailureCodesPage,
    AssignToFailureCodesCategoriesPage,
    AdminManageFailureCodesPage,
    CreateFailureCodePage,
    AuditsHistoryUserPage,
    AuditsHistoryPlantPage,
    MainScheduleAuditsPage,
    UserAssignmentsPage,
    ScheduleAuditsToGroupPage,
    ResourcesManagementPage,
    AdminManagementPage,
    AdhocAuditsPage,
    AdminManageShiftPage,
    AuditSchedularPage,
    EditScheduledAuditPage,
    ScheduleNewAuditPage,
    WeeklySchedulingToAuditorsPage,
    GeneralAuditsPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    TranslateModule.forRoot({
      provide:TranslateLoader,
      useFactory:(createTranslateLoader),
      deps:[Http]
    }),
    HttpModule,
    MomentModule,
    MomentTimezoneModule,
    CalendarModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    Reports,
    Admin,
    AnnotatePicturePage,
    Schedular,
    AuditsListPage,
    AuditListUserPage,
    AuditListPlantPage,
    ReportsInquiry,
    OperationResults,
    AdminAudits,
    AdminMachines,
    AdminQuestions,
    RequestsListPage,
    AdminManageUser,
    AuditStartResults,
    ScheduledAudits,
    UnScheduledAudits,
    MyCorrectiveActionAssignments,
    CorrectiveActionAssignmentDetailsPage,
    LoginPage,
    CreateQuestionsCQA,
    UpdateQuesFailureCodeModals,
    QuestionFailureCodeDetails,
    AdminCreateAudit,
    AuditDetails,
    EditAuditQuestion,
    ShowFailureCodes,
    MoreInfoModal,
    ReportNewIssue,
    ReportNewIssueDetails,
    OpenNewIssue,
    SearchUsersInPlant,
    SearchMachineInPlant,
    AuditsHistory,
    SearchAudits,
    AssignmentDetails,
    ReportIssueSearchItems,
    Search,
    CorrectiveAssignments,
    SelectionPage,
    AssignFailureCodesPage,
    AssignToFailureCodesCategoriesPage,
    AdminManageFailureCodesPage,
    CreateFailureCodePage,
    AuditsHistoryUserPage,
    AuditsHistoryPlantPage,
    MainScheduleAuditsPage,
    UserAssignmentsPage,
    ScheduleAuditsToGroupPage,
    ResourcesManagementPage,
    AdminManagementPage,
    AdhocAuditsPage,
    AdminManageShiftPage,
    AuditSchedularPage,
    EditScheduledAuditPage,
    ScheduleNewAuditPage,
    WeeklySchedulingToAuditorsPage,
    GeneralAuditsPage  
  ],
  providers: [
    StatusBar,
    SplashScreen,
     Network,
    Camera,
    InAppBrowser,
    CallService,
    Privileges,
    UserService,
    LoginService,
    UtilService,
    InitialDataService,
    AuditService,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    {
      provide:HttpService,
      useFactory:(useFactoryHttpservice),
      deps:[XHRBackend,RequestOptions]
    },
    AdminManageQuesServiceProvider,
    AdminAuditProvider,
    AuditDetailsServiceProvider,
    AuditStartResultsProvider,
    UpdateQuesFailureCodeProvider,
    HomeServiceProvider,
    AdminServiceProvider,
    AdminManageMachineProvider,
    TranslateDataService,
    AdminManageFailureCodesService,
    AuditsHistoryServiceProvider,
    CorrectiveActionAssignmentServiceProvider,
    CacheDataForOfflineProvider,
    AdhocAuditsServiceProvider,
    EditScheduledAuditServiceProvider,
    AnnotatePictureProvider        
  ]
})
export class AppModule {}
