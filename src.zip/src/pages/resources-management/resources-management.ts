import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AdminManageUser } from './admin-manage-user/admin-manage-user';
import { AdminMachines } from './admin-manage-machine/admin-manage-machine';
import { AdminManageShiftPage } from './admin-manage-shift/admin-manage-shift';
/**
 * Generated class for the ResourcesManagementPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-resources-management',
  templateUrl: 'resources-management.html',
})
export class ResourcesManagementPage {
 private tab1:any;
    private tab2:any;
    private tab3:any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
     this.tab1 = AdminMachines;
     this.tab2 = AdminManageUser;
     this.tab3 = AdminManageShiftPage;
  }

  ionViewDidLoad() {    
  }

}
