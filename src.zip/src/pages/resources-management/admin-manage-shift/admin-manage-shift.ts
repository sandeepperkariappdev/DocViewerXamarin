import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, PopoverController } from 'ionic-angular';
import {  Shift } from '../../models/Level';
import { UserSelectionData, UserSelectionPrivileges, UserObject } from '../../../models/QuestionItem';
import { UserService } from '../../../providers/user-service';
import { UtilService } from '../../../providers/util-service';
import { AdminManageMachineProvider } from '../admin-manage-machine/admin-manage-machine-service';
import { SelectionPage } from '../../selection/selection';


/**
 * Generated class for the AdminManageShiftPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-admin-manage-shift',
  templateUrl: 'admin-manage-shift.html',
})
export class AdminManageShiftPage {
  public shiftList:Array<string>;
     selectionData:UserSelectionData;
  constructor(public navCtrl: NavController, public navParams: NavParams, 
  private popoverCtrl: PopoverController,
  private adminManageMachinesService:AdminManageMachineProvider,
  private utilService: UtilService, private userService: UserService,
    private modalCtrl: ModalController) {
    this.selectionData = this.userService.getUserSelection();
    this.shiftList = [];
  }

  ionViewDidEnter() {
    this.retrieveShiftForPlants();
  }

  private retrieveShiftForPlants(){
     // retrive the shifts from the server
            this.adminManageMachinesService.getShiftsForPlant(this.selectionData.selPltId).subscribe((response)=>{
                if(this.utilService.checkValidData(response)){
                        this.shiftList = response.Response;
                    } else{
                        this.utilService.showToast("","Shifts are yet to be added to the system for your plant!");
                    }
            });
  }


  public removeSelectedShift(shift:string){
      //DeleteShiftForPlant
      this.adminManageMachinesService.deleteShiftFromPlant(this.selectionData.selPltId, shift, this.selectionData.selPGId).subscribe((response)=>{
                if(this.utilService.checkValidData(response)){
                     this.retrieveShiftForPlants(); 
                }
      });
  }

 public addNewShift():void{
                let popover = this.popoverCtrl.create(SelectionPage,{
                                    "isMandatory":"false",
                                    "isFromPage":"addNewShift",  
                                    "isPopOverCtrl":"true",                                  
                                    "updateUserSelectionData":"false",
                                    "pageTitle":"Add Shift",
                                     "userSelectionData": this.selectionData,
                    "userPrivileges":new UserSelectionPrivileges(false, false, false, false, false, false, 
                                                                 false, false, false, false, false, false, false,
                                                                 false, false, false, false, false, false, false, 
                                                                 false, false) });
                    popover.present();
                    popover.onDidDismiss((data:UserSelectionData)=>{                                        
                                 this.retrieveShiftForPlants();                                      
                    });  
        }
}
