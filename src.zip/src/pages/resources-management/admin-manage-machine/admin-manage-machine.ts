import { Component} from '@angular/core';
import { NavController, ModalController, NavParams, PopoverController} from 'ionic-angular';
import { UserService } from '../../../providers/user-service';
import { UtilService } from '../../../providers/util-service';
import { AdminManageMachineProvider } from './admin-manage-machine-service';
import { UserSelectionData, UserSelectionPrivileges, UserObject, ResponseObject, UpdateMachineSequence } from '../../../models/QuestionItem';
import { Lot, Machine, Shift } from '../../../models/Level';
import { SelectionPage } from '../../selection/selection';
import { MachinesList } from '../../../models/QuestionItem';
import { HomePage } from '../../home/home';
import  { TranslateService }  from 'ng2-translate';

@Component({
  selector: 'admin-manage-machines-page',
  templateUrl: 'admin-manage-machine.html'
})


export class AdminMachines {  
    machinesList:Array<MachinesList> = [];
    machinesListInitial:Array<MachinesList> = [];
    selectionData:UserSelectionData;
    shiftList:Array<string>;
    public optionView:string;
    public reorderMachines:boolean;
    public buttonSel:string;
    constructor(public navCtrl: NavController,private popoverCtrl: PopoverController, 
    public navParams: NavParams,private utilService: UtilService, private userService: UserService, private translate: TranslateService, 
    private modalCtrl: ModalController, private adminManageMachinesService:AdminManageMachineProvider){
        this.selectionData = this.userService.getUserSelection();
        this.selectionData.selActive = "2";
        this.optionView = "machine";
        this.shiftList = [];
        this.buttonSel = '';
        this.reorderMachines = false;
    }  

    trackByItem(index, item){
        return item.machineId;
    }

    getAllMachinesForPlant(){ 
        /*@plantId as int = 0,  -- 0 = for all plant, !== 0 a specific plant
        @procId as int = 0,		 -- 0 = for all process, !== 0 a specific process
        @ActiveFlag as int = 1   --  2= All, 1 = Active, 0 = inactive   */

        if(this.selectionData.selActive ===""){
            this.selectionData.selActive = "2";
        }
        if(this.selectionData.selPltId !== 0  && (this.selectionData.selActive !=="" &&  this.selectionData.selActive !=="select") &&
            this.selectionData.selPrId !== undefined){
            this.machinesList = [];
            this.adminManageMachinesService.getMachinesFromServer(this.selectionData.selPltId, this.selectionData.selActive
                ,this.selectionData.selPrId, false,this.selectionData.selPGId).subscribe((data)=>{
                if(this.utilService.checkValidData(data)){
                    this.machinesList = this.machinesList.concat(data);
                    this.machinesListInitial = this.machinesListInitial.concat(data);
                } else{
                    this.utilService.showToast("","Machines are yet to be added to the system for your plant!");
                }                    
        });
            this.adminManageMachinesService.getMachinesFromServer(this.selectionData.selPltId, this.selectionData.selActive
                ,0, false,1).subscribe((data)=>{
                if(this.utilService.checkValidData(data)){
                    this.machinesList = this.machinesList.concat(data);
                    this.machinesListInitial = this.machinesListInitial.concat(data);
                } else{
                    this.utilService.showToast("","Machines are yet to be added to the system for your plant!");
                }                    
            });           
        }                  
    }
    ionViewDidEnter(){
        this.getAllMachinesForPlant();
    }
    private searchMachinesInPlant():void{
        let popover = this.modalCtrl.create(SelectionPage,{"isMandatory":"false",
                        "isPopOverCtrl":"true", 
                        "isFromPage":"addNewMachine", "updateUserSelectionData":"true","pageTitle":"Search Machines",
                        "isSearchMachine":"true",
        "userPrivileges":new UserSelectionPrivileges(false,false,false,true,false,false, false, false, 
        false, false, false, false, false, false,false, false, false, false, false, false, true, false), 
        "userSelectionData": this.selectionData },{
            enableBackdropDismiss:false,
        });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData)=>{
            if(data){
                this.selectionData = data
            this.getAllMachinesForPlant();
            }                
        }); 
    }
    public navigateToHome():void{
        this.navCtrl.setRoot(HomePage);
    }
    public editMachine(item:MachinesList){
        let selData = Object.assign({}, this.selectionData);
        selData.selPrId = +item.procId;
        selData.selPrName = item.procDesc;
        selData.machine = new Machine(item.machineId.toString(), item.machineNum, item.procDesc, JSON.parse(item.isActive));
            let popover = this.modalCtrl.create(SelectionPage,{
                            "isMandatory":"false",
                            "isFromPage":"addNewMachine",
                            "isPopOverCtrl":"false",
                            "isEditMachine":"true",
                            "machineInfoObject":item,
                            "isSearchMachine":"false", 
                            "updateUserSelectionData":"true",
                            "pageTitle":"Manage Machine",
            "userPrivileges":new UserSelectionPrivileges(false,false,true,false,false,false, false, false, 
            false, false, false, false, false, false,false, false, false, false, false, false, false, false), 
            "userSelectionData": selData },{
                enableBackdropDismiss:false,
            });
            popover.present();
            popover.onDidDismiss((data:UserSelectionData)=>{
            // if(data !== undefined){                
            this.getAllMachinesForPlant();
                //}                
            });
    }
    addNewMachine(){
        const selData = Object.assign({},this.selectionData);
        let popover = this.modalCtrl.create(SelectionPage,{
                        "isMandatory":"false",
                        "isFromPage":"addNewMachine",
                        "isPopOverCtrl":"false",
                        "isSearchMachine":"false",
                        "isEditMachine":"false",
                        "machineInfoObject":{}, 
                        "updateUserSelectionData":"true",
                        "pageTitle":"Create Machine",
        "userPrivileges":new UserSelectionPrivileges(false,false,true,false,false,false, false, false, 
        false, false, false, true, false, false,false, false, false, false, false, false, true, false), 
        "userSelectionData": selData },{
            enableBackdropDismiss:false,
        });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData)=>{
        // if(data !== undefined){                
                        this.getAllMachinesForPlant();
            //}                
        }); 
    }
    reorderMachinesToggle(){
    console.log(this.reorderMachines + " - reorder machines");
    }

    reorderMachinesChange(indexes) {

        let element = this.machinesList[indexes.from];
        this.machinesList.splice(indexes.from, 1);
        this.machinesList.splice(indexes.to, 0, element);
        this.buttonSel = 'save_changes';
    }
    getSearchItems(ev:any){
        let val = ev.target.value;
        this.machinesList = Object.assign([], this.machinesListInitial);
        // if the value is an empty string don't filter the items
        if (val && val.trim() != '') {
        this.machinesList = this.machinesList.filter((item:MachinesList) => {
            return (item.machineNum.toLowerCase().indexOf(val.toLowerCase()) > -1 || 
                    item.plantName.toLowerCase().indexOf(val.toLowerCase()) > -1 || 
                    item.plantId.toString().toLowerCase().indexOf(val.toLowerCase()) > -1 || 
                    item.isActive.toString().toLowerCase().indexOf(val.toLowerCase()) > -1);
        });
        }
    }
   
    public searchMachinesCancelClicked(){
    this.machinesList = Object.assign([], this.machinesListInitial);    
    }
    saveChangesButtonClicked(){
                const wLogin = this.selectionData.wLogin;
            let updateMachineSequenceArray:Array<UpdateMachineSequence> = this.machinesList.reduce((prev, item, i)=>{
                    prev.push(new UpdateMachineSequence(item.machineId, i+1, wLogin));
                return prev;
            },[]);
           
          this.adminManageMachinesService.updateMachineSequence(updateMachineSequenceArray).subscribe((response:ResponseObject)=>{
                if(this.utilService.checkValidData(response)){
                     this.utilService.showToast("","Successfully updated the machines sequence!");
                     this.buttonSel = '';
                }
          });   
    }       
}