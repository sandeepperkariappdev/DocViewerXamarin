import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { AppSettings, MethodConstants } from '../../../constants/AppSettings';
import { CallService} from '../../../providers/call-service';
import { UtilService} from '../../../providers/util-service';
import {Machine} from '../../../models/Level'
import {MachinesList, CreatePlantShift, CreatePlantMachine, UpdatePlantMachine, RequestUpdateMachineSequence, UpdateMachineSequence, UpdateProcessForMachine} from '../../../models/QuestionItem';
/*
  Generated class for the AdminManageMachineProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class AdminManageMachineProvider {

  constructor(public http: Http,
  private utilSer:UtilService,
  private callService:CallService) {
    
  }
 public getMachinesFromScheduledAudits(plantId:number, processId:number, levelId:number, startDate:string, endDate:string){
      if(plantId!== 0 && processId!== undefined && levelId!== undefined && startDate!=="" && endDate!==""){
          //http://ahdeviis01/LPADevServices/api/ScheduledMachines/getMachinesFromScheduledAudits?plantId=1&processId=1&levelId=1&startDate=01/01/2000&endDate=12/30/2017
           const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetMachinesFromScheduledAudits+"plantId="+plantId+"&processId="+processId+"&levelId="+levelId+"&startDate="+startDate+"&endDate="+endDate);
            return this.callService.callServerForGet(url);
      }  else{
        console.log("error");
      }  
  } 

  public getListOfMachines(plantId:number,  activeFlag:string,  processId:number, onlyMachines:boolean, pgNum:number){  
/*@plantId as int = 0,  -- 0 = for all plant, !== 0 a specific plant
	@procId as int = 0,		 -- 0 = for all process, !== 0 a specific process
	@ActiveFlag as int = 1   --  2= All, 1 = Active, 0 = inactive   */
    if((plantId !== undefined) && (activeFlag !== undefined ) && (processId !== undefined)){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.ListOfMachinesfromPlants+"plantId="+plantId+"&procId="+processId+"&activeFlag="+activeFlag+"&pgNum="+pgNum);
        if(onlyMachines){
            return this.callService.callServerForGet(url).map((data)=>{
              if(this.utilSer.checkValidData(data)){              
                let response = data.Response;
                  return response.reduce((prev, item, index)=>{
                              prev.push(new Machine(item.machineId.toString(),item.machineNum, item.procDesc,true));
                            return prev;
                  },[]);
              }
            });  
        } else{
            return this.callService.callServerForGet(url);
        }          
    } else{
      console.error('values cannot be null');
    }
  }

  public getMachinesFromServer(plantId:number,  activeFlag:string,  processId:number, onlyMachines:boolean, pgNum:number){  
    /*@plantId as int = 0,  -- 0 = for all plant, !== 0 a specific plant
      @procId as int = 0,		 -- 0 = for all process, !== 0 a specific process
      @ActiveFlag as int = 1   --  2= All, 1 = Active, 0 = inactive     */
        if((plantId !== undefined) && (activeFlag !== undefined ) && (processId !== undefined)){
            const url =  (AppSettings.API_ENDPOINT + MethodConstants.ListOfMachinesfromPlants+"plantId="+plantId+"&procId="+processId+"&activeFlag="+activeFlag+"&pgNum="+pgNum);
            if(onlyMachines){
                return this.callService.callServerForGet(url).map((data)=>{
                  if(this.utilSer.checkValidData(data)){              
                    let response = data.Response;
                      return response.reduce((prev, item, index)=>{
                                  prev.push(new Machine(item.machineId.toString(),item.machineNum, item.procDesc,true));
                                return prev;
                      },[]);
                  }
                });  
            } else{
                return this.callService.callServerForGet(url).map((data)=>{
                  if(this.utilSer.checkValidData(data)){              
                    return data.Response.reduce((prev, item, index)=>{
                                  prev.push(new MachinesList(item.machineId,item.machineNum, item.plantName, item.plantId, 
                                    item.procDesc, item.procId, item.swiPath, item.dateModified, item.isActive,((item.swiPath !== undefined && item.swiPath.length > 10) ? 'Yes' : 'No'), (item.isActive ? 'Yes' : 'No')));
                                return prev;
                      },[]);
                  }
                });;
            }          
        } else{
          console.error('values cannot be null');
        }
      }

  public addNewMachinesToPlant(data:CreatePlantMachine){      
    if(data !== undefined){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.AddNewMachineToPlant);
      return this.callService.callServerForPost(url,"",data);
    } else{
      console.error('values cannot be null');
    }
  }
  public updateProcessForMachine(data:UpdateProcessForMachine){      
    if(data !== undefined){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.UpdateProcessForMachine);
      return this.callService.callServerForPost(url,"",data);
    } else{
      console.error('values cannot be null');
    }
  }
  public updateMachineSequence(data:Array<UpdateMachineSequence>){
        const reqData = new RequestUpdateMachineSequence(data);
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.UpdateMachineSequence);
        return this.callService.callServerForPost(url,"",reqData);
  }
   public updatePlantMachine(data:UpdatePlantMachine){      
    if(data !== undefined){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.UpdateMachineToPlant);
        return this.callService.callServerForPut(url,"",data);
    } else{
      console.error('values cannot be null');
    }
  }
public addNewShiftToPlant(data:CreatePlantShift){
      const url =  (AppSettings.API_ENDPOINT + MethodConstants.postShiftForPlant);       
      return this.callService.callServerForPost(url,"",data);
//
}
public getShiftsForPlant(plantId:number){  
  const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetShiftForPlant+"plantId="+plantId);       
  return this.callService.callServerForGet(url,"");
}
  public deleteMachineFromPlant(plantId:number,  activeFlag:string,  processId:number){  
    
    if((plantId !== undefined) && (activeFlag !== undefined ) && (processId !== undefined)){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.ListOfMachinesfromPlants+"plantId="+plantId+"&activeFlag="+activeFlag+"&procId="+processId);
      return this.callService.callServerForGet(url);
    } else{
      console.error('plantId !==0  processId !== 0 values cannot be null');
    }
  }

   public deleteShiftFromPlant(plantId:number, shift:string, pgNum:number){      
    if((plantId !== undefined) && (shift !== undefined)){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.DeleteShiftForPlant+"plantId="+plantId+"&shift="+shift+"&pgNum="+pgNum);
      return this.callService.callServerForGet(url);
    } else{
      console.error('plantId !==0  processId !== 0 values cannot be null');
    }
  }
}
