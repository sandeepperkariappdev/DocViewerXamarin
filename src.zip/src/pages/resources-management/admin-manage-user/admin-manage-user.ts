import { Component} from '@angular/core';
import { IonicPage, NavController, NavParams,ModalController, PopoverController } from 'ionic-angular';
import { UsersInPlant, UserSelectionData, UserSelectionPrivileges, UserObject, ResponseObject, PlantUsers, UsersForPlant }  from '../../../models/QuestionItem';
import { UserService }  from '../../../providers/user-service';
import { Privileges }  from '../../../providers/privileges';
import { UtilService }  from '../../../providers/util-service';
import { SelectionPage } from '../../selection/selection';
import { Role }  from '../../../models/level';
import { User }  from '../../../models/User';
import { UserDetailsResponse} from '../../../models/UserDetailsResponse';
import { UserAssignmentsPage } from "../../user-assignments/user-assignments";
import { Lot, Machine, Shift } from '../../../models/Level';
import * as _ from 'lodash';
import { HomePage } from '../../home/home';

/**
 * Generated class for the AdminManageUser page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-admin-manage-user',
  templateUrl: 'admin-manage-user.html',
})
export class AdminManageUser  {
    private shownGroupas = null;//to show or hide used for accordion
    private rolesList:Array<Role>;    
    public usersList:Array<PlantUsers>;
    private initialUsersList:Array<PlantUsers>;
    private selectionData:UserSelectionData;
    private showAddNewUser:boolean;
    private isCreateNewUser:boolean;
    private isAddPlantsToUser:boolean;
    public isPlantAdmin:boolean;
    public isSuperAdmin:boolean;
    private user :User;
    constructor(public navCtrl: NavController, 
                private popoverCtrl:PopoverController,
                private userService: UserService,
                private privileges:Privileges, 
                private modalCtrl:ModalController,
                private utilService:UtilService){                  
                  
                  this.showAddNewUser = false;                  
                  this.user = this.userService.getUser();//setting the user for this page                    
                  this.isPlantAdmin = this.user.roleId === 3; 
                  this.isSuperAdmin = this.user.roleId === 1; 
                  
                  const privPage = this.privileges.getPageObject(this.user.roleName,"Admin")["UsersTab"];
                  this.isCreateNewUser = privPage["isCreateNewUser"] === "true";
                  this.isAddPlantsToUser = privPage["isAddPlantsToUser"] === "true";
    } 

   ionViewWillEnter(){
     this.loadDataFromService();
   }   

    private loadDataFromService(){
      this.selectionData = this.userService.getUserSelection();   
          const user = this.userService.getUser(); 
          const pagePriv = this.privileges.getPageObject(user.roleName,"Admin")["UsersTab"];
          if(pagePriv){
              this.showAddNewUser = pagePriv["showAddNewUser"] === "true";
              const isForAllPlants = pagePriv["showAllPlants"] === "true";
              const plantId = isForAllPlants ? 0 : this.selectionData.selPltId; 
              const pgNum =  isForAllPlants ? 0 : this.selectionData.selPGId; 
                this.userService.retrieveUsersByPlant(plantId, pgNum).subscribe((data:ResponseObject)=>{
                  if(this.utilService.checkValidData(data)){
                    if(this.selectionData.selRoleId.toString() === "1"){
                          const that = this;
                          const usrList = new Array(new PlantUsers(0,"",0,"",0,"",that.modifyResponseFormat(data.Response)));
                          this.usersList = usrList;
                          this.initialUsersList =  usrList;         
                    } else{
                        this.usersList = data.Response;                  
                        this.initialUsersList =  data.Response;                          
                    }                     
                  }                    
                });
                this.rolesList = this.utilService.getAllRoles();
          }
    }

    private modifyResponseFormat(response:Array<PlantUsers>):Array<UsersForPlant>{
      if(response !== undefined){
          return response.reduce((prev, item)=>{                          
              prev = prev.concat(item.users);
              return _.uniqBy(prev, "userId");
            },[]);
      } else{
       return [];
      }        
    }

    private getUserDetails(index:number,userItem:UsersForPlant, plantId:number, plantName:string,  pgId:number, pgName:string, opId:number, opName:string):void{     
      let selData:UserSelectionData = Object.assign({},this.selectionData);
      selData.selRoleId = userItem.roleId;
      
      selData.selOpId = opId;
      selData.selOpName = opName;
      selData.selPltName = plantName;
      selData.selPltId = plantId;
      selData.selPGId = pgId;
      selData.selPGName = pgName;
      selData.selCertified = userItem.certified.toString();
      selData.wLogin = userItem.wLogin;
      selData.selEmail = userItem.email; 
      selData.selFirstName = userItem.firstName;
      selData.selLastName = userItem.lastName;
      selData.shift.name = userItem.shift.toString();     
      if(userItem.wLogin !== ""){
        this.adminManageUser(true, true, selData, userItem.wLogin,userItem.active);  
      }      
    }
    private adminManageUser(isExistingUser:boolean, useSelectionDataSent:boolean, selectionData:UserSelectionData, wLogin:string, active:boolean){
     // if(active){      
          this.userService.getAllUserFromService(wLogin).subscribe((data:UserDetailsResponse) => { 
                selectionData.auditor = new UserObject(data.userId, data.firstName+","+data.lastName);
                selectionData.selFirstName = data.firstName;
                selectionData.selLastName = data.lastName;
                selectionData.selRoleId = data.roleId;
                selectionData.selRoleName = data.roleName;
                selectionData.selActive = data.active.toString();
                selectionData.selCertified = data.certified.toString();
                selectionData.selLevelId = data.levelId;
                selectionData.selLevelName = data.levelName;
                selectionData.selEmail = data.email;
                selectionData.selPGId = data.pgId || 0;
                selectionData.selPGName = data.pgName || "";
                selectionData.selLangCode = data.languageCode;   
                selectionData.wLogin = data.wLogin;   
                selectionData.selEmail = data.email;                                        
                let userPrivilegesObj;
                //selectionData.shift.id = data.sel
                // Super Admin
                if(this.user.roleId === 1){                  
                    userPrivilegesObj = new UserSelectionPrivileges(true,true,false,false,
                                                false,true, true, false, false, false, false,
                                                false, false, false,true, true, true, false, true, false, false, false);
                } else if(this.user.roleId === 3){
                // Plant Admin
                    userPrivilegesObj = new UserSelectionPrivileges(true,true,false,false,
                                                true,false, true, false, false, false, false,
                                                false, false, false,false, false, false, false, false, false, false, false);  

                    } else if(this.user.roleId === 2){                                          
                      // Corp Admin
                    userPrivilegesObj = new UserSelectionPrivileges(true,true,false,false,
                                                false,false, true, false, false, false, false,
                                                false, false, false,false, false, false, false, false, false, false, false);
                    }

                let modal = this.modalCtrl.create(SelectionPage, {
                                                "isMandatory":"false",
                                                "exitWithOutSave":"true",
                                                "isFromPage":"manageUser",
                                                "isAddPlantsToUser":this.isAddPlantsToUser.toString(),
                                                "useSelectionDataSent":useSelectionDataSent,
                                                "pageTitle":""+ data.firstName+" "+data.lastName,
                                                "isEditData":"true",
                                                "availPlants":data.plants,
                                                "isExistingUser":isExistingUser.toString(),
                                                "userPrivileges":userPrivilegesObj,
                                                "userSelectionData": selectionData}, {enableBackdropDismiss:false});
                  modal.onDidDismiss(() => {   
                    // reloading the data
                      this.loadDataFromService();                                                                              
                  });
                  modal.present();
          });
      // } else{
      //   this.utilService.showToast("","User is not active in the system");
      // }          
    }
    public navigateToHome():void{
       const user = this.userService.getUser();//setting the user for this page
        const page = this.privileges.getPageObject(user.roleName,"SideMenu");
        const isHomeTab = page["Home"]["thisShow"];
        if(isHomeTab === "true"){
            this.navCtrl.setRoot(HomePage);
        }        
   }
   private openSelectionPopOver(isExistingUser:boolean, useSelectionDataSent:boolean, selectionData:UserSelectionData){
        let modal = this.modalCtrl.create(SelectionPage, {
        "isMandatory":"false",
        "exitWithOutSave":"true",
        "isFromPage":"addNewUser",
        "useSelectionDataSent":useSelectionDataSent,
        "pageTitle":"Manage User",
        "isCreateNewUser":this.isCreateNewUser.toString(),
        "isAddPlantsToUser":"false",//this.isAddPlantsToUser.toString(),
        "isExistingUser":isExistingUser.toString(),
        "userPrivileges":new UserSelectionPrivileges(true,true,false,false,
        true,true, true, false, false, false, false,
        false, false, false,true, true, true, false, true, false, false, false),
        "userSelectionData": selectionData},{enableBackdropDismiss:false});
          modal.onDidDismiss(() => {
                  // reloading the data
                      this.loadDataFromService();     
          });
          modal.present();
   }
   private addNewUser():void{
      this.openSelectionPopOver(false, false, this.selectionData);
   }
   showAssignedFailureCodes(userId:number, levelId:number){
      let modal = this.modalCtrl.create(UserAssignmentsPage,{"self":"true","isFromPage":"usersInPlant","getShowTab":"0", "userId":userId,"levelId":levelId});
      modal.onDidDismiss(() => {
                    
      });
      modal.present();
   }
  ionViewDidLoad() {
    
  }
  searchUsersCancelClicked(){
     this.usersList = this.initialUsersList;
  }

  getSearchItems(ev:any){
    let val = ev.target.value;
    //if(val.trim() === ''){
    if(this.initialUsersList !== undefined){
      this.usersList = this.initialUsersList;  
    }      
    //}
    
    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      this.usersList = this.usersList.reduce((prev, plant) => {        
        if((plant.plantName !== undefined && plant.plantName.toLowerCase().indexOf(val.toLowerCase()) > -1) || 
          (plant.pgName  !== undefined && plant.pgName.toLowerCase().indexOf(val.toLowerCase()) > -1)){
            prev.push(plant.plantId, plant.plantName, plant.opId, plant.opName, plant.pgId, plant.pgName, plant.users);           
        } else{                    
              let item :Array<UsersForPlant> = [];
              if(plant.users.length > 0){
                  item = plant.users.reduce((pv, user)=>{
                  if(user.firstName.toLowerCase().indexOf(val.toLowerCase()) > -1 || 
                        user.lastName.toLowerCase().indexOf(val.toLowerCase()) > -1 || 
                        user.wLogin.toLowerCase().indexOf(val.toLowerCase()) > -1){                
                              pv.push(user);                  
                        };                    
                return pv;
                }, []);
              }
              prev.push(new PlantUsers(plant.plantId, plant.plantName, plant.opId, plant.opName, plant.pgId, plant.pgName, item));  
        }
                 
          return prev;            
      }, [])
    }
  }
toggleGroup(group) {
      if (this.isGroupShown(group)) {
          this.shownGroupas = null;
      } else {
          this.shownGroupas = group;
      }
    };

    isGroupShown(group) {
        return this.shownGroupas === group;
    };

}
