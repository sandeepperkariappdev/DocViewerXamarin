import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController ,PopoverController, ModalController } from 'ionic-angular';
import { AdminManageFailureCodesService } from './admin-manage-failure-codes-service';
import { CreateFailureCode } from '../../models/QuestionItem';
import { Language, Category, Lot, Machine, Shift } from '../../models/Level';
import { UtilService }  from '../../providers/util-service';
import { UserService }  from '../../providers/user-service';
import { SelectionPage } from '../selection/selection';
import { CreateFailureCodePage }  from "../create-failure-code/create-failure-code";
import { UserSelectionData,ResponseObject,AuditDetailsFailureCode, Question, FailureCode, FailureCodeItem, FailureCodesList, LanguagesFailCodesList } from '../../models/QuestionItem';
import { User } from '../../models/User';
import * as _ from 'lodash';

//TODO Add select All to select all the check boxes

/**
 * Generated class for the AdminManageFailureCodesPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-admin-manage-failure-codes',
  templateUrl: 'admin-manage-failure-codes.html',
})
export class AdminManageFailureCodesPage implements OnInit{

  private languagesList:Array<Language>;// for language checkbox List
  private catList:Array<Category>;// for categories checkbox List
  private onLanguageSelected:boolean;
  private selLangQue:string = 'all';
  private shownGroupas = null;//to show or hide used for accordion
  private shownDetailsGroupas = null;
  private showCatTextInput:boolean;
  private selLanguage = {id:'all'};// for language checkbox modal
  private selCategories = {id:'select'};// for categories checkbox modal
  private selActive = {name:'select'};// for categories checkbox modal  
  private isRequestedQue:boolean;
  private createCategories = {name:''};
  private failCodesResponse:Array<LanguagesFailCodesList>;
  private failCodesList:Array<FailureCodesList>;
  private failCodesListDup:Array<FailureCodesList>;
  private failCodesItemsList:FailureCodeItem ;
  private user:User;
  private auditFailCodesList:Array<AuditDetailsFailureCode>;
  private auditFailCodesListInitial:Array<AuditDetailsFailureCode>;
  private showActive:boolean;
  private isFromAnotherPage:boolean;
  private sortFCList : boolean;
  private isShowAddNewFC : boolean;
  private userSelectionData:UserSelectionData;
  public isEditFc:boolean;
  constructor(private navCtrl: NavController,
              private utilService : UtilService,
              private userService : UserService,              
              private popoverCtrl : PopoverController,              
              private viewCtrl : ViewController,              
              private modalCtrl : ModalController,
              private failureCodesService: AdminManageFailureCodesService, 
              private navParams: NavParams) {
                this.showActive = true;
                this.isFromAnotherPage = false;
                this.sortFCList = false;
                this.isShowAddNewFC = true;
                this.failCodesList = [];
                this.isEditFc = false;
  }

  ionViewDidLoad() {
    
  }
  ngOnInit(){
        const navParams = this.navParams.data;
        if(navParams && navParams.isFromPage){
            this.isFromAnotherPage = true;
            this.isShowAddNewFC = true;
        }
         
        if(this.isFromAnotherPage && navParams.isFromPage === "AssignFailureCodes"){
            if(navParams.availFCList !== undefined){                
                this.auditFailCodesList = navParams.availFCList;
                this.auditFailCodesListInitial = navParams.availFCList;
                this.sortFCList = true;       
                this.isShowAddNewFC= false;        
            }            
        }
      this.selActive.name = "all";
      this.user = this.userService.getUser();
      this.languagesList = this.utilService.getAllLanguages();
      this.catList = this.utilService.getAllcategories();   // TODO to load categories by only failure codes.
      this.selActive.name = "1";
      this.selCategories.id = "all";         
      this.selLanguage.id = this.user.languageCode; 
      if(!this.sortFCList){
        this.getFailureCodesList(this.selLanguage.id, this.selCategories.id, this.selActive.name, 0/*we need to show approved failure codes*/);
      }           
  }

  private getFailureCodesList(langCode:string, catId:string, blnAll:string, requested:number){
      const categoryId = catId === "select" || catId === "all"  ? 0 : catId;
      const isActive = blnAll === "select" || blnAll === "all"  ? 2 : blnAll;
      this.failureCodesService.getFailCodesListByLangCat(langCode, +categoryId, +isActive , requested).subscribe((data:ResponseObject)=>{
          if(this.utilService.checkValidData(data)) {
              this.failCodesResponse = data.Response;               
              this.onLanguageChange();
          } else{                          
              if(this.isFromAnotherPage){
                   this.viewCtrl.dismiss();
              }
          }
      });
  }
/*
  if(this.sortFCList){
                if(this.auditFailCodesList !== undefined && this.auditFailCodesList.length > 0){
                        this.failCodesList = this.failCodesList.reduce((prev, item)=>{
                            if(item.data[]){

                            }
                            return prev;
                        }, [])
                }
              }

const obj = item.data.reduce((prev, itm)=>{
                                        if(fcAvailArray.indexOf(itm.)){

                                        }
                                        prev.push(itm);
                                        return prev;
                                    }, [])*/
  private onLanguageChange(){       
      const fcAvailArray =   _.map(this.auditFailCodesList, "failCode");
      this.failCodesList = this.failCodesResponse.reduce((prev,item)=>{
                            if(this.selLanguage.id !== "select"){
                                if(item.lngCode = this.selLanguage.id){                                            
                                   prev = prev.concat(item.data);
                                }
                            }                            
                            return prev;
                          }, []);

    const fcLD = this.failCodesList;
    this.failCodesListDup = fcLD;
  }
  private cancelButtonClicked(){
      this.viewCtrl.dismiss();
  }
  private checkSelFailureCodes():Array<FailureCode>{
        return this.failCodesList.reduce((prev, item)=>{
                  const fc = item.failureCodes.reduce((p, i:FailureCodeItem)=>{
                      if(i.isAlloted){
                            p.push(new FailureCode(0,0,0,i.failCode,item.failCatId,i.failDesc, i.failCodeHelp, i.failActive,item.failCatName));
                      }                      
                    return p;
                  },[])
                  prev = prev.concat(fc);
              return prev;
        }, [])
  }
  private checkSelFailureCodesFrmAuditsFC():Array<AuditDetailsFailureCode>{
        return this.auditFailCodesList.reduce((prev, item)=>{                  
                      if(item.isAlloted){
                            prev.push(item);      
                        }                                  
                    return prev;
                }, [])
  }
  private doneButtonClicked(){
      let selFailureCodesList ;
      if(!this.sortFCList){
            selFailureCodesList = this.checkSelFailureCodes();
      } else{
            selFailureCodesList = this.checkSelFailureCodesFrmAuditsFC();
      }
      
      if(selFailureCodesList !== undefined && selFailureCodesList.length > 0){
          this.viewCtrl.dismiss(selFailureCodesList);
      } else{
        this.utilService.showToast("","Failure Codes yet to be selected.");
      }
  }
  private onActiveSelChange(){
      this.getFailureCodesList(this.selLanguage.id, this.selCategories.id, this.selActive.name, 0);
  }
  private onCategoryChange(){
      this.getFailureCodesList(this.selLanguage.id, this.selCategories.id, this.selActive.name, 0);
  }
  private changeSearchSelection(){
     //this.showUserSelectionPopUp(true,this.userSelectionData, new UserSelectionPrivileges(false,));
  }

  private toggleGroup(group) {
    if (this.isGroupShown(group)) {
        this.shownGroupas = null;
    } else {
        this.shownGroupas = group;
    }
  };

  private isGroupShown(group) {
    return this.shownGroupas === group;
  };

  private toggleDetailsGroup(group, fcItem :FailureCodeItem, fcCatId:string) {
      if(!this.isEditFc){
            if (this.isGroupDetailsShown(group)) {
                this.shownDetailsGroupas = null;
            } else {
                this.shownDetailsGroupas = group;
            }
      } else{
        let modal = this.modalCtrl.create(CreateFailureCodePage, 
                                        {"isFromPage": "adminManageFailureCodes", 
                                        "failureCodeUpdate":new CreateFailureCode(fcItem.failCode,fcCatId,fcItem.failActive,false,
                                        fcItem.failRequestedBy,false,this.selLanguage.id,fcItem.failCodeHelp, fcItem.failDesc)}); 
        modal.onDidDismiss((data:Array<CreateFailureCode>)=>{ // question object is returned from the model window.
            if(data !== undefined){// return the array of Failure Code Objects
                this.failureCodesService.CreateFailureCodes(data).subscribe((response)=>{
                    if(this.utilService.checkValidData(response)){
                        this.getFailureCodesList(this.selLanguage.id, this.selCategories.id, this.selActive.name, 0);
                    }
                })
            }            
        });                                        
        modal.present(); 
      }    
  };

  private isGroupDetailsShown(group) {
    return this.shownDetailsGroupas === group;
  };

    private addFailureCodeClick(item:Question){
        let modal = this.modalCtrl.create(CreateFailureCodePage, {"isFromPage": "adminManageFailureCodes"});
        modal.onDidDismiss((data:Array<CreateFailureCode>)=>{ // question object is returned from the model window.
            if(data !== undefined){// return the array of Failure Code Objects
                this.failureCodesService.CreateFailureCodes(data).subscribe((response)=>{
                    if(this.utilService.checkValidData(response)){
                        this.getFailureCodesList(this.selLanguage.id, this.selCategories.id, this.selActive.name, 0);
                    }
                })
            }            
        });
        modal.present();
    }
    private buildFailureCodesItemsList(data:Array<CreateFailureCode>){
        return data.reduce((prev, item, index)=>{
            //prev.push(new CreateFailureCode(item.failCode,item));
            return prev;
        },[])
    }

    public searchCancelClicked(){
         if(this.sortFCList){
            this.auditFailCodesList = this.auditFailCodesListInitial;
        } else{
            this.failCodesList = this.failCodesListDup;  
        }        
    }
     // Searching the quesions and failure code on the inputs entered.
    private getSearchItems(ev:any){
        let val = ev.target.value;
        if(val && val.trim() !== ''){
            if(this.sortFCList){
                    this.auditFailCodesList =  this.auditFailCodesList.reduce((prev, item)=>{
                                                        if(((item.failDesc !== "" && item.failDesc !== null) ? (item.failDesc.toLowerCase().indexOf(val.toLowerCase()) > -1): false) ||
                                                                ((item.failCodeHelp !== "" && item.failCodeHelp !== null) ?(item.failCodeHelp.toLowerCase().indexOf(val.toLowerCase()) > -1):false)){
                                                                prev.push(item);  
                                                        } else{
                                                            item.question = item.question.reduce((prv, i)=>{
                                                                if((i.queHelp !=="" ? (i.queHelp.toLowerCase().indexOf(val.toLowerCase()) > -1) : false) ||
                                                                    (i.queDesc !=="" ? (i.queDesc.toLowerCase().indexOf(val.toLowerCase()) > -1): false)){
                                                                        prv.push(item);  
                                                                }       
                                                                return prv;
                                                            },[]);
                                                            if(item.question.length >0){
                                                                prev.push(item);
                                                            }
                                                        }
                                                        return prev;
                                                    },[]);
            } else{   
                this.failCodesList = this.failCodesListDup;       
                
               this.failCodesList  = this.failCodesList.reduce((prev, catItem:FailureCodesList) =>{                   
                    let itm:Array<FailureCodeItem> = catItem.failureCodes.reduce((prv:Array<FailureCodeItem>, i:FailureCodeItem) => {     
                            if(((i.failDesc !== "" && i.failDesc !== null) ? (i.failDesc.toLowerCase().indexOf(val.toLowerCase()) > -1) : false) ||
                                ((i.failCodeHelp !== "" && i.failCodeHelp !== null) ? (i.failCodeHelp.toLowerCase().indexOf(val.toLowerCase()) > -1) : false)){
                                prv.push(i);
                            }                   
                        return prv;
                    }, []);
                    if(itm.length > 0){
                        let x:FailureCodesList =  new FailureCodesList( catItem.failCatId, catItem.failCatName, itm);                                     
                        prev = prev.concat(x);
                    }                                
                    return prev;
                },[]);
            }
        }        
    }
selectAllClicked(){
    this.auditFailCodesList = this.auditFailCodesList.reduce((prev, item)=>{
        item.isAlloted = true;
        prev.push(item);
        return prev;
    }, []);
}
    searchFCCancelClicked(){
          if(this.sortFCList){

          } else{

          }
    }
    editButtonClicked(){
        this.isEditFc = !this.isEditFc;

    }
}
