import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { CreateFailureCode } from '../../models/QuestionItem';
import { UtilService } from '../../providers/util-service';
import { UserService } from '../../providers/user-service';
import { CallService } from '../../providers/call-service';
import { AppSettings, MethodConstants } from '../../constants/AppSettings';
/*
  Generated class for the AssignFailureCodesServiceProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class AdminManageFailureCodesService {

  constructor(public http: Http, 
              private userService:UserService,
              private utilService : UtilService,
              private callService : CallService) {
  
  }
  /**
   * 
   * @param langCode == "" -- All Languages
   * @param catId  == 0 -- All Categories
   * @param blnAll ==  2 -- ALL -- 1 --ACTIVE, -- 0 --INACTIVE
   * @param requested == -- 2 = all, 1 - approved failure Code, 0 - requested failure Code
   */
  public getFailCodesListByLangCat(langCode:string, catId:number, blnAll:number, requested:number){
    if(this.utilService.itemDefined(langCode) && this.utilService.itemDefined(catId) && this.utilService.itemDefined(blnAll) && this.utilService.itemDefined(requested)){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetFailCodesListByLangCat+"langCode="+langCode +"&catId="+catId+"&blnAll="+blnAll+"&requested="+requested);
        return this.callService.callServerForGet(url); 
    } else{
      console.error(' values cannot be null.')
    }      
  }
  public CreateUpdateFailureCode(langCode:string, catId:number, blnAll:number, requested:number){
    if(this.utilService.itemDefined(langCode) && this.utilService.itemDefined(catId) && this.utilService.itemDefined(blnAll) && this.utilService.itemDefined(requested)){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetFailCodesListByLangCat+"langCode="+langCode +"&catId="+catId+"&blnAll="+blnAll+"&requested="+requested);
        return this.callService.callServerForGet(url); 
    } else{
      console.error(' values cannot be null.')
    }      
  }

  public getFailureCodeCateories(){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetFailureCodeCateories+"failureCdCatId=0");
        return this.callService.callServerForGet(url);     
  }
   public getPlantFailureCodeCateories(plantId:number){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetPlantFailCodeCat+"plantId="+plantId);
        return this.callService.callServerForGet(url);     
  }

  public CreateFailureCodes(data:Array<CreateFailureCode>){
    const wLogin = this.userService.getUser().wLogin;
        let request = { "wLogin": wLogin, "failureCodes":data };
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.CreateFailureCodes);
        return this.callService.callServerForPost(url,"", request);            
  }

}
