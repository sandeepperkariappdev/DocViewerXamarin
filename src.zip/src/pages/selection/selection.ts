import { Component, OnInit, Input,  } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, ModalController } from 'ionic-angular';
import * as _ from 'lodash';
import { Admin } from '../admin/admin';
import { Reports } from '../reports/reports';
import { HomePage} from '../home/home';
import {UtilService} from '../../providers/util-service';
import  { TranslateService }  from 'ng2-translate';
import {UserService} from '../../providers/user-service';
import {SearchUsersInPlant} from '../../popup-modals/search-users-in-plant/search-users-in-plant';
import {InitialDataService} from '../../providers/initial-data-service';
import { Level,Lot, Machine, Shift, Role, Language, ProductGroup, Operation, Process,Plant } from '../../models/Level';
import { CreateNewUser, UserSelectionData,AssignPlantsRequest, UserSelectionPrivileges,UpdatePlantMachine,
     PlantInfo,CreatePlantShift,CreatePlantMachine, AuditList, UserObject, MachinesList, ResponseObject, UserPlants, UpdateProcessForMachine } from '../../models/QuestionItem';
import { User } from '../../models/user';
import { AdminManageMachineProvider } from '../resources-management/admin-manage-machine/admin-manage-machine-service';
import {CalendarController} from "ion2-calendar";
import { SimpleChanges } from '@angular/core/src/metadata/lifecycle_hooks';



/**
 * Generated class for the SelectionPage page.
 * 
 * SelectionPage Model  
 *     Input Params:
 *            userPrivileges:UserSelectionPrivileges
 *            availList:Array<AuditList>;
 *            userSelectionData:UserSelectionData
 *      Output: UserSelectionData
 */

@Component({
  selector: 'page-selection',
  templateUrl: 'selection.html',
})
export class SelectionPage implements OnInit {
    private saveUserSelection:boolean;
    private pgList:Array<ProductGroup>;
    private plantpgList:Array<ProductGroup>;
    private opList:Array<Operation>;
    private prList:Array<Process>;
    private levelList:Array<Level>;
    private roleList:Array<Role>;
    private langaugeList:Array<Language>;
    private plantsList:Array<Plant>;
    private userPlantsList:Array<UserPlants>;
    private plantsListDup:Array<Plant>;
    private plantsInfoList:Array<PlantInfo>;
    private availPlantsList:Array<UserPlants>;
    private availPlantsListDup:Array<UserPlants>;
    private availPlantsInfoList:Array<UserPlants>;
    private lotList:Array<Lot>;
    private machinesList:Array<Machine>;
    private shiftList:Array<Shift>;
    private pageTitle:string;
    private exitWithOutSave:boolean;
    public addNewMachine:boolean;
    public addNewShift:boolean;    
    public isManageUser:boolean;
    private showSelection:UserSelectionPrivileges;
    private machineInputName = "";
    private shiftInputName = "";
    private swiPathInput = "";
    private swiPathInputErrorMessage = "";
    @Input() private swiPathServerInput = "";
    @Input() private swiPathFolderInput = "";
    @Input() private swiPathFileNameInput = "";
    public startDateTitle:string;
    private selPGId = { pgId : 'select', name:""};
    private selPlantPGId = { plantpgId : 'select', plantpgName:""};
    private selOpId = { opId : 'select', name:""};
    private selAvailPGId = { pgId : '', name:""};
    private selAvailOpId = { opId : '', name:""};
    private selPRId = { prcId : 'select', name:""};
    private selLevelId = { levelId : 'select'};
    private selRoleId = { roleId : 'select'}; 
    private selLngId = { langCode : 'select'};  
    private selPlantId = { plantId : "select", plantName:"" , pgId:"0", pgName:"" };
    // TODO Need to change the type of the Product Group
   // private selPlantId = new UserPlants(+"select","",[new ProductGroup(+"0","")])//{ plantId : "select", plantName:"" , pgId:"0", pgName:"" };
    public selUserPlant = { plantId : "select", plantName:"" , pgId:"0", pgName:"" };
    private selAvailPlantId = { Id : "select", name:"" };
    private selStDate = { stDate:""};
    private selEndDate = { endDate : ""};
    private selUser = { id : "0" , name:"select", wLogin:""};
    private selLot = { id:'0', name:'select' };
    private selMachine = new Machine('0', 'select', "", true);
    private selShift = { id:'0', name:'select' };
    private selAuditor = { id:'0', name:'select' }; 
    private selActive = {name:"select", id:"0"};    
    private selFirstName = { id : "0", name : "" };
    private selLastName = { id : "0", name : ""};
    private selwLogin = { id : "0", name:""};
    private selEmail = { id : "0", name :""};
    private selCertified = { id : "0", name : "select"};
    private selCommentsTextarea = "";    
    private useSelectionDataSent:boolean;
    private showLotInput:boolean;
    private showMachineInput:boolean;
    private showShiftInput:boolean;
    private isSearchMachine:boolean;
    private makeItActive:boolean;
    private showPGSelLabel:boolean;
    private showOPSelLabel:boolean;
    private showAvailPlantsSelLabel:boolean;
    private showAvailPGSelLabel:boolean;
    public deleteAssignedPlants:boolean;
    private showAvailOPSelLabel:boolean;
    private showMachineActiveToggle:boolean;
    private submitButtonTitle:string;    
    private isEditData:boolean;    
    private isDeleteAudit:boolean; 
    private isShowDeleteAudit:boolean;    
    private activeTitle:string;
    private plantTitle:string;
    // this is used to show IsActive Drop Down to populate the machiens list
    private isFromMachinesPage:boolean;
    private updateUserSelectionData:boolean;
    private isAddNewUser:boolean;
    private isNewUserCreateButton:boolean;
    private user:User;
    private usrPrvgs :UserSelectionPrivileges;
    private usrSeltn:UserSelectionData; 
    private createNewUserFlag:boolean;
    private initialUsrSelData : UserSelectionData;
    private showNotAvailSelection:boolean;
    private showCheckBoxNotAvailSel : boolean;
    private isPreferences : boolean;
    public isEditMachine : boolean;
    public isMultipleSelect : boolean;
    private availPrcList:Array<AuditList>;
    private translate:TranslateService;
    private selectMultipleMachines:boolean;
    public showDeletedAssignedPlants:boolean;
    public isOpenedPopOver:boolean;
    public showPlantProductGroup:boolean;
    public showUserPlants:boolean;
    public availPlantsListString:string;
    public swiSamplePath:string;
    private oldMachineName:string;
    public isAuditorActive:string;
  constructor(private navCtrl: NavController,
              private userService:UserService,
              private viewCtrl: ViewController,
              private navParams: NavParams,
              private translateService: TranslateService,
              private modalCtrl: ModalController, 
              private utilService: UtilService, 
              private calendarCtrl: CalendarController,
              private adminManageMachine: AdminManageMachineProvider,
              private initialDataService:InitialDataService) {
                this.selectMultipleMachines = true;
                this.useSelectionDataSent = false;
                this.isFromMachinesPage = false;   
                this.isSearchMachine = false;      
                this.showShiftInput = false;
                this.showCheckBoxNotAvailSel = false;
                this.showNotAvailSelection = false;  
                this.saveUserSelection = false;   
                this.submitButtonTitle = "Done";   
                this.updateUserSelectionData = false;
                this.makeItActive = false;  
                this.activeTitle= "Machine Active";                                                            
                this.isAddNewUser = false;
                this.createNewUserFlag = false;
                this.isNewUserCreateButton  = false;
                this.plantsList = [];
                this.plantsListDup = [];
                this.machinesList = [];
                this.lotList = [];
                this.prList = [];
                this.levelList = [];
                this.shiftList = [];
                this.showPGSelLabel = false;
                this.showOPSelLabel = false;
                this.plantsInfoList= [];
                this.showMachineActiveToggle = false;
                this.pageTitle = "Change Preference";
                this.plantTitle = "Plant";
                this.startDateTitle = "Start Date"
                this.isEditData = false;
                this.exitWithOutSave = false;
                this.isDeleteAudit= false;
                this.isShowDeleteAudit = false;
                this.isPreferences = false;
                this.addNewMachine = false;
                this.addNewShift = false;
                this.isManageUser = false;
                this.availPlantsList=[];
                this.availPlantsListDup=[];
                this.availPlantsInfoList=[];
                this.isOpenedPopOver = false;
                this.showAvailPlantsSelLabel = false;
                this.isEditMachine = false;
                this.deleteAssignedPlants = false;
                this.showDeletedAssignedPlants = false;
                this.showPlantProductGroup = false;
                this.showUserPlants = false;
                this.plantpgList = [];
                this.userPlantsList = [];
                this.availPlantsListString = "";
                this.isMultipleSelect = true;        
                this.isAuditorActive = "true";       
                this.swiSamplePath= "//<serverName>/<folderName>/<fileName>.extn";                
  }

  ngOnInit(){
      try{
      
        this.translate = this.translateService;
        this.translate.get(['change_pref']).subscribe((values)=>{
            this.pageTitle = values['change_pref'];
        });
        const navParams = Object.keys(this.navParams.data).length > 0  ? this.navParams.data : undefined;        
         this.user = this.userService.getUser();
        // Load Drop down information
        this.pgList = this.utilService.getAllProductGroup();        
        this.levelList = this.utilService.getAllLevels();
        this.roleList = this.utilService.getAllRoles().filter(item => item.Id.toString() !== "1");// do not show the super admin role

        this.langaugeList = this.utilService.getAllLanguages();
        // assign the default language and role id for the drop down
        if(this.user !== undefined){
            this.selRoleId.roleId = this.user["roleId"].toString();
            this.selLngId.langCode = this.user.languageCode.toString();
        }
        
        //  this.usrSeltn - User Selection data is passed from the pop-up opening component.
         if(this.utilService.itemDefined(navParams) && this.utilService.itemDefined(navParams.userSelectionData)){ 
           this.usrSeltn = navParams.userSelectionData;
         } else{
           this.usrSeltn = this.userService.getUserSelection();
         }         
          this.initialUsrSelData = this.usrSeltn;// Initial User selelction data    
          if(navParams === undefined){
              this.isPreferences = true;
              if(this.initialUsrSelData.selRoleId === 2 || this.initialUsrSelData.selRoleId === 5){
                // If the page is opened form Preferences Side Menu              
                this.showSelection = new UserSelectionPrivileges(false,false,false,false,
                                                                false,false,true,false,
                                                                false,false,false,false,
                                                                false,false,false,false,
                                                                false,false,false,false,
                                                                false,false);
              } else{
                this.showSelection = new UserSelectionPrivileges(false,false,false,false,
                                                                false,false,true,false,
                                                                false,false,false,false,
                                                                false,false,false,false,
                                                                false,false,false,false,
                                                                false,false);                                    
              }                          
                this.usrPrvgs  = this.showSelection;
                let userDetailsData = this.utilService.getUserDetailsResponse();
                // get the plant product groups from the service            
            // let plantProductGroups:Array<ProductGroup> = _.uniqBy(_.flatMap(_.map(userDetailsData.plants,"productGroups")), "pgId");
                let plantProductGroups:Array<ProductGroup> = this.utilService.getPgByPlant();
                let userPlants:Array<UserPlants> = userDetailsData.plants; 
                this.populateSelectPlantPG(plantProductGroups, userPlants);
                this.selPlantPGId.plantpgId = this.user.pgId.toString();
                this.selUserPlant.plantId = this.usrSeltn.selPltId.toString();                      
          }
          if(navParams !== undefined  && navParams.exitWithOutSave !== undefined){
              this.exitWithOutSave = navParams.exitWithOutSave === "true";  
          }          
          if(navParams !== undefined  && navParams.isPopOverCtrl !== undefined){
                this.isOpenedPopOver = navParams.isPopOverCtrl === "true";
          }
           
          if(navParams !== undefined  && navParams.userPrivileges !== undefined){
            this.usrPrvgs = navParams.userPrivileges;

            if(this.usrPrvgs !== undefined){          
                            this.showSelection = this.usrPrvgs;
                            const isFromPage = navParams !== undefined  ? navParams.isFromPage : undefined;
                                // do the below only if the plants drop down is shown
                                if(this.showSelection.plt){
                                        if(navParams !== undefined && navParams.isFromPage !== undefined && (navParams.isFromPage !== "loginPage" && navParams.isFromPage !== "manageUser" && navParams.isFromPage !=="addNewUser")){ 
                                            this.plantsInfoList = _.uniq(this.user["plants"]);
                                            // TODO this is not required for every call.
                                            this.plantsInfoList.forEach((item)=>{
                                                if(item.pgId !== undefined && item.pgName !== undefined){
                                                    this.plantsList.push(new Plant(item.plantId, item.plantName, item.pgId, item.pgName));
                                                    this.plantsListDup.push(new Plant(item.plantId, item.plantName, item.pgId, item.pgName));
                                                } else{
                                                    console.error("Incorrect product groups received for the plants");
                                                }                   
                                            });        
                                        }
                                }
                                // if from login page and selecting the product groups and plants from multiple list
                                if(navParams.selectPlantPG !== undefined && navParams.selectPlantPG === "true"){  
                                    // this will fill up the drop down for the product groups and plants                      
                                    this.populateSelectPlantPG(navParams.productGroupList,navParams.userPlantsList);
                                }               
                            
                                if(this.usrPrvgs.machine){                     
                                    this.adminManageMachine.getListOfMachines(+this.usrSeltn.selPltId, "1",+this.usrSeltn.selPrId, true, this.usrSeltn.selPGId).subscribe((data:Array<Machine>)=>{
                                        if(data !== undefined && data.length > 0){
                                            this.machinesList = this.machinesList.concat(data);
                                            this.machinesList = _.uniqBy(this.machinesList, "name");
                                            this.machinesList = _.filter(this.machinesList, item =>  item.name!== "" );
                                        }
                                    });
                                    if(this.usrPrvgs.machine && isFromPage !== undefined && isFromPage === "AuditSchedular"){
                                        this.selShift.name = "select";
                                        this.isMultipleSelect = (navParams.isMultipleSelect !== undefined ?  (navParams.isMultipleSelect === "true") : true);
                                        if(this.usrSeltn.startDate !== "" && this.usrSeltn.endDate !== ""){
                                                this.adminManageMachine.getMachinesFromScheduledAudits(+this.usrSeltn.selPltId,0,0,this.usrSeltn.startDate, this.usrSeltn.endDate).subscribe((response) => {
                                                    if(this.utilService.checkValidData(response)){
                                                            const schMachineList = _.filter(_.map(response.Response,"MACHINE_NUM"), item => item !== (undefined || null || ""));
                                                            if(schMachineList.length >0){                                    
                                                                this.machinesList = this.machinesList.reduce((prev, item)=>{
                                                                        if(schMachineList.indexOf(item.name) !== -1){
                                                                            item.available = false;                                                   
                                                                        };     
                                                                        prev.push(item);                                           
                                                                    return prev;
                                                                },[]);
                                                        }
                                                    }                                        
                                                });
                                                }                            
                                                }                              
                                            }
                                        if(this.usrPrvgs.shift){
                                            this.loadShiftsForPlant();                     
                                        }

                                        if(isFromPage === "scheduleAuditForWeek"){                                            
                                            if(navParams.showWeekStartOnly !== undefined && navParams.showWeekStartOnly === "true"){
                                                this.startDateTitle = "Week Start"
                                            }
                                            if(navParams.isScheduledAudit !== undefined){
                                               this.selectMultipleMachines = navParams.isScheduledAudit;
                                            }                         
                                        }
                                    }
          }                                                                           
        // useSelectionDataSent - used to check if load selection from the passed in User Selection Data, this value has to eb sent on openeing the pop-up
         if(this.utilService.itemDefined(navParams) && this.utilService.itemDefined(navParams.useSelectionDataSent)) {
           this.useSelectionDataSent = (navParams.useSelectionDataSent.toString() === "true")
        }

        // using the User Slection data sent over from 
        
        if(this.usrSeltn !==  undefined  && this.usrSeltn.selPltId !==undefined && this.usrSeltn.selPltId  !== 0 && this.usrSeltn.selPGId !== 0 ){
              this.selPlantId.plantId = this.usrSeltn.selPltId  === 0 ? "select" : this.usrSeltn.selPltId.toString();               
              this.selPGId.pgId = this.usrSeltn.selPGId === 0 ? "select" : this.usrSeltn.selPGId.toString();
              this.selPlantId.pgId = this.usrSeltn.selPGId === 0 ? "select" : this.usrSeltn.selPGId.toString();
              this.onPGSelChange(); // to load the select box item               
              this.selOpId.opId = this.usrSeltn.selOpId  === 0 ? "select" : (this.usrSeltn.selOpId !== undefined ? this.usrSeltn.selOpId.toString() : "");
               this.onOpSelChange("");
                if(this.selOpId.opId === "select" && this.selPGId.pgId !== "select"){
                    this.getProcessByPG();
                }
              this.selPRId.prcId = this.usrSeltn.selPrId === -1 ? "select" : this.usrSeltn.selPrId.toString();
              this.selLevelId.levelId = this.usrSeltn.selLevelId  === -1 ? "select" : this.usrSeltn.selLevelId.toString();
              this.selRoleId.roleId = this.usrSeltn.selRoleId  === 0 ? "select" : this.usrSeltn.selRoleId.toString();
              this.selLngId.langCode = this.usrSeltn.selLangCode  === "" ? "select" : this.usrSeltn.selLangCode;
              this.selCommentsTextarea = this.usrSeltn.selCommentsTextarea;
              
              if(this.usrSeltn.selPrId === 0){ // To add additional Process if process id is 0
                  this.prList.push(new Process(0,"All Process"));
              }

              if(this.usrSeltn.selLevelId === 0){ // To add additional Level if level id is 0
                  this.levelList.push(new Level("0","All Levels"));
              }

              this.selLot.name = this.usrSeltn.lot.name;
              this.selLot.id = this.usrSeltn.lot.id.toString();
              if(this.usrSeltn.lot.name.toLowerCase() !== "select"){ // to avoid duplicates in the drop down
                  this.lotList.push(new Lot(this.usrSeltn.lot.id, this.usrSeltn.lot.name));
              }              
              
              this.selMachine.name = this.usrSeltn.machine.name;
              this.selMachine.id = this.usrSeltn.machine.id.toString();
              if(this.usrSeltn.machine.name.toLowerCase() !== "select"){
                this.machinesList.push(new Machine(this.usrSeltn.machine.name, this.usrSeltn.machine.name, this.usrSeltn.machine.procDesc, true));
              }

              this.selShift.id = this.usrSeltn.shift.id.toString();
              this.selShift.name = this.usrSeltn.shift.name.toString();  
              if(this.usrSeltn.shift.name.toString().toLowerCase() !== "select"){
                  this.shiftList.push(new Shift(this.usrSeltn.shift.name, this.usrSeltn.shift.name));
              }              

              this.selAuditor.id = this.usrSeltn.auditor.id.toString();
              this.selAuditor.name = this.usrSeltn.auditor.name.toString()

            this.selEndDate.endDate = !this.usrSeltn.endDate || this.usrSeltn.endDate === "" ? "select" : this.usrSeltn.endDate;
            this.selStDate.stDate = !this.usrSeltn.startDate || this.usrSeltn.startDate === "" ? "select" : this.usrSeltn.startDate;

              if(this.usrSeltn.selPltName && this.usrSeltn.selPltId  !== 0){ 
                  const plantId:number = this.usrSeltn.selPltId;
                  const plantName:string = this.usrSeltn.selPltName;
                  const pgId:number = this.usrSeltn.selPGId;
                  const pgName:string = this.usrSeltn.selPGName;
                if(this.isPlantsExistsInUserAssignedPlants(plantId.toString(), plantName)){
                        this.plantsList = new Array(new Plant(plantId, plantName, pgId, pgName));
                }
              }
              if(this.usrSeltn.selPGId !== 0 && this.showSelection.op){
                this.onPGSelChange();           
              }              
              if(this.usrSeltn.selOpId  !== 0  && this.showSelection.prc){ 
                this.onOpSelChange("");
              }
              if(this.utilService.itemDefined(this.usrSeltn.selPrName) && this.usrSeltn.selPrId !== 0){
                this.prList = new Array(new Process(this.usrSeltn.selPrId, this.usrSeltn.selPrName));
              }          
          
        
    } else if( !this.useSelectionDataSent && this.utilService.itemDefined(localStorage.saveUserSelection) && navParams !== undefined && navParams.useLocalStorageData !== undefined && navParams.useLocalStorageData === "true"){
            // Loading the data from local storage if the data is not sent from the component page
            const usrSelStored:UserSelectionData =  JSON.parse(localStorage.saveUserSelection);
            if(!usrSelStored.selPltId || usrSelStored.selPltId  === 0){
                this.selPlantId.plantId = "select" ; 
                this.selPlantId.plantName = "select"
            } else{
                const plantId:string = usrSelStored.selPltId.toString();
                const plantName:string = usrSelStored.selPltName;
                if(this.isPlantsExistsInUserAssignedPlants(plantId, plantName)){
                    // Check if the plant exists in the User assigned plants
                    this.selPlantId.plantId = plantId
                    this.selPlantId.plantName = plantName;
                }  else{
                    this.selPlantId.plantId = "select"; 
                    this.selPlantId.plantName = "select"
                }              
            }
            
            this.selPGId.pgId = (!usrSelStored.selPGId || usrSelStored.selPGId === 0 || usrSelStored.selPGId.toString() === "")? "select" : usrSelStored.selPGId.toString();
            this.onPGSelChange(); // to l oad the select box item 
            this.selOpId.opId = (!usrSelStored.selOpId || usrSelStored.selOpId  === 0 || usrSelStored.selOpId.toString()  === "") ? "select" : usrSelStored.selOpId.toString();
            this.onOpSelChange("");
            if(this.selOpId.opId === "select" && this.selPGId.pgId !== "select"){
                this.getProcessByPG();
            }
            this.selLevelId.levelId =  !usrSelStored.selLevelId || usrSelStored.selLevelId  === 0 ? "select" : usrSelStored.selLevelId.toString();
            this.selRoleId.roleId = !usrSelStored.selRoleId || usrSelStored.selRoleId  === 0 ? "select" : usrSelStored.selRoleId.toString();
            this.selLngId.langCode =  !usrSelStored.selLangCode || usrSelStored.selLangCode  === "" ? "select" : usrSelStored.selLangCode;   
            this.selEndDate.endDate = !usrSelStored.endDate || usrSelStored.endDate === "" ? "select" : this.utilService.revertToSystemDateFormat(usrSelStored.endDate);
            this.selStDate.stDate = !usrSelStored.startDate || usrSelStored.startDate === "" ? "select" : this.utilService.revertToSystemDateFormat(usrSelStored.startDate);
            this.selPRId.prcId = !usrSelStored.selPrId || usrSelStored.selPrId === 0 ? "select" : usrSelStored.selPrId.toString();
        }
        if(navParams !== undefined && navParams.isFromPage !== undefined && navParams.isFromPage === "manageUser"){ 
             if(navParams.isEditData === "true"){
                    this.submitButtonTitle = "Done";
                    this.isEditData = true;                        
             } else{                       
                    this.isEditData = false;                        
             }
                this.selCertified.name = this.usrSeltn.selCertified;
                this.selRoleId.roleId = this.usrSeltn.selRoleId.toString();
                this.isAddNewUser = false;
                this.showAvailPGSelLabel = false;
                this.showAvailOPSelLabel = false;
                this.isManageUser = true;
                this.showAvailPlantsSelLabel = true;
                this.isNewUserCreateButton = false;
                const user:User = this.user;
                this.selFirstName.name = this.usrSeltn.selFirstName;
                this.selLastName.name = this.usrSeltn.selLastName;
                this.selUser.name = user.firstName+","+user.lastName;
                this.selUser.id = user.userId.toString();
                this.selUser.wLogin = user.wLogin; 
                const adtr:UserObject = this.usrSeltn.auditor;
                this.selAuditor.name = adtr.name;
                this.selLngId.langCode = this.usrSeltn.selLangCode;
                this.selAvailPlantId.Id = "select";
                this.plantTitle = "Add New Plants";
                this.selLevelId.levelId = this.usrSeltn.selLevelId.toString();
                this.selPGId.pgId = this.usrSeltn.selPGId.toString();                
                this.selAuditor.id = adtr.id.toString();
                this.selwLogin.name  = this.usrSeltn.wLogin;   
                this.selEmail.name = this.usrSeltn.selEmail;            
                if(navParams.availPlants !== undefined){
                    this.availPlantsInfoList = _.uniqWith(navParams.availPlants, _.isEqual);
                    this.availPlantsList = Object.assign([], this.availPlantsInfoList);
                    this.availPlantsListDup = Object.assign([], this.availPlantsInfoList);
                    // this.availPlantsInfoList.forEach((item)=>{                        
                    //         this.availPlantsList.push(new Plant(item.plantId, item.plantName, item.pgId,item.pgName ));
                    //         this.availPlantsListDup.push(new Plant(item.plantId, item.plantName,item.pgId,item.pgName));                                               
                    // });
                   this.availPlantsListString = _.map(this.availPlantsList,"plantName").join(", ");
                } 
                //this.selAvailPlantId.Id = this.usrSeltn.selPltId.toString();// not required as user logged in plant is different from the selected user
                //this.selAvailPGId.name = this.usrSeltn.selPGName;
                //this.selAvailOpId.name = this.usrSeltn.selOpName;
                this.plantsInfoList = _.uniqWith(this.utilService.getAllAvailablePlants(), _.isEqual);
                this.plantsInfoList.forEach((item)=>{
                    this.plantsList.push(new Plant(item.plantId, item.plantName,item.pgId,item.pgName));
                    this.plantsListDup.push(new Plant(item.plantId, item.plantName,item.pgId,item.pgName));
                });  
                this.showSelection.plt = false;
                this.showPGSelLabel = false;// read only product group
                this.showOPSelLabel = false;
                this.isNewUserCreateButton = false; 
                this.showAvailPlantsSelLabel = true;
                this.showAvailPGSelLabel = true;
                this.showAvailPGSelLabel = false;
                this.showAvailOPSelLabel = false;               
                this.showAvailPlantsSelLabel = true;
                this.showDeletedAssignedPlants = true;
                this.isNewUserCreateButton = false;         
                this.isAuditorActive = this.usrSeltn.selActive; 
                this.showSelection.showCertifiedSelect = true;         
                if(this.isManageUser){
                    this.showSelection.plt = (navParams.isAddPlantsToUser !== undefined && navParams.isAddPlantsToUser === "true") ? true :false;
                    this.isNewUserCreateButton = true;
                }                            
                this.resetFieldsOnRoles();
                // If the logged in user is a Super Admin Show the add new Plants button


        }
        // Called form User Tab for adding  new user
        if(navParams !== undefined && navParams.isFromPage !== undefined && navParams.isFromPage === "addNewUser"){            
            const isCreateNewUser =  navParams.isCreateNewUser === "true";
            const isAddPlantsToUser =  navParams.isAddPlantsToUser === "true";
                    if(isCreateNewUser){// isCreate New User                            
                        this.isNewUserCreateButton = true;
                        this.isAddNewUser = true;
                        this.showSelection.plt = true;
                        this.showSelection.auditor = false;                        
                        this.showSelection.plt = false;    
                        this.showSelection.role = true;
                        this.createNewUserFlag = true;
                        this.showSelection.level = true;
                        this.showSelection.language = true;
                        this.showSelection.wLogin = false;
                        this.showSelection.shift = false;
                        this.showSelection.showFirstNameInput = true;
                        this.showSelection.showLastNameInput = true;
                        this.showSelection.showEmailInput = false;
                        this.showSelection.showCertifiedSelect = false;
                        this.showSelection.showWLoginInput = true;
                        this.showSelection.pg = true;
                        this.showSelection.auditor = false;
                        this.pageTitle = navParams.pageTitle;//   Setting the page Title 
                        this.selwLogin.name = "corplear\\";
                        this.showDeletedAssignedPlants = false;
                         this.plantsInfoList = _.uniqWith(this.utilService.getAllAvailablePlants(), _.isEqual);
                            this.plantsInfoList.forEach((item)=>{
                                this.plantsList.push(new Plant(item.plantId, item.plantName,item.pgId,item.pgName));
                                this.plantsListDup.push(new Plant(item.plantId, item.plantName,item.pgId,item.pgName));
                            }); 
                    }
                    if(isAddPlantsToUser){// is Add Users to Plant            
                        this.isNewUserCreateButton = true;
                        this.showSelection.auditor = true;
                        this.isAddNewUser = false;                        
                        this.showSelection.plt = true;
                        this.showSelection.level = false;
                        this.showSelection.language = false;            
                        this.createNewUserFlag = false;
                        this.showSelection.pg = false;
                        this.showSelection.role = false;
                        this.showSelection.showFirstNameInput = false;
                        this.showSelection.showLastNameInput = false;
                        this.showSelection.showEmailInput = false;
                        this.showSelection.showCertifiedSelect = false;
                        this.showSelection.showWLoginInput = false;
                        this.submitButtonTitle = "Done";
                        this.showSelection.shift = false;                        
                    }
                    const user:User = this.user;
                    this.selUser.name = user.firstName+","+user.lastName;
                    this.selUser.id = user.userId.toString();
                    this.selUser.wLogin = user.wLogin;                                                              
                    this.pageTitle = navParams.pageTitle;// Setting the page Title 
        }

        if(navParams !== undefined && navParams.isFromPage !== undefined && (navParams.isFromPage === "homePage" || navParams.isFromPage === "loginPage")){
            if(this.selRoleId.roleId.toString() === "2"){
                    this.showSelection.plt = false;
                    this.showSelection.pg = true;
            }            
        }
        if(navParams !== undefined && navParams.isFromPage !== undefined && navParams.isFromPage === "addNewShift"){
              this.addNewShift = true;
              const user:User = this.user;
              this.shiftInputName = "";
              this.showShiftInput = true;
              this.selUser.name = user.firstName+","+user.lastName;
              this.selUser.id = user.userId.toString();
              this.selUser.wLogin = user.wLogin;
            this.pageTitle = navParams.pageTitle;// Setting the page Title 
            this.selShift.name = "createnew";
        }
        if(navParams !== undefined && navParams.isFromPage !== undefined && navParams.isFromPage === "addNewMachine"){
            //TODO add the  swi path
              this.isFromMachinesPage = true;
              if(navParams.isSearchMachine !== undefined){
                  this.isSearchMachine = navParams.isSearchMachine === "true";
              }
              const user:User = this.user;
              this.selUser.name = user.firstName+","+user.lastName;
              this.selUser.id = user.userId.toString();
              this.selUser.wLogin = user.wLogin;
              this.addNewMachine = true;
              this.pageTitle = navParams.pageTitle;// Setting the page Title 

              // Edit Machine
              this.isEditMachine = navParams.isEditMachine === "true";
              let machineInfoObject:MachinesList = navParams.machineInfoObject;
              if(this.isEditMachine){
                    this.addNewMachine = false;
                    this.selPRId.prcId = machineInfoObject.procId;
                    this.selMachine.id = machineInfoObject.machineNum;
                    this.selMachine.name = machineInfoObject.machineNum;
                    this.oldMachineName = machineInfoObject.machineNum;
                    this.machineInputName = machineInfoObject.machineNum;
                    this.selActive.name = machineInfoObject.isActive !== undefined ?  (machineInfoObject.isActive.toString() === "true" ? "1" : "0") : "0";
                    this.showMachineInput = true;
                    this.swiPathInput = machineInfoObject.swiPath; 
                    this.splitSWIPath(this.swiPathInput); 
                    this.machineInputName = machineInfoObject.machineNum;
                    this.makeItActive = (machineInfoObject.isActive.toString() === "true");
                    this.showMachineInput = true;                                       
                    this.selPRId.prcId = this.usrSeltn.selPrId.toString();
                    this.showMachineActiveToggle = true;
                    if(this.selActive.name === "1"){                        
                        this.activeTitle ="Active";
                    }
                    if(this.selActive.name === "0"){                        
                        this.activeTitle ="InActive";
                    }                    
              } else{                                         
                    // by default show createnew machine
                    this.machineInputName = "";
                    this.showMachineInput = true;
                    this.isSearchMachine = false;
                    this.showSelection.showActive = false;
                    this.showMachineActiveToggle = false;
                    this.selMachine.name = "createnew";
                    this.selPRId.prcId = "select";
                    let savedData = window.localStorage.getItem("savedswifilepath");
                    if(savedData !== undefined){         
                        this.splitSWIPath(savedData,true);                  
                    }                   
              }              
        }

        if(navParams !== undefined && navParams.isFromPage !== undefined && navParams.isFromPage === "modifyScheduleAudits"){
            this.submitButtonTitle = "Edit";
            this.isEditData = true;
            this.pageTitle = "Audit Details";
            this.isShowDeleteAudit = false;
        }

        if(navParams !== undefined){
            if(navParams.updateUserSelectionData  !== undefined){
                this.updateUserSelectionData = navParams.updateUserSelectionData === "true";
            }            
            // Check to see the Query params for the check boxes to show up
            // To show the check box for the  process to be updated on the availability of the audit list for the process
            if(navParams.availableAuditsList !== undefined && navParams.availableAuditsList.length > 0){
            this.availPrcList = navParams.availableAuditsList;
                this.showCheckBoxNotAvailSel = true;
                this.showNotAvailSelection = true;
                this.showSelection.level = false;
            }
            if(navParams.pageTitle !== undefined){
                this.pageTitle = navParams.pageTitle;
            }              
        }
    } catch(ex){
          console.log(ex);
      }
  }


  private splitSWIPath(swiFullPath:string, createnew?:boolean){
    let swiFullPathSplitArray = swiFullPath.indexOf("/") === -1 ? swiFullPath.split("\\") : swiFullPath.split("/");
    let len = swiFullPathSplitArray.length;
    if(len > 2){
        this.swiPathFileNameInput = swiFullPathSplitArray[len-1];
        let folderName = (((swiFullPathSplitArray[len-2].length === 0) || (swiFullPathSplitArray[len-2].length === 1)) ? swiFullPathSplitArray[len-3] : swiFullPathSplitArray[len-2]);
        let indexOfSwiFolder = swiFullPath.indexOf(folderName);
        let indexOfSwiFile = swiFullPath.indexOf(swiFullPathSplitArray[len-1]);
        this.swiPathFolderInput = folderName;
        // this.swiPathFolderInput = swiFullPath.substring(indexOfSwiFolder, indexOfSwiFile);
        this.swiPathServerInput = swiFullPath.substr(0, (indexOfSwiFolder-1)); 
        if(this.swiPathServerInput.endsWith("\\")){
            let len = this.swiPathServerInput.length;
            this.swiPathServerInput = this.swiPathServerInput.substr(0, len-1);
        }
        if(this.swiPathServerInput.endsWith("\\\\")){
            let len = this.swiPathServerInput.length;
            this.swiPathServerInput = this.swiPathServerInput.substr(0, len-2);
        }
        if(createnew){
            this.swiPathFileNameInput = "";
        }
        this.swiPathServerInputChange();           
    }
  }

  private formSWIFullPath():boolean{                
    if(this.swiPathInput.length === 0){
            return true;
    }
    let isForwardSlash =  this.swiPathInput.indexOf("/") !== -1;
    let isBackwardSlash =  this.swiPathInput.indexOf("\\") !== -1;
        // if(this.swiPathFileNameInput.split('.').length > 2){
        //     this.swiPathInputErrorMessage = "Error: SWI File Name is incorrect, it should have only one period('.') in the file name. for example correct SWI File Name : '<SWI file Name>.extn'";
        //     return false;
        // } 
        if((this.swiPathFileNameInput.indexOf("/") !== -1 && this.swiPathFileNameInput.startsWith("/"))  || (this.swiPathFileNameInput.indexOf("\\")  !== -1 && this.swiPathFileNameInput.startsWith("\\"))){
            this.swiPathInputErrorMessage = "Error: SWI File Name is incorrect, it should NOT start with ('\\'). for example correct SWI File Name : '<SWI file Name>.extn'";
            return false;
        }; 
        if((this.swiPathFolderInput.indexOf("/")  !== -1 && !this.swiPathFolderInput.endsWith("/")) || (this.swiPathFolderInput.indexOf("\\")  !== -1 && !this.swiPathFolderInput.endsWith("\\"))){
            //this.swiPathInputErrorMessage = "Error: SWI SubFolder Path is incorrect, it should end with ('\\'). for example correct SWI SubFolder path : '<SWI folderName>\\'";
            //return false;
            if(isBackwardSlash){
                this.swiPathFolderInput = this.swiPathFolderInput +"\\";
            }
            if(isForwardSlash){
                this.swiPathFolderInput = this.swiPathFolderInput +"/";
            }
        };          
        if((this.swiPathServerInput.indexOf("/")  !== -1 && !this.swiPathServerInput.endsWith("/")) || (this.swiPathServerInput.indexOf("\\")  !== -1 && !this.swiPathServerInput.endsWith("\\"))){
            //this.swiPathInputErrorMessage = "Error: SWI ServerFolder Path is incorrect, it should end with ('\\'). for example correct SWI ServerFolder Path : '\\\\<serverName>\\<folderName>\\'";
            //return false;
            if(isBackwardSlash){
                this.swiPathFolderInput = this.swiPathFolderInput +"\\";
                this.swiPathServerInput = this.swiPathServerInput + "\\";
            }
            if(isForwardSlash){
                this.swiPathFolderInput = this.swiPathFolderInput +"/";
                this.swiPathServerInput = this.swiPathServerInput + "/";
            }
        }; 
        if((this.swiPathServerInput.indexOf("/")  !== -1 && !this.swiPathServerInput.startsWith("file://")) || (this.swiPathServerInput.indexOf("\\\\")  !== -1 && !this.swiPathServerInput.startsWith("\\\\"))){
            this.swiPathInputErrorMessage = "Error: SWI ServerFolder Path is incorrect, it should start with ('\\\\'). for example correct SWI ServerFolder Path : '\\\\<serverName>\\<folderName>\\'";    
        return false;
        };
        this.swiPathInput = this.swiPathServerInput + this.swiPathFolderInput + this.swiPathFileNameInput;
        return true;
  }
  
  private changePreferenceButtonClicked(){
    if(this.initialUsrSelData.selRoleId === 2 || this.initialUsrSelData.selRoleId === 5){
        if(this.selLngId.langCode !== "select"){
            let userSelData = this.userService.getUserSelection();
            userSelData.selLangCode = this.selLngId.langCode;
            this.userService.setUserSelection(userSelData);             
            this.initialUsrSelData.selRoleId === 2 ? this.navCtrl.setRoot(Admin) : this.navCtrl.setRoot(Reports);                         
        }
    } else{
        if(this.selLngId.langCode !== "select" && this.selUserPlant.plantId !== "select" && this.selPlantPGId.plantpgId !== "select"){      
            let userSelDataUpdate = this.userService.getUserSelection();
            userSelDataUpdate.selLangCode = this.selLngId.langCode;
            userSelDataUpdate.selPltId = +this.selUserPlant.plantId;
            userSelDataUpdate.selPltName = this.userPlantsList.filter(item => item.plantId.toString() === this.selUserPlant.plantId.toString())[0]["plantName"] || "";//this.user.plants.filter(item => item.plantId.toString() === this.selUserPlant.plantId.toString())["plantName"] || 
            userSelDataUpdate.selPGId = +this.selPlantPGId.plantpgId;
            let selPG = this.plantpgList.filter(item => item.pgId.toString() === this.selPlantPGId.plantpgId.toString());
            userSelDataUpdate.selPGName = selPG && selPG.length > 0 ? selPG[0]["pgName"] : ""; //this.user.plants.filter(item => item.pgId.toString() === this.selPlantPGId.plantpgId.toString())["pgName"];
            if(this.userService.updateUserAndUserSelData(this.utilService.getUserDetailsResponse(),userSelDataUpdate, true)){
                if(this.initialUsrSelData.selRoleId !== 2){
                    this.navCtrl.setRoot(HomePage);// this prefernce screen will be available for apeople who have Home page as landing page.
                }                
            };
        }  
    }          
  }
  // this will fill up the drop down for the product groups and plants                      
  private populateSelectPlantPG(productGroupList, userPlantsList){
        this.plantpgList = productGroupList;
        this.userPlantsList = userPlantsList;
        if(this.initialUsrSelData.selRoleId !== 2 && this.initialUsrSelData.selRoleId !== 5){
            this.showPlantProductGroup = true;
            this.showUserPlants = true;      
        }        
  }

  private isPlantsExistsInUserAssignedPlants(plantId:string, plantName:string):boolean{
      if(this.plantsList.length >0){
            return (_.findIndex(this.plantsList,(item)=>{return item.plantId.toString() === plantId}) !== -1);    
      } else{
          return true;
      }     
  }
  onPGSelChange(){     
    this.selPlantId = {plantId :"0" , plantName : "", pgId : "", pgName :""}
    
    if(this.selPGId.pgId !== 'select'){         
      this.initialDataService.getOperationByProductGroup(+this.selPGId.pgId).subscribe((data:ResponseObject)=>{
          if(this.utilService.checkValidData(data)){
                //if(data.Response.length > 0){            
                //    this.opList =  data.Response;
                    // since we're not showing the operation dropdown no need to assign the operations to the op list.
             //   } else {
                    this.selOpId.opId = 'select';
                    this.selPRId.prcId  = 'select';
                   // this.selLevelId.levelId ="select";
                    this.opList = [];
                    this.prList = [];
                 //   this.levelList = [];
                    if(this.selOpId.opId === "select" && this.selPGId.pgId !== "select"){// the get process if the operation is empty
                        this.getProcessByPG();
                    }
                    // this.utilService.showToast("NoDataForSelection" ,"");
                //}
          }          
      });      
    }
  }
    public onUserPlantSelClicked(){
        if(this.selPlantPGId.plantpgId === "select"){
            this.utilService.showToast("","Please select a Product Group before Selecting Plants");
        }
    }
    public onUserPlantSelChange(){
        let selPlant = this.userPlantsList.filter(item => item.plantId.toString() === this.selUserPlant.plantId.toString())
        if(selPlant.length > 0){
            this.selPlantId.plantId = selPlant[0].plantId.toString();
            this.selPlantId.plantName = selPlant[0].plantName.toString();
            this.selPlantId.pgId = this.selPlantPGId.plantpgId;
            this.plantsList = Object.assign([],this.userPlantsList);
            const pltId = +this.selPlantId.plantId;
            this.initialDataService.getPGByPlant(pltId).subscribe((response:ResponseObject)=>{
                if(this.utilService.checkValidData(response)){             
                    this.utilService.setPgByPlant(response.Response);
                    let userDetailsData = this.utilService.getUserDetailsResponse();
                    let plantProductGroups:Array<ProductGroup> = this.utilService.getPgByPlant();
                    let userPlants:Array<UserPlants> = userDetailsData.plants; 
                    this.populateSelectPlantPG(plantProductGroups, userPlants);
                }
            });
        }      
    }
    public onPlantPGSelChange(){
        this.selPGId.pgId = this.selPlantPGId.plantpgId;
        this.pgList = Object.assign([],this.plantpgList);
        this.userPlantsList = this.userPlantsList.reduce((prev, item)=>{            
            prev.push(new UserPlants(item.plantId, item.plantName, item.productGroups.filter(pg => pg.pgId.toString() === this.selPlantPGId.plantpgId.toString())));            
            return prev;
        },[]);
    }
  private deleteAuditClicked():void{
      this.isDeleteAudit = true;
      this.submitButtonClicked();
  }
  private assignProcess(resp){
         if(resp && resp.length > 0){
                            if(!this.showNotAvailSelection){
                                this.prList =  resp;   
                                if(this.usrSeltn !== undefined && this.usrSeltn.selPrId === 0 && !this.showMachineInput){ // To add additional Process if process id is 0
                                    this.prList.push(new Process(0,"All Process"));
                                } else{
                                    if(this.usrSeltn.selPrId.toString() !== "0"){
                                        this.selPRId.prcId = this.usrSeltn.selPrId.toString();    
                                    } else{
                                             this.selPRId.prcId = "select";
                                    }                                    
                                } 
                            } else{              
                                if(this.availPrcList.length > 0){ // Used by the corporate admin to load the process that are not having any Audits created.
                                this.prList = resp.reduce((prev, item)=>{
                                        if(_.findIndex(this.availPrcList,(i)=>{
                                            return i.procId.toString() === item.prcId.toString()
                                        }) === -1){
                                            prev.push(item);
                                        }                  
                                        return prev;                                            
                                    }, []);
                                } else{
                                    this.prList =  resp;
                                    if(this.usrSeltn !== undefined && this.usrSeltn.selPrId.toString() === "0"  && !this.showMachineInput){ // To add additional Process if process id is 0
                                        this.prList.push(new Process(0,"All Process"));
                                    }
                                }
                                this.selPRId.prcId =  "select" ; 
                            }                                       
                    } else {
                        this.selPRId.prcId  = 'select';
                        this.selLevelId.levelId ="select";              
                        this.prList = [];
                      //  this.levelList = []; // TODO not sure if this is required here
                        if(this.usrSeltn !== undefined && this.usrSeltn.selPrId === 0){ // To add additional Process if process id is 0
                            this.prList.push(new Process(0,"All Process"));
                        }
                        //this.utilService.showToast("NoDataForSelection" ,"");//Data not available for selection, Please change your selection!"
                        //this.utilService.showToast("Processes not available for the slected Product Group" ,"");
                    }
  }
  private getProcessByPG(){
        if(this.selPGId.pgId !== "select" && this.selPGId.pgId !== "" && this.usrSeltn.selPltId !== 0 ){
            this.initialDataService.getProcessByProductGroup(+this.selPGId.pgId, this.usrSeltn.selPltId).subscribe((data:ResponseObject)=>{
                    if(this.utilService.checkValidData(data)){                       
                        this.assignProcess(data.Response);
                    }
            });
        }
  }
  private onOpSelChange(ev:any){
    if(this.selOpId.opId !== 'select' && this.selOpId.opId !== ""){
         this.initialDataService.getProcessByOperation(+this.selOpId.opId).subscribe((data:ResponseObject)=>{ 
             if(this.utilService.checkValidData(data)){                       
                    this.assignProcess(data.Response);
                }
      });      
    } else {
        if(this.usrPrvgs.op) this.utilService.showToast("","Please select a Product Group");
    }     
  }
  showNotAvailSelectionChange(){
      this.showSelection.level = !this.showNotAvailSelection;
      this.onOpSelChange("");
  }
  private loadShiftsForPlant():void{
        this.adminManageMachine.getShiftsForPlant(+this.usrSeltn.selPltId).subscribe((data:ResponseObject)=>{
                        if(this.utilService.checkValidData(data) && _.isArray(data.Response)){
                            this.shiftList = data.Response;
                            //  this.shiftList = data.Response.reduce((prev,item)=>{
                            //         prev.push(new Shift(item.SHIFT, item.SHIFT));
                            //      return prev; 
                            //  },[]);
                             if(this.showShiftInput) this.addNewShift = true;// this makes adding the new shift easily
                        } else{
                            this.utilService.showToast("","Shifts are not received from server.");
                        }
        });
  }
  onPRSelChange(){    
    // For submitting the Audit to show up the machines list
    // we should show machines list according to the process selection
    if(this.showSelection.machine){
   if(this.selActive.name ==="" || this.selActive.name ==="select"){
        this.selActive.name = "1";
   }
   if((this.selPlantId.plantId !== "" && this.selPlantId.plantId !== "select") && (this.selActive.name !=="" && this.selActive.name !=="select") &&
          (this.selPRId.prcId !=="" && this.selPRId.prcId !=="select")){
          this.adminManageMachine.getListOfMachines(+this.selPlantId.plantId, "1",
          +this.selPRId.prcId, true, +this.selPGId.pgId).subscribe((data:Array<Machine>)=>{
                this.machinesList = data;
                this.utilService.hideLoading();
            });
      }         
    }
  }
  onLevelSelChange(){
    if(this.selRoleId.roleId.toString() === "6"){// on Guest role selected 
        this.selLevelId.levelId = "4";
    }
  }
  onActiveSelChange(){
    if(this.showSelection.machine && this.isFromMachinesPage){
      if((this.selPlantId.plantId !== "" && this.selPlantId.plantId !== "select") && (this.selActive.name !=="" && this.selActive.name !=="select") &&
          (this.selPRId.prcId !=="" && this.selPRId.prcId !=="select")){
          this.adminManageMachine.getListOfMachines(+this.selPlantId.plantId, this.selActive.name,
                                                     +this.selPRId.prcId, true,this.usrSeltn.selPGId).subscribe((data:Array<Machine>)=>{
            this.machinesList = data;
        });
      }              
    }
    if(this.selActive.name === "1"){
      this.showMachineActiveToggle = true;
      this.activeTitle ="Make Machine InActive";
    }
    if(this.selActive.name === "0"){
      this.showMachineActiveToggle = true;
      this.activeTitle ="Make Machine Active";
    }
    if(this.selActive.name === "2"){
      this.showMachineActiveToggle = false;
    }    
  }
    swiPathServerInputChange(){        
        this.swiPathInput = this.swiPathServerInput +"\\"+this.swiPathFolderInput +"\\"+ this.swiPathFileNameInput;
        let isForwardSlash =  this.swiPathInput.indexOf("/") !== -1;
        let isBackwardSlash =  this.swiPathInput.indexOf("\\") !== -1;
        if(isBackwardSlash){
            this.swiPathInput = this.swiPathServerInput +"\\"+this.swiPathFolderInput +"\\"+ this.swiPathFileNameInput;
        }
        if(isForwardSlash){
            this.swiPathInput = this.swiPathServerInput +"/"+this.swiPathFolderInput +"/"+ this.swiPathFileNameInput;
        }
       if(this.swiPathFileNameInput === ""){// if the file name is empty then make the swi file path as empty
            this.swiPathInput = "";
       } 
    }
  createNewMachine(){
    //this.utilService.showLoading();
    
    // create a new machine 
    if(this.selPRId.prcId ==="" || this.selPRId.prcId ==="select" || this.selPRId.prcId ==="0"){
        this.utilService.showToast("","Please select Process to create a  new Machine.");
        return;
    }
    if(!this.formSWIFullPath()){
        this.swiPathInputErrorMessage = "Error: Can you please enter the correct SWI File Path otherwise you can keep the fields empty.";
        return;
    }
    
    if((this.usrSeltn.selPltId.toString() !=="0" ) &&    
    (this.machineInputName !=="" && (this.isEditMachine ? true : this.selMachine.name.indexOf("createnew") !== -1) )&& 
    (this.selPRId.prcId !=="" && this.selPRId.prcId !=="select" && this.selPRId.prcId !=="0") 
    && (this.selUser.wLogin !== "")){
        if(this.addNewMachine){
                this.adminManageMachine.addNewMachinesToPlant(new CreatePlantMachine(+this.usrSeltn.selPltId,+this.selPRId.prcId, this.machineInputName.trim(),  this.makeItActive, this.swiPathInput,  this.selUser.wLogin)).subscribe((data)=>{                  
                        if(this.utilService.checkValidData(data)){
                            //   if(!this.isEditMachine){              
                            //     this.isSearchMachine = true;
                            //     this.addNewMachine = true;
                            //     this.selMachine.name = "select";
                            //     this.utilService.showToast("", data.Response);  
                            //     this.onPRSelChange();                               
                            // } else{
                                if(this.swiPathInput.length > 10){
                                    window.localStorage.setItem("savedswifilepath", this.swiPathInput);
                                }                                
                                this.viewCtrl.dismiss();
                        // }
                        }          
                    },(error)=>{
                        this.utilService.showToast("","Error occurred from service");
                        this.viewCtrl.dismiss();
                    },()=>{ 
                    });
        } else{
                this.adminManageMachine.updatePlantMachine(new UpdatePlantMachine(+this.usrSeltn.selPltId,+this.selPRId.prcId, this.oldMachineName.trim(), this.machineInputName.trim(), !this.makeItActive, this.swiPathInput,  this.selUser.wLogin)).subscribe((data)=>{                  
                        if(this.utilService.checkValidData(data)){

                            // Update the Process to the Machine.
                            this.adminManageMachine.updateProcessForMachine(new UpdateProcessForMachine(+this.usrSeltn.machine.id,+this.selPRId.prcId,this.selUser.wLogin)).subscribe((response)=>{
                                if(this.utilService.checkValidData(response)){
                                    if(this.swiPathInput.length > 10){
                                        window.localStorage.setItem("savedswifilepath", this.swiPathInput);
                                    }                                     
                                }
                            });
                            //   if(!this.isEditMachine){              
                            //     this.isSearchMachine = true;
                            //     this.addNewMachine = true;
                            //     this.selMachine.name = "select";
                            //     this.utilService.showToast("", data.Response);  
                            //     this.onPRSelChange();                               
                            // } else{
                                this.viewCtrl.dismiss();
                        // }
                        }          
                    },(error)=>{
                        this.utilService.showToast("","Error occurred from service");
                        this.viewCtrl.dismiss();
                    },()=>{ 
                    });
        }      
    }  else{
            this.utilService.showToast("","Please enter all the mandatory fields");
    }  
  }
 public createNewShift():void{
     if((this.usrSeltn.selPltId !== 0 &&  this.usrSeltn.selPltId.toString() !=="select") && 
    (this.shiftInputName !=="" && this.selShift.name === "createnew")     
    && (this.selUser.wLogin !== "")){
        this.adminManageMachine.addNewShiftToPlant(new CreatePlantShift(+this.usrSeltn.selPltId, this.shiftInputName, this.selUser.wLogin)).subscribe((data)=>{                  
          if(this.utilService.checkValidData(data)){
                 this.addNewShift = false;
                 this.showShiftInput = false;
                 this.selShift.name = "select";
                // this.loadShiftsForPlant();
                this.utilService.showToast("", "Successfully added new Shift");
                this.viewCtrl.dismiss();          
          } 
        },(error)=>{
        this.utilService.showToast("","Error occurred from service");
          this.viewCtrl.dismiss();
      },()=>{ 

      });
    }
 }
  makeMachineActive(){
    
  }

  onLangSelChange(){
      if(this.isPreferences){
         this.utilService.setDeviceLanguage(this.selLngId.langCode);
      }
  }
    onRoleSelChange(){
         this.showSelection.op = false;
        if(this.isManageUser){
                if(this.selRoleId.roleId.toString() === "2"){              
                    this.showSelection.plt = false;
                    this.selPlantId.plantId = "0";
                    this.selPlantId.plantName = "";
                    this.showSelection.pg = true;                   
                    this.showSelection.level = false;
                    this.showAvailPlantsSelLabel = false;  
                    this.showAvailPGSelLabel = false;
                     this.showDeletedAssignedPlants = false;
                } else{
                    const navParams = this.navParams.data;
                    if((this.isAddNewUser) || (navParams.isFromPage === "loginPage")){
                        this.showSelection.plt = this.selRoleId.roleId.toString() === "1" ? false : true;// not required if super admin
                        
                    } else{
                        this.showSelection.plt = true;
                        this.showAvailPlantsSelLabel = true;  
                        this.showAvailPGSelLabel = false;                                                
                    }                    
                    if(this.selRoleId.roleId.toString() !== "1"){              
                            this.showSelection.pg = true;                                        
                            this.showSelection.level = true;                    
                            this.showDeletedAssignedPlants = true;
                    }
                     //if(navParams.isFromPage !== undefined &&  navParams.isFromPage === "loginPage"){                                
                        // TODO this is only for testing as a super admin.. wil be removed later
                        // const user = this.user["roleId"].toString();
                        // if(user === "1"){
                        //     this.selLevelId.levelId = "1";
                        //     this.plantsInfoList = _.uniqWith(this.utilService.getAllAvailablePlants(), _.isEqual);
                        //     this.plantsInfoList.forEach((item)=>{
                        //         this.plantsList.push(new Plant(item.plantId, item.plantName));
                        //         this.plantsListDup.push(new Plant(item.plantId, item.plantName));
                        //     }); 
                        // }
                    //}                     
                }
        }
        if(this.isAddNewUser){
           this.resetFieldsOnRoles();
        }          
  }
  onFirstNamekeyUp(event:any){
    this.selwLogin.name = "corplear\\";
    const firstName= this.selFirstName.name.trim().charAt(0);    
    this.selwLogin.name = this.selwLogin.name + firstName + this.selLastName.name;        
  }
  onLastNamekeyUp(event:any){
    this.selwLogin.name = "corplear\\";
    const firstName= this.selFirstName.name.trim().charAt(0);    
    this.selwLogin.name = this.selwLogin.name + firstName + this.selLastName.name;    
  }
  private resetFieldsOnRoles(){
      
           switch(this.selRoleId.roleId.toString()){
                   case "1":// Super Admin Role
                        this.showSelection.pg = false;
                        this.showSelection.level = false;
                        this.showSelection.plt = false;
                        this.showAvailPGSelLabel = false;
                        this.showAvailOPSelLabel = false;                
                        this.showAvailPlantsSelLabel = false;  
                        this.showDeletedAssignedPlants = false;
                        if(this.isManageUser){
                            this.showAvailPlantsSelLabel = false;  
                            this.showAvailPGSelLabel = false;
                        }
                        break;
                    case "2":// Corp Admin Role
                        this.showSelection.pg = true;
                        this.showSelection.level = false;
                        this.showSelection.plt = false;
                        this.showAvailPGSelLabel = false;
                        this.showAvailOPSelLabel = false;                
                        this.showAvailPlantsSelLabel = false;
                        this.showDeletedAssignedPlants = false;
                        break;
                    case "3":// Plant Admin Role
                        this.showSelection.pg = false;
                        this.showDeletedAssignedPlants = false;
                        this.showSelection.level = true;
                        this.showSelection.plt = false; 
                        this.showAvailOPSelLabel = false;
                        // preselecting the layer on the Guest Role selection.                        
                        if(this.isAddNewUser){
                            this.showAvailPGSelLabel = false;                                       
                            this.showAvailPlantsSelLabel = false;                  
                        } else{
                            this.showAvailPGSelLabel = true;                                       
                            this.showAvailPlantsSelLabel = true;  
                            this.selAvailPGId.name = this.usrSeltn.selPGName                                                          
                        } 
                        break;
                         case "4":// Auditor Admin Role
                        this.showSelection.pg = true;
                        this.showDeletedAssignedPlants = true;
                        this.showSelection.level = true;
                        this.showSelection.plt = true; 
                        this.showAvailOPSelLabel = false;
                        // preselecting the layer on the Guest Role selection.
                         
                        if(this.isAddNewUser){
                            this.showAvailPGSelLabel = false;                                       
                            this.showAvailPlantsSelLabel = false;                                              
                        } else{
                            this.showAvailPGSelLabel = false;                                       
                            this.showAvailPlantsSelLabel = true;   
                             
                        }   
                        break;
                         case "5"://Read Only Role
                        this.showSelection.pg = true;
                        this.showDeletedAssignedPlants = false;
                        this.showSelection.level = false;
                        this.showSelection.plt = false; 
                        this.showAvailOPSelLabel = false;
                        if(this.isAddNewUser){
                            this.showAvailPGSelLabel = false;                                       
                            this.showAvailPlantsSelLabel = false;                  
                        } else{
                            this.showAvailPGSelLabel = false;                                       
                            this.showAvailPlantsSelLabel = false;                  
                        }     
                        break;
                        case "6":// Guest/Exec Admin Role
                        this.showSelection.pg = true;
                        this.showDeletedAssignedPlants = true;
                        this.showSelection.level = true;
                        this.showSelection.plt = true; 
                        this.showAvailOPSelLabel = false;
                        if(this.isAddNewUser){
                            this.showAvailPGSelLabel = false;                                       
                            this.showAvailPlantsSelLabel = false;                  
                        } else{
                            this.showAvailPGSelLabel = false;                                       
                            this.showAvailPlantsSelLabel = true;  
                        }     
                        // preselecting the layer on the Guest Role selection.                                               
                        break;
                    default:
                        this.showSelection.pg = false;
                        this.showSelection.level = true;
                        this.showSelection.plt = false;      
                        this.showAvailPGSelLabel = false;
                        this.showAvailOPSelLabel = false;                
                        this.showAvailPlantsSelLabel = false;                  
                    break;
               }
               if(this.user.roleId.toString() === "1"){
                this.showAvailPlantsSelLabel = true;  
                this.showSelection.pg = true;
                this.showSelection.plt = true;       
                this.showDeletedAssignedPlants = true; 
              }
  }
  onPlantSelChange(){
    if(!this.useSelectionDataSent && !this.usrPrvgs.pg 
        && !this.usrPrvgs.op && this.selPlantId.plantId !== "0"
        && this.selPlantId.plantId !== "select" && this.plantsInfoList.length >0){      
        const plant:PlantInfo = _.find(this.plantsInfoList,(item)=>{
            return item.plantId.toString() === this.selPlantId.plantId.toString();
        });
        if(this.utilService.itemDefined(plant)){
            this.selPGId.name = plant.pgName;
            this.selPGId.pgId = plant.pgId.toString();
            this.selOpId.opId = plant.opId.toString();
            this.selOpId.name = plant.opName;
            this.showPGSelLabel = true;
            this.showOPSelLabel = false; // not needed
        }        
      }              
  }

  onAvailPlantSelChange(){
    if(this.selAvailPlantId.Id !== "0"
        && this.selAvailPlantId.Id !== "select" && this.availPlantsInfoList.length >0){      
        const plant:PlantInfo = _.find(this.availPlantsInfoList,(item)=>{
            return item.plantId.toString() === this.selAvailPlantId.Id.toString();
        });
        if(this.utilService.itemDefined(plant)){
            this.selAvailPGId.name = plant.pgName;
            this.selAvailPGId.pgId = plant.pgId.toString();
            this.showAvailPGSelLabel = true;
            this.showAvailOPSelLabel = false;
        }        
      }              
  }


  submitButtonClicked(){
    if(this.submitButtonTitle === "Edit"){
        this.isEditData = false;
        this.submitButtonTitle = "Done";
        const navParams = this.navParams.data;
        if(navParams !== undefined && navParams.isFromPage !== undefined && navParams.isFromPage === "modifyScheduleAudits"){
            this.isShowDeleteAudit = true;      
        }      
        this.exitWithOutSave = false;                
    } else{
      if(this.exitWithOutSave){
          this.viewCtrl.dismiss();
      } else{      
          if(this.selActive.name === "select"){
            this.selActive.name = "0";
          }      
          if(this.selPGId.pgId ===''|| this.selPGId.pgId ==='select' || +this.selPGId.pgId === -1 || isNaN(+this.selPGId.pgId)){
              this.selPGId.pgId = '0';
          }
          if(this.selPlantId.plantId ===''|| this.selPlantId.plantId ==='select' || +this.selPlantId.plantId === -1 || isNaN(+this.selPlantId.plantId)){
              this.selPlantId.plantId = '0';
          }
          if(this.selPRId.prcId ===''|| this.selPRId.prcId ==='select' || +this.selPRId.prcId === -1 || isNaN(+this.selPRId.prcId)){
              this.selPRId.prcId = '0';
          }
          if(this.selOpId.opId ===''|| this.selOpId.opId ==='select' || +this.selOpId.opId === -1 || isNaN(+this.selOpId.opId)){
              this.selOpId.opId = '0';
          }
          //  if(this.selLevelId.levelId ===''|| this.selLevelId.levelId ==='select' || +this.selLevelId.levelId === -1 || isNaN(+this.selLevelId.levelId)){
          //     this.selLevelId.levelId = '0';
          // }          
          if(this.selMachine.name.indexOf("createnew") !== -1 ){
              this.selMachine.name = this.machineInputName;
          }
          const selIndex = this.selMachine.name.indexOf("select");
          const selLen =  this.selMachine.name.length;
          if(selIndex !==-1){
              if(_.isArray(this.selMachine.name)){
                    this.selMachine.name = this.selMachine.name.slice(1, selLen);                    
              }            
          }
          const selAllIndex = this.selMachine.name.indexOf("SelectAll");
          if(selAllIndex !== -1){
               if(_.isArray(this.selMachine.name)){
                this.selMachine.name = _.map(this.machinesList, 'name');
            }
          }

          if(((this.selPlantId.plantId.toString().toLowerCase()!=='select' && this.selPlantId.plantId.toString().toLowerCase()!=='' && this.selPlantId.plantId.toString().toLowerCase()!=='0' && +this.selPlantId.plantId !== -1  
          && !isNaN(+this.selPlantId.plantId))  ? true : ((this.showSelection.plt || this.showUserPlants) ? false : true)) &&          
              ((this.selPGId.pgId.toString().toLowerCase()!=='' && this.selPGId.pgId.toString().toLowerCase()!=='0' && this.selPGId.pgId.toString().toLowerCase()!=='select' && +this.selPGId.pgId !== -1 && !isNaN(+this.selPGId.pgId))  ? true : ((this.showSelection.pg || this.showPlantProductGroup) ? false : true)) &&          
              ((this.selPRId.prcId!=='select' && this.selPRId.prcId!=='' && this.selPRId.prcId!=='0' && +this.selPRId.prcId !== -1 && !isNaN(+this.selPRId.prcId))  ? true : (this.showSelection.prc ?  false : true)) &&          
              (this.selOpId.opId!=='select' && +this.selOpId.opId !==-1 && !isNaN(+this.selOpId.opId)   ? true : (this.showSelection.op ?  false : true)) &&          
              (this.selLevelId.levelId!=='select'&& +this.selLevelId.levelId !== -1 && !isNaN(+this.selLevelId.levelId) ?  true : (this.showSelection.level ?  false : true))  &&          
              (this.selRoleId.roleId !=='select' && +this.selRoleId.roleId !==-1 && !isNaN(+this.selRoleId.roleId)   ? true : (this.showSelection.role? false : true)) &&         
              (this.selStDate.stDate !== ""   ? true : (this.showSelection.stDate ? false : true)) &&         
              (this.selEndDate.endDate !== ""  ? true : (this.showSelection.endDate ? false : true)) &&         
              (this.selUser.id !== "0" ? true : (this.showSelection.wLogin ? false : true)) &&
              (this.selLot.name !== "" ? true : (this.showSelection.lot ? false : true)) && 
              ((this.selMachine.name.indexOf("select") && this.selMachine.name.length !== 0) ? true : (this.showSelection.machine ? false : true)) &&
              ((this.selShift.name !== "" && this.selShift.name !== "") ? true : (this.showSelection.shift ? false : true)) &&
              (this.selAuditor.id !== "0" ? true : (this.showSelection.auditor ? false : true)) &&
              (this.selFirstName.name !== "" ? true :(this.showSelection.showFirstNameInput ? false:true)) &&
              (this.selLastName.name !== "" ? true :(this.showSelection.showLastNameInput ? false:true)) &&
              (this.selEmail.name !== "" ? true :(this.showSelection.showEmailInput ? false:true)) &&
              (this.selCertified.name !== "" ? true :(this.showSelection.showCertifiedSelect ? false:true)) &&
              (this.selActive.name !== "" && this.selActive.name !== "select"? true :(this.showSelection.showActive ? false:true)) &&
              (this.selwLogin.name !== "" ? true :(this.showSelection.showWLoginInput ? false:true)) /* && // -- comments are not mandatory
              (this.selCommentsTextarea !== "" ? true :(this.showSelection.showComments ? false:true)) */)
              {         
                 let plantName = "";
                 let pgName = "";
                  if(this.showUserPlants){                         
                        plantName = _.find(this.userPlantsList,['plantId', +this.selPlantId.plantId]);         
                    } else{
                        plantName = _.find(this.plantsList,['plantId', +this.selPlantId.plantId]);          
                    }
                    if(this.showPlantProductGroup){
                        pgName = (this.selPGId.pgId!=='select' && this.selPGId.pgId!=='0' && +this.selPGId.pgId !== -1 && !isNaN(+this.selPGId.pgId)) ? 
                                  _.find(this.plantpgList,['pgId', +this.selPGId.pgId]) : "";
                    } else{
                            pgName = (this.selPGId.pgId!=='select' && this.selPGId.pgId!=='0' && +this.selPGId.pgId !== -1 && !isNaN(+this.selPGId.pgId)) ? 
                                  _.find(this.pgList,['pgId', +this.selPGId.pgId]) : "";
                    }                        
                                  const  opDesc =  _.find(this.opList,['opId', +this.selOpId.opId]);
                                  const  prcDesc = _.find(this.prList,['prcId', +this.selPRId.prcId]);
                                  const  levelDesc =  _.find(this.levelList,['id', +this.selLevelId.levelId]);
                                  const  langDesc =  _.find(this.langaugeList, ['langCode', this.selLngId.langCode]);
                                  const  roleDesc =  _.find(this.roleList,['Id', +this.selRoleId.roleId]);

                const usrSelData  = new UserSelectionData(+this.selPlantId.plantId, plantName ? plantName["plantName"] : "", 
                                                          +this.selPGId.pgId, pgName ? pgName["pgName"] : this.selPGId.name,
                                                          +this.selOpId.opId, opDesc ? opDesc["opDesc"] : this.selOpId.name,
                                                          +this.selPRId.prcId, prcDesc ? prcDesc["prcDesc"] : "",
                                                          +this.selLevelId.levelId, levelDesc ?  levelDesc["desc"] : "",
                                                          this.selRoleId.roleId !=="select" && +this.selRoleId.roleId ? +this.selRoleId.roleId :0 ,  roleDesc ? roleDesc["desc"] : "",  
                                                          this.selLngId.langCode, langDesc ? langDesc["langDesc"] : "",
                                                          this.utilService.changeDateFormat(this.selStDate.stDate),
                                                          this.utilService.changeDateFormat(this.selEndDate.endDate),
                                                          this.selUser.id,new Lot(+this.selLot.id, this.selLot.name),
                                                          new Machine(this.selMachine.id,this.selMachine.name,"", true),
                                                          new Shift(this.selShift.id,this.selShift.name),
                                                          new UserObject(+this.selAuditor.id, this.selAuditor.name),
                                                          this.selFirstName.name,
                                                          this.selLastName.name,
                                                          this.selwLogin.name,
                                                          this.selEmail.name,
                                                          this.selCertified.name,
                                                          this.selActive.name, this.selCommentsTextarea);           

                if(this.saveUserSelection) {
                  //TODO -- Save the User Name to the Local Storage
                  localStorage.saveUserSelection = JSON.stringify(usrSelData)
                }

                if(this.isDeleteAudit){
                     this.viewCtrl.dismiss(usrSelData, "deleteAudit");
                } else{
                  this.viewCtrl.dismiss(usrSelData);
                }               
          } else{
              // this.viewCtrl.dismiss();
            this.utilService.showToast("","Selection Cannot be empty");
          }  
      }   
    }
  }
  dismiss(){
    const isSelectionMandatory = this.navParams.data.isMandatory === "true";
      if(!isSelectionMandatory) this.viewCtrl.dismiss();
      else this.utilService.showToast("","Please do selection before cancel.");
  }
  ionViewDidLoad() {
    
  }
  searchUsers(flag:string){    
    let modal = this.modalCtrl.create(SearchUsersInPlant);
    modal.onDidDismiss((data:User)=>{
      if(this.utilService.itemDefined(data)){
          if(flag === "Auditor"){
            this.selAuditor.id = data.userId.toString();
            this.selAuditor.name = data.firstName + " " + data.lastName;
          } else{
            this.selUser.id = data.userId.toString();
            this.selUser.name = data.firstName + " " + data.lastName;
            this.selUser.wLogin = data.wLogin;
          }
      }              
    });
    modal.present();
  }
  private filterPlantsFromAvailList(availPlants:Array<UserPlants>, plantsList:Array<UserPlants>){
    if(availPlants.length > 0){
        return plantsList.filter(item => !availPlants.some(other => item.plantId === other.plantId));
    } else{
        return plantsList;
    }
  }
  public selectPlantFromSearchPlants():void{                    
            if(this.selPGId.pgId.toString() === "0" && this.selPGId.pgId.toString() === "" && this.selPGId.pgId.toString().toLowerCase() === "select"){
               this.utilService.showToast("","Select a Product Group to Add Plants");
               return;
            }
            let pltLst:UserPlants[] = [];
            let availPltsLt:UserPlants[] = [];
             let plantsAllAvail = _.uniqWith(this.utilService.getAllAvailablePlants(), _.isEqual);
            if(plantsAllAvail.length > 1){
                pltLst = plantsAllAvail;
                availPltsLt = this.filterPlantsFromAvailList(this.availPlantsListDup,pltLst);
            } else{  
                // TODO Remove the below code this is for testing as a super admin                                          
                // const user = this.user["roleId"].toString();
                // if(user === "1"){
                //     this.selLevelId.levelId = "1";
                //     this.plantsInfoList = _.uniqWith(this.utilService.getAllAvailablePlants(), _.isEqual);
                //     this.plantsInfoList.forEach((item)=>{
                //         this.plantsList.push(new Plant(item.plantId, item.plantName));
                //         this.plantsListDup.push(new Plant(item.plantId, item.plantName));
                //     }); 
                // }
                pltLst = plantsAllAvail;
                availPltsLt = this.filterPlantsFromAvailList(this.availPlantsListDup,pltLst);
            }

            if(availPltsLt.length > 1){                                                         
                        let modal = this.modalCtrl.create(SearchUsersInPlant, {"isFromPage":"manageUser",
                                                            "selectedProductGroup":this.selPGId.pgId,
                                                            "isMultipleSelect":(this.isManageUser || this.isAddNewUser).toString(), 
                                                            "plantsArray": availPltsLt});
                        modal.onDidDismiss((data)=>{//:Array<Plant>
                                    if(data !== undefined){         
                                        if(!(this.isManageUser||this.isAddNewUser)){   /// if not manager user then we not assigning multiple plants to the user             
                                                    this.selPlantId.plantId = data.plantId.toString();   
                                                    this.selPlantId.plantName = data.plantName;
                                                            if(!this.useSelectionDataSent && !this.usrPrvgs.pg 
                                                                && !this.usrPrvgs.op && this.selPlantId.plantId !== "0"
                                                                && this.selPlantId.plantId !== "select" && this.plantsInfoList.length >0){      
                                                                const plant:PlantInfo = _.find(this.plantsInfoList,(item)=>{
                                                                    return item.plantId.toString() === this.selPlantId.plantId.toString();
                                                                });
                                                                        if(this.utilService.itemDefined(plant)){
                                                                            this.selPGId.name = plant.pgName;
                                                                            this.selPGId.pgId = plant.pgId.toString();
                                                                            this.selOpId.opId = plant.opId.toString();
                                                                            this.selOpId.name = plant.opName;
                                                                            this.showPGSelLabel = true;
                                                                            this.showOPSelLabel = false;                                                                          
                                                                        }        
                                                            }                  
                                            } else{
                                                if(data.length > 0){  // here we receive data as array of plants as we  select multiple plants                                               
                                                    this.selPlantId = data;
                                                    this.selPlantId.plantName = _.map(data,"plantName").join(",");
                                                    this.showPGSelLabel = false;
                                                    this.showOPSelLabel = false; 
                                                }
                                            }        
                                }      
                        });
                        modal.present();
            } else{                
                this.utilService.showToast("noPlantsForUser","");                
            }
  }

  onLotSelChange(){
    if(this.selLot.name !== "" && this.selLot.name !=="select" && this.selLot.name !=="create"){
            //this.newQuestionsList.catId = +this.selCategories.id;
      }
      if(this.selLot.name ==="create"){
        this.selLot.name = "";
        this.showLotInput = true;
      }
  }
  removeLotInput(){
      this.showLotInput = false;
      this.selLot.name ="select";
  }

   onMachineSelChange(){   
      if(_.isArray(this.selMachine.name)){        
          const selIndex = this.selMachine.name.indexOf("select");
          const selLen =  this.selMachine.name.length;
          if(selIndex !==-1){              
             this.selMachine.name = this.selMachine.name.slice(1, selLen);                           
          }
          const selAllIndex = this.selMachine.name.indexOf("SelectAll");
          const selAllLen =  this.selMachine.name.length;
          if(selAllIndex !== -1){
              this.selMachine.name = this.selMachine.name.slice(1, selAllLen); 
              this.selMachine.name = _.map(this.machinesList, 'name');            
          }
      }

       if(this.selMachine.name.indexOf("select") == -1 && this.selMachine.name.indexOf("createnew") === -1 ){            
            this.machineInputName = "";
            this.showMachineInput = false;
            this.isSearchMachine = true;                
      }
      if(this.selMachine.name.indexOf("createnew") !== -1){     // used to create  anew new machine   
            this.machineInputName = "";
            this.showMachineInput = true;
            this.isSearchMachine = false;
            this.showSelection.showActive = false;
            this.showMachineActiveToggle = false;
      } 

      if(this.isEditMachine){
            this.showMachineInput = true;
      }      
    }
  removeMachineInput(){
      this.showMachineInput = false;
      this.selMachine.name ="select";
  }

  onShiftSelChange(){
   
      if( this.selShift.name ==="select" || this.selShift.name !=="createnew"){
            //this.newQuestionsList.catId = +this.selCategories.id;
            this.showShiftInput = false;
      }
      if(this.selShift.name === "createnew"){
          this.shiftInputName = "";
          this.showShiftInput = true;
      }
    }
  removeShiftInput(){
      this.showShiftInput = false;
      this.selShift.name ="select";
  }
//Called when Create new User button clicked
  createNewUser(){
    this.isAddNewUser = false;
    this.showSelection.plt = false;    
    this.showSelection.role = true;
    this.createNewUserFlag = true;
    this.showSelection.level = true;
    this.showSelection.language = true;
    this.showSelection.wLogin = false;
    this.showSelection.shift = false;
    this.showSelection.showFirstNameInput = true;
    this.showSelection.showLastNameInput = true;
    this.showSelection.showEmailInput = true;
    this.showSelection.showCertifiedSelect = false;
    this.showSelection.showWLoginInput = true;
    this.showSelection.pg = true;
    this.showSelection.auditor = false;
    // Level should show up Plant Admin or Auditor
    // If admin is Super Admin allow all levels to show up
  }
  // Called when cancel button clicked on Creating a new user
  createNewUserCancelButtonClicked(){
      if(this.isManageUser){
            this.viewCtrl.dismiss();
      } else{      
            this.isAddNewUser = true;
            this.showSelection.plt = true;
            this.showSelection.role = false;
            this.createNewUserFlag = false;
            this.showSelection.level = false;
            this.showSelection.language = false;
            this.showSelection.wLogin = false;
            this.showSelection.showFirstNameInput = false;
            this.showSelection.showLastNameInput = false;
            this.showSelection.showEmailInput = false;
            this.showSelection.showCertifiedSelect = false;
            this.showSelection.showWLoginInput = false;
            this.showSelection.pg = false;
            this.showSelection.shift = true;
            this.showSelection.auditor = true;
            this.navCtrl.pop();
    }
  }
  

  createNewUserButtonClicked(){
      if(this.isManageUser){
            this.selLevelId.levelId = ((!this.showSelection.level)  ? "0" :  this.selLevelId.levelId);    
            this.selLevelId.levelId = (this.showSelection.level && (this.selLevelId.levelId === "0")) ? "" :  this.selLevelId.levelId;    
          if(this.selAuditor.id !=="" && this.selLastName.name !== "" && this.selFirstName.name !== "" &&  this.selCertified.name.toString().toLowerCase() !== "select" && this.selCertified.name !== "" 
          &&  this.selLngId.langCode!=="" &&  this.selLngId.langCode !=="select" && this.selUser.wLogin !=="" && this.selwLogin.name.toLowerCase().indexOf("corplear\\") !== -1 &&
          this.selRoleId.roleId.toString().toLowerCase()  !== "select" && this.selLevelId.levelId.toString().toLowerCase() !== "select" &&
           this.selRoleId.roleId.toString().toLowerCase()  !== "" && this.selLevelId.levelId.toString().toLowerCase() !== ""){
               const selPgIdsConst = this.selPGId.pgId.toString().toLowerCase();
               if(selPgIdsConst === "" || selPgIdsConst === "select" ){
                    this.utilService.showToast("","Please Select the Product Group.");
                   return;
                //    if(this.showSelection.plt){
                //         const selPlantsArray = _.isArray(this.selPlantId) ? this.selPlantId : [this.selPlantId];
                //         this.selPGId.pgId = selPlantsArray[0].pgId;
                //    }                    
               }
                   if(this.showSelection.plt){ 
                    
                        const selPlantsArray:any =  _.isArray(this.selPlantId) ? this.selPlantId : [this.selPlantId];
                            // Below will compare the selected plant product group to the plants product group.
                            // bloe check is important otherwise it will create a new user for same plant but different product group
                            if(selPlantsArray.length >0 && selPlantsArray[0].plantId !== "" && selPlantsArray[0].plantId !== "0" && selPlantsArray[0].plantId.toString().toLowerCase() !== "0" && selPlantsArray[0].plantId.toString().toLowerCase() !== "select"){
                                    if(this.utilService.checkValidPlantsForPGSel(selPlantsArray, +this.selPGId.pgId)){//  return true if the selected plants are incorrect
                                        this.utilService.showToast("","Selected Product Groups and Selected Plants Product group doesn't match, Please change your selection.");
                                        return;
                                }
                            }                            
                    }   
                    if((this.selEmail.name === "" && this.selEmail.name.toString().toLowerCase() === "select") || (this.user.roleId === 1)){
                            if(this.selwLogin.name.toLowerCase().indexOf("corplear\\") !== -1){
                                const emailUserId = this.selwLogin.name.toLowerCase().split("\\");  
                                this.selEmail.name =  emailUserId[1]+"@lear.com";                                                          
                            }
                            else{
                                this.utilService.showToast("","Enter wlogin as Corplear\name");
                                return; 
                            }
                    }                                           
                const updateUser = new CreateNewUser(+this.selAuditor.id, /*this.usrSeltn.selLastName,*/ this.selLastName.name.trim(),
                                                                /*this.usrSeltn.selFirstName,*/ this.selFirstName.name.trim(),
                                                                this.selwLogin.name.toLowerCase().trim(),
                                                                this.selEmail.name.trim(),
                                                                +this.selRoleId.roleId,
                                                                +this.selLevelId.levelId,
                                                                0,(this.isAuditorActive === "true"),
                                                                this.selCertified.name === "true",
                                                                +this.selPGId.pgId,
                                                                this.selLngId.langCode.trim(),
                                                                this.selUser.wLogin.trim());
            this.userService.createNewUser(updateUser).subscribe((data)=>{
                if(this.utilService.checkValidData(data)){
                    this.utilService.showToast(data.Response[0],"");
                        if(this.showSelection.plt){      
                             const selPlantsArray = _.isArray(this.selPlantId) ? this.selPlantId : [this.selPlantId];                 
                            if(selPlantsArray[0] !== null && selPlantsArray[0] !== undefined && selPlantsArray[0].plantId !=="0" && selPlantsArray[0].plantId !=="" && selPlantsArray[0].plantId.toString().toLowerCase() !=="select"){
                                    
                                   // plts = plts.filter(item => (item !== 0 && item !== undefined)); // removing the 0 and undefined.
                                   // const selPlantsArray = _.isArray(this.selPlantId) ? this.selPlantId : [this.selPlantId];
                                    let plts:Array<number> = _.map(selPlantsArray,"plantId");
                                     const assignedPlantsIds:Array<number> = _.map(this.availPlantsList,"plantId");
                                     //if(assignedPlantsIds.indexOf(+this.selPGId.pgId) === -1){
                                        // if the assigned plants doesn't belong to selected product group
                                        // then delete the existing assigned plants
                                    //     this.deleteAssignedPlants = true;   
                                    // }
                                     if(!this.deleteAssignedPlants){ // combine the assigned plants with newly selected plants only if deleted not selected
                                        plts = plts.concat(assignedPlantsIds);
                                     }                                    
                                    plts = plts.filter(item => (item !== 0 && item !== undefined));
                                    this.userService.assignMulitplePlantsToUser(new AssignPlantsRequest(plts.join(), +this.selAuditor.id, this.selUser.wLogin)).subscribe((data)=>{
                                        if(this.utilService.checkValidData(data)){
                                            this.utilService.showToast("assignedPlantsToUser","");
                                            this.viewCtrl.dismiss();
                                        }
                                    });
                            }  else{
                                this.viewCtrl.dismiss();
                            }                          
                        } else{
                            this.viewCtrl.dismiss();
                        }
                    }
                });   
          } else{
              this.utilService.showToast("","Enter all the fields before update");
          }          
      } else {    
                if(this.createNewUserFlag){
                        this.selLevelId.levelId = ((!this.showSelection.level)  ? "0" :  this.selLevelId.levelId);     
                        this.selPGId.pgId = (((this.selPGId.pgId.toString().toLowerCase() === "select") || (this.selPGId.pgId === "") || (!this.showSelection.pg))  ? "0" :  this.selPGId.pgId);   
                        this.selCertified.name = (this.selCertified.name.toLowerCase() === "select" || this.selCertified.name === "") ? false.toString() : this.selCertified.name;  
                       // this.selLevelId.levelId = (this.selLevelId.levelId === "select"    ? "0" :  this.selLevelId.levelId);
                       if(this.selwLogin.name.toLowerCase().indexOf("corplear\\") !== -1){
                            const emailUserId = this.selwLogin.name.toLowerCase().split("\\");  
                            this.selEmail.name =  emailUserId[1]+"@lear.com";                                                          
                       }else{
                            this.utilService.showToast("","Enter wlogin as Corplear\name");
                           return; 
                       }
                            if(this.selUser.id !== "" &&  this.selLastName.name  !== "" &&
                           this.selwLogin.name.toLowerCase().indexOf("corplear\\") !== -1 &&
                                                                this.selFirstName.name !== "" &&
                                                                this.selwLogin.name !== "" &&
                                                                this.selEmail.name !== "" &&
                                                                this.selRoleId.roleId !== "select" &&
                                                                this.selRoleId.roleId !== "" &&
                                                                +this.selRoleId.roleId !== 0 &&
                                                                this.selLevelId.levelId !== "" &&
                                                                this.selLevelId.levelId.toString().toLowerCase() !== "select" &&                                        
                                                                this.selCertified.name !== "select" &&
                                                                this.selPGId.pgId  !== "" &&
                                                                this.selLngId.langCode  !== "" &&
                                                                this.selUser.wLogin  !== ""){
                                                                     
                                                                    //if UserId is 0 then create otherwise update
                                        const newUser = new CreateNewUser(0/*User Id of the Auditor*/, this.selLastName.name.trim(),
                                                                this.selFirstName.name.trim(),
                                                                this.selwLogin.name.toLowerCase().trim(),//always send lower case of the wLogin
                                                                 this.selEmail.name.trim(),
                                                                +this.selRoleId.roleId,
                                                                +this.selLevelId.levelId,
                                                                0,// Layer will be inserted as 0 for all the new
                                                                // users as the layer will be removed from system later on
                                                                true,
                                                                this.selCertified.name === "true",
                                                                +this.selPGId.pgId,
                                                                this.selLngId.langCode.trim(),
                                                                this.selUser.wLogin.trim()/*wLogin of the super admin who is adding the new user*/);
                                this.userService.createNewUser(newUser).subscribe((data)=>{
                                    if(this.utilService.checkValidData(data)){
                                      this.utilService.showToast(data.ResponseCode,"");
                                       if(data.ResponseCode === "1022"){// succesfully inserted the user to the LPA system
                                            const userId = data.Response;// userId si returned form the stored Procedure.
                                            if(userId !== undefined && userId !== "" && +userId !== NaN){//check valid user Id.                                            
                                             if(this.showSelection.plt){      
                                                    const selPlantsArray = _.isArray(this.selPlantId) ? this.selPlantId : [this.selPlantId];                 
                                                    if(selPlantsArray[0] !== undefined && selPlantsArray[0].plantId !==""&& selPlantsArray[0].plantId.toString().toLowerCase() !=="select"){
                                                            let plts = _.map(this.availPlantsList,"plantId");
                                                        // plts = plts.filter(item => (item !== 0 && item !== undefined)); // removing the 0 and undefined.
                                                        // const selPlantsArray = _.isArray(this.selPlantId) ? this.selPlantId : [this.selPlantId];
                                                            const selPlantsIds = _.map(selPlantsArray,"plantId");
                                                            plts = plts.concat(selPlantsIds);
                                                            plts = plts.filter(item => (item !== 0 && item !== undefined));
                                                            this.userService.assignMulitplePlantsToUser(new AssignPlantsRequest(plts.join(), +userId, this.selUser.wLogin)).subscribe((data)=>{
                                                                if(this.utilService.checkValidData(data)){
                                                                    this.utilService.showToast("assignedPlantsToUser","");                                         
                                                                    this.viewCtrl.dismiss();
                                                                }
                                                            });
                                                    }                         
                                            }  else{
                                                this.viewCtrl.dismiss();
                                            }                                           
                                            } else{
                                                this.utilService.showToast("","Failed Create new User to the LPA System");
                                            }
                                        } else{
                                            this.viewCtrl.dismiss();
                                        }
                                    }
                                    //this.createNewUserCancelButtonClicked();
                                });
                            }  else{
                                this.utilService.showToast("enterAllFields","");
                            }      
                } else {
                    if(this.selShift.name.toLowerCase() === "select"){
                        this.selShift.name = "";
                    }
                    if(this.selPlantId.plantId  !== "" && this.selAuditor.id  !== "" && this.selAuditor.id.toString() !== "0" && this.selUser.wLogin !== "" ){
                        this.userService.assignMulitplePlantsToUser(new AssignPlantsRequest(_.map(this.selPlantId.plantId,"plantId").join(), +this.selAuditor.id,  this.selUser.wLogin)).subscribe((data)=>{
                            if(this.utilService.checkValidData(data)){
                                this.utilService.showToast(data.Response[0], "");
                                this.viewCtrl.dismiss();
                            }                              
                        });
                    } else{
                        this.utilService.showToast("enterAllFields","");
                       }                
                } 
      }     
  }


private showCalender(dateType:string){
  this.translateService.get(["selectStartDate","selectEndDate","weekDaysArray","monthTitle"]).subscribe((values)=>{
        // const datePickerTitle = dateType === "stDate" ?  values["selectStartDate"] : values["selectEndDate"] ;
        let showWeekStartOnly = false;
        let isEndDateOnly = dateType === "endDate";

        const navParams = this.navParams.data;
        if(navParams.showWeekStartOnly !== undefined && navParams.showWeekStartOnly === "true"){
            showWeekStartOnly = true;
            this.showSelection.endDate = false;
        }
        let date = new Date();        
        //let stDate = new Date(date.getFullYear(),date.getMonth() - 3,date.getDate()); 
       // let edDate = new Date((date.getFullYear()+1),date.getMonth(),date.getDate());                                       
        let _daysConfig = [];
        if(this.selStDate.stDate !== "" && this.selStDate.stDate.toLowerCase() !== "select"  &&
            this.selEndDate.endDate.toLowerCase() !== "select" && this.selEndDate.endDate !== ""){  
                _daysConfig.push({
                    date:new Date(this.selStDate.stDate),
                    subTitle:"Start",
                    marked:true
                });
                _daysConfig.push({
                    date:new Date(this.selEndDate.endDate),
                    subTitle:"End",
                    marked:true                                
                });                                
                //stDate = new Date(this.selStDate.stDate);
                //edDate = new Date(this.selEndDate.endDate);
        } 
        const datePickerTitle = values["selectDateRange"];
        this.calendarCtrl.openCalendar({            
            isRadio: !showWeekStartOnly,
            title: datePickerTitle,                        
        //    from:stDate,
        //    to:edDate,
            daysConfig:_daysConfig,
            disableWeekdays: showWeekStartOnly ? [1,2,3,4,5,6] : [],
            monthTitle:values["monthTitle"],
            weekdaysTitle:values["weekDaysArray"],
            //canBackwardsSelected:true,
            //showYearPicker:true,
           // closeIcon:true
            //from: this.selStDate.stDate !== "" && this.selStDate.stDate !== "select" ? new Date(this.selStDate.stDate) : new Date(),
           // to  : this.selEndDate.endDate !== "" && this.selEndDate.endDate !== "select" ? new Date(this.selEndDate.endDate) : new Date()
            //defaultDate:new Date(2017,4,1),   
        }).then((res:any)=>{
            let selStartDate = "";
            let selEndDate = "";
            if(isEndDateOnly){
               selEndDate = this.utilService.changeDateFormatFromTicks(res.from.time);  
            } else{
                selStartDate = this.utilService.changeDateFormatFromTicks(res.from.time);
            }                                        
            if(showWeekStartOnly && !isEndDateOnly){                
               selEndDate = this.utilService.getWeekEndDateForWeekStart(res.from.time);
            } 
            if(!showWeekStartOnly && !isEndDateOnly){
              selEndDate = this.utilService.changeDateFormatFromTicks(res.to.time);  
            }                            
            if(selStartDate !== undefined && selStartDate !== "" ){
                    this.selStDate.stDate = selStartDate;  
            } 
            if(selEndDate !== undefined  && selEndDate !== ""){                
                this.selEndDate.endDate = selEndDate;
               // this.showSelection.endDate = true; // limit to select only weekly dates
            }                        
        }).catch(() => {
        });
  });  
}

}
