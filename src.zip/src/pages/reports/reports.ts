import { Component } from '@angular/core';
import { NavController} from 'ionic-angular';
import {UtilService} from "../../providers/util-service";
import { UserService} from '../../providers/user-service';
import { UserSelectionData } from '../../models/QuestionItem';
import * as moment from  'moment';
import { NumberValueAccessor } from '@angular/forms/src/directives/number_value_accessor';
@Component({
  selector: 'reports-page',
  templateUrl: 'reports.html'
})


export class Reports{    
    selectionData:UserSelectionData;
    serverUrl:string ="http://usdca-lpbsdb01.corp.lear.com/reportserver?/LEAR/LPA/";
    currentYear:string;
    currentMonth:string;
    currWeek:number;
    public plantNameTitle: string;
    constructor(public navCtrl: NavController, public utilService:UtilService, public userService:UserService){ 
        this.plantNameTitle = "";            
    }
    ionViewDidLoad(){
        moment.locale('en-US');
        this.currWeek = Math.ceil((+moment.tz('America/New_York').format("DD")) / 7);
        this.currentYear = moment.tz('America/New_York').format("YYYY");
        this.currentMonth = moment.tz('America/New_York').format("MM");
        this.selectionData = this.userService.getUserSelection();
        this.plantNameTitle = this.selectionData.selPltName;
    }
    reportsLPAUsersItemClicked(){
       
        const pgId = this.selectionData.selPGId;//.toString() !== '' && ;
        const plantId = this.selectionData.selPltId;
        const lpaUsersReport = "LPA User Report&repProductGroup="+pgId+"&repPlant="+plantId;
      if(this.utilService.isMobileApp){
          (<any>window).location.href = "LPAReport.com?"+lpaUsersReport;      
        
      } else{
           window.open(this.serverUrl+lpaUsersReport,"_blank");
      }
  }
  reportsLPAAuditsSummaryItemClicked(){
      this.selectionData = this.userService.getUserSelection();
      const pgId = this.selectionData.selPGId;
      const plantId = this.selectionData.selPltId;
      const levelId = this.selectionData.selLevelId;
      const startDate = moment().format('MM/[01]/YYYY');
      const endDate = moment().format('MM/DD/YYYY');
       
        //http://usdca-lpbsdb01.corp.lear.com/ReportServer/Pages/ReportViewer.aspx?/LEAR/LPA/LPA%20Audit%20Summary_20180403&
        //repProductGroup=5&repRegion=Global&repPlant=16&repProcess=0&repLayer=0&repAdhoc=0&repStartDate=04/01/2018&repEndDate=04/20/2018

      const lpaAuditSummaryReport = "LPA Audit Summary&repProductGroup="+pgId+"&repRegion=Global"+"&repPlant="+plantId+"&repProcess=0&repLayer="+levelId+"&repAdhoc=0";

      if(this.utilService.isMobileApp){
          (<any>window).location.href = "LPAReport?"+lpaAuditSummaryReport;      
         
      } else{
          window.open(this.serverUrl+lpaAuditSummaryReport,"_blank");
      }
  }
  reportsLPAAuditsListItemClicked(){
    this.selectionData = this.userService.getUserSelection();
    const pgId = this.selectionData.selPGId;
    const plantId = this.selectionData.selPltId;
    const levelId = this.selectionData.selLevelId;
    const startDate = moment().format('MM/[01]/YYYY');
    const endDate = moment().format('MM/DD/YYYY');
   
    const lpaAuditSummaryReport = "LPA Audit List&repProductGroup="+pgId+"&repLayer="+levelId+"&repProcess=0&repPlant="+plantId+
    "&repStatusId=0&repAdhoc=0";
    //http://usdca-lpbsdb01.corp.lear.com/ReportServer/Pages/ReportViewer.aspx?/LEAR/LPA/LPA%20Audit%20List&
    //repProductGroup=5&repLayer=0&repProcess=0&repPlant=16&repStatusId=0&repAdhoc=0&repStartDate=04/01/2018&repEndDate=04/20/2018
  
    if(this.utilService.isMobileApp){
        (<any>window).location.href = "LPAReport?"+lpaAuditSummaryReport;      
       
    } else{
        window.open(this.serverUrl+lpaAuditSummaryReport,"_blank");
    }
}
reportsWasteWalkItemClicked(){
    this.selectionData = this.userService.getUserSelection();
    const pgId = this.selectionData.selPGId;
    const plantId = this.selectionData.selPltId;
    const levelId = this.selectionData.selLevelId;
    const startDate = moment().format('MM/[01]/YYYY');
    const endDate = moment().format('MM/DD/YYYY');
   
    const lpaAuditSummaryReport = "LPA Audit List&repProcess=1001";
    if(this.utilService.isMobileApp){
        (<any>window).location.href = "LPAReport?"+lpaAuditSummaryReport;      
        
    } else{
        window.open(this.serverUrl+lpaAuditSummaryReport,"_blank");
    }
}

reportsOpenActionItemClicked(){
    this.selectionData = this.userService.getUserSelection();
    const pgId = this.selectionData.selPGId;
    const plantId = this.selectionData.selPltId;
    const levelId = this.selectionData.selLevelId;
   
   const lpaAuditSummaryReport = "LPA Action Item Report&repProductGroup="+pgId+"&repPlant="+plantId+"&repLayer=0&repStatus=0&repProcess=0";

    if(this.utilService.isMobileApp){
        (<any>window).location.href = "LPAReport?"+lpaAuditSummaryReport;      
        
    } else{
        window.open(this.serverUrl+lpaAuditSummaryReport,"_blank");
    }
}
reportsLPAQuestionMasterClicked(){
    this.selectionData = this.userService.getUserSelection();
    const pgId = this.selectionData.selPGId;
    const plantId = this.selectionData.selPltId;
    const levelId = this.selectionData.selLevelId;

    const lpaAuditSummaryReport = "LPA Question Master&repProductGroup="+pgId;
    if(this.utilService.isMobileApp){
        (<any>window).location.href = "LPAReport?"+lpaAuditSummaryReport;      
       
    } else{
        window.open(this.serverUrl+lpaAuditSummaryReport,"_blank");
    }
}

reportsTopOpportunitiesClicked(){
    this.selectionData = this.userService.getUserSelection();
    const pgId = this.selectionData.selPGId;
    const plantId = this.selectionData.selPltId;
    const levelId = this.selectionData.selLevelId;    
    const langCode = this.selectionData.selLangCode;

    //http://usdca-lpbsdb01.corp.lear.com/reports/report/LEAR/LPA/LPA%20Top%20N%20Opp
   const lpaTopOppReport = "LPA Top N Opp&repProductGroup="+pgId+"&repLayer=0&repProcess=0&repPlant="+plantId
   +"&repProcessType=1&repLang="+langCode+"&repAdhoc=0&repTopNQuestion=0";

    if(this.utilService.isMobileApp){
        (<any>window).location.href = "LPAReport?"+lpaTopOppReport;      
        
    } else{
        window.open(this.serverUrl+lpaTopOppReport,"_blank");
    }
}


}