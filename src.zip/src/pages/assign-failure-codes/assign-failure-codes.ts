import { Component, OnInit } from '@angular/core';
import { ViewController, IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { UsersInPlant, AuditDetailsFailureCode,AuditDetailsFailureCodeQuestion,  FailureCode} from '../../models/QuestionItem';
import { UtilService } from '../../providers/util-service';
import { UserService } from '../../providers/user-service';
import { SearchUsersInPlant } from '../../popup-modals/search-users-in-plant/search-users-in-plant';
import { AdminManageFailureCodesPage } from '../admin-manage-failure-codes/admin-manage-failure-codes';
import * as _ from 'lodash';

/**
 * Generated class for the AssignFailureCodesPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 * 
 * 
 * Input:
 * isFromPage
 * 
 * 
 */

@Component({
  selector: 'page-assign-failure-codes',
  templateUrl: 'assign-failure-codes.html',
})
export class AssignFailureCodesPage implements OnInit{
    private shownGroupas;
    private auditDtsFailCode:Array<AuditDetailsFailureCode>;
    private auditDtsFailCodeQues:AuditDetailsFailureCodeQuestion;
    private failCodes:Array<AuditDetailsFailureCode>;
    private showInComplete:boolean;
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              private viewCtrl: ViewController,
              private modalCtrl: ModalController,
              private utilService: UtilService,
              private userService:UserService) {
                this.shownGroupas = null;
                this.showInComplete = false;
              
  }

  ionViewDidLoad() {
    
  }

  ngOnInit(){
       const usersList:Array<UsersInPlant> = this.userService.getUsersInPlant();
       const navParams = this.navParams.data;
       if(this.utilService.itemDefined(navParams.assignFailureCodesToQuestions)){
          this.auditDtsFailCode = navParams.assignFailureCodesToQuestions;
       }
       // Grouping the Group with same Failure Codes
       let auditDtsFailCodeGrp : Array<Array<AuditDetailsFailureCode>> = _.values(_.groupBy(this.auditDtsFailCode,'failCode'));    
          this.failCodes = auditDtsFailCodeGrp.reduce((prev, item) => {            
             const itm = item.reduce((pv, im)=>{
                              item[0].assignedQueList.push(+im.question[0].queId);// addign the queId to the faile Code list of questions
                            im.question[0].failCode = item[0].failCode;// assigning the failCode by default to the question
                              pv.push(im.question[0]);
                              return pv;
                          }, []);
                          const assignee = _.filter(usersList, (usr) => usr.userId === item[0].assigneeId )[0];
                          const reviewer = _.filter(usersList, (usr) => usr.userId === item[0].reviewerId )[0]; 
                          if((assignee === undefined) || (reviewer === undefined)){
                               console.error("asignee or reviewer is undefined, incorrect data received from service, Cannot fin the assignee in the plant.");
                          }                         
            prev.push(new AuditDetailsFailureCode(item[0].failCode,
                                                  item[0].failDesc,
                                                  item[0].assigneeId,
                                                  item[0].reviewerId,
                                                  assignee !== undefined ? (assignee["firstName"] + assignee["lastName"]) : "",
                                                  reviewer !== undefined ? (reviewer["firstName"] + reviewer["lastName"]) : "",
                                                  item[0].assignedTo,
                                                  item[0].severity,
                                                  false,
                                                  item[0].failCodeHelp,
                                                  item[0].failActive,
                                                  item[0].assignedQueList,itm));
              return prev;
          },[])
  }    
private checkFailCodesAssigned(){
       return this.failCodes.reduce((prev, item) => {
          if(item.assigneeId === 0 && item.reviewerId ===0){
              prev.push(item);
          }
          return prev;
      },[]);
}
  private doneButtonClicked(){
    if(this.checkFailCodesAssigned().length === 0){
        this.viewCtrl.dismiss(this.failCodes);
    } else{
      this.showInComplete = true;
    }      
  }

  private appliesToOtherFailureCodes(failCode:AuditDetailsFailureCode){
     let fcList:Array<AuditDetailsFailureCode> = this.failCodes;
     const itemIndex = _.findIndex(fcList,(item)=>{
                          return item.assigneeId === failCode.assigneeId;
                      });
       //const selLen =  fcList.length;
      if(itemIndex !==-1){              
        fcList.splice(itemIndex, 1);  // Removing the item from assigned failure code                         
      }
     // TODO remove the assigne item from fcList
     // add the serch functionality
    let modalCtrl = this.modalCtrl.create(AdminManageFailureCodesPage,{
      "isFromPage":"AssignFailureCodes",
      "availFCList":fcList
    });
    modalCtrl.onDidDismiss((data:Array<FailureCode>)=>{
      if(data){
          const selfailCodeArray = _.map(data,"failCode");
        // TODO get the select list of failure codes to which selected assignee and reviewer applies to
        // find the selected Failure Codes 
        this.failCodes = this.failCodes.reduce((prev, item:AuditDetailsFailureCode)=>{
          if(selfailCodeArray.indexOf(item.failCode) !== -1){
              if(item.failCode !== failCode.failCode){
                  item.assigneeId = failCode.assigneeId;
                  item.reviewerId = failCode.reviewerId;
                  item.assigneeName = failCode.assigneeName;
                  item.reviewerName = failCode.reviewerName;
                  item.assignedTo = failCode.assignedTo;
                  item.severity = failCode.severity;
                  prev.push(item); 
              }
          }
          return prev;
        }, []); 
        //this.failCodes.push(failCode); 
        this.failCodes.splice(itemIndex,0,failCode); // adding back the item that was removed before sending to the manage failure codes page  at the same location
      }      
    });
    modalCtrl.present();
  }

  private cancelButtonClicked(){
      this.viewCtrl.dismiss();
  }
  private createNewFailCodeToQue(event, fc:AuditDetailsFailureCode, que:AuditDetailsFailureCodeQuestion, index, mainIndex){
       
       if(fc.question.length === 1){
          const fcItem:Array<AuditDetailsFailureCode> = this.failCodes.splice(mainIndex ,1); 
          this.insertNewFailureCodeToList(fcItem[0]);
       } else{
         const ques:Array<AuditDetailsFailureCodeQuestion> = fc.question.splice(index, 1); // splicing the question from failure code       
         this.failCodes.push(new AuditDetailsFailureCode(fc.failCode,fc.failDesc,0,0,"","",false,0,false,fc.failCodeHelp,fc.failActive,fc.assignedQueList,ques));
      }
  }

  private insertNewFailureCodeToList(data:AuditDetailsFailureCode){
    this.failCodes.push(data);
  }
   searchUsers(fcObject,itemId, itemName){
    let modal = this.modalCtrl.create(SearchUsersInPlant);
    modal.onDidDismiss((data:UsersInPlant)=>{
      if(data){
          fcObject[itemId] = data.userId;
         fcObject[itemName] = data.firstName+","+data.lastName;
      }        
    });
    modal.present();
  }

  toggleGroup(group) {
    if (this.isGroupShown(group)) {
        this.shownGroupas = null;
    } else {
        this.shownGroupas = group;
    }
  };

  isGroupShown(group) {
      return this.shownGroupas === group;
  };
}
