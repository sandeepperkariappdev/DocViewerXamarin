import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';

/**
 * Generated class for the SearchAudits page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-search-audits',
  templateUrl: 'search-audits.html',
})
export class SearchAudits {

  constructor(public navCtrl: NavController, public navParams: NavParams, private viewCtrl:ViewController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SearchAudits');
  }
  dismiss(){
    this.viewCtrl.dismiss();
  }
  submit(){
     this.viewCtrl.dismiss();
  }
}
