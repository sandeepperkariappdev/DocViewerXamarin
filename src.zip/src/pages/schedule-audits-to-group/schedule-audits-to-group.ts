import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, ModalController } from 'ionic-angular';
import { SearchUsersInPlant} from '../../popup-modals/search-users-in-plant/search-users-in-plant';
import { UserObject, ResponseObject, UserSelectionData, SubmitScheduledAudit } from '../../models/QuestionItem';
import { User } from '../../models/user';
import * as _ from 'lodash';
import { AuditService } from '../audits/audit-service';
import { UtilService} from '../../providers/util-service';
import { UserService} from '../../providers/user-service';
import { Machine, Shift } from '../../models/Level';
import { AdminManageMachineProvider } from '../resources-management/admin-manage-machine/admin-manage-machine-service';
/**
 * Generated class for the ScheduleAuditsToGroupPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

class AssigningAuditors{
  constructor(public auditor:UserObject, public shift:Shift, public machine:Machine){
  }
}

@Component({
  selector: 'page-schedule-audits-to-group',
  templateUrl: 'schedule-audits-to-group.html',
})

export class ScheduleAuditsToGroupPage {
  public auditorsList:Array<AssigningAuditors>;
  public selAuditor = { id:"",name:""};
  private selUser = { id : "0" , name:"select", wLogin:""};
  public shift:string;
  public machines:string;
  private user:User;
  private plantAuditListId:string;
  private shiftList:Array<Shift>;
  private machinesList:Array<Machine>;  
  private selectionData:UserSelectionData; 
  constructor(public navCtrl: NavController, 
              private modalCtrl: ModalController, 
              private viewCtrl:ViewController,
              private utilService: UtilService, 
              private userService:UserService,
              private auditService:AuditService,
              private adminManageMachine: AdminManageMachineProvider,
              public navParams: NavParams) {
    this.auditorsList = [];
    this.shiftList = [];
    this.machinesList = [];
    this.selectionData  = this.userService.getUserSelection();
    this.user = this.userService.getUser();
    this.plantAuditListId = "";
  }

  ionViewDidLoad() {
    if(this.navParams.data.plantAuditListId !== undefined){
      this.plantAuditListId = this.navParams.data.plantAuditListId;  
    }
    this.plantAuditListId = this.navParams.data.plantAuditListId;
   this.loadShiftsForPlant();
   this.loadMachinesFromServerForpLant();
  }
  public addNewAuditorToAudit(){
    this.auditorsList.push(new AssigningAuditors(new UserObject(0,""),new Shift('0', 'select'),new Machine('0', 'select', "", true)));
  }
   private loadShiftsForPlant():void{
        this.adminManageMachine.getShiftsForPlant(+this.selectionData.selPltId).subscribe((data:ResponseObject)=>{
                        if(this.utilService.checkValidData(data)){
                             this.shiftList = data.Response;
                            //  = data.Response.reduce((prev,item)=>{
                            //         prev.push(new Shift(item.SHIFT, item.SHIFT));
                            //      return prev; 
                            //  },[]);                             
                        } else{
                            this.utilService.showToast("","Shifts are not received from server.");
                        }
        });
  }

  private loadMachinesFromServerForpLant(){
    this.adminManageMachine.getListOfMachines(+this.selectionData.selPltId, "1",
          +this.selectionData.selPrId, true,this.selectionData.selPGId).subscribe((data)=>{
                this.machinesList = data;
                this.utilService.hideLoading();
            });
  }
 searchUsers(item:AssigningAuditors){    
    let modal = this.modalCtrl.create(SearchUsersInPlant);
    modal.onDidDismiss((data:User)=>{
      if(this.utilService.itemDefined(data)){          
            item.auditor.id = data.userId;
            item.auditor.name = data.firstName + "," + data.lastName;          
      }              
    });
    modal.present();
  }
onMachineSelChange(item){   
      if(_.isArray(item.machine.name)){        
          const selIndex = item.machine.name.indexOf("select");
          const selLen =  item.machine.name.length;
          if(selIndex !==-1){    
            if(_.isArray(item.machine.name)){          
             item.machine.name = item.machine.name.slice(1, selLen);                          
            } 
          }
          const selAllIndex = item.machine.name.indexOf("selectAll");
          const selAllLen =  item.machine.name.length;
          if(selAllIndex !== -1){
            if(_.isArray(item.machine.name)){
              item.machine.name = item.machine.name.slice(1, selAllLen); 
              item.machine.name = _.map(this.machinesList, 'name');            
            }
          }
      }
}
 
  private assignAuditToSelectedUsers(){
          // remove the select or selectAll from the machines list
          this.auditorsList.forEach((item)=>{
                this.onMachineSelChange(item);
                if(item.auditor.id !== 0 && item.shift.name !== "select" && item.machine.name.indexof("select") !== -1 && item.machine.name.length > 0){                        
                    this.auditService.postScheduleAcceptedAuditToUser(new SubmitScheduledAudit(+this.plantAuditListId, item.auditor.id, "0000", 
                                                                      item.machine.name, item.shift.name, 
                                                                      "",this.user.wLogin)).subscribe((data:ResponseObject)=>{
                                if(this.utilService.checkValidData(data)){                               
                                        this.utilService.showToast("","Successfully Assigned the Audit.")                                                                
                                }
                            });                                  
                }
          });
          this.viewCtrl.dismiss();
  }

  cancelButtonClicked(){
          this.viewCtrl.dismiss();
  }
}



