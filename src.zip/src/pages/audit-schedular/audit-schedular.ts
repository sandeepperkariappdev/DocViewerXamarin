import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { EditScheduledAuditPage } from "./edit-scheduled-audit/edit-scheduled-audit";
import { ScheduleNewAuditPage } from "./schedule-new-audit/schedule-new-audit";
import { UserService} from '../../providers/user-service';
import { TranslateService } from 'ng2-translate';
/**
 * Generated class for the AuditSchedularPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */


@Component({
  selector: 'page-audit-schedular',
  templateUrl: 'audit-schedular.html',
})
export class AuditSchedularPage {
  public pageTitle:string; 
  constructor(public navCtrl: NavController, private translate: TranslateService, public navParams: NavParams, public userService: UserService) {
  }

  ionViewDidLoad() {
    const selData = this.userService.getUserSelection();
    this.translate.get(["scheduler"]).subscribe((values)=>{
      this.pageTitle = values["scheduler"] + " - " + selData.selPltName;
    });    
  }
  editScheduledAuditClicked(isLpaAudit:boolean){
      this.navCtrl.push(EditScheduledAuditPage,{ "isLpaAudit":isLpaAudit.toString() });
  }
  scheduleNewAuditClicked(){
    //this.navCtrl.setRoot(ScheduleNewAuditPage);
    this.navCtrl.push(ScheduleNewAuditPage);
  }

}
