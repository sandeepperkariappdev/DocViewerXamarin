import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { UserObject, UserSelectionData,ResponseObject, ProcessWeeklyAuditsList, UserSelectionPrivileges, ActiveAudit, WeeklyAuditsList, AcceptedAuditItem } from '../../../models/QuestionItem';
import * as _ from 'lodash';
import { UtilService } from '../../../providers/util-service';
import * as moment from  'moment';
/*
  Generated class for the EditScheduledAuditServiceProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
@Injectable()
export class EditScheduledAuditServiceProvider {

  constructor(public utilService:UtilService) {
    moment.locale('en-US');
  }
  private getYearFromDate(date:string =""){
      if(date!==""){
          return moment.tz(date,'America/New_York').format("YYYY");
      } else{
        return moment.tz('America/New_York').format("YYYY");
      }     
  }

  //public getGroupByProcess(auditsList:Array<AcceptedAuditItem>):Array<ProcessWeeklyAuditsList>{
public getWeeklyAuditsList(auditsList:Array<AcceptedAuditItem>):Array<WeeklyAuditsList>{
    const that = this;
      let auditsGroupedByProcess = _.groupBy(auditsList,(item => item.procId ));
      let auditProcesses = Object.keys(auditsGroupedByProcess);
      if(auditProcesses.length > 0){
            return auditProcesses.reduce((prev, item)=>{
                            let processAuditsList = auditsGroupedByProcess[item];
                            prev = prev.concat(that.getWeeklyAuditsForFuture(processAuditsList));
                        return prev;
                    },[]);
      } else{
            return this.getEmptyWeeklyAuditsForFuture();
      }      
  }
  public getGroupedByWeeks(auditsList:Array<AcceptedAuditItem>):Array<WeeklyAuditsList>{  
        moment.locale('en-US');  
        const currWeekStartDate = this.utilService.getWeekStartDate();
        const lookInYearCurrWeek = this.getYearFromDate(currWeekStartDate);
        let emptyWeeks = this.getEmptyWeeklyAuditsForFuture();
        const emptyWeekStartDatesArray = _.map(emptyWeeks, 'weekStart');
        const momCurr = moment(lookInYearCurrWeek);
        //let auditsGroupedByWeek = _.groupBy(auditsList,(item => { return (moment.tz(item.startDate,'America/New_York').week() -1)}));
        let auditsGroupedByWeek = _.groupBy(auditsList,(item => { return (moment.tz(item.startDate,'America/New_York').week())}));
        let auditWeeks = Object.keys(auditsGroupedByWeek);
        return auditWeeks.reduce((prev, item)=>{
                const startDate = auditsGroupedByWeek[item][0]["startDate"];
                const lookInYear = this.getYearFromDate(startDate);
                //const currWeekCount = moment.tz('America/New_York').week() -3;
                //const momCurr = moment();
                const momCurr = moment(lookInYearCurrWeek);
                const currWeekCount = momCurr.tz('America/New_York').week() -1;                
                const currentWeekStart =  moment.tz('America/New_York').add((+currWeekCount), 'weeks').startOf('week').format("MM/DD/YYYY");
                //const mom = ((lookInYear === lookInYearCurrWeek) ? moment() : moment(lookInYear));
                const mom = moment(lookInYear);
                const weekStartDate = mom.tz('America/New_York').add(+item -1, 'weeks').startOf('week').format("MM/DD/YYYY");
                const weekFormattedStartDate = moment(weekStartDate).format("MMM Do, YYYY");
                const weekMom =  moment(weekStartDate);
                const currWeekMom = moment(currentWeekStart);
                if(weekMom.tz('America/New_York').valueOf() >= currWeekMom.tz('America/New_York').valueOf()){
                    const index = emptyWeekStartDatesArray.indexOf(weekStartDate)
                    if(index === -1){
                            prev.unshift(new WeeklyAuditsList(weekStartDate, weekFormattedStartDate, auditsGroupedByWeek[item]));                                    
                    } else{
                        prev[index]["weekStart"] = weekStartDate;
                        prev[index]["weekFormattedStartDate"] = weekFormattedStartDate;
                        prev[index]["auditsList"] = auditsGroupedByWeek[item];
                    }                               
                }                          
            return prev;
        },emptyWeeks);              
    }

    private getEmptyWeeklyAuditsForFuture(){
    moment.locale('en-US');
    
    let auditWeek = [];
    const currWeekStartDate = this.utilService.getWeekStartDate();
    const lookInYear = this.getYearFromDate(currWeekStartDate);
    const mom = moment(lookInYear);
   // const todayLookInYear = this.getYearFromDate();
  //  const momToday  = moment(todayLookInYear);
    let currWeekCount = mom.tz('America/New_York').week() - 1;    
    // if(todayLookInYear === lookInYear){
    //    currWeekCount = currWeekCount - 2;           
    // }    
    //for(let i= 0; i<12; i++){ 
    //    const weekStartDate = moment.tz('America/New_York').add(currWeekCount, 'weeks').startOf('week').format("MM/DD/YYYY");
    //    const weekFormattedStartDate = moment(weekStartDate).format("MMM Do, YYYY") 
    //    auditWeek.push(new WeeklyAuditsList(weekStartDate, weekFormattedStartDate, []));
    //    currWeekCount = currWeekCount + 1;
    //}
    for(let i= 0; i<12; i++){                    
        const weekStartDate = moment.tz('America/New_York').add(currWeekCount, 'weeks').startOf('week').format("MM/DD/YYYY");
        const weekFormattedStartDate = moment(weekStartDate).format("MMM Do, YYYY") 
        auditWeek.push(new WeeklyAuditsList(weekStartDate, weekFormattedStartDate, []));
        currWeekCount = currWeekCount + 1;
    }
    return auditWeek;
    }
    private getWeeklyAuditsForFuture(auditsList:Array<AcceptedAuditItem>){
    return this.getGroupedByWeeks(auditsList);               
    }
}
