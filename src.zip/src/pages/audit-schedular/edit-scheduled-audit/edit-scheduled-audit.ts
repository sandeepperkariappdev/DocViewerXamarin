import { Component } from '@angular/core';
import { PopoverController, IonicPage, NavController,ModalController, NavParams } from 'ionic-angular';
import { AuditService } from '../../audits/audit-service';
import { UserService } from '../../../providers/user-service';
import { UtilService } from '../../../providers/util-service';
import { User} from '../../../models/User';
import { SelectionPage } from '../../selection/selection';
import { UserObject, UserSelectionData,ResponseObject, AuditList, UserSelectionPrivileges, ProcessWeeklyAuditsList, WeeklyAuditsList, ActiveAudit, AcceptedAuditItem } from '../../../models/QuestionItem';
import * as _ from 'lodash';
import * as moment from  'moment';
import { TranslateService } from 'ng2-translate';
import { AdminAuditProvider } from '../../admin/admin-audits/admin-audits-service';
import { EditScheduledAuditServiceProvider } from "./edit-scheduled-audit-service";
import { WeeklySchedulingToAuditorsPage} from "../../weekly-scheduling-to-auditors/weekly-scheduling-to-auditors";
/**
 * Generated class for the EditScheduledAuditPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-edit-scheduled-audit',
  templateUrl: 'edit-scheduled-audit.html',
})
export class EditScheduledAuditPage {
    private selectionData:UserSelectionData;

    public weeklyAuditsListLevel1:Array<WeeklyAuditsList>;
    public initialWeeklyAuditsListLevel1:Array<WeeklyAuditsList>;

    public weeklyAuditsListLevel2:Array<WeeklyAuditsList>;
    public initialWeeklyAuditsListLevel2:Array<WeeklyAuditsList>;

    public weeklyAuditsListLevel3:Array<WeeklyAuditsList>;
    public initialWeeklyAuditsListLevel3:Array<WeeklyAuditsList>;

    public weeklyAuditsListLevel4:Array<WeeklyAuditsList>;
    public initialWeeklyAuditsListLevel4:Array<WeeklyAuditsList>;

    public weeklyAuditsListLevel:Array<WeeklyAuditsList>;
    public initialWeeklyAuditsListLevel:Array<WeeklyAuditsList>;

    private adminAuditUserSelPrivileges:UserSelectionPrivileges;
    public auditsListInitialLevel1:Array<AuditList>;
    public auditsListLevel1:Array<AuditList>;

    public auditsListInitialLevel2:Array<AuditList>;
    public auditsListLevel2:Array<AuditList>;

    public auditsListInitialLevel3:Array<AuditList>;
    public auditsListLevel3:Array<AuditList>;

    public auditsListInitialLevel4:Array<AuditList>;
    public auditsListLevel4:Array<AuditList>;

    public auditsListInitialLevel:Array<AuditList>;
    public auditsListLevel:Array<AuditList>;

    private isPlantAdmin:boolean;
    private user:User;
    private levelList:Array<string>;
    public optionView :string;
    public showAllQue:boolean;
    private selData:UserSelectionData; 
    private isCropAdmin:boolean;
    private pageTitle:string;
    private plantId:number;
    private shownGroupas = null;
    public isLPAAuditScheduler: boolean;
  constructor(public navCtrl: NavController, 
    private auditService:AuditService, 
    private adminAuditService:AdminAuditProvider,
    private utilService: UtilService,
    private userService: UserService,
    private popoverCtrl:PopoverController,
    private modalCtrl:ModalController, 
    private translate: TranslateService,
    private editSchAuditService:EditScheduledAuditServiceProvider,
    public navParams: NavParams) {
        

        this.weeklyAuditsListLevel1 = [];
        this.initialWeeklyAuditsListLevel1 = [];
        this.weeklyAuditsListLevel2 = [];
        this.initialWeeklyAuditsListLevel2 = [];
        this.weeklyAuditsListLevel3 = [];
        this.initialWeeklyAuditsListLevel3 = [];
        this.weeklyAuditsListLevel4 = [];
        this.initialWeeklyAuditsListLevel4 = [];

        this.weeklyAuditsListLevel = [];
        this.initialWeeklyAuditsListLevel = [];

        this.auditsListInitialLevel1 = [];
        this.auditsListLevel1 = [];
        this.auditsListInitialLevel2 = [];
        this.auditsListLevel2 = [];
        this.auditsListInitialLevel3 = [];
        this.auditsListLevel3 = [];
        this.auditsListInitialLevel4 = [];
        this.auditsListLevel4 = [];

        this.auditsListInitialLevel = [];
        this.auditsListLevel = [];


        this.user = this.userService.getUser();
        this.selectionData = this.userService.getUserSelection();
        this.isPlantAdmin = this.user["roleId"] === 3;
        this.showAllQue = false;
        this.optionView = "1";
        this.plantId = 0;
        this.isLPAAuditScheduler = true;
  }

  ionViewDidLoad() {
  //  this.loadAllScheduledAuditsForUser();
    
  }
   ionViewWillEnter(){
         const navParams = this.navParams.data
         this.isLPAAuditScheduler = (navParams.isLpaAudit === "true");
         this.translate.get(['schedule', 'schedule_other_Auditors']).subscribe((value)=>{
            this.pageTitle = this.isLPAAuditScheduler ? value['schedule']+" LPA" : value['schedule_other_Auditors'];
         });         
         this.loadData();       
    }
    private loadData(){
            this.levelList = this.utilService.getAllLevels().map((item)=>{return item.id.toString();});
        this.selData = ((this.selData === undefined) ? this.userService.getUserSelection() : this.selData);          
         this.plantId = this.selData.selPltId;
        if(this.isCropAdmin){                     
            if(this.selData === undefined){
                this.presentSelectionPopover(true);
            }   else{                
                this.getAuditList(this.selData.selPGId, this.selData.selOpId, this.selData.selLevelId, this.selData.selPltId);                
            }         
        } else{            
            this.getAuditList(this.selData.selPGId, this.selData.selOpId, this.selData.selLevelId,  this.selData.selPltId);                       
        }
    }
   private presentSelectionPopover(isMandatory:boolean) {
       const priv = Object.assign({},this.adminAuditUserSelPrivileges);
       const selDat = this.selData;
        let popover = this.popoverCtrl.create(SelectionPage, {"isMandatory":isMandatory, 
                                                            "userPrivileges": priv,
                                                            "isPopOverCtrl":"true",
                                                            "pageTitle":"Select Level", 
                                                            "userSelectionData": selDat },
                                                            {
                                                                enableBackdropDismiss:false,
                                                            });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData)=>{
            if(data){
                this.selData = data;
                this.getAuditList(data.selPGId, data.selOpId, data.selLevelId, data.selPltId);
            }                
        }); 
    }


 private getAuditList(pgId:number,opId:number, levelId:number, plantId:number){
            if(this.isLPAAuditScheduler){
                    this.auditsListInitialLevel1 =[];
                this.auditsListInitialLevel2 =[];
                this.auditsListInitialLevel3 =[];
                this.auditsListInitialLevel4 =[];
                this.initialWeeklyAuditsListLevel1 =[];
                this.initialWeeklyAuditsListLevel2 =[];
                this.initialWeeklyAuditsListLevel3 =[];
                this.initialWeeklyAuditsListLevel4 =[];    
                if(pgId !== 0 && levelId !== undefined && opId !== undefined && opId.toString() !== ""){  
                    this.utilService.showLoading();          
                    this.adminAuditService.getAuditsListByOpPg(pgId, opId, 1, this.isPlantAdmin,plantId ).subscribe((data)=>{
                        this.utilService.hideLoading();
                        if(this.utilService.checkValidData(data)){                                            
                                this.auditsListLevel1 = data.Response;
                                this.auditsListInitialLevel1 = data.Response;                                                               
                        } 
                    });

                    this.adminAuditService.getAuditsListByOpPg(pgId, opId, 2, this.isPlantAdmin, plantId).subscribe((data)=>{
                        if(this.utilService.checkValidData(data)){                                            
                                this.auditsListLevel2 = data.Response;
                                this.auditsListInitialLevel2 = data.Response;     
                        } 
                    });
                    this.adminAuditService.getAuditsListByOpPg(pgId, opId, 3, this.isPlantAdmin, plantId).subscribe((data)=>{
                        if(this.utilService.checkValidData(data)){                                            
                                this.auditsListLevel3 = data.Response;
                                this.auditsListInitialLevel3 = data.Response;                                                             
                        } 
                    });
                    this.adminAuditService.getAuditsListByOpPg(pgId, opId, 4, this.isPlantAdmin, plantId).subscribe((data)=>{
                        if(this.utilService.checkValidData(data)){                
                                this.auditsListLevel4 = data.Response;
                                this.auditsListInitialLevel4 = data.Response;                                                               
                        } 
                    });
                } else{
                console.error("Values cannot be null.");
                }
            }
            if(!this.isLPAAuditScheduler){
                    this.utilService.showLoading();
                    this.adminAuditService.getAuditsListByOpPg(1, 0, 11, this.isPlantAdmin, plantId).subscribe((data)=>{
                        this.utilService.hideLoading();
                        if(this.utilService.checkValidData(data)){                
                                this.auditsListLevel = data.Response;
                                this.auditsListInitialLevel = data.Response;                                                               
                        } 
                    });
            }                
    }



   private toggleGroup(group, levelId, objName, procId, pdId) {
      if (this.isGroupShown(group)) {
          this.shownGroupas = null;
      } else {
          this.shownGroupas = group;
          this.loadAuditsForProcess(levelId, objName, procId, pdId);
      }
    };
    private loadAuditsForProcess(levelId, objName, procId, pdId){     
        if(this.isLPAAuditScheduler){
             if(levelId !== undefined && levelId !== null && pdId !== undefined && pdId !== null && pdId !== 0 && levelId !== 0 && procId !== undefined && procId !== null && procId !== 0 && objName !== undefined && objName !== null && objName !== ""){
                this.initialWeeklyAuditsListLevel = []
                this.utilService.showLoading();
                this.auditService.getScheduledAuditForUserByPlantId(0,"","",this.plantId,levelId,procId, pdId).subscribe((data:ResponseObject)=>{
                    if(this.utilService.checkValidData(data)){                                             
                        this.initialWeeklyAuditsListLevel = this.initialWeeklyAuditsListLevel.concat(this.editSchAuditService.getWeeklyAuditsList(data.Response));
                        this[objName] = Object.assign([],this.initialWeeklyAuditsListLevel);   
                        this.utilService.hideLoading();                                                                       
                    }
                });
            }
        }    
        if(!this.isLPAAuditScheduler){
            if(levelId !== undefined && levelId !== null && levelId !== 0 && procId !== undefined && procId !== null && procId !== 0 && objName !== undefined && objName !== null && objName !== ""){
                this.initialWeeklyAuditsListLevel = []
                this.utilService.showLoading();
                this.auditService.getScheduledAuditForUserByPlantId(0,"","",this.plantId,11,procId, 1).subscribe((data:ResponseObject)=>{
                    if(this.utilService.checkValidData(data)){                                             
                        this.initialWeeklyAuditsListLevel = this.initialWeeklyAuditsListLevel.concat(this.editSchAuditService.getWeeklyAuditsList(data.Response));
                        this[objName] = Object.assign([],this.initialWeeklyAuditsListLevel);   
                        this.utilService.hideLoading();                                                                       
                    }
                });
            }
        }
                                      
    }
    private isGroupShown(group) {                                        
        return this.shownGroupas === group;
    };
    public onAuditWeekItemClicked(item:WeeklyAuditsList, processId:number, levelId:number){
        this.assignAuditToAuditors(item.weekStart, processId, levelId, item.auditsList);      
    }
  private assignAuditToAuditors(startDate:string, processId:number, levelId:number, scheduledAuditsList:Array<AcceptedAuditItem>){
           let modalCtrl = this.modalCtrl.create(WeeklySchedulingToAuditorsPage,{  "startDate":startDate, 
                                                                                   "selProcessId":processId, 
                                                                                   "selLevelId": levelId,
                                                                                   "isLPAAuditScheduler":this.isLPAAuditScheduler.toString(),
                                                                                   "isFromPage":"editScheduledAudits",
                                                                                   "scheduledAuditsList":scheduledAuditsList});
            modalCtrl.onDidDismiss((data)=>{   
                this.shownGroupas = null;
                /*if(data !== undefined){
                        this.utilService.showLoading();
                        setTimeout(()=>{                    
                                this.loadData();
                                this.utilService.hideLoading();
                        },6000);                               
                }   */                                    
            });                                                                                
           modalCtrl.present();            
    }
}
