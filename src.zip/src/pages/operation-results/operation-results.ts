import { Component } from '@angular/core';
import { NavController} from 'ionic-angular';
@Component({
  selector: 'operation-results-page',
  templateUrl: 'operation-results.html'
})


export class OperationResults{
    operationsList:Array<any>;
    facilityList:Array<any>;
    processList:Array<any>;
    auditorList:Array<any>;
    levelList:Array<any>;
    languagesList:Array<any>;
    
    operation: String;
    facility:String;
    process: String;
    auditor:String;
    level: String;
    language:String;
    date:String;
    constructor(public navCtrl: NavController){
      this.operationsList = ["Finishing", "Cutting", "Assembely"];
      this.facilityList = ["Jarudo Finishing","Leon Finishing ","Shanghai Finishing", "Rochester Hills Finishing","Szolnok Finishing","Thailand FInishing","Victoria Finishing"];
      this.processList = ["Base Coat Spray Only", "BaseCoat Roll Only", "Base Coat Roll Spray"];
      this.auditorList = ["Hernandez David", "Hernandez Jose Juan","Holguin Veronica"];
      this.levelList = ["Operator Level Audit","Plant Level Audit","Regional Audit","Corporate Audit"];            
      this.languagesList = ["English","Spanish","Chinese", "Portuguese","Thai","Hungarian"];
      this.date = "07:43";
    }
}