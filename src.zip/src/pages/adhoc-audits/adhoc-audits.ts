import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, PopoverController } from 'ionic-angular';
import { AdminAuditProvider } from '../admin/admin-audits/admin-audits-service';
import { UtilService} from '../../providers/util-service';
import { UserObject, UserSelectionData,UserSelectionPrivileges,AuditList, AcceptedAuditItem} from '../../models/QuestionItem';
import { UserService } from '../../providers/user-service';
import { User } from '../../models/user';
import { Lot, Machine, Shift } from '../../models/Level';
import { Network } from '@ionic-native/network';
import { AuditStartResults } from '../audit-start-results/audit-start-results';
import { SelectionPage } from '../selection/selection';
import * as moment from  'moment';
import { TranslateService } from 'ng2-translate';
/**
 * Generated class for the AdhocAuditsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-adhoc-audits',
  templateUrl: 'adhoc-audits.html',
})
export class AdhocAuditsPage {
 private auditListInitial:Array<AuditList>;
 private auditList:Array<AuditList>;
 private isPlantAdmin:boolean;
 private user:User;
public isOffline:boolean;
  private subscription:any;
  private selectionData:UserSelectionData;
  constructor(public navCtrl: NavController,
  private network: Network, 
  public platform: Platform, 
  private utilService:UtilService,
   private userService:UserService,
   private popoverCtrl: PopoverController,
   private translate:TranslateService,
   private adminAuditService:AdminAuditProvider, public navParams: NavParams) {
       this.isPlantAdmin  = false;
       this.user = this.userService.getUser();
       this.isOffline = false;
       this.selectionData =  this.userService.getUserSelection();
  }

  ionViewDidLoad() {
   
  }
  ionViewDidEnter(){
        if(this.platform.is("cordova")){
            this.subscription=  this.network.onchange().subscribe((data) => {
                if(data.type === "offline"){               
                    this.isOffline = true;
                    this.utilService.showToast("","Network Offline - Un Schduled Audits");
                }
                if(data.type === "online"){               
                    this.isOffline = false;
                    this.utilService.showToast("","Network Online -Un Schduled Audits");
                    this.getAuditList( this.selectionData.selPGId, 0,this.selectionData.selLevelId, this.selectionData.selPltId);
                } 
            });
        }
          if(this.utilService.isNetworkConnected){
                this.isOffline = false;
                this.getAuditList(this.selectionData.selPGId, 0,this.selectionData.selLevelId, this.selectionData.selPltId);
          } else{
                this.isOffline = true;
          }
  }
    
  private getAuditList(pgId:number,opId:number, levelId:number, plantId:number){
        if(pgId !== 0 && levelId !== undefined && opId !== undefined && opId.toString() !== ""){            
            this.adminAuditService.getAuditsListByOpPg(pgId, opId,levelId,this.isPlantAdmin,plantId ).subscribe((data)=>{
                if(this.utilService.checkValidData(data)){                
                    if(data !== undefined && data.Response !== undefined && data.Response.length > 0){
                        this.auditList = data.Response;
                        this.auditListInitial = data.Response;
                    } else{                                    
                        this.utilService.showToast("AuditsListNotAvailable","");                        
                    }           
                } 
            });
        }
      }

       private getSearchItems(ev:any){
        let val = ev.target.value;         
           if(val && val.trim() !== '' && val.length >= 3){                        
               this.auditList  = this.auditListInitial.filter((item) => {
                    return (item.auditName.toLowerCase().indexOf(val.toLowerCase()) > -1);
                });
            }        
      }
    private searchCancelClicked():void{            
      this.auditList = this.auditListInitial;    
    }
   
    private auditSelectedForDetails(auditItem:AuditList):void{                   
        if(auditItem.numOfQuesCorp !== 0){
               /* let selData = Object.assign({}, this.selectionData);
                selData.selPrId = auditItem.procId;
                selData.selPrName = auditItem.procName;
                //CreateAndAssignAuditRequest - serice call
                let popover = this.popoverCtrl.create(SelectionPage, {
                                                    "isMandatory" : "false",
                                                    "isPopOverCtrl":"true", 
                                                    "isFromPage" :  "AuditSchedular",
                                                    "isMultipleSelect":"false",
                                                    "pageTitle":(auditItem.procName),
                                                    "userPrivileges" : new UserSelectionPrivileges(false,false, false, false, false,
                                                                                                false, false, false, false, false, 
                                                                                                false, true, true, false, false, 
                                                                                                false, false, false, false, false, false, true), 
                                                    "userSelectionData": selData },
                                                    {
                                                            enableBackdropDismiss:false,
                                                        });
                popover.present();
                popover.onDidDismiss((data:UserSelectionData) => {
                    if(data !== undefined){  */          
                        const loggedInUserWLogin = this.user.wLogin;
                        const userId = this.user.userId
                            //data.machine.name, data.shift.name, 
                            //data.selCommentsTextarea,loggedInUserWLogin
                            const auditTakenTime = moment().format('YYYY/MM/DD HH:mm:ss'); 
                            const plantId = this.selectionData.selPltId;
                            const plantName = this.selectionData.selPltName;
                            let acceptedAuditItem:AcceptedAuditItem = new AcceptedAuditItem(0,this.user.userId, this.user.firstName, 
                            this.user.lastName, auditTakenTime,auditTakenTime,'',auditItem.auditName,auditItem.pgId,auditItem.opName, auditItem.pgName,
                            auditItem.opId,auditItem.procId,auditItem.procName,plantId,plantName,auditItem.levelId, "0",'select','select','',0,
                            auditTakenTime, auditTakenTime);
                            this.navigateToAuditTakingPage(acceptedAuditItem);
                            //auditListId -PLANT_PROCESS_AUDIT_LIST 
                        //}
                    //});  
        }  else{
            this.utilService.showToast("","Question not available for the Audit.");
        }                         
    }

    private navigateToAuditTakingPage(acceptedAuditItem:AcceptedAuditItem){
      
        let selData = Object.assign({},this.selectionData);
        selData.auditor = new UserObject(acceptedAuditItem.userId, acceptedAuditItem.firstName+","+acceptedAuditItem.lastName);
        selData.startDate = acceptedAuditItem.startDate;
        selData.endDate = acceptedAuditItem.endDate;
        selData.lot = new Lot(0, acceptedAuditItem.lotNum);
        selData.machine = new Machine("0", acceptedAuditItem.machineNum, acceptedAuditItem.procName, true);
        selData.selCommentsTextarea = acceptedAuditItem.comments;
        selData.shift = new Shift("0", acceptedAuditItem.shift.toString());                                 
        selData.selPrId = acceptedAuditItem.procId;
        selData.selPrName = acceptedAuditItem.procName;
        selData.selLevelId = acceptedAuditItem.levelId;
        selData.selLevelName = "";

        this.navCtrl.push(AuditStartResults, {"isReadOnly":  "false",
                                                "isFromPage":"AuditsListUserPage", 
                                                "userSelectionData":selData,
                                                "isScheduledAudit":"true", 
                                                "isAdhocAudit":"true",
                                                "isOffline":"false",
                                                "auditInfoDetails":acceptedAuditItem}); 
    }
  //     public onOfflineToggleChange():void{
  //       if(this.isOffline){                                              
  //           const stDate = this.selectionData.startDate; const edDate =  this.selectionData.endDate; 

  //           const pltId = this.selectionData.selPltId; const levId =  this.selectionData.selLevelId;
  //           const prId = this.selectionData.selPrId;
  //           const langCode = this.selectionData.selLangCode;
  //           const auditsList:Array<AcceptedAuditItem> = this.auditList;
  //           if(stDate  !== "" && edDate !== "" && pltId !== 0 &&  prId !== undefined && levId !== undefined && !isNaN(prId)){
  //                   this.cacheData.saveUnSchAuditslistDetails(false,stDate, edDate, pltId,  levId,  prId, langCode, auditsList);
  //           }
  //       }
  // }
}
