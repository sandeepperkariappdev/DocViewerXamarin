import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import {  CreateAndAssignAuditRequest } from '../../models/QuestionItem';
/*
  Generated class for the AdhocAuditsServiceProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
@Injectable()
export class AdhocAuditsServiceProvider {

  constructor(public http: Http) {
    
  }

}
