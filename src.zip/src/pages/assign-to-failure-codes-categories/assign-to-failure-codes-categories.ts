import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, ModalController, Navbar,  AlertController} from 'ionic-angular';
import {  UsersInPlant,  FailCodeCategoryList, FailCodeCategoryAssigningList, ResponseObject, CreateFailureCode } from '../../models/QuestionItem';
import { AdminManageFailureCodesService } from "../admin-manage-failure-codes/admin-manage-failure-codes-service";
import { SearchUsersInPlant } from '../../popup-modals/search-users-in-plant/search-users-in-plant';
import {UtilService} from "../../providers/util-service";
import {UserService} from "../../providers/user-service";
import { AuditDetailsServiceProvider } from '../admin/audit-details/audit-details-service';
/**
 * Generated class for the AssignToFailureCodesCategoriesPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-assign-to-failure-codes-categories',
  templateUrl: 'assign-to-failure-codes-categories.html',
})
export class AssignToFailureCodesCategoriesPage {
    @ViewChild(Navbar) navBar: Navbar;
  public failCodesCatList:Array<FailCodeCategoryAssigningList>; 
  private failCodeCategoryList:Array<FailCodeCategoryList>;
  private shownGroupas;
  private showInComplete:boolean;
  public buttonSel:string;
  private isItemsChanged:boolean;
  private showAllCat:boolean; 
 constructor(private navCtrl: NavController, 
              private adminManageFCService : AdminManageFailureCodesService,
              private viewCtrl:ViewController,
              private modalCtrl:ModalController,
              private utilService:UtilService,
              private alertCtrl:AlertController,
              private auditDetailsService:AuditDetailsServiceProvider,
              private userService:UserService,
              private navParams: NavParams) {     
     this.failCodesCatList = [];
     this.failCodeCategoryList = [];
     this.isItemsChanged = false;
     this.showAllCat = false;
     this.buttonSel = '';
  }

  ionViewDidLoad() {    
     this.failCodeCategoryList =  this.utilService.getAllFailureCodeCategories();
     const usersList:Array<UsersInPlant> = this.userService.getUsersInPlant();  
     const userSelPltId = this.userService.getUserSelection().selPltId;
      this.adminManageFCService.getPlantFailureCodeCateories(userSelPltId).subscribe((data:ResponseObject)=>{
              if(this.utilService.checkValidData(data)){                        
                  this.failCodesCatList = data.Response;
                  if(this.failCodesCatList.length === 0){
                        this.failCodesCatList = this.failCodeCategoryList.reduce((prev, item)=>{
                            prev.push(new FailCodeCategoryAssigningList(item.failureCdCatId, item.failureCdCatDesc, item.daysOfCompletion, item.severity,
                             0, 0, "","", item.daysOfCompletionAssignee, item.daysOfCompletionReviewee));
                            return prev;
                        },[]);
                  }  
                }
      });
      this.navBar.backButtonClick = (e:UIEvent)=>{
          if(this.isItemsChanged){
                let confirm = this.alertCtrl.create({
                            title: 'Alert',
                            message: 'You have un-saved changes, Please save your changes.',
                            buttons: [
                                {
                                    text: 'Cancel',
                                    handler: () => {                                        
                                    }
                                },
                                {
                                    text: 'Okay',
                                    handler: () => {
                                        if(this.navCtrl.canGoBack()){
                                               this.navCtrl.pop();
                                            };
                                    }
                                }
                            ]
                    });
                    confirm.present(); 
          } else{
                 if(this.navCtrl.canGoBack()){
                        this.navCtrl.pop();
                    };
          }
          
      }
  }

  private checkFailCodesAssigned(){
       return this.failCodesCatList.reduce((prev, item) => {
          if(item.assigneeId === 0 && item.reviewerId ===0){
              prev.push(item);
          }
          return prev;
      },[]);
}
   searchUsers(fcObject,itemId, itemName){
       this.isItemsChanged = true;
       this.buttonSel = 'save_changes';
    let modal = this.modalCtrl.create(SearchUsersInPlant,{},{enableBackdropDismiss:false});
    modal.onDidDismiss((data:UsersInPlant)=>{
      if(this.utilService.itemDefined(data)){
          fcObject[itemId] = data.userId;
         fcObject[itemName] = data.firstName+" "+data.lastName;
      }        
    });
    modal.present();
  }
    private submitNonComplianceAssignment(){
            if(this.checkFailCodesAssigned().length === 0){                
                if(this.failCodesCatList.length > 0){
                        this.auditDetailsService.assignPlantAssigneeReviewerToFailCodeCategory(Object.assign([],this.failCodesCatList)).subscribe((response)=>{
                            if(this.utilService.checkValidData(response)){
                                    this.buttonSel = '';
                                    this.isItemsChanged = false;
                                    this.utilService.showToast("","Successfully Saved Changes");
                                }
                        });
                    }
            } else{
            this.showInComplete = true;
            }      
  }
  

  private appliesToOtherFailureCodes(fcItem:FailCodeCategoryAssigningList){
      if(fcItem.assigneeId !== 0 && fcItem.reviewerId !== 0){
            this.failCodesCatList = this.failCodesCatList.reduce((prev, item) => {  
                        item.assigneeId = fcItem.assigneeId;
                        item.reviewerId = fcItem.reviewerId;
                        item.assigneeName = fcItem.assigneeName; 
                        item.reviewerName =  fcItem.reviewerName; 
                        item.severity = fcItem.severity;                
                        prev.push(item);
                    return prev;
                },[]);
            this.buttonSel = 'save_changes';
      } 
      this.utilService.showToast("","Successfully Assigned Selection to Other Categories");       
  }
    toggleGroup(group) {
    if (this.isGroupShown(group)) {
        this.shownGroupas = null;
    } else {
        this.shownGroupas = group;
    }
  };

  isGroupShown(group) {
      if(this.showAllCat){
          return true;
      } else{          
          return this.shownGroupas === group;     
      }         
  };
  showAllCatClicked(){      
  }
//    public navigateToHome():void{
//        const user = this.userService.getUser();//setting the user for this page
//         const page = this.privileges.getPageObject(user.roleName,"SideMenu");
//         const isHomeTab = page["Home"]["thisShow"];
//         if(isHomeTab === "true"){
//             this.navCtrl.setRoot(HomePage);
//         }        
//    }
}
