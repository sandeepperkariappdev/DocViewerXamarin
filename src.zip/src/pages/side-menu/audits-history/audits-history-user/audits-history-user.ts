import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, PopoverController } from 'ionic-angular';
import { SelectionPage } from '../../../selection/selection';
import { UserSelectionData, UserSelectionPrivileges, AcceptedAuditItem, UserObject, ResponseObject, TempAudit  } from '../../../../models/QuestionItem';
import { AuditsHistoryServiceProvider }  from '../audits-history-service';
import { Privileges } from '../../../../providers/privileges';
import { UserService} from '../../../../providers/user-service';
import { UtilService} from '../../../../providers/util-service';
import { Lot, Machine, Shift } from '../../../../models/Level';
import { AuditStartResults } from '../../../audit-start-results/audit-start-results';
import { AuditStartResultsProvider } from '../../../audit-start-results/audit-start-results-service';
import { TranslateService} from 'ng2-translate';
import * as storage from "../../../../providers/local-Storage";
import { HomePage } from '../../../home/home';
import { User} from '../../../../models/User';
import {CalendarController} from "ion2-calendar";
/**
 * Generated class for the AuditsHistoryUserPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-audits-history-user',
  templateUrl: 'audits-history-user.html',
})
export class AuditsHistoryUserPage implements OnInit {
    private selectionData:UserSelectionData;
    private auditList:Array<AcceptedAuditItem>;
    private showLevel:boolean; 
    private showProcess:boolean; 
    private showOperation:boolean; 
    private showProductGroup:boolean;
    private optionView:string;
    public cmpltdAuditList:Array<TempAudit>
    public showStDate:string;
    public showEdDate:string;
    public user:User;
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              private popoverCtrl:PopoverController, 
              private privileges:Privileges, 
              private auditService:AuditsHistoryServiceProvider, 
              private utSer:UtilService,
              private calendarCtrl: CalendarController,
              private auditStartResultsProvider:AuditStartResultsProvider,
              private translate : TranslateService,
              private userService:UserService) {
                this.optionView = "submitted";
                  this.selectionData = this.userService.getUserSelection();
                   this.user = this.userService.getUser();
                  const pagePriv = this.privileges.getPageObject(this.user.roleName,"Audits")["selfAudits"]["search"];
                  this.showLevel = pagePriv["showLevel"] === "true";
                  this.showOperation = pagePriv["showOperation"] === "true";
                  this.showProcess = pagePriv["showProcess"] === "true";
                  this.showProductGroup = pagePriv["showProductGroup"] === "true"; 
                  this.cmpltdAuditList = [];            
                  this.showStDate = "";
                  this.showEdDate = ""; 
                  this.auditList = [];
  }

  ngOnInit(){
    this.selectionData.endDate = this.utSer.getWeekEndDate();
     this.selectionData.startDate = this.utSer.getWeekStartDate();
        this.getFinishedActiveAuditListForUser();
   }

   private getFinishedActiveAuditListForUser():void{
      	/*
	      @processId as int = 0,   -- 0 for all processes
	      @level as int = 0		 -- 0 for all levels
     */
     if(this.selectionData.startDate  !== "" && this.selectionData.endDate !== "" && this.selectionData.selPltId !== 0 &&  
        this.selectionData.selLevelId !== 0 && this.selectionData.selPrId !== undefined && !isNaN(this.selectionData.selPrId) && this.selectionData.selPGId !== undefined && !isNaN(this.selectionData.selPGId)){
          const stDate  = this.selectionData.startDate;
          const edDate = this.selectionData.endDate;

          this.showStDate = this.utSer.getSearchDateToShow(stDate);
          this.showEdDate = this.utSer.getSearchDateToShow(edDate);
          this.utSer.showLoading();
          this.auditService.getFinishedActiveAuditsForUser(this.selectionData.startDate, this.selectionData.endDate, 
          this.selectionData.selPltId,  this.selectionData.selLevelId, this.selectionData.selPrId,
          this.userService.getUser().userId, this.selectionData.selPGId).subscribe((data)=>{
              if(this.utSer.checkValidData(data)){
                this.auditList = this.auditList.concat(data.Response);
              } 
              this.utSer.hideLoading();        
          });
          this.auditService.getFinishedActiveAuditsForUser(this.selectionData.startDate, this.selectionData.endDate, 
          this.selectionData.selPltId,  0, 0,this.userService.getUser().userId, 1).subscribe((data)=>{
              if(this.utSer.checkValidData(data)){
                this.auditList = this.auditList.concat(data.Response);
              }                  
          });
      }
        // Load the saved Audits to Submit
         let savedNotCompltAuditData = storage.loadSavedData(this.user.wLogin,"submitNotCompletedAudit");      
          if(savedNotCompltAuditData !== undefined){
              this.cmpltdAuditList = this.utSer.getMappedData(savedNotCompltAuditData)[0];
          }
   }
   auditSubmittedItemClicked(auditItem:AcceptedAuditItem){
    let selData:UserSelectionData = this.selectionData; 
         selData.selPrId = auditItem.procId; 
         selData.selPrName = auditItem.procName;
         selData.selLevelId = auditItem.levelId;
         selData.machine.name = auditItem.machineNum;
         selData.shift.name = auditItem.shift.toString();
         this.navCtrl.push(AuditStartResults,{"isReadOnly":"true","isFromPage":"AuditsHistoryPage","auditInfoDetails":auditItem, "userSelectionData":selData,"auditId":auditItem.auditListId});
  }
 auditSavedItemDetails(auditItem:TempAudit){
        let selData:UserSelectionData = this.selectionData; 
         selData.selPrId = auditItem.procId; 
         selData.selPrName = auditItem.procName;
         selData.selLevelId = auditItem.level;
         selData.machine.name = auditItem.machineNum[0];
         selData.shift.name = auditItem.shift.toString();
   this.navCtrl.push(AuditStartResults,{"isReadOnly":"true","isFromPage":"AuditsSavedHistory","auditInfoDetails":auditItem, "userSelectionData":selData,"auditDetailsData":this.cmpltdAuditList});
 }
  ionViewDidLoad() {
   
  }
   public navigateToHome():void{
        this.navCtrl.setRoot(HomePage);
   }
   presentPopover(){       
    let popover = this.popoverCtrl.create(SelectionPage,{
                                                "isMandatory":"false",
                                                "isPopOverCtrl":"true", 
                                                "userPrivileges":new UserSelectionPrivileges(false,this.showProductGroup,
                                                                                              this.showProcess,this.showOperation,this.showLevel,
                                                                                            false, false, true, true, false, 
                                                                                            false, false, false, false, false, 
                                                                                            false, false, false, false, false, false, false), 
                                                "userSelectionData": this.selectionData },{
            enableBackdropDismiss:false,
        });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData)=>{
            if(data){
                this.selectionData = data;
                this.getFinishedActiveAuditListForUser();             
            }                
        });
   }
   /* private checkValidData(data:ResponseObject){
      if(data !== undefined && data.IsSuccess && data.Message.length === 0 &&  (data.ResponseCode === null  || data.ResponseCode === undefined) && data.Response.length > 0){
        if(data.ResponseCode !== undefined && data.ResponseCode !== null && data.ResponseCode.length === 4){
            this.showToastMessage(data.Message, data.ResponseCode);
        }
        return true;
      } else{
        if(data !== undefined && !data.IsSuccess && data.Message.length > 0 && (data.ResponseCode === null  || data.ResponseCode === undefined)){
            this.utSer.showToast("",data.Message);
        }
        if(data !== undefined && !data.IsSuccess  && (data.ResponseCode !== null  || data.ResponseCode !== undefined) && data.ResponseCode.length === 4){
          this.showToastMessage(data.Message, data.ResponseCode);                      
        }
        return false;
      }
    }*/
  private showToastMessage(message:string, key:string){
    if(message !== "" && key !== ""){
      this.translate.get([key]).subscribe((data)=>{
          this.utSer.showToast(data[key],message);
      });
    }                        
  }
  submitAuditButtonClicked(auditItem:TempAudit){
      this.auditStartResultsProvider.submitCachedCompletedAudits();//submitting the cached Audits; 
  }
  openCalendar(date:string){
    this.translate.get(["selectStartDate","selectEndDate","weekDaysArray","monthTitle"]).subscribe((values)=>{
            this.calendarCtrl.openCalendar({            
                isRadio: false,
                from : new Date("01/01/2015"),
                disableWeekdays:  [],
                //defaultScrollTo:new Date(),  
                 defaultDate: new Date(),
                title: "Select Start and End Date",
                monthTitle:values["monthTitle"],
            weekdaysTitle:values["weekDaysArray"],
        }).then((res:any)=>{

          this.selectionData.startDate= this.utSer.changeDateFormatFromTicks(res.from.time);
          const stDate  = this.selectionData.startDate;          
          this.showStDate = this.utSer.getSearchDateToShow(stDate);  
            this.selectionData.endDate= this.utSer.changeDateFormatFromTicks(res.to.time);                  
            const edDate = this.selectionData.endDate;
            this.showEdDate = this.utSer.getSearchDateToShow(edDate); 
            this.getFinishedActiveAuditListForUser();
          //'startDate'
          //'endDate'
               /* if(date === 'startDate'){
                    this.selectionData.startDate= this.utSer.changeDateFormatFromTicks(res.date.time);
                    const stDate  = this.selectionData.startDate;          
                    this.showStDate = this.utSer.getSearchDateToShow(stDate);          
                }
                if(date === 'endDate'){
                    this.selectionData.endDate= this.utSer.changeDateFormatFromTicks(res.date.time);                  
                      const edDate = this.selectionData.endDate;
                      this.showEdDate = this.utSer.getSearchDateToShow(edDate);
                } */                                                   
            }).catch(() => {

            });
        });
  }
}
