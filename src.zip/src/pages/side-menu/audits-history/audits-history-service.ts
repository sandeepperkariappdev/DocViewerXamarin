import { Injectable } from '@angular/core';
import { CallService} from '../../../providers/call-service';
import { AppSettings, MethodConstants } from '../../../constants/AppSettings';
import 'rxjs/add/operator/map';
import { Observable }from 'rxjs/observable';

/*
  Generated class for the AuditsHistoryServiceProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class AuditsHistoryServiceProvider {

  constructor(public callService: CallService) {    
  }

  // Audits History for Plants This is used to get the list of Active Audits for a plant falling  between the passed Input date and the Audit End Data. (future Active Audits).
  public getFinishedActiveAuditListForPlant(startDate:string, endDate:string, plantId:number,  level:number,  processId:number, userId:number, pgId:number):Observable<any>{  
    //processId ===0 to return for all the processes
    if((startDate !== undefined && startDate !=="" )&& (endDate !== undefined  && endDate!=="") && (plantId  !== undefined && plantId !==0) && (level  !== undefined) &&  (processId  !== undefined) ){
         const url =  (AppSettings.API_ENDPOINT + MethodConstants.AcceptedAuditsForUserOrPlantByCondition+"pgId="+pgId+"&plantId="+plantId+"&processId="+processId+"&level="+level+"&auditorId=0&startDate="+startDate+"&endDate="+endDate+"&condition="+5);
        return this.callService.callServerForGet(url);
    } else{
        console.error('values cannot be null.');
    }    
  }
//Audits History for Users 
  public getFinishedActiveAuditsForUser(startDate:string, endDate:string, plantId:number,  level:number,  processId:number, userId:number, pgId:number):Observable<any>{  
    // processId ===0 to return for all the processes
    if((startDate  !== undefined && startDate!=="")  && (endDate !== undefined  && endDate !=="") && (plantId !== undefined  && plantId!==0) &&  (level !== undefined) && (processId  !== undefined ) &&  (userId !== undefined && userId!==0)){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.AcceptedAuditsForUserOrPlantByCondition+"pgId="+pgId+"&plantId="+plantId+"&processId="+processId+"&level="+level+"&auditorId="+userId+"&startDate="+startDate+"&endDate="+endDate+"&condition="+5);
        return this.callService.callServerForGet(url);
    } else{
      console.error('values cannot be null');
    }    
  }


}
