import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, PopoverController, ModalController, AlertController } from 'ionic-angular';
import { AuditsHistoryServiceProvider }  from '../audits-history-service';
import { Privileges } from '../../../../providers/privileges';
import { UserService } from '../../../../providers/user-service';
import { UtilService } from '../../../../providers/util-service';
import { Lot, Machine, Shift } from '../../../../models/Level';
import { User } from '../../../../models/User';
import { AuditStartResults } from '../../../audit-start-results/audit-start-results';
import { SelectionPage } from '../../../selection/selection';
import { UserSelectionData, UserSelectionPrivileges, AcceptedAuditItem,UserObject  } from '../../../../models/QuestionItem';
import { HomePage } from '../../../home/home';
import {CalendarController} from "ion2-calendar";
import { TranslateService} from 'ng2-translate';
/**
 * Generated class for the AuditsHistoryPlantPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-audits-history-plant',
  templateUrl: 'audits-history-plant.html',
})
export class AuditsHistoryPlantPage {
  private selectionData:UserSelectionData;
    private auditList:Array<AcceptedAuditItem> = [];
    private initialAuditList:Array<AcceptedAuditItem> = [];
    private showLevel:boolean; 
    private showProcess:boolean; 
    private showOperation:boolean; 
    private showProductGroup:boolean;
    private user: User;
    public showStDate:string;
    public showEdDate:string;
  constructor(public navCtrl: NavController,
                public utilService : UtilService, 
                private userService:UserService,
                private modalCtrl:ModalController, 
                private popoverCtrl:PopoverController, 
                private alertCtrl:AlertController, 
                private privileges:Privileges, 
                private translate : TranslateService,
                private calendarCtrl: CalendarController,
                private auditService:AuditsHistoryServiceProvider){
                  this.user = this.userService.getUser();
                  this.selectionData = this.userService.getUserSelection();
                  const pagePriv = this.privileges.getPageObject(this.user.roleName,"Audits")["plantAudits"]["search"];
                  this.showLevel = pagePriv["showLevel"];
                  this.showOperation = pagePriv["showOperation"];
                  this.showProcess = pagePriv["showProcess"];
                  this.showProductGroup = pagePriv["showProductGroup"];
                   this.showStDate = "";
                  this.showEdDate = ""; 
                  this.auditList = [];
  }

ngOnInit(){
     this.selectionData.endDate = this.utilService.getWeekEndDate();
     this.selectionData.startDate = this.utilService.getWeekStartDate();
     this.selectionData.selLevelId = 0;
    this.getFinishedActiveAuditListForPlant();
   }
   private getFinishedActiveAuditListForPlant():void{
     	/*
	      @processId as int = 0,   -- 0 for all processes
	      @level as int = 0		 -- 0 for all levels
     */
     if(this.selectionData.startDate !== "" &&
        this.selectionData.endDate !== "" && 
        this.selectionData.selPltId !== 0 &&        
        this.selectionData.selPrId !== undefined && !isNaN(this.selectionData.selPrId)){
          const stDate  = this.selectionData.startDate;
          const edDate = this.selectionData.endDate;
          this.auditList = [];
          this.initialAuditList = [];
          this.showStDate = this.utilService.getSearchDateToShow(stDate);
          this.showEdDate = this.utilService.getSearchDateToShow(edDate);
          this.utilService.showLoading();
        this.auditService.getFinishedActiveAuditListForPlant(this.selectionData.startDate, this.selectionData.endDate,
         this.selectionData.selPltId,  this.selectionData.selLevelId,  0, 0, this.selectionData.selPGId).subscribe((data)=>{
            if(this.utilService.checkValidData(data)){
                this.auditList = this.auditList.concat(data.Response);
                this.initialAuditList = this.initialAuditList.concat(data.Response);
            }
            this.utilService.hideLoading();
        });
        this.auditService.getFinishedActiveAuditListForPlant(this.selectionData.startDate, this.selectionData.endDate,
         this.selectionData.selPltId,  0,  0, 0, 1).subscribe((data)=>{
            if(this.utilService.checkValidData(data)){
              this.auditList = this.auditList.concat(data.Response);
              this.initialAuditList = this.initialAuditList.concat(data.Response);
            }          
        });
     } else{
       console.error("Values cannot be empty ");
     }      
   }
   
   navToResults(){
     this.navCtrl.push(AuditStartResults);
   }
    auditSubmittedItemClicked(auditItem:AcceptedAuditItem){
     let selData:UserSelectionData = this.selectionData; 
          selData.selPrId = auditItem.procId; 
          selData.selPrName = auditItem.procName;
          selData.selLevelId = auditItem.levelId;
          selData.machine.name = auditItem.machineNum;
          selData.shift.name = auditItem.shift.toString();
          this.navCtrl.push(AuditStartResults,{"isReadOnly":"true","isFromPage":"AuditsHistoryPage", "userSelectionData":selData,"auditId":auditItem.auditListId, "auditInfoDetails":auditItem});
   }
   private searchAudits():void{
      // let modal = this.modalCtrl.create(SearchAudits);
      
      // modal.present();
   }
   presentPopover(){
      this.selectionData.endDate = this.utilService.defaultPlantAuditEndDate();
     this.selectionData.startDate = this.utilService.defaultPlantAuditStartDate();
    let popover = this.popoverCtrl.create(SelectionPage,{
      "isMandatory":"false",
      "useSelectionDataSent":"true",
      "isPopOverCtrl":"true",
      "userPrivileges":new UserSelectionPrivileges(false,false,false,false,false,false, 
                                                    false, true, true, false, false, 
                                                  false, false, false,false, false, 
                                                  false, false, false, false,false, false), 
      "userSelectionData": this.selectionData },{
            enableBackdropDismiss:false,
        });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData)=>{
            if(data){
                this.selectionData = data;
             this.getFinishedActiveAuditListForPlant();          
            }                
        });
   }
  openCalendar(date:string){
      /*  this.translate.get(["selectStartDate","selectEndDate","weekDaysArray","monthTitle"]).subscribe((values)=>{
            this.calendarCtrl.openCalendar({            
                isRadio: true,
                from : new Date("01/01/2015"),
                disableWeekdays:  [],
                //defaultScrollTo:new Date(),  
                 defaultDate: new Date(),
                title: "Select Week Start",
                monthTitle:values["monthTitle"],
            weekdaysTitle:values["weekDaysArray"],
        }).then((res:any)=>{
            this.selectionData.startDate= this.utilService.changeDateFormatFromTicks(res.from.time);
            const stDate  = this.selectionData.startDate;          
            this.showStDate = this.utilService.getSearchDateToShow(stDate);  
            this.selectionData.endDate= this.utilService.changeDateFormatFromTicks(res.to.time);                  
            const edDate = this.selectionData.endDate;
            this.showEdDate = this.utilService.getSearchDateToShow(edDate); 
            this.getFinishedActiveAuditListForPlant();
                //'startDate'
                //'endDate'
                //  if(date === 'startDate'){
                //     this.selectionData.startDate= this.utilService.changeDateFormatFromTicks(res.date.time);
                //     const stDate  = this.selectionData.startDate;          
                //     this.showStDate = this.utilService.getSearchDateToShow(stDate);          
                //  }
                //  if(date === 'endDate'){
                //     this.selectionData.endDate= this.utilService.changeDateFormatFromTicks(res.date.time);                  
                //       const edDate = this.selectionData.endDate;
                //       this.showEdDate = this.utilService.getSearchDateToShow(edDate);
                //    }                                                       
            }).catch(() => {

            });
        });*/

         this.translate.get(["selectStartDate","selectEndDate","weekDaysArray","monthTitle"]).subscribe((values)=>{
            this.calendarCtrl.openCalendar({            
                isRadio: false,
                from : new Date("01/01/2015"),
                disableWeekdays:  [],
                //defaultScrollTo:new Date(),  
                 defaultDate: new Date(),
                title: "Select Start and End Date",
                monthTitle:values["monthTitle"],
            weekdaysTitle:values["weekDaysArray"],
        }).then((res:any)=>{

          this.selectionData.startDate= this.utilService.changeDateFormatFromTicks(res.from.time);
          const stDate  = this.selectionData.startDate;          
          this.showStDate = this.utilService.getSearchDateToShow(stDate);  
            this.selectionData.endDate= this.utilService.changeDateFormatFromTicks(res.to.time);                  
            const edDate = this.selectionData.endDate;
            this.showEdDate = this.utilService.getSearchDateToShow(edDate); 
            this.getFinishedActiveAuditListForPlant();                                                            
            }).catch(() => {

            });
        });
        //'startDate'
          //'endDate'
               /* if(date === 'startDate'){
                    this.selectionData.startDate= this.utSer.changeDateFormatFromTicks(res.date.time);
                    const stDate  = this.selectionData.startDate;          
                    this.showStDate = this.utSer.getSearchDateToShow(stDate);          
                }
                if(date === 'endDate'){
                    this.selectionData.endDate= this.utSer.changeDateFormatFromTicks(res.date.time);                  
                      const edDate = this.selectionData.endDate;
                      this.showEdDate = this.utSer.getSearchDateToShow(edDate);
                } */ 
  }

  private getSearchItems(ev:any):void{
    let val = ev.target.value;   
    if(val.trim() === ''){
        if(this.initialAuditList !== undefined){
            this.auditList = this.initialAuditList;  
        }
    }
    if(val && val.trim() !== '' && val.length >= 3){  
        if(this.initialAuditList !== undefined){
            this.auditList = this.initialAuditList;  
        }
        if(this.auditList !== undefined){                     
                this.auditList = this.auditList.reduce((prev,item:AcceptedAuditItem,index)=>{                                                    
                    if((item.firstName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                    (item.lastName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                    //(item.plantName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                    (item.pgName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||                        
                    (item.procName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                    //(item.opName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                    //(item.auditListId.toString().indexOf(val.toLowerCase()) > -1) ||
                    // (item.comments.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                    //(item.startDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                    //(item.endDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1 )||
                    (item.machineNum.toLowerCase().toString().indexOf(val.toLowerCase()) > -1)){
                        prev.push(item);
                    }                
                    return prev;
                },[]);
        }
    }                
}

private searchCancelClicked():void{
  this.auditList = this.initialAuditList;
}
}