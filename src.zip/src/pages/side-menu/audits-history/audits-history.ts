import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Privileges} from '../../../providers/privileges';
import { UserService} from '../../../providers/user-service';
import { User } from '../../../models/user';
import { AuditsHistoryPlantPage } from './audits-history-plant/audits-history-plant';
import { AuditsHistoryUserPage } from './audits-history-user/audits-history-user';
/**
 * Generated class for the AuditsHistory page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-audits-history',
  templateUrl: 'audits-history.html',
})
export class AuditsHistory {

showSelf:boolean;
      showPlant:boolean;
      tab1:any;
      tab2:any;
      user:User;
       pageName:string; 
      selTabIndex:string;
  constructor(public navCtrl: NavController, public navParams: NavParams, private privileges:Privileges, private userService:UserService) {
        this.pageName = "AuditsHistory";
        this.user = this.userService.getUser();
        const pagePriv = this.privileges.getPageObject(this.user.roleName,this.pageName);    
        this.showSelf = pagePriv["selfAudits"] ? pagePriv["selfAudits"]["thisShow"] === "true": false;
        this.showPlant= pagePriv["plantAudits"] ? pagePriv["plantAudits"]["thisShow"] === "true": false;
        this.tab1 = AuditsHistoryUserPage;
        this.tab2 = AuditsHistoryPlantPage;       
        this.selTabIndex = '0';        
  }

  ionViewDidLoad() {
    
  }

}
