import { Component } from '@angular/core';
import { NavController} from 'ionic-angular';
import { ScheduledAudits} from '../../home/scheduled-audits/scheduled-audits';
import { UnScheduledAudits} from '../../home/un-scheduled-audits/un-scheduled-audits';

@Component({
  selector: 'schedular-page',
  templateUrl: 'schedular.html'
})


export class Schedular{
    tab1:any;
    tab2:any;
    constructor(public navCtrl: NavController){
        this.tab1 = UnScheduledAudits;
        this.tab2 = ScheduledAudits
    }
}