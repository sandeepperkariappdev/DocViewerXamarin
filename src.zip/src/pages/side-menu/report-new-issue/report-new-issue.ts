import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { OpenNewIssue } from '../../../popup-modals/open-new-issue/open-new-issue';
import {ReportNewIssueDetails} from './report-new-issue-details/report-new-issue-details';
import {ReportIssueSearchItems} from './report-issue-search-items/report-issue-search-items';

/**
 * Generated class for the ReportNewIssue page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-report-new-issue',
  templateUrl: 'report-new-issue.html',
})
export class ReportNewIssue {

  constructor(public navCtrl: NavController, public navParams: NavParams, private modalCtrl:ModalController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ReportNewIssue');
  }
  openItemDetailsIssue(){
      this.navCtrl.push(ReportNewIssueDetails);
  }
  searchItems(){
    let modal = this.modalCtrl.create(ReportIssueSearchItems);
    modal.present();
  }
  addNewIssue(){
  let modal = this.modalCtrl.create(OpenNewIssue);
    modal.present();
  }
}
