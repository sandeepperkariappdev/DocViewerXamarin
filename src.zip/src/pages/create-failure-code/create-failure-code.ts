import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { Questions, Question, FailureCode, FailCodeCategoryList, ResponseObject, CreateFailureCode } from '../../models/QuestionItem';
import { AdminManageFailureCodesService } from "../admin-manage-failure-codes/admin-manage-failure-codes-service";
import {UtilService} from "../../providers/util-service";
import {UserService} from "../../providers/user-service";
/**
 * Generated class for the CreateFailureCodePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-create-failure-code',
  templateUrl: 'create-failure-code.html',
})
export class CreateFailureCodePage {
  private failureCodesList:Array<CreateFailureCode>;
  public failCodeCatList:Array<FailCodeCategoryList>;
  public daysOfCompletionAssignee:number;
  public daysOfCompletionReviewee:number;
  public severity:number;
  public isEditFc:boolean;
  public selCategories = { id : "select" };
  constructor(private navCtrl: NavController, 
              private adminManageFCService : AdminManageFailureCodesService,
              private viewCtrl:ViewController,
              private utilService:UtilService,
              private userService:UserService,
              private navParams: NavParams) {
                this.isEditFc = false;
     this.failureCodesList = [];   
     this.failCodeCatList = [];
  }

  ionViewWillEnter() {
      const navParams= this.navParams.data;
      if(navParams.failureCodeUpdate !== undefined){
            this.isEditFc = true;
            this.failureCodesList.push(navParams.failureCodeUpdate);    
      }
    this.adminManageFCService.getFailureCodeCateories().subscribe((data:ResponseObject)=>{
        if(this.utilService.checkValidData(data)){                        
            this.failCodeCatList = data.Response;  
            if(this.isEditFc){
                this.daysOfCompletionAssignee = this.failCodeCatList[0].daysOfCompletionAssignee;
                this.daysOfCompletionReviewee = this.failCodeCatList[0].daysOfCompletionReviewee;
                this.severity = this.failCodeCatList[0].severity;           
            }
        }
    });
  }

  onCatSelChange(event, index:number){
    this.daysOfCompletionAssignee = this.failCodeCatList[index -1].daysOfCompletionAssignee;
    this.daysOfCompletionReviewee = this.failCodeCatList[index -1].daysOfCompletionReviewee;
    this.severity = this.failCodeCatList[index -1].severity;    
  }

  private addNewFailureCode(){
    const userId = this.userService.getUser().userId;
    this.failureCodesList.push(new CreateFailureCode(0,"select",true,false,userId,true,"ENG","",""));    
  }

  private cancelButtonClicked(){
      this.viewCtrl.dismiss();
  }
  private checkFailureCodesNotempty():Array<CreateFailureCode>{
      return this.failureCodesList.filter((item)=>{
          if((item.failCodeDesc === "") || (item.catId === "") || (item.catId === "select")){
                return true;       
          } else{
              return false;
          }
      });
  }
  private doneButtonClicked(){      
      if(this.checkFailureCodesNotempty().length == 0){
           this.viewCtrl.dismiss(this.failureCodesList);
      }
  }

  private removeNewFailureCode(index){
     this.failureCodesList.splice(index,1);    
  }


}
