import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController,AlertController, ModalController } from 'ionic-angular';
import { SearchUsersInPlant} from '../../popup-modals/search-users-in-plant/search-users-in-plant';
import { SearchMachineInPlant} from '../../popup-modals/search-machine-in-plant/search-machine-in-plant';
import { UserObject, ResponseObject, UserSelectionData,  SubmitScheduledAudit, AcceptedAuditItem , ScheduleAuditToUser, ScheduleToAuditor} from '../../models/QuestionItem';
import { User } from '../../models/user';
import { TranslateService } from 'ng2-translate';
import { AuditDetails } from '../admin/audit-details/audit-details';
import { AuditService } from '../audits/audit-service';
import { UtilService} from '../../providers/util-service';
import { UserService} from '../../providers/user-service';
import { Machine, Shift } from '../../models/Level';
import { AuditDetailsServiceProvider } from '../admin/audit-details/audit-details-service';
import { AdminManageMachineProvider } from '../resources-management/admin-manage-machine/admin-manage-machine-service';
import * as _ from 'lodash';
import * as moment from  'moment';
/**
 * Generated class for the WeeklySchedulingToAuditorsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
class AssigningAuditorsForWeek{
  constructor(public startDate:string, public auditId:number,
    public auditor:UserObject, public shift:Shift,
     public machine:Machine, public comments:string, public applyToOthers:string){
  }
}

@Component({
  selector: 'page-weekly-scheduling-to-auditors',
  templateUrl: 'weekly-scheduling-to-auditors.html',
})
export class WeeklySchedulingToAuditorsPage {
  public auditorsListDay:Array<AssigningAuditorsForWeek>;
  public auditorsListDay1:Array<AssigningAuditorsForWeek>;
  public auditorsListDay2:Array<AssigningAuditorsForWeek>;
  public auditorsListDay3:Array<AssigningAuditorsForWeek>;
  public auditorsListDay4:Array<AssigningAuditorsForWeek>;
  public auditorsListDay5:Array<AssigningAuditorsForWeek>;
  public auditorsListDay6:Array<AssigningAuditorsForWeek>;
  public auditorsListDay7:Array<AssigningAuditorsForWeek>;
  public optionView:string;
  public day:string;
  public day1:string;
  public day2:string;
  public day3:string;
  public day4:string;
  public day5:string;
  public day6:string;
  public day7:string;
  public fullDay:string;
  public headerWeek:string;
  public fullDay1:string;
  public fullDay2:string;
  public fullDay3:string;
  public fullDay4:string;
  public fullDay5:string;
  public fullDay6:string;
  public fullDay7:string;
  public isShowfullDay:boolean;
  public isShowfullDay1:boolean;
  public isShowfullDay2:boolean;
  public isShowfullDay3:boolean;
  public isShowfullDay4:boolean;
  public isShowfullDay5:boolean;
  public isShowfullDay6:boolean;
  public isShowfullDay7:boolean;
  public sendReminder:boolean;
   public selAuditor = { id:"",name:""};
  private selUser = { id : "0" , name:"Select", wLogin:""};
  public shift:string;
  public machines:string;
  private user:User;
  private startDateOfWeekSel:string;
  private selProcessId:number;
  private  selLevelId:number;
  private shiftList:Array<Shift>;
  private machinesList:Array<Machine>;  
  private selectionData:UserSelectionData;
  private isScheduledAudits:boolean; 
  private scheduledAuditsList:Array<AcceptedAuditItem>
  public isLPAAuditScheduler:boolean;
  public isShowMachine:boolean;
  public isDailySchedule:boolean;
  constructor(public navCtrl: NavController, 
              private modalCtrl: ModalController, 
              private alertCtrl:AlertController,
              private viewCtrl:ViewController,
              private translate: TranslateService,
              private utilService: UtilService, 
              private userService:UserService,
              private auditService:AuditService,
              private auditDetailsService:AuditDetailsServiceProvider,
              private adminManageMachine: AdminManageMachineProvider,
              public navParams: NavParams) {
    this.day1 = "";
    this.day2 = "";
    this.day3 = "";
    this.day4 = "";
    this.day5 = "";
    this.day6 = "";
    this.day7 = ""; 
    this.headerWeek = ""; 
    this.auditorsListDay1 = [];
    this.auditorsListDay2 = [];
    this.auditorsListDay3 = [];
    this.auditorsListDay4 = [];
    this.auditorsListDay5 = [];
    this.auditorsListDay6 = [];
    this.auditorsListDay7 = [];
    this.auditorsListDay = [];
        
    this.fullDay1 = "";
    this.fullDay2 = "";
    this.fullDay3 = "";
    this.fullDay4 = "";
    this.fullDay5 = "";
    this.fullDay6 = "";
    this.fullDay7 = "";  

    this.shiftList = [];
    this.machinesList = [];
    this.selectionData  = this.userService.getUserSelection();
    this.user = this.userService.getUser();
    this.startDateOfWeekSel = "";
    this.selProcessId = 0;
    this.optionView = "1";
    this.isScheduledAudits =  false;
    this.scheduledAuditsList = [];
    this.isLPAAuditScheduler = true;
    this.isShowMachine = true;
    this.isDailySchedule = false;
    this.sendReminder = false;
  }

  ionViewDidLoad() {  
    const navParams = this.navParams.data;
    if(navParams.startDate !== undefined){
      this.startDateOfWeekSel = navParams.startDate;  
    }
    if(navParams.selProcessId !== undefined){
      this.selProcessId = navParams.selProcessId;  
    }
    if(navParams.selLevelId !== undefined){
      this.selLevelId = navParams.selLevelId;  
    }

    if(navParams.isFromPage === "editScheduledAudits"){
      this.isScheduledAudits = true;
      this.scheduledAuditsList = navParams.scheduledAuditsList;
    }

    this.isLPAAuditScheduler = (navParams.isLPAAuditScheduler === 'true');//Waste walk machine.

     this.isShowMachine =  this.isLPAAuditScheduler;
      this.loadViewFromParams(this.startDateOfWeekSel);    
      this.loadShiftsForPlant();
      this.loadMachinesFromServerForpLant();
      
  }

  private loadAuditorsFromAuditsList(){
     
    this.scheduledAuditsList.forEach((item)=>{
        const auditDate = moment(item.startDate).format("MM/DD/YYYY");
        if(auditDate === this.fullDay1){            
            const shiftObj = this.utilService.getPlantsShiftsList().filter(shift => shift.name.toString() === item.shift.toString());
            const shiftId = shiftObj[0] || {"id":"select"};
          this.auditorsListDay1.push( new AssigningAuditorsForWeek(auditDate,item.auditListId,new UserObject(item.userId, (item.lastName+", "+item.firstName)),new Shift(shiftId.id.toString(), item.shift),new Machine('0', item.machineNum, "", true), item.comments, 'Search'));
        }
        if(auditDate === this.fullDay2){
            const shiftObj = this.utilService.getPlantsShiftsList().filter(shift => shift.name.toString() === item.shift.toString());
            const shiftId = shiftObj[0] || {"id":"select"};
            this.auditorsListDay2.push(new AssigningAuditorsForWeek(auditDate,item.auditListId,new UserObject(item.userId, (item.lastName+", "+item.firstName)),new Shift(shiftId.id.toString(), item.shift),new Machine('0', item.machineNum, "", true), item.comments,'Search'));
        }
        if(auditDate === this.fullDay3){
            const shiftObj = this.utilService.getPlantsShiftsList().filter(shift => shift.name.toString() === item.shift.toString());
            const shiftId = shiftObj[0] || {"id":"select"};
            this.auditorsListDay3.push(new AssigningAuditorsForWeek(auditDate,item.auditListId,new UserObject(item.userId, (item.lastName+", "+item.firstName)),new Shift(shiftId.id.toString(), item.shift),new Machine('0', item.machineNum, "", true), item.comments,'Search'));
        }
        if(auditDate === this.fullDay4){
            const shiftObj = this.utilService.getPlantsShiftsList().filter(shift => shift.name.toString() === item.shift.toString());
            const shiftId = shiftObj[0] || {"id":"select"};
            this.auditorsListDay4.push(new AssigningAuditorsForWeek(auditDate,item.auditListId,new UserObject(item.userId, (item.lastName+", "+item.firstName)),new Shift(shiftId.id.toString(), item.shift),new Machine('0', item.machineNum, "", true), item.comments,'Search'));
        }
        if(auditDate === this.fullDay5){
            const shiftObj = this.utilService.getPlantsShiftsList().filter(shift => shift.name.toString() === item.shift.toString());
            const shiftId = shiftObj[0] || {"id":"select"};
            this.auditorsListDay5.push(new AssigningAuditorsForWeek(auditDate,item.auditListId,new UserObject(item.userId, (item.lastName+", "+item.firstName)),new Shift(shiftId.id.toString(), item.shift),new Machine('0', item.machineNum, "", true), item.comments,'Search'));
        }
        if(auditDate === this.fullDay6){
            const shiftObj = this.utilService.getPlantsShiftsList().filter(shift => shift.name.toString() === item.shift.toString());
            const shiftId = shiftObj[0] || {"id":"select"};
            this.auditorsListDay6.push(new AssigningAuditorsForWeek(auditDate,item.auditListId,new UserObject(item.userId, (item.lastName+", "+item.firstName)),new Shift(shiftId.id.toString(), item.shift),new Machine('0', item.machineNum, "", true), item.comments,'Search'));
        }
        if(auditDate === this.fullDay7){
            const shiftObj = this.utilService.getPlantsShiftsList().filter(shift => shift.name.toString() === item.shift.toString());
            const shiftId = shiftObj[0] || {"id":"select"};
            this.auditorsListDay7.push(new AssigningAuditorsForWeek(auditDate,item.auditListId,new UserObject(item.userId, (item.lastName+", "+item.firstName)),new Shift(shiftId.id.toString(), item.shift),new Machine('0', item.machineNum, "", true), item.comments,'Search'));
        }
    });

  
    this.scheduledAuditsList.forEach((item)=>{
      const auditDate = moment(item.startDate).format("MM/DD/YYYY");         
      let shiftObj = []
      if(this.shiftList.length > 0){
        shiftObj = this.shiftList.filter(shift => shift.name.toString() === item.shift.toString());
      } 
      const shiftId = shiftObj[0] || {"id":"select"};           
      this.auditorsListDay.push( new AssigningAuditorsForWeek(auditDate,item.auditListId,new UserObject(item.userId, (item.lastName+", "+item.firstName)),new Shift(shiftId.id.toString(), item.shift),new Machine('0', item.machineNum, "", true), item.comments, 'Search'));
    });
    
  }
    public addNewAuditorToAudit(auditorListItem){
      this.translate.get(["Select"]).subscribe((values)=>{
        this[auditorListItem].push(new AssigningAuditorsForWeek('',0,new UserObject(0,""),new Shift('select', values["Select"]),new Machine('0', values["Select"], "", true), "", 'select'));
      });        
    }
   private loadShiftsForPlant():void{
        this.adminManageMachine.getShiftsForPlant(+this.selectionData.selPltId).subscribe((data:ResponseObject)=>{
                        if(this.utilService.checkValidData(data)){
                              this.shiftList = data.Response.map(item => new Shift(item.id.toString(), item.name));     
                              this.loadAuditorsFromAuditsList();                                                 
                        } else{
                            this.utilService.showToast("","Shifts are not received from server.");
                        }
        });        
  }

  private loadMachinesFromServerForpLant(){
    //should load audits for only selected processes
    this.adminManageMachine.getListOfMachines(+this.selectionData.selPltId, "1",
          this.selProcessId, true, this.selectionData.selPGId).subscribe((data)=>{
                this.machinesList = this.machinesList.concat(data);
                this.utilService.hideLoading();
            });
            this.adminManageMachine.getListOfMachines(+this.selectionData.selPltId, "1",
            this.selProcessId, true, 1).subscribe((data)=>{
              this.machinesList = this.machinesList.concat(data);
                  this.utilService.hideLoading();
              });
  }
 searchUsers(item:AssigningAuditorsForWeek){    
    let modal = this.modalCtrl.create(SearchUsersInPlant,{
      "loadUsersByLevel":"true",
      "isFromPage":"weeklySchedulingAudits",
      "selectedLevel":this.selLevelId
    });
    modal.onDidDismiss((data:User)=>{
      if(this.utilService.itemDefined(data)){          
            item.auditor.id = data.userId;
            item.auditor.name = data.firstName + " " + data.lastName;          
      }              
    });
    modal.present();
  }

  searchMachines(item:AssigningAuditorsForWeek){    
    let modal = this.modalCtrl.create(SearchMachineInPlant,{      
      "machinesList":this.machinesList
    });
    modal.onDidDismiss((data:Machine)=>{
      if(this.utilService.itemDefined(data)){          
        item.machine.name = data.name;
        this.onMachineSelChange(item);
      }              
    });
    modal.present();
  }


onMachineSelChange(item){  
  if(this.isShowMachine){
    if(_.isArray(item.machine.name)){        
      const selIndex = item.machine.name.indexOf("select");
      const selLen =  item.machine.name.length;
      if(selIndex !==-1){    
        if(_.isArray(item.machine.name)){          
          item.machine.name = item.machine.name.slice(1, selLen);                          
        } 
      }
      const selAllIndex = item.machine.name.indexOf("selectAll");
      const selAllLen =  item.machine.name.length;
      if(selAllIndex !== -1){
        if(_.isArray(item.machine.name)){
          item.machine.name = item.machine.name.slice(1, selAllLen); 
          item.machine.name = _.map(this.machinesList, 'name');            
        }
      }
    } 
  }       
}
  private loadViewFromParams(startDateofWeek:string){
    const navParams = this.navParams.data.weekStart;
    
    //const mom = moment(startDateofWeek);
    this.fullDay = moment(startDateofWeek).endOf('week').format("MM/DD/YYYY");
    this.day = moment(startDateofWeek).endOf('week').format("MMM Do, YYYY");
    //this.isShowfullDay = (!moment(this.fullDay1).isBefore(moment()) || moment(this.fullDay1).isSame(moment().format('MM/DD/YYYY')));
    const day1Date = moment(startDateofWeek).format("MM/DD");
    const day1Day = moment(startDateofWeek).format("dd").toLowerCase();
    this.translate.get([day1Day]).subscribe((values)=>{
      this.day1 = day1Date +" - " + values[day1Day];
    });  
    this.fullDay1 = moment(startDateofWeek).format("MM/DD/YYYY");
    this.headerWeek = moment(startDateofWeek).format("MMM Do, YYYY");
    this.isShowfullDay1 = (!moment(this.fullDay1).isBefore(moment()) || moment(this.fullDay1).isSame(moment().format('MM/DD/YYYY')));


    const day2Date = moment(this.fullDay1).add(1,'day').format("MM/DD");
    const day2Day = moment(this.fullDay1).add(1,'day').format("dd").toLowerCase();    
    this.translate.get([day2Day]).subscribe((values)=>{
      this.day2 = day2Date +" - " + values[day2Day];
    });
    //this.day2 = moment(this.fullDay1).add(1,'day').format("MM/DD - dd");
    this.fullDay2 = moment(this.fullDay1).add(1,'day').format("MM/DD/YYYY");
    this.isShowfullDay2 = !moment(this.fullDay2).isBefore(moment())  || moment(this.fullDay2).isSame(moment().format('MM/DD/YYYY'));

    
    const day3Date = moment(this.fullDay2).add(1,'day').format("MM/DD");
    const day3Day = moment(this.fullDay2).add(1,'day').format("dd").toLowerCase();    
    this.translate.get([day3Day]).subscribe((values)=>{
      this.day3 = day3Date +" - " + values[day3Day];
    });
    //this.day3 = moment(this.fullDay2).add(1,'day').format("MM/DD - dd");
    this.fullDay3 = moment(this.fullDay2).add(1,'day').format("MM/DD/YYYY");
    this.isShowfullDay3 = !moment(this.fullDay3).isBefore(moment())  || moment(this.fullDay3).isSame(moment().format('MM/DD/YYYY'));

    const day4Date = moment(this.fullDay3).add(1,'day').format("MM/DD");
    const day4Day = moment(this.fullDay3).add(1,'day').format("dd").toLowerCase();    
    this.translate.get([day4Day]).subscribe((values)=>{
      this.day4 = day4Date +" - " + values[day4Day];
    });
    //this.day4 = moment(this.fullDay3).add(1,'day').format("MM/DD - dd");
    this.fullDay4 = moment(this.fullDay3).add(1,'day').format("MM/DD/YYYY");
    this.isShowfullDay4 = (!moment(this.fullDay4).isBefore(moment())  || moment(this.fullDay4).isSame(moment().format('MM/DD/YYYY')));


    const day5Date = moment(this.fullDay4).add(1,'day').format("MM/DD");
    const day5Day = moment(this.fullDay4).add(1,'day').format("dd").toLowerCase();    
    this.translate.get([day5Day]).subscribe((values)=>{
      this.day5 = day5Date +" - " + values[day5Day];
    });
    //this.day5 = moment(this.fullDay4).add(1,'day').format("MM/DD - dd");
    this.fullDay5 = moment(this.fullDay4).add(1,'day').format("MM/DD/YYYY");
    this.isShowfullDay5 = (!moment(this.fullDay5).isBefore(moment())  || moment(this.fullDay5).isSame(moment().format('MM/DD/YYYY')));


    const day6Date = moment(this.fullDay5).add(1,'day').format("MM/DD");
    const day6Day = moment(this.fullDay5).add(1,'day').format("dd").toLowerCase();    
    this.translate.get([day6Day]).subscribe((values)=>{
      this.day6 = day6Date +" - " + values[day6Day];
    });
    //this.day6 = moment(this.fullDay5).add(1,'day').format("MM/DD - dd");
    this.fullDay6 = moment(this.fullDay5).add(1,'day').format("MM/DD/YYYY");
    this.isShowfullDay6 = (!moment(this.fullDay6).isBefore(moment())  || moment(this.fullDay6).isSame(moment().format('MM/DD/YYYY')));

    const day7Date = moment(this.fullDay6).add(1,'day').format("MM/DD");
    const day7Day = moment(this.fullDay6).add(1,'day').format("dd").toLowerCase();    
    this.translate.get([day7Day]).subscribe((values)=>{
      this.day7 = day7Date +" - " + values[day7Day];
    });
    //this.day7 = moment(this.fullDay6).add(1,'day').format("MM/DD - dd");   
    this.fullDay7 = moment(this.fullDay6).add(1,'day').format("MM/DD/YYYY");   
    this.isShowfullDay7 = (!moment(this.fullDay7).isBefore(moment())  || moment(this.fullDay7).isSame(moment().format('MM/DD/YYYY')));  

      if(this.isShowfullDay1){
             this.optionView = "1";
      } else if(this.isShowfullDay2){
             this.optionView = "2";
      } else if(this.isShowfullDay3){
             this.optionView = "3";
      } else if(this.isShowfullDay4){
             this.optionView = "4";
      } else if(this.isShowfullDay5){
             this.optionView = "5";
      } else if(this.isShowfullDay6){
             this.optionView = "6";
      } else if(this.isShowfullDay7){
             this.optionView = "7";
      }
      /*
      Below code helap to delete the old Audits             
      this.isShowfullDay1 = true;
      this.isShowfullDay2 = true;
      this.isShowfullDay3 = true;
      this.isShowfullDay4 = true;
      this.isShowfullDay5 = true;
      this.isShowfullDay6 = true;
      this.isShowfullDay7 = true;
*/
}

private confirmApplyThisScheduleOnADay(auditItem, item){
  let confirm = this.alertCtrl.create({
    title: 'Confirm',
    message: 'Please confirm you want to apply this on other date ?',
    buttons: [{
          text: 'No',
          handler: () => {
                      
          }
        },
        {
          text: 'Yes',
          handler: () => {  
            this.applyThisScheduleOnADay(auditItem, item);                            
          }
        }]
    });
  confirm.present(); 
}
private confirmApplyAllSchedulesToOtherDays(auditItem, item){
  let confirm = this.alertCtrl.create({
    title: 'Confirm',
    message: 'Please confirm you want to apply all the Schedules on other days ?',
    buttons: [{
          text: 'No',
          handler: () => {                          
          }
        },
        {
          text: 'Yes',
          handler: () => { 
            this.applyAllSchedulesToOtherDays(auditItem, item);                         
          }
        }]
    });
  confirm.present(); 
}
private confirmApplyThisScheduleToOtherDays(auditItem, item){
  let confirm = this.alertCtrl.create({
    title: 'Confirm',
    message: 'Please confirm you want to apply this on other date ?',
    buttons: [{
          text: 'No',
          handler: () => {
                           
          }
        },
        {
          text: 'Yes',
          handler: () => {     
            this.applyThisScheduleToOtherDays(auditItem, item);                    
          }
        }]
    });
  confirm.present(); 
}
private applyThisScheduleOnADay(auditItem, item){
  item = item.toString();
  let auditListItem = Object.assign({},auditItem);
  auditListItem.auditId = 0;
  if(item !== '' && item !== 'select'){
    if(this.isShowfullDay1 && ('1' === item)){
    this.auditorsListDay1.push(auditListItem);}
    if(this.isShowfullDay2 && ('2' === item)){
    this.auditorsListDay2.push(auditListItem);}
    if(this.isShowfullDay3 && ('3' === item)){
    this.auditorsListDay3.push(auditListItem);}
    if(this.isShowfullDay4 && ('4' === item)){
    this.auditorsListDay4.push(auditListItem);}
    if(this.isShowfullDay5 && ('5' === item)){
    this.auditorsListDay5.push(auditListItem);}
    if(this.isShowfullDay6 && ('6' === item)){
    this.auditorsListDay6.push(auditListItem);}
    if(this.isShowfullDay7 && ('7' === item)){
    this.auditorsListDay7.push(auditListItem);}
    this.utilService.showToast("", "Successfully applied the selected schedule to other days of this week.");
  }      
}
private applyThisScheduleToOtherDays(auditItem, item){
  let auditListItem = Object.assign({},auditItem);
  auditListItem.auditId = 0;
  if(item !== '' && item !== 'select'){
    if(this.isShowfullDay1 && ('1' !== item)){
    this.auditorsListDay1.push(auditListItem);}
    if(this.isShowfullDay2 && ('2' !== item)){
    this.auditorsListDay2.push(auditListItem);}
    if(this.isShowfullDay3 && ('3' !== item)){
    this.auditorsListDay3.push(auditListItem);}
    if(this.isShowfullDay4 && ('4' !== item)){
    this.auditorsListDay4.push(auditListItem);}
    if(this.isShowfullDay5 && ('5' !== item)){
    this.auditorsListDay5.push(auditListItem);}
    if(this.isShowfullDay6 && ('6' !== item)){
    this.auditorsListDay6.push(auditListItem);}
    if(this.isShowfullDay7 && ('7' !== item)){
    this.auditorsListDay7.push(auditListItem);}
    this.utilService.showToast("", "Successfully applied the selected schedule to other days of this week.");
  }      
}
private applyAllSchedulesToOtherDays(auditListId, item){
      const readOnlyauditListItem:Array<AssigningAuditorsForWeek> = this[auditListId];
      let auditListItem:Array<AssigningAuditorsForWeek> = readOnlyauditListItem.map(item => Object.assign({},item));
      auditListItem.forEach(item => item.auditId = 0);
      if(this.isShowfullDay1 && ('1' !== item)){
          this.auditorsListDay1 = this.auditorsListDay1.concat(Object.assign([],auditListItem));}
      if(this.isShowfullDay2 && ('2' !== item)){
      this.auditorsListDay2 = this.auditorsListDay2.concat(Object.assign([],auditListItem));}
      if(this.isShowfullDay3 && ('3' !== item)){
      this.auditorsListDay3 = this.auditorsListDay3.concat(Object.assign([],auditListItem));}
      if(this.isShowfullDay4 && ('4' !== item)){
      this.auditorsListDay4 = this.auditorsListDay4.concat(Object.assign([],auditListItem));}
      if(this.isShowfullDay5 && ('5' !== item)){
      this.auditorsListDay5 = this.auditorsListDay5.concat(Object.assign([],auditListItem));}
      if(this.isShowfullDay6 && ('6' !== item)){
      this.auditorsListDay6 = this.auditorsListDay6.concat(Object.assign([],auditListItem));}
      if(this.isShowfullDay7 && ('7' !== item)){
      this.auditorsListDay7 = this.auditorsListDay7.concat(Object.assign([],auditListItem));}
      this.utilService.showToast("", "Successfully applied the schedules to other days of this week.");
}
public returnRequest(auditorsListDay, auditDate, resendEmail){
    return this[auditorsListDay].reduce((prev, item)=>{
          this.onMachineSelChange(item);
          let machinesList = this.machinesList.filter(i => i.name.toString() === item.machine.name.toString());
          const machineId =  machinesList[0] ||  {"id":0};
            const machineName = this.isShowMachine ? item.machine.name : "";
            if(!this.isLPAAuditScheduler){
              if(item.auditor.id !== 0 && item.shift.id !== "0" && item.shift.id !== "" && item.shift.id !== "select"){ 
                prev.push(new ScheduleToAuditor(auditDate, resendEmail, item.auditId,item.auditor.id,item.shift.id, +machineId.id, machineName,item.comments,"","",""));
              } else{
                if(item.auditor.id !== 0){
                  this.utilService.showToast("","The Shift or Machine for the Auditor "+item.auditor.name+" is not selected to Schedule. Can you please re-schedule for this Auditor?");
                }              
              }
            } else{
              if(item.auditor.id !== 0 && item.shift.id !== "0" && item.shift.id !== "" && item.shift.id !== "select" && machineName !=="" && machineName !=="select" && machineId.id !== 0){ 
                prev.push(new ScheduleToAuditor(auditDate, resendEmail, item.auditId,item.auditor.id,item.shift.id, +machineId.id, machineName,item.comments,"","",""));
              } else{
                if(item.auditor.id !== 0){
                  this.utilService.showToast("","The Shift or Machine for the Auditor "+item.auditor.name+" is not selected to Schedule. Can you please re-schedule for this Auditor?");
                }              
              }
            }          
        return prev;
    },[])
}
public sendReminderToAuditors(){
  this.sendReminder = true;
  this.utilService.showToast("","Please hit Submit to successfully Send Reminders to Auditors.");
}
public assignAuditToSelectedUsers(){
  const langCode =this.selectionData.selLangCode;
  // Todo check if the date was edited
  if(this.selProcessId !== 0 &&  this.selLevelId &&  this.selLevelId !==0){
    if(this.isDailySchedule){
          if(this.isShowfullDay1){         
            const auditorsList = this.returnRequest('auditorsListDay1', this.fullDay1, this.sendReminder);
           // if(auditorsList.length > 0){
              this.auditDetailsService.scheduleAuditToUser([new ScheduleAuditToUser(this.selProcessId,this.selectionData.selPltId,
                this.selLevelId,
                this.fullDay1,
                0,false,
                langCode,
                this.user.wLogin,auditorsList)]).subscribe((data:ResponseObject)=>{
                  if(this.utilService.checkValidData(data)){
                      this.utilService.showToast("","Successfully Assigned  the Audit on " + moment(this.fullDay1).format("MMM Do YYYY"));                                                                
                  }
                });
            //}            
        }
        if(this.isShowfullDay2){
          const auditorsList = this.returnRequest('auditorsListDay2', this.fullDay2, this.sendReminder);
          //if(auditorsList.length > 0){
              this.auditDetailsService.scheduleAuditToUser([new ScheduleAuditToUser(this.selProcessId,this.selectionData.selPltId,
                                this.selLevelId,this.fullDay2, 0,false,langCode,
                                this.user.wLogin,this.returnRequest('auditorsListDay2', this.fullDay2, this.sendReminder))]).subscribe((data:ResponseObject)=>{
                                  if(this.utilService.checkValidData(data)){
                                      this.utilService.showToast("","Successfully Assigned  the Audit on " + moment(this.fullDay2).format("MMM Do YYYY"));                                                                
                                  }
                                });
            //                  }
        }
        if(this.isShowfullDay3){
          const auditorsList = this.returnRequest('auditorsListDay3', this.fullDay3, this.sendReminder);
          //if(auditorsList.length > 0){
              this.auditDetailsService.scheduleAuditToUser([new ScheduleAuditToUser(this.selProcessId,this.selectionData.selPltId,
                                this.selLevelId,
                                this.fullDay3,
                                0,false,langCode,
                                this.user.wLogin,auditorsList)]).subscribe((data:ResponseObject)=>{
                                  if(this.utilService.checkValidData(data)){
                                      this.utilService.showToast("","Successfully Assigned  the Audit on " + moment(this.fullDay3).format("MMM Do YYYY"));                                                                
                                  }
                                });
            //                  }
        }
        if(this.isShowfullDay4 ){
          const auditorsList = this.returnRequest('auditorsListDay4', this.fullDay4, this.sendReminder);
          //if(auditorsList.length > 0){
              this.auditDetailsService.scheduleAuditToUser([new ScheduleAuditToUser(this.selProcessId,this.selectionData.selPltId,
                                this.selLevelId, 
                                this.fullDay4,                               
                                0,false,langCode,
                                this.user.wLogin,auditorsList)]).subscribe((data:ResponseObject)=>{
                                  if(this.utilService.checkValidData(data)){
                                      this.utilService.showToast("","Successfully Assigned  the Audit on " + moment(this.fullDay4).format("MMM Do YYYY"));                                                                
                                  }
                                });
          //}
        }
        if(this.isShowfullDay5){
          const auditorsList = this.returnRequest('auditorsListDay5', this.fullDay5, this.sendReminder);
          //if(auditorsList.length > 0){
              this.auditDetailsService.scheduleAuditToUser([new ScheduleAuditToUser(this.selProcessId,this.selectionData.selPltId,
                                this.selLevelId,
                                this.fullDay5,
                                0,false,langCode,
                                this.user.wLogin,auditorsList)]).subscribe((data:ResponseObject)=>{
                                  if(this.utilService.checkValidData(data)){
                                      this.utilService.showToast("","Successfully Assigned  the Audit on " + moment(this.fullDay5).format("MMM Do YYYY"));                                                                
                                  }
                                });
            //                  }
        } 
        if(this.isShowfullDay6){
          const auditorsList = this.returnRequest('auditorsListDay6', this.fullDay6, this.sendReminder);
          //if(auditorsList.length > 0){
              this.auditDetailsService.scheduleAuditToUser([new ScheduleAuditToUser(this.selProcessId,this.selectionData.selPltId,
                                this.selLevelId,   
                                this.fullDay6,                             
                                0,false,langCode,
                                this.user.wLogin,auditorsList)]).subscribe((data:ResponseObject)=>{
                                  if(this.utilService.checkValidData(data)){
                                      this.utilService.showToast("","Successfully Assigned  the Audit on " + moment(this.fullDay6).format("MMM Do YYYY"));                                                                
                                  }
                                });
            //                  }
        }
        if(this.isShowfullDay7){
          const auditorsList = this.returnRequest('auditorsListDay7',this.fullDay7,this.sendReminder);
          //if(auditorsList.length > 0){
              this.auditDetailsService.scheduleAuditToUser([new ScheduleAuditToUser(this.selProcessId,this.selectionData.selPltId,
                                this.selLevelId,  
                                this.fullDay7,                              
                                0,false,langCode,
                                this.user.wLogin,auditorsList)]).subscribe((data:ResponseObject)=>{
                                  if(this.utilService.checkValidData(data)){
                                      this.utilService.showToast("","Successfully Assigned  the Audit on " + moment(this.fullDay7).format("MMM Do YYYY"));                                                                
                                  }
                                });
            //                  }
        }
    }
   if(!this.isDailySchedule){
    const auditorsList = this.returnRequest('auditorsListDay', this.fullDay, this.sendReminder);
    //if(auditorsList.length > 0){
        this.auditDetailsService.scheduleAuditToUser([new ScheduleAuditToUser(this.selProcessId,this.selectionData.selPltId,
          this.selLevelId, 
          this.fullDay,         
          0,false,langCode,
          this.user.wLogin,auditorsList)]).subscribe((data:ResponseObject)=>{
            if(this.utilService.checkValidData(data)){
                this.utilService.showToast("","Successfully Assigned  the Audit on " + moment(this.fullDay7).format("MMM Do YYYY"));                                                                
            }
          });
      //  }
   }
  } else{
    console.error("Values cannot be null");
  }
  this.viewCtrl.dismiss();
}

public cancelButtonClicked(){ 
  this.viewCtrl.dismiss();  
}

public removeAddedAuditorFromAudit(index, item, auditlistid){
  if(item.startDate !== "" && item.startDate !== undefined && item.startDate !== null){
    if(!(!moment(item.startDate).isBefore(moment())  || moment(item.startDate).isSame(moment().format('MM/DD/YYYY')))){
      this.utilService.showToast("","Cannot delete past due date Audits.");
      return; 
    }
  }
  
    let alert = this.alertCtrl.create({
                            title: 'Confirm',
                            message:"You're deleting the Scheduled Audit, Are you sure?",                            
                            buttons: [
                            {
                                text: 'No',
                                role: 'cancel',
                                handler: data => {   
                                    
                                }
                            },
                            {
                                text: 'Yes',
                                handler: () => {
                                      let auditList =  Object.assign([],this[auditlistid]);
                                      auditList.splice(index,1);    
                                      this[auditlistid] = auditList;
                                }
                            }
                            ]
                        });
                         alert.present();        
  }
}
