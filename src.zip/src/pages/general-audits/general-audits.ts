import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, PopoverController, AlertController, ViewController,Platform, App  } from 'ionic-angular';
import { SelectionPage } from '../selection/selection';
import { AuditService } from '../audits/audit-service';
import { AdminAuditProvider } from '../admin/admin-audits/admin-audits-service';
import { CacheDataForOfflineProvider } from '../../providers/cache-data-for-offline';
import { AuditList, UserObject, UserSelectionData,ResponseObject, UserSelectionPrivileges, ActiveAudit, AcceptedAuditItem } from '../../models/QuestionItem';
import { UtilService } from '../../providers/util-service';
import { UserService } from '../../providers/user-service';
import { AuditDetails } from '../admin/audit-details/audit-details';
import { AuditStartResults } from '../audit-start-results/audit-start-results';
import { AuditStartResultsProvider } from '../audit-start-results/audit-start-results-service';
import { User} from '../../models/User';
import { Network } from '@ionic-native/network';
import { Lot, Machine, Shift } from '../../models/Level';
import * as _ from 'lodash';
import * as moment from  'moment';
import * as storage from "../../providers/local-Storage";
import { SubmitScheduledAudit } from '../../models/QuestionItem';
import { HomePage } from '../home/home';
import {AdhocAuditsPage} from "../adhoc-audits/adhoc-audits";
/**
 * Generated class for the GeneralAuditsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-general-audits',
  templateUrl: 'general-audits.html',
})
export class GeneralAuditsPage {
  private selectionData:UserSelectionData;
  private adhocGeneralAuditList:Array<AuditList>;
  private initialAdhocGeneralAuditList:Array<AuditList>;
  private scheduledGeneralAuditList:Array<AcceptedAuditItem>;
  private initialscheduledGeneralAuditList:Array<AcceptedAuditItem>;
  private isAuditsSchedular:boolean;
  private isShowDetails:boolean;
  private isShowPlant:boolean;
  private isPlantAdmin:boolean;
  private pageTitle:string;
  private user:User;
  private userId:number;
  private levelId:number;
  public isOffline:boolean;
  private isReadOnly :boolean;
  public isPopModel : boolean;
  public showStDate:string;
  public showEdDate:string;
  private subscription:any;
  public optionView:string;
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              private utilService: UtilService,
              private alertCtrl : AlertController,
              private userService: UserService,
              private appCtrl:App,
              public platform: Platform, 
              private network: Network, 
              private cacheData:CacheDataForOfflineProvider,
              private viewCtrl:ViewController, 
              private auditService:AuditService, 
              private adminAuditService:AdminAuditProvider,
              private auditStartResultService:AuditStartResultsProvider,
              private popoverCtrl: PopoverController) {
                this.isAuditsSchedular = false;
                this.selectionData = this.userService.getUserSelection();
                this.isShowDetails = true;
                this.isShowPlant = false;
                this.isReadOnly = false;
                this.isOffline = false;
                this.pageTitle = "Waste Walk";//"Other Audits";
                this.isPopModel = false;
                this.showStDate = "";
                this.showEdDate = "";
                this.adhocGeneralAuditList = [];
                this.initialAdhocGeneralAuditList = [];
                this.user = this.userService.getUser();
                this.isPlantAdmin = this.user["roleId"] === 3;
                this.optionView = "schedule";
  }
  public navigateToHome():void{
        this.navCtrl.setRoot(HomePage);
   }
   ionViewWillLeave(){
        if(this.subscription !== undefined){
            this.subscription.unsubscribe();
        }
    }
  ionViewDidEnter() {      
      this.userId = this.isShowPlant ? 0 : this.userService.getUser().userId;
    if(this.platform.is("cordova")){
            this.subscription=  this.network.onchange().subscribe((data) => {
                if(data.type === "offline"){               
                    this.isOffline = true;
                    this.utilService.showToast("","Network Offline - Un Schduled Audits");
                }
                if(data.type === "online"){               
                    this.isOffline = false;
                    this.utilService.showToast("","Network Online -Un Schduled Audits");
                    this.getActiveGeneralAuditList();
                    this.getAllGeneralAvailableAdhocAudits(this.selectionData.selPltId);                    
                } 
            });
        }
        if(this.utilService.isNetworkConnected){
                this.isOffline = false;
                this.getActiveGeneralAuditList();
                this.getAllGeneralAvailableAdhocAudits(this.selectionData.selPltId);                
          } else{
                this.isOffline = true;
          }
  }
  private getAllGeneralAvailableAdhocAudits(plantId:number){               
      this.adminAuditService.getAuditsListByOpPg(1, 0, 11, this.isPlantAdmin, plantId ).subscribe((data:ResponseObject)=>{
          if(this.utilService.checkValidData(data)){                                    
              this.adhocGeneralAuditList = data.Response;
              this.initialAdhocGeneralAuditList = data.Response;                               
          }
      });        
  }

  private adhocGeneralAuditListItemClicked(auditItem:AuditList):void{
      if(auditItem.numOfQuesCorp !== 0){
                let selData = Object.assign({}, this.selectionData);
                selData.selPrId = auditItem.procId;
                selData.selPrName = auditItem.procName;
                //CreateAndAssignAuditRequest - serice call
                /*let popover = this.popoverCtrl.create(SelectionPage, {
                                                    "isMandatory" : "false",
                                                    "isPopOverCtrl":"true", 
                                                    "isFromPage" :  "AuditSchedular",
                                                    "isMultipleSelect":"false",
                                                    "pageTitle":(auditItem.procName),
                                                    "userPrivileges" : new UserSelectionPrivileges(false,false, false, false, false,
                                                                                                false, false, false, false, false, 
                                                                                                false, false, true, false, false, 
                                                                                                false, false, false, false, false, false, true), 
                                                    "userSelectionData": selData },
                                                    {
                                                            enableBackdropDismiss:false,
                                                        });
                popover.present();
                popover.onDidDismiss((data:UserSelectionData) => {
                    if(data !== undefined){  */          
                        const loggedInUserWLogin = this.user.wLogin;
                        const userId = this.user.userId
                            const auditTakenTime = moment().format('YYYY/MM/DD HH:mm:ss'); 
                            const plantId = this.selectionData.selPltId;
                            const plantName = this.selectionData.selPltName;
                            let acceptedAuditItem:AcceptedAuditItem = new AcceptedAuditItem(0,this.user.userId, this.user.firstName, 
                            this.user.lastName, auditTakenTime,auditTakenTime,'',auditItem.auditName,auditItem.pgId,auditItem.opName, auditItem.pgName,
                            auditItem.opId,auditItem.procId,auditItem.procName,plantId,plantName,auditItem.levelId, "0","select","0",'',0,
                            auditTakenTime, auditTakenTime);
                            this.navigateToAuditTakingPage(acceptedAuditItem);
                        }
           /*         });  
        }  else{
            this.utilService.showToast("","Question not available for the Audit.");
        }*/
  }

    private navigateToAuditTakingPage(acceptedAuditItem:AcceptedAuditItem){      
            let selData = Object.assign({},this.selectionData);
            selData.auditor = new UserObject(acceptedAuditItem.userId, acceptedAuditItem.firstName+","+acceptedAuditItem.lastName);
            selData.startDate = acceptedAuditItem.startDate;
            selData.endDate = acceptedAuditItem.endDate;
            selData.lot = new Lot(0, acceptedAuditItem.lotNum);
            selData.machine = new Machine("0", acceptedAuditItem.machineNum, acceptedAuditItem.procName, true);
            selData.selCommentsTextarea = acceptedAuditItem.comments;
            selData.shift = new Shift("0", acceptedAuditItem.shift.toString());                                 
            selData.selPrId = acceptedAuditItem.procId;
            selData.selPrName = acceptedAuditItem.procName;
            selData.selLevelId = acceptedAuditItem.levelId;
            this.navCtrl.push(AuditStartResults, {"isReadOnly":  "false",
                                                    "isFromPage":"AuditsListUserPage", 
                                                    "userSelectionData":selData,
                                                    "isScheduledAudit":"true", 
                                                    "isAdhocAudit":"true",
                                                    "isOffline":"false",
                                                    "auditInfoDetails":acceptedAuditItem}); 
    }

  private getActiveGeneralAuditList():void{
      /*
      this will returns audits for the past scheduled 3 months and the curent week audits
        @processId as int = 0,   -- 0 for all processes
        @level as int = 0		 -- 0 for all levels
      */
      if(!this.isOffline){  
            const stDate = this.selectionData.startDate;//2017-08-06 
            const edDate =  this.selectionData.endDate; 
           /* this.showStDate = this.utilService.getSearchDateToShow(stDate);
            const pastStDate= this.utilService.getPastMonthStartDate(3);
            const pastEdDate= this.utilService.getPastMonthEndDate(stDate);
            this.showEdDate = this.utilService.getSearchDateToShow(edDate);*/
            const pltId = this.selectionData.selPltId; 
            const levId =  this.isPlantAdmin ? 0 : this.selectionData.selLevelId;// for plant admin load all the audits
            const prId = this.selectionData.selPrId;
            const langCode = this.selectionData.selLangCode;
            this.scheduledGeneralAuditList =[];
            const savedAuditsList =  this.auditStartResultService.getSubmitNotCompldAuditIds();            
            if(pltId !== 0 &&  prId !== undefined && levId !== undefined && !isNaN(prId)){   
                // Since we're passign the startDate adn EndDate as empty we do not need the past 3 months Audits which are returned by default.
               let initalAuditsList = [];
              this.utilService.showLoading();
              this.auditService.getScheduledAuditForUserByPlantId(this.isShowPlant ? 0 :this.userId, "", "",
                pltId, 11,  0, 1 ).subscribe((data:ResponseObject)=>{
                    this.auditService.getSavedInCompleteAuditForUserByPlantId(this.isShowPlant ? 0 :this.userId, "", "",
                        pltId, 11,  0, 1 ).subscribe((response:ResponseObject)=>{                      
                    if(!this.isShowPlant && this.utilService.checkValidData(response)){
                       initalAuditsList = initalAuditsList.concat(response.Response);                   
                    } 
                    if(this.utilService.checkValidData(data)){
                      initalAuditsList = initalAuditsList.concat(data.Response);                                                                                  
                    } 
                    this.utilService.hideLoading();
                  this.scheduledGeneralAuditList = initalAuditsList.reduce((prev, item)=>{
                      if(savedAuditsList.length > 0){
                            // chekcing if the saved completed audits exists.
                            // if exists don't load those audits.
                            if(savedAuditsList.indexOf(item.auditListId) === -1){
                                prev.push(item);                            
                            }
                      } else{
                            prev.push(item);                            
                      }                           
                      return prev;                   
                  },[]);
                  const auditListConst = this.scheduledGeneralAuditList;
                  this.initialscheduledGeneralAuditList = auditListConst;

                  if(this.isOffline){
                          const auditsList = this.scheduledGeneralAuditList;
                          this.cacheData.saveUnSchAuditslistDetails(true,stDate, edDate, pltId,  levId,  prId, langCode, auditsList);
                  }
              }); 
            });  
            } else{
              console.error("Values cannot be empty ");
            }     
      } else{          
            const response:Array<AcceptedAuditItem> = storage.loadSavedData(this.user.wLogin,"schAuditsList");
            if(response!== undefined){
                this.scheduledGeneralAuditList = response;                  
                this.initialscheduledGeneralAuditList = response;
            }            
        }   
   }
   
private scheduledGeneralAuditListItemClicked(auditItem:AcceptedAuditItem):void{
          const selData:UserSelectionData = Object.assign({}, this.selectionData);                                      
          selData.selPrId = auditItem.procId; 
          selData.selPrName = auditItem.procName;
          selData.selLevelId = auditItem.levelId;
          selData.machine.name = auditItem.machineNum;
          selData.shift.name = auditItem.shift.toString();

          this.navCtrl.push(AuditStartResults, { "isReadOnly":this.isReadOnly.toString(),
                                                "isFromPage":"AuditsListUserPage", 
                                                "userSelectionData":selData,
                                                "isScheduledAudit":"true", 
                                                "isOffline":this.isOffline.toString(),
                                                "auditInfoDetails":auditItem});
 }
}
