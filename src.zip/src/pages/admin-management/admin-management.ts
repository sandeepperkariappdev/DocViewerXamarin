import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Schedular } from '../side-menu/schedular/schedular';
import { AssignToFailureCodesCategoriesPage } from '../assign-to-failure-codes-categories/assign-to-failure-codes-categories';
import { ResourcesManagementPage } from '../resources-management/resources-management';
import { Admin } from '../admin/admin';
import { HomePage } from '../home/home';
import { UtilService} from '../../providers/util-service';
import { UserService } from '../../providers/user-service';
import { AdminManageMachineProvider } from '../resources-management/admin-manage-machine/admin-manage-machine-service';
import { UserSelectionData,UserSelectionPrivileges, ResponseObject, UserObject } from '../../models/QuestionItem';
import { TranslateService }  from 'ng2-translate';

/**
 * Generated class for the AdminManagementPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-admin-management',
  templateUrl: 'admin-management.html',
})
export class AdminManagementPage {
public pageTitle:string;
public userFirstLastName :string;
public layerName :string;
public pgName :string;
public wloginName :string;
  constructor(public navCtrl: NavController,
     public userService:UserService,
     private translate: TranslateService,
     public utilService:UtilService,
  private adminManageMachinesService:AdminManageMachineProvider,
  public navParams: NavParams) {
    this.pageTitle = "";
    this.layerName = "";
    this.pgName = "";
    this.wloginName= "";
  }

  ionViewDidLoad() {
    const selData = this.userService.getUserSelection();
    const usrDetails = this.utilService.getUserDetailsResponse();
   this.pageTitle = " - " + selData.selPltName;
   this.layerName = "" + selData.selLevelName;
   this.pgName = "" + selData.selPGName;
   this.wloginName = "" + usrDetails.wLogin;
   this.userFirstLastName = usrDetails.firstName + " " + usrDetails.lastName;
    if(selData.selPltId !== 0){
        this.userService.retrieveUsersForPlant(selData.selPltId, selData.selPGId);             
    } 
  }
  nonComplianceManagementClicked(){
    //AssignToFailureCodesCategoriesPage
    this.navCtrl.push(AssignToFailureCodesCategoriesPage);
  }
  resourcesManagementClicked(){
      this.navCtrl.push(ResourcesManagementPage);
  }
  editScheduledAuditsClicked(){
      this.navCtrl.push(Schedular);
  }
  scheduleAndAssignAuditsClicked(isLPAAudits){
    this.navCtrl.push(Admin,{"isLPAAudits":isLPAAudits});
  }
  auditsClicked(){
      this.navCtrl.setRoot(HomePage);
  }
}
