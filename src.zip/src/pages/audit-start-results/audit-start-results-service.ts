import { Injectable } from '@angular/core';
import { CallService } from '../../providers/call-service';
import { AppSettings, MethodConstants } from '../../constants/AppSettings';
import { User } from '../../models/User';
import { UserService } from '../../providers/user-service';
import { UtilService } from '../../providers/util-service';
import * as moment from 'moment';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { Observable }from 'rxjs/Rx';
import { Subscribe }from 'rxjs/Subscribe';
import { UserSelectionData, TempAudit, ResponseObject, AcceptedAuditItem, UsersInPlant, TempFailureCodes, RequestSWIPath, AuditFailureAF, AuditDetailAF } from '../../models/QuestionItem';
import { SubmitAudit, SubmitAdhocAudit, UserObject, SubmitQuestion,MachineInfo,  SubmitFailureCodes, AuditHeaderForAuditID } from '../../models/QuestionItem';
import * as storage from "../../providers/local-Storage";
import { TranslateService } from 'ng2-translate';
import * as _ from 'lodash';

@Injectable()
export class AuditStartResultsProvider {
    private user: User;
    private wLogin: string;
    private submitAuditFailureCodesList:Array<AuditDetailAF> = [];
    private submitAdhocAuditFailureCodesList:Array<AuditDetailAF> = [];
    constructor(public callService: CallService, private translate: TranslateService, private userService: UserService, private utilService: UtilService) {
        this.user = this.userService.getUser();
        if (this.user !== undefined) {
            this.wLogin = this.user.wLogin;
        }
    }
    private createResponseObjectSubmittedSavedAudit(data, machineNumInput: string, shiftNumInput: string, lotNumInput: string): Array<TempAudit> {
        // Adding the additional poperties to the object
        const usersList: Array<UsersInPlant> = this.userService.getUsersInPlant();
        let index: number = 0;
        return data.reduce((p, d) => {
            d.data = d.data.reduce((pr, da) => {
                da.questions = da.questions.reduce((prv, dat) => {
                    dat.index = index++;
                    dat.elementRefIndex = 0;
                    dat.isDefferred = false;
                    dat.pass = (dat.result === 1);
                    dat.fail = (dat.result === 2);
                    dat.naEntered = (dat.result === 3);
                    dat.failCodes = dat.failCodes.reduce((prvs, item) => {
                        // below commented code checks if the assigneed assignee and reviewer are present in the plant
                        //const assignee:UsersInPlant = _.filter(usersList, (usr) => usr.userId === item.assigneeId )[0];
                        //const reviewer:UsersInPlant = _.filter(usersList, (usr) => usr.userId === item.reviewerId )[0];                                                       
                        const failCodeSelected = false;
                        //let assigneeObj = new UserObject(0, "");
                        // let reviewerObj = new UserObject(0, "");
                        //if(assignee !== undefined){
                        //   let assigneeObj = new UserObject(assignee.userId,(assignee.firstName+","+assignee.lastName)); 
                        // }
                        // if(reviewer !== undefined){
                        //let   reviewerObj = new UserObject(reviewer.userId,(reviewer.firstName+","+reviewer.lastName));

                        const assigneeId = ((item.assigneeIdFCLevel !== undefined && item.assigneeIdFCLevel.toString().trim() !== "0" && item.assigneeIdFCLevel.toString().trim() !== "") ? item.assigneeIdFCLevel : item.assigneeId);
                        const assigneeName = ((item.assigneeNameFCLevel !== undefined && item.assigneeNameFCLevel.toString().trim() !== "0" && item.assigneeNameFCLevel.toString().trim() !== "") ? item.assigneeNameFCLevel : item.assigneeName);

                        const reviewerId = ((item.reviewerIdFCLevel !== undefined && item.reviewerIdFCLevel.toString().trim() !== "0" && item.reviewerIdFCLevel.toString().trim() !== "") ? item.reviewerIdFCLevel : item.reviewerId);
                        const reviewerName = ((item.reviewerNameFCLevel !== undefined && item.reviewerNameFCLevel.toString().trim() !== "0" && item.reviewerNameFCLevel.toString().trim() !== "") ? item.reviewerNameFCLevel : item.reviewerName);
                        let assigneeObj = new UserObject(assigneeId, (assigneeName));
                        let reviewerObj = new UserObject(reviewerId, (reviewerName));
                        //  }
                        let asgnDays = 0;
                        let revDays = 0;
                        const assigneeCompletionDays = item.assigneeCompletionDays;
                        let assigneeCompletionDate = "";
                        if (item.assigneeCompletionDays !== undefined && item.assigneeCompletionDays !== "" && item.assigneeCompletionDays !== "0") {
                            asgnDays = +item.assigneeCompletionDays;
                            assigneeCompletionDate = this.getFullDateFromDays(asgnDays);
                        }
                        if (item.assigneeCompletionDate !== undefined && item.assigneeCompletionDate !== "" && item.assigneeCompletionDate !== "0") {
                            assigneeCompletionDate = item.assigneeCompletionDate;
                        }

                        const reviewerCompletionDays =  parseInt(item.assigneeCompletionDate) + parseInt(item.reviewerCompletionDays);
                        let reviewerCompletionDate = "";
                        if (reviewerCompletionDays !== undefined && reviewerCompletionDays.toString() !== "" && reviewerCompletionDays.toString() !== "0") {
                            revDays = +reviewerCompletionDays;
                            reviewerCompletionDate = this.getFullDateFromDays(revDays);
                        }

                        if (item.reviewerCompletionDate !== undefined && item.reviewerCompletionDate !== "" && item.reviewerCompletionDate !== "0") {
                            reviewerCompletionDate = item.reviewerCompletionDate;
                        }


                        // // if the complete  failure days is zero , then assigning the reviewer completion days plus assignee completion days.
                        // if (item.failureCompletionDays !== undefined && (item.failureCompletionDays === "" || item.failureCompletionDays.toString() === "0")) {
                        //     item.failureCompletionDays = asgnDays + revDays;
                        // }
                        const failureCompletionDays = parseInt(item.assigneeCompletionDays) + parseInt(item.reviewerCompletionDays) + parseInt(item.failureCompletionDays);
                        let failureCompletionDate = "";

                        if (failureCompletionDays !== undefined && failureCompletionDays.toString() !== "" && failureCompletionDays.toString() !== "0") {
                            failureCompletionDate = this.getFullDateFromDays(+failureCompletionDays)
                        }
                        // if (item.failureCodeCompletionDate !== undefined && item.failureCodeCompletionDate !== "" && item.failureCodeCompletionDate !== "0") {
                        //     failureCompletionDate = item.failureCodeCompletionDate;
                        // }
                        const severity = item.severity;
                        prvs.push(new TempFailureCodes(0, item.failCode, false, item.failDesc, item.failCodeHelp,
                            assigneeObj, assigneeCompletionDays, assigneeCompletionDate, item.assigneeComments, reviewerObj, reviewerCompletionDays,
                            reviewerCompletionDate, item.reviewerComments, failureCompletionDays, failureCompletionDate, item.failureComments,
                            severity, item.imageType, item.imageAudit, "", 0, "", item.auditFailureId, 0, "", 0, "", item.changeDateAFR));
                        return prvs;
                    }, []);
                    prv.push(dat);
                    return prv;
                }, []);
                pr.push(da);
                return pr;
            }, []);
            d.machineNum = d.machineNum ? d.machineNum : machineNumInput;
            d.lotNum = d.lotNum ? d.lotNum : lotNumInput;
            d.shift = d.shift ? d.shift : shiftNumInput;
            p.push(d);
            return p;
        }, []);
    }
    private createResponseObject(data, machineNumInput: string, shiftNumInput: string, lotNumInput: string): Array<TempAudit> {
        // Adding the additional poperties to the object
        const usersList: Array<UsersInPlant> = this.userService.getUsersInPlant();
        let index: number = 0;
        return data.reduce((p, d) => {
            d.data = d.data.reduce((pr, da) => {
                da.questions = da.questions.reduce((prv, dat) => {
                    dat.index = index++;
                    dat.elementRefIndex = 0;
                    dat.isDefferred = false;
                    dat.pass = false;
                    dat.fail = false;
                    dat.result = 0;
                    dat.naEntered = false;
                    dat.queComment = "";
                    dat.failCodes = dat.failCodes.reduce((prvs, item) => {
                        // below commented code checks if the assigneed assignee and reviewer are present in the plant
                        //const assignee:UsersInPlant = _.filter(usersList, (usr) => usr.userId === item.assigneeId )[0];
                        //const reviewer:UsersInPlant = _.filter(usersList, (usr) => usr.userId === item.reviewerId )[0];                                                       
                        const failCodeSelected = false;
                        //let assigneeObj = new UserObject(0, "");
                        // let reviewerObj = new UserObject(0, "");
                        //if(assignee !== undefined){
                        //   let assigneeObj = new UserObject(assignee.userId,(assignee.firstName+","+assignee.lastName)); 
                        // }
                        // if(reviewer !== undefined){
                        //let   reviewerObj = new UserObject(reviewer.userId,(reviewer.firstName+","+reviewer.lastName));

                        const assigneeId = ((item.assigneeIdFCLevel !== undefined && item.assigneeIdFCLevel.toString().trim() !== "0" && item.assigneeIdFCLevel.toString().trim() !== "") ? item.assigneeIdFCLevel : item.assigneeId);
                        const assigneeName = ((item.assigneeNameFCLevel !== undefined && item.assigneeNameFCLevel.toString().trim() !== "0" && item.assigneeNameFCLevel.toString().trim() !== "") ? item.assigneeNameFCLevel : item.assigneeName);

                        const reviewerId = ((item.reviewerIdFCLevel !== undefined && item.reviewerIdFCLevel.toString().trim() !== "0" && item.reviewerIdFCLevel.toString().trim() !== "") ? item.reviewerIdFCLevel : item.reviewerId);
                        const reviewerName = ((item.reviewerNameFCLevel !== undefined && item.reviewerNameFCLevel.toString().trim() !== "0" && item.reviewerNameFCLevel.toString().trim() !== "") ? item.reviewerNameFCLevel : item.reviewerName);
                        let assigneeObj = new UserObject(assigneeId, (assigneeName));
                        let reviewerObj = new UserObject(reviewerId, (reviewerName));
                        //  }
                        let asgnDays = 0;
                        let revDays = 0;
                        const assigneeCompletionDays = item.assigneeCompletionDays;
                        let assigneeCompletionDate = "";
                        if (item.assigneeCompletionDays !== undefined && item.assigneeCompletionDays !== "" && item.assigneeCompletionDays !== "0") {
                            asgnDays = +item.assigneeCompletionDays;
                            assigneeCompletionDate = this.getFullDateFromDays(asgnDays);
                        }
                        if (item.assigneeCompletionDate !== undefined && item.assigneeCompletionDate !== "" && item.assigneeCompletionDate !== "0") {
                            assigneeCompletionDate = item.assigneeCompletionDate;
                        }

                        const reviewerCompletionDays = parseInt(item.assigneeCompletionDays) + parseInt(item.reviewerCompletionDays);
                        let reviewerCompletionDate = "";
                        if (item.reviewerCompletionDays !== undefined && item.reviewerCompletionDays !== "" && item.reviewerCompletionDays !== "0") {
                            revDays = +item.reviewerCompletionDays;
                            reviewerCompletionDate = this.getFullDateFromDays(revDays);
                        }

                        if (item.reviewerCompletionDate !== undefined && item.reviewerCompletionDate !== "" && item.reviewerCompletionDate !== "0") {
                            reviewerCompletionDate = item.reviewerCompletionDate;
                        }


                        // if the complete  failure days is zero , then assigning the reviewer completion days plus assignee completion days.
                        if (item.failureCompletionDays !== undefined && (item.failureCompletionDays === "" || item.failureCompletionDays.toString() === "0")) {
                            item.failureCompletionDays = asgnDays + revDays;
                        }
                        const failureCompletionDays = parseInt(item.assigneeCompletionDays) + parseInt(item.reviewerCompletionDays) +  parseInt(item.failureCompletionDays);
                        let failureCompletionDate = "";

                        if (failureCompletionDays !== undefined && failureCompletionDays.toString() !== "" && failureCompletionDays.toString() !== "0") {
                            failureCompletionDate = this.getFullDateFromDays(+failureCompletionDays)
                        }
                        // if (item.failureCodeCompletionDate !== undefined && item.failureCodeCompletionDate !== "" && item.failureCodeCompletionDate !== "0") {
                        //     failureCompletionDate = item.failureCodeCompletionDate;
                        // }
                        const severity = item.severity;
                        prvs.push(new TempFailureCodes(0, item.failCode, false, item.failDesc, item.failCodeHelp,
                            assigneeObj, assigneeCompletionDays, assigneeCompletionDate, "", reviewerObj, reviewerCompletionDays,
                            reviewerCompletionDate, "", failureCompletionDays, failureCompletionDate, "", severity, "", "", "", 0, ""));
                        return prvs;
                    }, []);
                    prv.push(dat);
                    return prv;
                }, []);
                //pr.push({catId:0, catName:'', questions:[]});
                pr.push(da);
                return pr;
            }, []);
            d.machineNum = d.machineNum ? d.machineNum : machineNumInput;
            d.lotNum = d.lotNum ? d.lotNum : lotNumInput;
            d.shift = d.shift ? d.shift : shiftNumInput;
            p.push(d);
            return p;
        }, []);
    }

    private createResponseObjectForSavedAudit(data, machineNumInput: string, shiftNumInput: string, lotNumInput: string, response: Array<TempAudit>): Array<TempAudit> {
        // Adding the additional poperties to the object
        const usersList: Array<UsersInPlant> = this.userService.getUsersInPlant();
        let index: number = 0;

        return data.reduce((p, d, itemIndex) => {
            d.data = d.data.reduce((pr, da, itemIndx) => {
                let queCatId = da.catId;
                da.questions = da.questions.reduce((prv, dat, itemIn) => {
                    const respObj = (response !== undefined ? response[itemIndex] : []);
                    const dataObj = (respObj !== undefined ? respObj["data"] : []);
                    const quesObj = (dataObj !== undefined ? dataObj.filter(c => c.catId.toString() === queCatId.toString())[0] : []);
                    const saveQuesObj = (quesObj !== undefined ? quesObj["questions"] : []);
                    const savedResponseQueObj = (saveQuesObj !== undefined ? saveQuesObj.filter(q => q.queId.toString() === dat.queId.toString())[0] : []);
                    dat.index = index++;
                    dat.elementRefIndex = 0;
                    dat.isDefferred = false;
                    dat.pass = savedResponseQueObj !== undefined ? (savedResponseQueObj.result === 1) : false;
                    dat.fail = savedResponseQueObj !== undefined ? (savedResponseQueObj.result === 2) : false;
                    dat.result = savedResponseQueObj !== undefined ? savedResponseQueObj.result : 0;
                    dat.naEntered = savedResponseQueObj !== undefined ? (savedResponseQueObj.result === 3) : false;
                    dat.queComment = savedResponseQueObj !== undefined ? (savedResponseQueObj.queComment) : "";
                    dat.auditDetailId = savedResponseQueObj !== undefined ? (savedResponseQueObj.auditDetailId) : 0;

                    const savedResponseQueObjFailCodeObj = savedResponseQueObj !== undefined ? savedResponseQueObj["failCodes"] : [];
                    const isFailCodeSelected = savedResponseQueObjFailCodeObj.length > 0;
                    const selFailCodeId = savedResponseQueObjFailCodeObj.length > 0 ? savedResponseQueObjFailCodeObj[0]["failCode"] : 0;
                    const selAuditFailureId = savedResponseQueObjFailCodeObj.length > 0 ? savedResponseQueObjFailCodeObj[0]["auditFailureId"] : 0;
                    const selAuditFailureComments = savedResponseQueObjFailCodeObj.length > 0 ? savedResponseQueObjFailCodeObj[0]["failureComments"] : "";
                    const selAuditAssigneeComments = savedResponseQueObjFailCodeObj.length > 0 ? savedResponseQueObjFailCodeObj[0]["assigneeComments"] : "";
                    const selAuditReviewerComments = savedResponseQueObjFailCodeObj.length > 0 ? savedResponseQueObjFailCodeObj[0]["reviewerComments"] : "";
                    const selAuditImageType = savedResponseQueObjFailCodeObj.length > 0 ? savedResponseQueObjFailCodeObj[0]["imageType"] : "";
                    const selAuditImageAudit = savedResponseQueObjFailCodeObj.length > 0 ? savedResponseQueObjFailCodeObj[0]["imageData"] : "";
                    const changeDateAFR = savedResponseQueObjFailCodeObj.length > 0 ? savedResponseQueObjFailCodeObj[0]["changeDateAFR"] : "";

                    dat.failCodes = dat.failCodes.reduce((prvs, item, itemI) => {


                        // below commented code checks if the assigneed assignee and reviewer are present in the plant
                        //const assignee:UsersInPlant = _.filter(usersList, (usr) => usr.userId === item.assigneeId )[0];
                        //const reviewer:UsersInPlant = _.filter(usersList, (usr) => usr.userId === item.reviewerId )[0];                                                       
                        let failCodeSelected = false;
                        let auditfailureId = 0;
                        let failCodeAssigneeComments = "";
                        let failCodeReviewerComments = "";
                        let failCodeFailureComments = "";
                        let failCodeImageType = "";
                        let failCodeImageAudit = "";
                        let failCodeChangeDateAFR  = "";
                        if (isFailCodeSelected && item.failCode.toString() === selFailCodeId.toString()) {
                            failCodeSelected = isFailCodeSelected;
                            auditfailureId = selAuditFailureId || 0;
                            failCodeAssigneeComments = selAuditAssigneeComments || "";
                            failCodeReviewerComments = selAuditReviewerComments || "";
                            failCodeFailureComments = selAuditFailureComments || "";
                            failCodeImageType = selAuditImageType || "";
                            failCodeImageAudit = selAuditImageAudit || "";
                            failCodeChangeDateAFR = changeDateAFR || "";
                        }
                        //let assigneeObj = new UserObject(0, "");
                        // let reviewerObj = new UserObject(0, "");
                        //if(assignee !== undefined){
                        //   let assigneeObj = new UserObject(assignee.userId,(assignee.firstName+","+assignee.lastName)); 
                        // }
                        // if(reviewer !== undefined){
                        //let   reviewerObj = new UserObject(reviewer.userId,(reviewer.firstName+","+reviewer.lastName));


                        const assigneeId = ((item.assigneeIdFCLevel !== undefined && item.assigneeIdFCLevel.toString().trim() !== "0" && item.assigneeIdFCLevel.toString().trim() !== "") ? item.assigneeIdFCLevel : item.assigneeId);
                        const assigneeName = ((item.assigneeNameFCLevel !== undefined && item.assigneeNameFCLevel.toString().trim() !== "0" && item.assigneeNameFCLevel.toString().trim() !== "") ? item.assigneeNameFCLevel : item.assigneeName);

                        const reviewerId = ((item.reviewerIdFCLevel !== undefined && item.reviewerIdFCLevel.toString().trim() !== "0" && item.reviewerIdFCLevel.toString().trim() !== "") ? item.reviewerIdFCLevel : item.reviewerId);
                        const reviewerName = ((item.reviewerNameFCLevel !== undefined && item.reviewerNameFCLevel.toString().trim() !== "0" && item.reviewerNameFCLevel.toString().trim() !== "") ? item.reviewerNameFCLevel : item.reviewerName);
                        let assigneeObj = new UserObject(assigneeId, (assigneeName));
                        let reviewerObj = new UserObject(reviewerId, (reviewerName));
                        //  }
                        let asgnDays = 0;
                        let revDays = 0;
                        const assigneeCompletionDays = item.assigneeCompletionDays;
                        let assigneeCompletionDate = "";
                        if (item.assigneeCompletionDays !== "" && item.assigneeCompletionDays !== "0") {
                            asgnDays = +item.assigneeCompletionDays;
                            assigneeCompletionDate = this.getFullDateFromDays(asgnDays);
                        }
                        const reviewerCompletionDays = parseInt(item.assigneeCompletionDays) + parseInt(item.reviewerCompletionDays);
                        let reviewerCompletionDate = "";
                        if (reviewerCompletionDays.toString() !== "" && reviewerCompletionDays.toString() !== "0") {
                            revDays = +reviewerCompletionDays;
                            reviewerCompletionDate = this.getFullDateFromDays(revDays);
                        }
                        // if the complete  failure days is zero , then assigning the reviewer completion days plus assignee completion days.
                        // if (item.failureCompletionDays === "" || item.failureCompletionDays.toString() === "0") {
                        //     item.failureCompletionDays = asgnDays + revDays;
                        // }
                        const failureCompletionDays = parseInt(item.assigneeCompletionDays) + parseInt(item.reviewerCompletionDays) + parseInt(item.failureCompletionDays);
                        let failureCompletionDate = "";
                        if (failureCompletionDays.toString() !== "" && failureCompletionDays.toString() !== "0") {
                            failureCompletionDate = this.getFullDateFromDays(+failureCompletionDays)
                        }
                        const severity = item.severity;
                        prvs.push(new TempFailureCodes(0, item.failCode, failCodeSelected, item.failDesc, item.failCodeHelp,
                            assigneeObj, assigneeCompletionDays, assigneeCompletionDate, failCodeAssigneeComments, reviewerObj, reviewerCompletionDays,
                            reviewerCompletionDate, failCodeReviewerComments, failureCompletionDays,
                            failureCompletionDate, failCodeFailureComments, severity, failCodeImageType,
                            failCodeImageAudit, "", 0, "", auditfailureId, 0,"",0,"",failCodeChangeDateAFR));
                        return prvs;
                    }, []);
                    prv.push(dat);
                    return prv;
                }, []);
                //pr.push({catId:0, catName:'', questions:[]});
                pr.push(da);
                return pr;
            }, []);
            d.machineNum = d.machineNum ? d.machineNum : machineNumInput;
            d.lotNum = d.lotNum ? d.lotNum : lotNumInput;
            d.shift = d.shift ? d.shift : shiftNumInput;
            p.push(d);
            return p;
        }, []);
    }
    //viewPlantQues = 2 = All audit questions for plant, 0 = coperate level audit questions, 1 = coperate + plant level audit questions
    public getAuditQuesFailCode(procId: number, levelId: number, langCode: string, plantId: number, viewPlantQues: number, machineNum: string, shiftNum: string, lotNum: string): Observable<Array<TempAudit>> {
        if ((procId && procId !== 0) && (levelId && levelId !== 0) && (langCode && langCode !== "") && (plantId && plantId !== 0)) {
            const url = (AppSettings.API_ENDPOINT + MethodConstants.GetAuditQuesFailCode + "&processId=" + procId + "&langCode=" + langCode + "&level=" + levelId + "&plantId=" + plantId + "&viewPlantQues=" + viewPlantQues);
            return this.callService.callServerForGet(url).map((dataResp: ResponseObject) => {
                if (this.utilService.checkValidData(dataResp)) {
                    let data = dataResp.Response;
                    return this.createResponseObject(data, machineNum, shiftNum, lotNum);
                }
            });
        } else {
            console.error('values cannot be null.');
        }
    }
    public getAuditQuesFailCodeForSavedAudits(response: Array<TempAudit>, procId: number, levelId: number, langCode: string, plantId: number, viewPlantQues: number, machineNum: string, shiftNum: string, lotNum: string): Observable<Array<TempAudit>> {
        if ((procId && procId !== 0) && (levelId && levelId !== 0) && (langCode && langCode !== "") && (plantId && plantId !== 0)) {
            const url = (AppSettings.API_ENDPOINT + MethodConstants.GetAuditQuesFailCode + "&processId=" + procId + "&langCode=" + langCode + "&level=" + levelId + "&plantId=" + plantId + "&viewPlantQues=" + viewPlantQues);
            return this.callService.callServerForGet(url).map((dataResp: ResponseObject) => {
                if (this.utilService.checkValidData(dataResp)) {
                    let data = dataResp.Response;
                    if (response[0]["data"][0]["catId"].toString() !== "0") {// checking if the submitted audit response is valid
                        return this.createResponseObjectForSavedAudit(data, machineNum, shiftNum, lotNum, response);
                    } else {
                        return this.createResponseObject(data, machineNum, shiftNum, lotNum);
                    }
                }
            });
        } else {
            console.error('values cannot be null.');
        }
    }

    public getSavedAuditQuesFailCode(langCode: string, auditId: number, machineNum: string, shiftNum: string, lotNum: string): Observable<Array<TempAudit>> {
        if ((langCode && langCode !== "") && (auditId && auditId !== 0)) {
            //const url = (AppSettings.API_ENDPOINT + MethodConstants.GetSavedAuditQuesFailCode+"langCode="+langCode+"&auditId="+auditId);
            const url = (AppSettings.API_ENDPOINT + MethodConstants.GetSubmittedAuditQuesFailCode + "auditId=" + auditId + "&langCd=" + langCode + "&machineNum=" + machineNum + "&shift=" + shiftNum);
            return this.callService.callServerForGet(url).map((dataResp: ResponseObject) => {
                if (this.utilService.checkValidData(dataResp)) {
                    let data = dataResp.Response;
                    return this.createResponseObjectSubmittedSavedAudit(data, machineNum, shiftNum, lotNum);
                }
            });
        } else {
            console.error('values cannot be null.');
        }
    }
    private createSubmittedAuditQueFailCodeResponse(data): Array<TempAudit> {
        let index: number = 0;
        // Adding the additional poperties to the object
        const usersList: Array<UsersInPlant> = this.userService.getUsersInPlant();
        return data.reduce((p, d) => {
            d.data = d.data.reduce((pr, da) => {
                da.questions = da.questions.reduce((prv, dat) => {
                    dat.index = index++;
                    dat.failCodes = dat.failCodes.reduce((prvs, item) => {
                        const assignee: UsersInPlant = _.filter(usersList, (usr) => usr.userId === item.assigneeId)[0];
                        const reviewer: UsersInPlant = _.filter(usersList, (usr) => usr.userId === item.reviewerId)[0];
                        let assigneeObj = new UserObject(0, "");
                        let reviewerObj = new UserObject(0, "");
                        if (assignee !== undefined) {
                            assigneeObj = new UserObject(assignee.userId, (assignee.firstName + "," + assignee.lastName));
                        }
                        if (reviewer !== undefined) {
                            reviewerObj = new UserObject(reviewer.userId, (reviewer.firstName + "," + reviewer.lastName));
                        }
                        item.assignee = assigneeObj;
                        item.reviewer = reviewerObj;
                        prvs.push(item);
                        return prvs;
                    }, []);
                    prv.push(dat);
                    return prv;
                }, []);
                pr.push(da);
                return pr;
            }, []);
            p.push(d);
            return p;
        }, []);
    }
    public GetSubmittedAuditQuesFailCode(auditId: number, langCd: string, machineNum: number, shift: string): Observable<Array<TempAudit>> {
        //http://ahdeviis01/LPADevServices/api/SubmittedAuditQuesFailCodes/GetSubmittedAuditQuesFailCode?auditId=29&langCd=ENG&machineNum=10&shift=1
        const url = (AppSettings.API_ENDPOINT + MethodConstants.GetSubmittedAuditQuesFailCode + "auditId=" + auditId + "&langCd=" + langCd + "&machineNum=" + machineNum + "&shift=" + shift);
        return this.callService.callServerForGet(url).map((dataResp: ResponseObject) => {
            if (this.utilService.checkValidData(dataResp)) {
                return this.createSubmittedAuditQueFailCodeResponse(dataResp.Response);
            }
        });
    }
    getDateFromDays(days: number) {
        if (days !== 0) {
            return moment().add(days, "days").format("YYYY/MM/DD");
        } else {
            return "";
        }
    }
    getFullDateFromDays(days: number) {
        if (days !== 0) {
            return moment().add(days, "days").format("ddd MMM Do YYYY");
        } else {
            return "";
        }
    }
    getTodaysDate() {
        const date = new Date();
        return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
    }
    private createSubmitFailureCodesRequest(data: Array<TempAudit>, auditStartTime: string, isSaveAudit: boolean): Observable<Array<AuditDetailAF>> {
        const auditEndDateTime = moment().format('YYYY/MM/DD HH:mm:ss');
        const auditStatus = isSaveAudit ? "0" : "0";
        const auditDate =  isSaveAudit ? data[0].dueDate : moment().format('YYYY-MM-DD');
        const auditTakenStartDate = moment().format('YYYY/MM/DD');
        this.user = this.userService.getUser();
        const _that = this;
        const auditorName = this.user.firstName + "," + this.user.lastName;
        const auditorWLogin = this.user.wLogin;

        return Observable.create((observer) => {
            observer.next(data.reduce((prev, item) => {
                let auditdet: Array<AuditDetailAF> = item.data.reduce((pr, it) => {
                    let queDet: Array<AuditDetailAF> = it.questions.reduce((prv, itm) => {
                        let auditFailures: Array<SubmitFailureCodes> = [];
                        if(itm.result.toString() === "2"){
                            auditFailures = itm.failCodes.reduce((prvs, itms) => {
                                /*const  assgnComments = _that.utilService.replaceSpecialCharsWithSpace(itms.assigneeComments);
                                const  reviewComments = _that.utilService.replaceSpecialCharsWithSpace(itms.reviewerComments);
                                const  failureComments = _that.utilService.replaceSpecialCharsWithSpace(itms.failureComments);*/
                                if (itms.failCode.toString() !== "0") {
                                    const auditFailureCodeId = itms.auditFailureId || 0;
                                    // if(!isSaveAudit){                                                    
                                    if (itms.failCodeSelected) {
                                        const assgnComments = itms.assigneeComments; const reviewComments = itms.reviewerComments;
                                        const failureComments = itms.failureComments;
                                        prvs.push(new SubmitFailureCodes(itms.failCode, auditFailureCodeId, itms.assignee.id,
                                            (itms.assignee.id !== 0 ? this.getDateFromDays(+itms.assigneeCompletionDays) : "0"),
                                            (assgnComments.length > 0 ? ("[" + auditEndDateTime + "]" + assgnComments) : assgnComments),
                                            itms.reviewer.id,
                                            (itms.reviewer.id !== 0 ? this.getDateFromDays(+itms.reviewerCompletionDays) : "0"),
                                            (reviewComments.length > 0 ? ("[" + auditEndDateTime + "]" + reviewComments) : reviewComments),
                                            this.getDateFromDays(+itms.failureCompletionDays),
                                            (failureComments.length > 0 ? ("[" + auditEndDateTime + "]" + failureComments) : failureComments),
                                            itms.severity, itms.imageType,
                                            itms.imageData, 1, (auditorWLogin), "", "", (itms.changeDateAFR || "")));
                                    }                           
                                }
                                return prvs;
                            }, []);
                        }                                  
                        const questnComments = _that.utilService.replaceSpecialCharsWithSpace(itm.queComment);
                        const auditDetailId = itm.auditDetailId || 0;
                        const langCode = this.userService.getUserSelection().selLangCode;
                        //this.submitAuditFailureCodesList.length = 0;// emptying the array
                        //this.submitAuditFailureCodesList = Object.assign([], auditFailures);// assigning the Failure Codes to the array
                        prv.push(new AuditDetailAF(itm.queId,item.auditId, item.machineNum ,auditDetailId, itm.result, questnComments,langCode, (auditorWLogin), auditFailures));
                        return prv;
                    }, []);
                    
                    pr = pr.concat(queDet);
                    return pr;
                }, []);
                prev=  prev.concat(auditdet);
                return prev;
            }, []));
            observer.complete();
        });
    }

    private createSubmitAuditRequest(data: Array<TempAudit>, auditStartTime: string, isSaveAudit: boolean): Array<SubmitAudit> {
        const auditEndDateTime = moment().format('YYYY/MM/DD HH:mm:ss');
        const auditStatus = isSaveAudit ? "0" : "0";
        const auditDate = isSaveAudit ? data[0].dueDate : moment().format('YYYY-MM-DD');
        const auditTakenStartDate = moment().format('YYYY/MM/DD');
        this.user = this.userService.getUser();
        const _that = this;
        const auditorName = this.user.firstName + "," + this.user.lastName;
        const auditorWLogin = this.user.wLogin;
        return data.reduce((prev, item) => {
            let auditdet: Array<SubmitQuestion> = item.data.reduce((pr, it) => {
                let queDet: Array<SubmitQuestion> = it.questions.reduce((prv, itm) => {
                    // commented the below code as we're sending the failure codes from using other service.
                    let auditFailures: Array<SubmitFailureCodes> = [];
                //if(itm.result.toString() === "2"){
                    auditFailures = itm.failCodes.reduce((prvs, itms) => {
                        /*const  assgnComments = _that.utilService.replaceSpecialCharsWithSpace(itms.assigneeComments);
                         const  reviewComments = _that.utilService.replaceSpecialCharsWithSpace(itms.reviewerComments);
                         const  failureComments = _that.utilService.replaceSpecialCharsWithSpace(itms.failureComments);*/
                        if (itms.failCode.toString() !== "0") {
                            const auditFailureCodeId = itms.auditFailureId || 0;
                            // if(!isSaveAudit){                                                    
                            if (itms.failCodeSelected) {
                                const assgnComments = itms.assigneeComments; const reviewComments = itms.reviewerComments;
                                const failureComments = itms.failureComments;
                                prvs.push(new SubmitFailureCodes(itms.failCode, auditFailureCodeId, itms.assignee.id,
                                    (itms.assignee.id !== 0 ? this.getDateFromDays(+itms.assigneeCompletionDays) : "0"),
                                    (assgnComments.length > 0 ? ("[" + auditEndDateTime + "]" + assgnComments) : assgnComments),
                                    itms.reviewer.id,
                                    (itms.reviewer.id !== 0 ? this.getDateFromDays(+itms.reviewerCompletionDays) : "0"),
                                    (reviewComments.length > 0 ? ("[" + auditEndDateTime + "]" + reviewComments) : reviewComments),
                                    this.getDateFromDays(+itms.failureCompletionDays),
                                    (failureComments.length > 0 ? ("[" + auditEndDateTime + "]" + failureComments) : failureComments),
                                    itms.severity, itms.imageType,/*removing the images as we want to get the Failure code delete from Table is the answer selection changed to pass or na*/
                                    "", 1, (auditorWLogin), "", "", (itms.changeDateAFR || "")));
                            }                            
                        }
                        return prvs;
                    }, []);
                //}                                  
                    const questnComments = _that.utilService.replaceSpecialCharsWithSpace(itm.queComment);
                    const auditDetailId = itm.auditDetailId || 0;
                    prv.push(new SubmitQuestion(itm.queId, auditDetailId, itm.result, questnComments, (auditorWLogin), []));
                    return prv;
                }, []);
                pr = pr.concat(queDet);
                return pr;
            }, []);

            const shiftObj = this.utilService.getPlantsShiftsList().filter(shift => shift.name.toString() === item.shift.toString());
            const shiftId = shiftObj[0] || { "id": "0" };
            const machineObj = this.utilService.getPlantsMachinesList().filter(machine => machine.machineNum.toString() === item.machineNum.toString());
            const machineId = machineObj[0] || { "machineId": 0 };
            const langCode = this.userService.getUserSelection().selLangCode;
            prev.push(new SubmitAudit(item.auditId, item.procId, item.plantId, item.level,
                auditDate, +item.auditorId,
                item.lotNum, shiftId.id, item.machineNum, machineId.machineId,
                auditStatus, false, item.wLogin,
                item.plantProcessAuditListId, auditStartTime,
                auditEndDateTime, auditStartTime, auditEndDateTime, item.comments,langCode, auditdet));
            return prev;
        }, []);
    }

    private createSubmitAdhocAuditRequest(data: Array<TempAudit>, auditStartTime: string, isSaveAudit: boolean): Array<SubmitAdhocAudit> {
        const auditEndDateTime = moment().format('YYYY/MM/DD HH:mm:ss');
        const auditStatus = isSaveAudit ? "0" : "0";
        const auditDate = isSaveAudit ? data[0].dueDate : moment().format('YYYY-MM-DD');
        const auditTakenStartTime = moment().format('YYYY/MM/DD');
        const _that = this;
        this.user = this.userService.getUser();
        const auditorName = this.user.firstName + "," + this.user.lastName;
        const auditorWLogin = this.user.wLogin;
        return data.reduce((prev, item) => {
            let auditdet: Array<SubmitQuestion> = item.data.reduce((pr, it) => {
                let queDet: Array<SubmitQuestion> = it.questions.reduce((prv, itm) => {
                   /* let auditFailures: Array<SubmitFailureCodes> = [];
                    //if(itm.result.toString() === "2"){
                    auditFailures = itm.failCodes.reduce((prvs, itms) => {
                        /*const  assgnComments = _that.utilService.replaceSpecialCharsWithSpace(itms.assigneeComments);
                        const  reviewComments = _that.utilService.replaceSpecialCharsWithSpace(itms.reviewerComments);
                        const  failureComments = _that.utilService.replaceSpecialCharsWithSpace(itms.failureComments);*/
                    /*    const auditFailureId = itms.auditFailureId || 0;
                        if (!isSaveAudit) {
                            if (itms.failCodeSelected) {
                                const assgnComments = itms.assigneeComments; const reviewComments = itms.reviewerComments;
                                const failureComments = itms.failureComments;
                                prvs.push(new SubmitFailureCodes(itms.failCode, auditFailureId, itms.assignee.id,
                                    (itms.assignee.id !== 0 ? this.getDateFromDays(+itms.assigneeCompletionDays) : "0"),
                                    (assgnComments.length > 0 ? ("[" + auditEndDateTime + "]" + assgnComments) : assgnComments),
                                    itms.reviewer.id,
                                    (itms.reviewer.id !== 0 ? this.getDateFromDays(+itms.reviewerCompletionDays) : "0"),
                                    (reviewComments.length > 0 ? ("[" + auditEndDateTime + "]" + reviewComments) : reviewComments),
                                    this.getDateFromDays(+itms.failureCompletionDays),
                                    (failureComments.length > 0 ? ("[" + auditEndDateTime + "]" + failureComments) : failureComments),
                                    itms.severity, itms.imageType,
                                    itms.imageData, 1, (auditorWLogin), "", "", itms.changeDateAFR));
                            }
                        } else {
                            const assgnComments = itms.assigneeComments; const reviewComments = itms.reviewerComments;
                            const failureComments = itms.failureComments;

                            prvs.push(new SubmitFailureCodes(itms.failCode, auditFailureId, itms.assignee.id,
                                (itms.assignee.id !== 0 ? this.getDateFromDays(+itms.assigneeCompletionDays) : "0"),
                                (assgnComments.length > 0 ? ("[" + auditEndDateTime + "]" + assgnComments) : assgnComments),
                                itms.reviewer.id,
                                (itms.reviewer.id !== 0 ? this.getDateFromDays(+itms.reviewerCompletionDays) : "0"),
                                (reviewComments.length > 0 ? ("[" + auditEndDateTime + "]" + reviewComments) : reviewComments),
                                this.getDateFromDays(+itms.failureCompletionDate),
                                (failureComments.length > 0 ? ("[" + auditEndDateTime + "]" + failureComments) : failureComments),
                                itms.severity, itms.imageType,
                                itms.imageData, 1, (auditorWLogin), "", "", itms.changeDateAFR));
                        }

                        return prvs;
                    }, []);*/
                    //}
                    const questnComments = _that.utilService.replaceSpecialCharsWithSpace(itm.queComment);
                    const auditDetailId = itm.auditDetailId || 0;
                    prv.push(new SubmitQuestion(itm.queId, auditDetailId, itm.result, questnComments, (auditorWLogin), []));
                    return prv;
                }, []);
                pr = pr.concat(queDet);
                return pr;
            }, []);
            const shiftObj = this.utilService.getPlantsShiftsList().filter(shift => shift.name.toString() === item.shift.toString());
            const shiftId = shiftObj[0] || { "id": "0" };
            const machineObj = this.utilService.getPlantsMachinesList().filter(machine => machine.machineNum.toString() === item.machineNum.toString());
            const machineId = machineObj[0] || { "machineId": 0 };
            const langCode = this.userService.getUserSelection().selLangCode;

            prev.push(new SubmitAdhocAudit(item.procId, item.auditId, item.plantId, item.level,
                auditDate, +item.auditorId,
                item.lotNum, shiftId.id,
                item.machineNum, machineId.machineId, auditStatus, true, item.wLogin,
                item.plantProcessAuditListId, auditStartTime,
                auditEndDateTime, auditTakenStartTime, auditTakenStartTime, item.comments, langCode, auditdet));
            return prev;
        }, []);
    }

    // Todo Call the below function when online
    public submitCachedCompletedAudits() {
        const url = (AppSettings.API_ENDPOINT + MethodConstants.SubmitAudit);
        this.user = this.userService.getUser();
        this.wLogin = this.user.wLogin;
        let savedData = storage.loadSavedData(this.wLogin, "submitCompletedAudit");
        if (savedData !== undefined) {
            const objectKeys = Object.keys(savedData);
            if (objectKeys.length > 0) {
                Object.keys(savedData).map((id) => {
                    this.callService.callServerForPost(url, "", savedData[id]).subscribe((data) => {
                        if (this.utilService.checkValidData(data)) {
                            //Delete the submitted Audit to server from the locally not submitted to server Audits
                            delete savedData[id];//
                            storage.saveData(this.wLogin, "submitCompletedAudit", savedData, true);
                            let auditId;
                            // Saving the Submitted Not Completed Audit
                            let savedNotCmptdData = storage.loadSavedData(this.wLogin, "submitNotCompletedAudit");
                            if (savedNotCmptdData !== undefined && savedNotCmptdData[id] !== undefined) {
                                auditId = savedNotCmptdData[id]["auditId"];
                                delete savedNotCmptdData[id];
                                storage.saveData(this.wLogin, "submitNotCompletedAudit", savedNotCmptdData, true);
                            }
                            //Deleting the Audit Id.
                            if (auditId !== undefined) {
                                let subNotCmptdAuditIds = storage.loadSavedData(this.wLogin, "submitNotCompldAuditIds");
                                if (subNotCmptdAuditIds !== undefined) {
                                    let savedAuditIds = subNotCmptdAuditIds["auditsIds"];

                                    if (savedAuditIds !== undefined) {
                                        let itemIndex = savedAuditIds.indexOf(auditId);
                                        if (itemIndex !== -1) {
                                            let auditsArray = savedAuditIds;
                                            auditsArray.splice(itemIndex, 1);
                                            storage.saveData(this.wLogin, "submitNotCompldAuditIds", auditsArray, true);
                                        }
                                    }
                                }
                            }
                            //   this.translate.get(["1004"]).subscribe((data) => {    
                            //         this.utilService.showToast(data["1004"],"");                           
                            //   });                         
                        }
                    });
                });
            }
        }
    }
 // calling the server to submit the fialure codes
    public callSubmitAuditFailuresService(auditDetails:AuditDetailAF){
        const url = AppSettings.API_ENDPOINT + MethodConstants.SubmitAuditFalureCode;        
        return this.callService.callServerForPost(url,"",auditDetails);
    }
    public callServiceToRetrieveAdhocAuditID(data: Array<TempAudit>, auditStartTime: string, isSaveAudit:boolean){
        let url = (AppSettings.API_ENDPOINT + MethodConstants.CreateAdhocAuditIDForSubmit);
        if (isSaveAudit) {// for saving the Audit use a different URL
            url = (AppSettings.API_ENDPOINT + MethodConstants.CreateAdhocAuditIDForSave);
        } 
        let item = data[0];
        const auditEndDateTime = moment().format('YYYY/MM/DD HH:mm:ss');
        const auditStatus = isSaveAudit ? "0" : "0";
        const auditDate =  isSaveAudit ? data[0].dueDate : moment().format('YYYY-MM-DD');
        const auditTakenStartDate = moment().format('YYYY/MM/DD');
        this.user = this.userService.getUser();
        const _that = this;
        const auditorName = this.user.firstName + "," + this.user.lastName;
        const auditorWLogin = this.user.wLogin;
        const shiftObj = this.utilService.getPlantsShiftsList().filter(shift => shift.name.toString() === item.shift.toString());
        const shiftId = shiftObj[0] || { "id": "0" };
        const machineObj = this.utilService.getPlantsMachinesList().filter(machine => machine.machineNum.toString() === item.machineNum.toString());
        const machineId = machineObj[0] || { "machineId": 0 };
        const langCode = this.userService.getUserSelection().selLangCode;
        return this.callService.callServerForPost(url,"",[new AuditHeaderForAuditID(item.auditId, item.procId, item.plantId, item.level,
            auditDate, +item.auditorId,
            item.lotNum, shiftId.id, item.machineNum, machineId.machineId,
            auditStatus, true, item.wLogin,
            item.plantProcessAuditListId, auditStartTime,
            auditEndDateTime, auditStartTime, auditEndDateTime, item.comments,langCode)]);
    }

    // creating the observables to  submit the failure codes
    public getSubmitAuditDetailsList(auditDetailsList:Array<AuditDetailAF>){
        return auditDetailsList.reduce(((prevItem, item, index)=>{
                prevItem.push(this.callSubmitAuditFailuresService(item));
                return prevItem;
        }),[])
    }
    // creating the observable list for submitting the failure codes list.
    public SubmitAuditFailures(auditDetailsList:Array<AuditDetailAF>){  
        let obsList = Object.assign([],this.getSubmitAuditDetailsList(auditDetailsList));
        return Observable.forkJoin(obsList);        
    }

    public SubmitAudit(data: Array<TempAudit>, selData: UserSelectionData, auditStartTime: string, isWorkOffline: boolean, auditCachedKey: string, isSchAudit: boolean, isAdhocAudit: boolean, isSaveAudit: boolean): Observable<ResponseObject> {
        this.user = this.userService.getUser();
        this.wLogin = this.user.wLogin;
        if (!isWorkOffline) { // this value os retrived from the toggle button on scheduled and un-scheduled Audits page.
            if (data[0].plantProcessAuditListId !== "0" && !isAdhocAudit) {
                //Submitting the failure codes before submitting the actual Audit
                this.createSubmitFailureCodesRequest(data, auditStartTime, isSaveAudit).subscribe((response)=>{
                    this.submitAuditFailureCodesList = Object.assign([],response);
                });
                this.SubmitAuditFailures(this.submitAuditFailureCodesList).subscribe((response)=>{
                
                });
                let url = (AppSettings.API_ENDPOINT + MethodConstants.SubmitAudit);
                if (isSaveAudit) {// for saving the Audit use a different URL
                    url = (AppSettings.API_ENDPOINT + MethodConstants.SaveAudit);
                }
                return this.callService.callServerForPost(url, "", this.createSubmitAuditRequest(data, auditStartTime, isSaveAudit));
            } else {
                 // TODO
                    // 1. INsert the Adhoc Audit
                    // 2. retrieve the Audit ID
                    // 3. Use that Audit ID to Insert the other Failure codes and the entire Audit.
                    // this.callServiceToRetrieveAdhocAuditID(data, auditStartTime, isSaveAudit).subscribe((resp:ResponseObject)=>{
                    //     if(this.utilService.checkValidData(resp)){
                    //         data[0]["auditId"] = resp.Response[0];
                    //     }
                    // });
                    if(data[0].auditId !== 0 && data[0].auditId.toString() !== "" ){
                        //Submitting the failure codes before submitting the actual Audit
                        this.createSubmitFailureCodesRequest(data, auditStartTime, isSaveAudit).subscribe((response)=>{
                            this.submitAuditFailureCodesList = Object.assign([],response);
                        });
                        this.SubmitAuditFailures(this.submitAuditFailureCodesList).subscribe((response)=>{
                        
                        });
                    
                        let url = (AppSettings.API_ENDPOINT + MethodConstants.SubmitAdhocAudit);
                        if (isSaveAudit) {// for saving the Adhoc Audit use a different URL
                            url = (AppSettings.API_ENDPOINT + MethodConstants.SaveAdhocAudit);
                        }
                        return this.callService.callServerForPost(url, "", this.createSubmitAdhocAuditRequest(data, auditStartTime, isSaveAudit));
                }
            }
        } else {
            if (auditCachedKey !== undefined && auditCachedKey !== "") {
                // Saving Not Completed/ not submitted to the server Audits
                // this will be used to load the Audit from the saved Audits list.
                let savedNotCompltAuditData = storage.loadSavedData(this.wLogin, "submitNotCompletedAudit");
                if (savedNotCompltAuditData !== undefined) {
                    storage.saveData(this.wLogin, "submitNotCompletedAudit", this.formStorageSaveData(auditCachedKey, data, savedNotCompltAuditData), false);
                } else {
                    storage.saveData(this.wLogin, "submitNotCompletedAudit", this.formStorageSaveData(auditCachedKey, data, {}), false);
                }

                let submitNotCompldAuditIds = storage.loadSavedData(this.wLogin, "submitNotCompldAuditIds");
                if (submitNotCompldAuditIds !== undefined) {
                    storage.saveData(this.wLogin, "submitNotCompldAuditIds", this.formStorageSaveDataAuditsList(data, submitNotCompldAuditIds), false);
                } else {
                    storage.saveData(this.wLogin, "submitNotCompldAuditIds", this.formStorageSaveDataAuditsList(data, {}), false);
                }

                // Saving Completed Audits 
                // this will be used to submit the Audit to the server.
                let savedCompletedAuditData = storage.loadSavedData(this.wLogin, "submitCompletedAudit");
                if (savedCompletedAuditData !== undefined) {
                    storage.saveData(this.wLogin, "submitCompletedAudit", this.formStorageSaveData(auditCachedKey, this.createSubmitAuditRequest(data, auditStartTime, false), savedCompletedAuditData), false);
                    this.rmCmpltdAdtFrmAdtsLst(data[0].auditId, data[0].machineNum, isSchAudit);
                    return Observable.create((observer) => {
                        observer.next(new ResponseObject(true, "", ["1012"], "1012"));
                        observer.complete();
                    });
                } else {
                    storage.saveData(this.wLogin, "submitCompletedAudit", this.formStorageSaveData(auditCachedKey, this.createSubmitAuditRequest(data, auditStartTime, false), {}), false);
                    this.rmCmpltdAdtFrmAdtsLst(data[0].auditId, data[0].machineNum, isSchAudit);
                    return Observable.create((observer) => {
                        observer.next(new ResponseObject(true, "", ["1012"], "1012"));
                        observer.complete();
                    });
                }
            }
        }
    }

    public GetSWIFilePDFPathFromServer(plantName: string, plantId: number, processId: number, machineNum: string) {
        const folderName = plantName;
        return this.getMachineSWI(plantId, processId, machineNum).map((response: ResponseObject) => {
            if (this.utilService.checkValidData(response)) {
                if (response.Response[0] !== "") {
                    const inputRequest = new RequestSWIPath(response.Response[0], folderName);
                    const API_PROD_ENDPOINT = "http://usdca-lpa01.corp.lear.com/LPAServices/api/";
                    //const url = (API_PROD_ENDPOINT + MethodConstants.GetSWIFilePDFPathFromServer);
                    const url = (AppSettings.API_ENDPOINT + MethodConstants.GetSWIFilePDFPathFromServer);
                    return this.callService.callServerForPost(url, "", inputRequest);
                } else {
                    return Observable.create((observer) => {
                        observer.next(new ResponseObject(true, "", ["1023"], "1023"));//1023 - SWI not available for the selected machine.
                    });
                }
            } else {
                return Observable.create((observer) => {
                    observer.next(new ResponseObject(true, "", ["1023"], "1023"));//1023 - SWI not available for the selected machine.
                });
            }
        });
        // ,((error)=>{
        //                     return Observable.create((observer)=>{                        
        //                            observer.next(new ResponseObject(true, "", ["1023"], "1023"));//1023 - SWI not available for the selected machine.
        //                        });
        // });

        //  const inputPlantSWIURL = "file://masle-fp01/groups/External%20share/WI/C1A/NM32410/C1A%205AMJ11F03/USM%20C1A%205AMJ11F03%20Ins%20composants.pdf";
        //  const folderName = "Monarca";
        // const inputRequest = new RequestSWIPath(inputPlantSWIURL, folderName);
        // const url = (AppSettings.API_PROD_ENDPOINT + MethodConstants.GetSWIFilePDFPathFromServer);
        // return this.callService.callServerForPost(url,"",inputRequest);
    }
    public getMachineSWI(plantId: number, processId: number, machineNum: string) {
        //http://ahdeviis01.eagleottawa.com/LPAtestServices/api/MachineSWI/getMachineSWI?plantId=2&procId=2&machineNum=3
        const url = (AppSettings.API_ENDPOINT + MethodConstants.GetMachineSWI);        
        return this.callService.callServerForPost(url, "", new MachineInfo(plantId, processId, machineNum));
    }
    //
    private rmCmpltdAdtFrmAdtsLst(auditId: number, machineNum: string, isSchAudit: boolean) {
        this.user = this.userService.getUser();
        this.wLogin = this.user.wLogin;
        // If unscheduled Audit then machine number is zero
        machineNum = isSchAudit ? machineNum : "0";
        const storagekey = isSchAudit ? "schAuditsList" : "unSchAuditsList";
        let response: Array<AcceptedAuditItem> = storage.loadSavedData(this.wLogin, storagekey);
        if (response !== undefined) {
            response = response.reduce((prev, item, index) => {
                if (item.auditListId.toString() !== auditId.toString() && item.machineNum !== machineNum) {
                    prev.push(item);
                }
                return prev;
            }, []);
            storage.saveData(this.wLogin, storagekey, response, true);
        }
    }
    //
    private formStorageSaveData(auditCachedKey, data, savedData) {
        if (auditCachedKey !== "") {
            savedData[auditCachedKey] = data;
            return savedData;
        } else {
            console.error("auditCachedKey cannot be empty");
        }
    }
    // saving the Audit id's from submitted not completed audits.
    private formStorageSaveDataAuditsList(data, savedData) {
        if (savedData["auditsIds"] !== undefined) {
            savedData["auditsIds"] = savedData["auditsIds"].push(data[0].auditId);
            return savedData;
        } else {
            savedData["auditsIds"] = [];
            savedData["auditsIds"].push(data[0].auditId);
            return savedData;
        }
    }
    // check if the Audits are not present in the saved Audits
    /*let savedAuditIds = [];
    const savedAuditsResp = storage.loadSavedData("submitNotCompletedAudit");
      if(savedAuditsResp!== undefined){
          const objKeys = Object.keys(savedAuditsResp);
          if(objKeys.length > 0){
              objKeys.map((item)=>{
                  const adtId = savedAuditsResp[item][0]["auditId"] 
                  if(adtId !== "" || adtId !== undefined ||adtId !== null){
                      savedAuditIds.push(adtId);
                  };
              });                                
          }                        
      }*/
    public getSubmitNotCompldAuditIds() {
        this.user = this.userService.getUser();
        this.wLogin = this.user.wLogin;
        let submitNotCompldAuditIds = storage.loadSavedData(this.wLogin, "submitNotCompldAuditIds");
        if (submitNotCompldAuditIds !== undefined && submitNotCompldAuditIds["auditsIds"] !== undefined) {
            return submitNotCompldAuditIds["auditsIds"];
        } else {
            return [];
        }
    }
}
