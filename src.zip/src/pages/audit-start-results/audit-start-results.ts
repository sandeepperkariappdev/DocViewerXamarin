import { Component, ElementRef, ViewChildren, ViewChild, QueryList } from '@angular/core';
import { PopoverController, NavParams, NavController, ModalController, Navbar, AlertController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { ReportsInquiry } from '../../pages/reports-inquiry/reports-inquiry';
import { ActionSheetController } from 'ionic-angular';
import { ShowFailureCodes } from '../../popup-modals/show-failure-codes/show-failure-codes';
import { MoreInfoModal } from '../../popup-modals/more-info-modal/more-info-modal';
import { SearchMachineInPlant} from '../../popup-modals/search-machine-in-plant/search-machine-in-plant';
import { AuditStartResultsProvider } from './audit-start-results-service';
import { UtilService } from '../../providers/util-service';
import { UserService } from '../../providers/user-service';
import { UserSelectionData, UserSelectionPrivileges, TempAudit, TempAuditData, ResponseObject, TempQuestion, AcceptedAuditItem, TempFailureCodes, UserObject } from '../../models/QuestionItem';
import { Questions, SubmitAudit, SubmitQuestion, SubmitFailureCodes } from '../../models/QuestionItem';
import { AdminManageMachineProvider } from '../resources-management/admin-manage-machine/admin-manage-machine-service';
import { SelectionPage } from '../selection/selection';
import { Lot, Machine, Shift } from '../../models/Level';
import { User } from '../../models/User';
import * as _ from 'lodash';
import { MomentModule } from 'angular2-moment';
import * as moment from 'moment';
import { MomentTimezoneModule } from 'angular-moment-timezone';
import { TranslateService } from 'ng2-translate';
import { Observable } from 'rxjs/observable';
import * as storage from "../../providers/local-Storage";
import { HomePage } from '../home/home';
@Component({
    selector: 'audit-start-results-page',
    templateUrl: 'audit-start-results.html'
})


export class AuditStartResults {
    /*This will ge thte reference of the ngFor from the HTML (template) for reference */
    @ViewChildren('ionItemsQues') ionItemsQues: QueryList<ElementRef>;
    @ViewChildren('queAnswersForm') queAnswersForm;
    @ViewChild(Navbar) navBar: Navbar;
    //@ViewChild('queAnswersForm')  queAnswersForm;
    // myForm:FormGroup;
    private selectionData: UserSelectionData;
    private auditResponse: Array<TempAuditData>;
    private TempAuditResponse: Array<TempAudit>;
    //myForm: FormGroup;
    private shownGroupas = null;
    private showUnAnsweredQue: boolean;
    private isReadOnly: boolean;
    private isGuestAudit: boolean;
    private failureCode: string;
    private guestName: string;
    private guestEmail: string;
    private guestPhone: string;
    private guestCompany: string;
    private title: string;
    private questionsCount: number;
    private auditStartDateTime: string;
    private auditEndTime: string;
    private isScheduledAudit: boolean;
    private auditInfoDetails: AcceptedAuditItem;
    private user: User;
    public isMobile : Boolean;
    public showSubmitSaveButton : Boolean;
    private auditCachedKey: string;
    private layerName: string;
    private isOffline: boolean;
    private isSavedAudit: boolean;
    private showAllQues: boolean;
    private isAdhocAudit: boolean;
    private isAuditChanged: boolean;
    private isLPAAudit: boolean;
    private shiftList: Array<Shift>;
    private machinesList: Array<Machine> = [];
    constructor(public auditResultsService: AuditStartResultsProvider,
        private fb: FormBuilder, private userService: UserService,
        private utilService: UtilService, public navCtrl: NavController,
        private navParams: NavParams, public elRef: ElementRef,
        private popoverCtrl: PopoverController, private alertCtrl: AlertController,
        private translate: TranslateService,
        private adminManageMachine: AdminManageMachineProvider,
        private actionSheetCtrl: ActionSheetController, private modalCtrl: ModalController) {
        this.auditCachedKey = "";
        this.isOffline = false;
        this.title = "";
        this.isMobile = false;
        this.showSubmitSaveButton = true;
        this.showAllQues = false;
        this.isScheduledAudit = false;
        this.isSavedAudit = false;
        this.isAdhocAudit = false;
        this.isAuditChanged = false;
        this.auditInfoDetails = new AcceptedAuditItem(0, 0, "", "", "", "", "", "", 0, "", "", 0, 0, "", 0, "", 0, "", "", "", "", 0, "", "");
        this.translate = translate; // Used for I18n
        //"auditStartTime":"2017/06/10 14:10",
        //  "auditEndTime":"2017/06/10 21:30",
        
        this.user = this.userService.getUser();
        this.isLPAAudit = true;
        this.auditStartDateTime = moment().format('YYYY/MM/DD HH:mm:ss');
        this.guestName = "";
        this.guestEmail = "";
        this.guestPhone = "";
        this.guestCompany = "";
        this.isGuestAudit = false;
    }
    getAuditQuesFailCode() {
        const pgId = this.selectionData.selPGId.toString();
        const pltId = this.selectionData.selPltId.toString();
        const prId = this.selectionData.selPrId.toString()
        const levId = this.selectionData.selLevelId.toString()
        const langCode = this.selectionData.selLangCode.toString()
        let machineNum = this.selectionData.machine.name.toString()
        let lotNum = this.selectionData.lot.name.toString();
        this.isLPAAudit = ((parseInt(prId) !== NaN && parseInt(prId) > 1000) ? false : true);// Waste walk Audits doesnot need machine.        
        this.auditInfoDetails.machineNum = this.isLPAAudit ? this.auditInfoDetails.machineNum : "waste walk";
        const wLogin = this.user.wLogin;
        machineNum = (machineNum === "" || machineNum.toLowerCase() === "select") ? "0" : machineNum;
        lotNum = (lotNum === "" || lotNum.toLowerCase() === "select") ? "0" : lotNum;
        let shiftNum = this.selectionData.shift.name;
        shiftNum = (shiftNum === "" || shiftNum.toLowerCase() === "") ? "0" : shiftNum;
        if (pgId != "" && prId != "" && levId != "" && langCode != "" && machineNum != "" && shiftNum != "") {
            if (!this.isOffline) {
                if (this.auditInfoDetails !== undefined && this.auditInfoDetails.status.toString() === "2") {
                    this.loadGetSavedAuditQuesFailCode(+prId, +levId, +pltId, langCode, this.auditInfoDetails.auditListId, machineNum, shiftNum, lotNum);
                } else {
                    this.loadGetAuditQuesFailCode(+prId, +levId, langCode, +pltId, machineNum, shiftNum, lotNum);
                }
            } else {
                const key = pgId + prId + levId + langCode + machineNum + shiftNum;
                const cachedData: Array<any> = this.utilService.getkeyItemFromData(storage.loadSavedData(wLogin, (this.isScheduledAudit ? "schAuditsDetails" : "unSchAuditsDetails")), key)[0];
                if (cachedData !== undefined && cachedData[0] !== undefined && cachedData[0].data !== undefined) {
                    const originalAuditResponse = Object.assign([], cachedData[0].data);
                    this.auditResponse = originalAuditResponse;            
                    this.TempAuditResponse = Object.assign([], cachedData);
                    this.title = cachedData[0].procName;
                    this.questionsCount = this.getQuestionsCount();
                    this.auditCachedKey = key;

                } else {
                    this.utilService.showToast("noOfflineDataAvailable", "");
                    this.navCtrl.pop();
                }
            }
        } else {
            this.utilService.showToast("noOfflineDataAvailable", "");
            this.navCtrl.pop();
        }
    }
    private loadShiftsForPlant(): void {
        this.adminManageMachine.getShiftsForPlant(+this.selectionData.selPltId).subscribe((data: ResponseObject) => {
            if (this.utilService.checkValidData(data)) {
                this.shiftList = data.Response;
            } else {
                this.utilService.showToast("", "Shifts for plant are not received from server.");
            }
        });
    }
    private loadMachinesFromServerForpLant() {
        const pltId = this.selectionData.selPltId.toString();
        const prId = this.selectionData.selPrId.toString();
        //should load audits for only selected processes
        this.adminManageMachine.getListOfMachines(+pltId, "1",
            +prId, true, this.selectionData.selPGId).subscribe((data) => {
                this.machinesList = this.machinesList.concat(data);
            });
        this.adminManageMachine.getListOfMachines(+pltId, "1",
            +prId, true, 1).subscribe((data) => {
                this.machinesList = this.machinesList.concat(data);
            });
    }
    private loadGetAuditQuesFailCode(prId: number, levId: number, langCode: string, pltId: number, machineNum: string, shiftNum: string, lotNum: string) {
        this.utilService.showLoading();
        this.auditResultsService.getAuditQuesFailCode(prId, levId,
            langCode, pltId, 2, machineNum, shiftNum, lotNum).subscribe((data) => {
                this.utilService.hideLoading();
                if (data !== undefined && data.length > 0 && data[0].data) {
                    const originalAuditResponse = Object.assign([], data[0].data);
                    this.auditResponse = originalAuditResponse;
                    this.TempAuditResponse = Object.assign([], data);
                    this.TempAuditResponse[0].auditId = this.auditInfoDetails.auditListId;
                    this.title = data[0].procName;
                    this.questionsCount = this.getQuestionsCount();
                } else {
                    this.utilService.showToast("EmptyAuditQuestions", "");
                }
            });
    }
    private loadGetSavedAuditQuesFailCode(prId: number, levId: number, pltId: number, langCode: string, auditId: number, machineNum: string, shiftNum: string, lotNum: string) {
        this.utilService.showLoading();
        this.auditResultsService.getSavedAuditQuesFailCode(langCode, auditId, machineNum, shiftNum, lotNum).subscribe((response: Array<TempAudit>) => {
            if (response !== undefined && response.length > 0 && response[0].data) {
                this.auditResultsService.getAuditQuesFailCodeForSavedAudits(response, prId, levId, langCode, pltId, 2, machineNum, shiftNum, lotNum).subscribe((data) => {
                    this.utilService.hideLoading();
                    if (data !== undefined && data.length > 0 && data[0].data) {
                        const originalAuditResponse = Object.assign([], data[0].data);
                        this.auditResponse = originalAuditResponse;
                        this.TempAuditResponse = Object.assign([], data);
                        this.TempAuditResponse[0].auditId = this.auditInfoDetails.auditListId;
                        this.title = data[0].procName;
                        this.questionsCount = this.getQuestionsCount();
                    } else {
                        this.utilService.showToast("EmptyAuditQuestions", "");
                    }
                });
            } else {
                this.utilService.hideLoading();
                this.utilService.showToast("EmptyAuditQuestions", "");
            }
        });
    }

    ionViewWillEnter() {
        let msg = "You are about to leave the Audit, un-saved changes will be lost. Are you sure?";
        this.translate.get(['audit_leave_unsasved']).subscribe((values)=>{
            msg = values["audit_leave_unsasved"];
        })
        const navParams = this.navParams.data;
        if (navParams !== undefined) {
            this.isMobile = this.utilService.isMobileApp;
            if (navParams.auditDetailsData !== undefined) {
                this.isSavedAudit = true;
                let data = navParams.auditDetailsData;
                const originalAuditResponse = Object.assign([], data[0].data);
                this.auditResponse = originalAuditResponse;
                            
                this.TempAuditResponse = Object.assign([], data);
                this.title = data[0].procName;
                this.questionsCount = this.getQuestionsCount();
            }
            if (navParams.userSelectionData !== undefined) {
                this.selectionData = navParams.userSelectionData;
                this.showSubmitSaveButton = (this.selectionData.selPltId === 18) ? this.isMobile: true   
                this.isGuestAudit = (this.selectionData.selRoleId === 6 ? true : false);
            }
            if (navParams.isAdhocAudit !== undefined) {
                this.isAdhocAudit = navParams.isAdhocAudit === "true";
            }
            if (navParams.isReadOnly !== undefined) {
                this.isReadOnly = (navParams.isReadOnly === "true");
            }
            if (navParams.isScheduledAudit !== undefined) {
                this.isScheduledAudit = (navParams.isScheduledAudit === "true");
            }
            if (navParams.auditInfoDetails !== undefined) {
                this.auditInfoDetails = navParams.auditInfoDetails;  
                this.layerName = "";
                if(this.auditInfoDetails.levelId < 10){
                    let layerObj = this.utilService.getAllLevels().filter(item => item.id.toString() === this.auditInfoDetails.levelId.toString())[0]
                    if(layerObj){
                        this.layerName = layerObj["desc"];
                    }                    
                } else{
                    this.layerName = "Waste Walk";
                }                     
            }
            if (this.auditInfoDetails.shift === 'select' || this.auditInfoDetails.shift === '' || this.auditInfoDetails.machineNum === 'select' || this.auditInfoDetails.machineNum === '') {
                this.utilService.showToast("select_shift_mach", "");
            }
            // this should be retrived from previous page.
            if (navParams.isOffline !== undefined) {
                this.isOffline = (navParams.isOffline === "true");
            } else {
                this.isOffline = !this.utilService.isNetworkConnected;
            }
        }
        this.loadShiftsForPlant();
        this.loadMachinesFromServerForpLant();
        if (!this.isSavedAudit && navParams.isFromPage !== "AuditsHistoryPage") {
            this.getAuditQuesFailCode();
        }
        if (navParams.isFromPage === "AuditsHistoryPage") {
            if (navParams.auditId !== undefined) {
                this.isSavedAudit = true;
                this.getSubmittedAuditsQuesFailCode(navParams.auditId);
            }
        }
        this.showUnAnsweredQue = false;
        this.navBar.backButtonClick = (e: UIEvent) => {
            if (this.isAuditChanged) {

                let confirm = this.alertCtrl.create({
                    title: 'Alert',
                    message: msg,
                    buttons: [
                        {
                            text: 'No',
                            handler: () => {

                            }
                        },
                        {
                            text: 'Yes',
                            handler: () => {
                                if (this.navCtrl.canGoBack()) {
                                    this.navCtrl.pop();
                                };
                            }
                        }
                    ]
                });
                confirm.present();
            } else {
                if (this.navCtrl.canGoBack()) {
                    this.navCtrl.pop();
                };
            }
        }
    }

    private getSubmittedAuditsQuesFailCode(auditId: number) {
        const selData = this.selectionData;
        this.utilService.showLoading();
        this.auditResultsService.GetSubmittedAuditQuesFailCode(auditId, selData.selLangCode, selData.machine.name, selData.shift.name).subscribe((response) => {
            this.utilService.hideLoading();
            if (response !== undefined && response[0] !== undefined && response[0].data !== undefined && response[0].auditName !== undefined) {
                const originalAuditResponse = Object.assign([], response[0].data);
                this.auditResponse = originalAuditResponse;
                this.TempAuditResponse = Object.assign([], response);
                this.title = response[0].procName ;
                this.questionsCount = 0;
            }
        });
    }

    searchMachines(item){    
        let modal = this.modalCtrl.create(SearchMachineInPlant,{      
          "machinesList":this.machinesList
        });
        modal.onDidDismiss((data:Machine)=>{
          if(this.utilService.itemDefined(data)){          
            item.machineNum = data.name;
          }              
        });
        modal.present();
      }
    toggleGroup(group) {
        if (this.isGroupShown(group)) {
            this.shownGroupas = null;
        } else {
            this.shownGroupas = group;
        }
    };
    isGroupShown(group) {
        // return this.shownGroupas === group;
        return true;
    };
    removeTheClass(index: number, classApplied: Array<string>, classList: any) {
        //return Observable.create((observer)=>{
        //  observer.next(()=>{
        // const itemClassList = this.ionItemsQues.toArray()[index].nativeElement.classList;        
        //this.ionItemsQues.toArray()[index].nativeElement.classList =     
        // let itemClassList = this.ionItemsQues.toArray()[index].nativeElement.classList;        
        classApplied.forEach((item) => {
            if (classList.contains(item)) {
                //accordion__item--failed //accordion__item--passed//accordion__item--deffered//accordion__item--na
                classList.remove(item);
            }
        });
        return classList;
        // return classList.reduce((prev,item)=>{
        //         if(classApplied.indexOf(item) === -1){
        //             prev.push(item);
        //         };
        //         return prev;
        //     },[]);


        //});
        //});                
    }
    onPassClicked(e, index, questionObj: TempQuestion) {
        this.isAuditChanged = true;
        questionObj.pass = true;
        questionObj.naEntered = false;
        questionObj.fail = false;
        questionObj.isDefferred = true;
        questionObj.result = 1; // ===1 when pass
    };
    //this.queAnswersForm.controls
    //this.ionItemsQues._results[index].nativeElement.classList.add('');
    //this.elRef.nativeElement.getElementsByClassName('accor-item-container')[0].classList  

    //const queIndex = questionObj.elementRefIndex === 0 ? questionObj.index : questionObj.elementRefIndex;
    //const indexItem = _.findIndex(this.auditResponse, ['catName', 'Defferred Questions']); // Checking if the defferred object is already created     
    //let classApplied = ['accordion__item--failed', 'accordion__item--passed','accordion__item--deffered','accordion__item--na'];
    //let classList;
    /*if(indexItem > 0){
         classList = this.ionItemsQues.toArray()[queIndex-1].nativeElement.classList;
         classList =  this.removeTheClass((queIndex-1), classApplied, classList); // remove the other classes(if other than pass is clicked) if already applied       
    } else{
         classList = this.ionItemsQues.toArray()[queIndex].nativeElement.classList;
         classList =  this.removeTheClass(queIndex, classApplied, classList); // remove the other classes(if other than pass is clicked) if already applied       
    }   */
    //    let modQueIndex =  queIndex;
    //     if(questionObj.elementRefIndex === 0){
    //         modQueIndex = indexItem > 0 ? queIndex-1 : queIndex;         
    //     }
    //let classList = this.ionItemsQues.toArray()[index].nativeElement.classList; 
    //classList =  this.removeTheClass(index, classApplied, classList); // remove the other classes(if other than pass is clicked) if already applied       
    //classList.add('accordion__item--passed');

    /*private getClassListForQuestion( queIndex:number){
        let classApplied = ['accordion__item--failed', 'accordion__item--passed','accordion__item--deffered','accordion__item--na'];
                    if(indexItem > 0){ 
                        classList = this.ionItemsQues.toArray()[queIndex-1].nativeElement.classList;
                        classList =  this.removeTheClass((queIndex-1), classApplied); // remove the other classes(if other than pass is clicked) if already applied       
                    } else{
                        classList = this.ionItemsQues.toArray()[queIndex].nativeElement.classList;
                        classList =  this.removeTheClass(queIndex, classApplied); // remove the other classes(if other than pass is clicked) if already applied       
                    }                                                          
                    questionObj.naEntered = false;
                    questionObj.pass = false;        
                    classList.add('accordion__item--failed');
    }*/

    onFailClicked(e, index, questionObj: TempQuestion, mainIndex) {
        e.target.checked = false;
        this.isAuditChanged = true;
        const _that = this;
        //const queIndex = questionObj.elementRefIndex === 0 ? questionObj.index : questionObj.elementRefIndex; 

        let modal = this.modalCtrl.create(ShowFailureCodes, { "questionObj": questionObj, "isLPAAudit": this.isLPAAudit.toString(), "isReadOnly": this.isReadOnly.toString() }, { enableBackdropDismiss: false });
        //const indexItem = _.findIndex(this.auditResponse, ['catName', 'Defferred Questions']); // Checking if the defferred object is already created 
        //let classApplied = ['accordion__item--failed', 'accordion__item--passed','accordion__item--deffered','accordion__item--na'];

        //    let modQueIndex =  queIndex;
        //     if(questionObj.elementRefIndex === 0){
        //         modQueIndex = indexItem > 0 ? queIndex-1 : queIndex;         
        //     }
        //   let classList = this.ionItemsQues.toArray()[index].nativeElement.classList;        
        // classList =  this.removeTheClass(index, classApplied, classList); // remove the other classes(if other than pass is clicked) if already applied                                                                                                      
        /*let classList;                  
                      if(indexItem > 0){ 
                          //classList = this.ionItemsQues.toArray()[queIndex-1].nativeElement.classList;
                          classList =  this.removeTheClass((queIndex-1), classApplied); // remove the other classes(if other than pass is clicked) if already applied       
                      } else{
                         // classList = this.ionItemsQues.toArray()[queIndex].nativeElement.classList;
                          classList =  this.removeTheClass(queIndex, classApplied); // remove the other classes(if other than pass is clicked) if already applied       
                      }   */
        //classList.add('accordion__item--failed');

        modal.onDidDismiss((fcSelected) => {
            if (fcSelected !== undefined) {
                if (fcSelected.failCodes !== undefined) {
                    questionObj.naEntered = false;
                    questionObj.pass = false;
                    questionObj.failCodes.forEach(item => {
                        if (item.failCode == fcSelected.failCodes[0]["failCode"]) {
                            item.failureComments = fcSelected.failCodes[0]["failureComments"];
                            item.imageData = fcSelected.failCodes[0]["imageData"];
                            item.imageFilePath = fcSelected.failCodes[0]["imageFilePath"];
                            item.imageType = fcSelected.failCodes[0]["imageType"];
                        }
                    });
                    questionObj.result = 2; // ===2 when fail
                    questionObj.isDefferred = true;
                    e.target.checked = true;
                    questionObj.fail = true;
                } else {
                    questionObj.fail = false;
                    questionObj.naEntered = false;
                    questionObj.pass = false;
                    e.target.checked = false;
                }
            } else {
                e.target.checked = questionObj.fail;
            }
        });
        modal.present();
    }
    onNAClicked(e, index, questionObj: TempQuestion) {
        this.isAuditChanged = true;
        questionObj.pass = false;
        questionObj.naEntered = true;
        questionObj.fail = false;
        questionObj.isDefferred = true;
        questionObj.result = 3; // === 3 when na
    }
    //const queIndex = questionObj.elementRefIndex === 0 ? questionObj.index : questionObj.elementRefIndex;
    //const indexItem = _.findIndex(this.auditResponse, ['catName', 'Defferred Questions']); // Checking if the defferred object is already created        
    //let classList;
    //let classApplied = ['accordion__item--failed', 'accordion__item--passed','accordion__item--deffered','accordion__item--na'];
    /*if(indexItem > 0){ 
        classList = this.ionItemsQues.toArray()[queIndex-1].nativeElement.classList;
        classList =  this.removeTheClass((queIndex-1), classApplied); // remove the other classes(if other than pass is clicked) if already applied       
    } else{
        classList = this.ionItemsQues.toArray()[queIndex].nativeElement.classList;
        classList =  this.removeTheClass(queIndex, classApplied); // remove the other classes(if other than pass is clicked) if already applied       
    }  */
    // let modQueIndex =  queIndex;

    // if(questionObj.elementRefIndex === 0){
    //     modQueIndex = indexItem > 0 ? queIndex-1 : queIndex;         
    // }

    //  let classList = this.ionItemsQues.toArray()[index].nativeElement.classList; 
    //  classList =  this.removeTheClass(index, classApplied, classList); // remove the other classes(if other than pass is clicked) if already applied                                                                                                            
    // classList.add('accordion__item--na');  



    onDeferClicked(e, mainIndex: number, index: number, questionObj: TempQuestion) {
        this.isAuditChanged = true;
        const quesArray: Array<TempQuestion> = this.auditResponse[mainIndex].questions.splice(index, 1); // removing the deferred object
        quesArray[0].elementRefIndex = this.questionsCount - 1;
        quesArray[0].isDefferred = true;
        const indexItem = _.findIndex(this.auditResponse, ['catName', 'Defferred Questions']); // Checking if the defferred object is already created        
        if (indexItem > 0) {
            this.auditResponse[indexItem].questions.push(quesArray[0]);
        } else {
            this.auditResponse.push(new TempAuditData(0, "Defferred Questions", quesArray));// addign the defferered object at the end of the list        
        }

        //this.reAssignIndexForQuestions();

        // let classList = this.ionItemsQues.toArray()[questionObj.index].nativeElement.classList;
        // let classApplied = ['accordion__item--failed', 'accordion__item--passed','accordion__item--deffered','accordion__item--na'];
        // classList =  this.removeTheClass(questionObj.index, classApplied); // remove the other classes(if other than pass is clicked) if already applied       
        // classList.add('accordion__item--deffered'); 
        return true;
    }

    showMoreInfoForAns(title, questionObj) {
        if (questionObj.queHelp) {
            const passCriteriaObj = {
                criteria: [questionObj.queHelp],
                imageData: "",
            };
            const failCriteriaObj = {
                criteria: [questionObj.queHelp],
                imageData: "",
            };

            const queCriteriaObj = {
                criteria: [questionObj.queHelp],
                imageData: "",
            };

            const naCriteriaObj = {
                criteria: [questionObj.queHelp],
                imageData: "",
            };


            const dic = { "pass": "passCriteriaObj", "fail": "failCriteriaObj", "que": "queCriteriaObj", "notApplicable": "naCriteriaObj" };

            let modal = this.modalCtrl.create(MoreInfoModal, {
                title: title,
                imageData: dic[title]["imageData"],
                criteriaData: dic[title]["criteria"]
            });
            modal.present({

            });
        } else {
            this.utilService.showToast("EmptyQuestionHelp", "");


        }

    }
    presentPopover(ev) {
        let popover = this.popoverCtrl.create(ReportsInquiry, {
            contentEle: '',
            textEle: ''
        });
        popover.present({
            ev: ev
        });

    }
    searchAudits() {
        let popover = this.popoverCtrl.create(ReportsInquiry, {
            contentEle: '',
            textEle: ''
        });
        popover.present();
    }
    presentActionSheetForQueInfo() {
        let actionSheet = this.actionSheetCtrl.create({
            title: 'Modify your album',
            buttons: [
                {
                    text: 'Info',
                    role: 'destructive',
                    handler: () => {
                        console.log('Destructive clicked');
                    }
                }, {
                    text: 'Cancel',
                    role: 'cancel',
                    handler: () => {
                        console.log('Cancel clicked');
                    }
                }]
        });
        actionSheet.present();

    }
    presentUserSelToSubmitAudit() {
        /*Task 299 Disable entering Lot number for taking Audits /Scheduling the Audits from the LPA application*/
        let popover = this.popoverCtrl.create(SelectionPage, {
            "isMandatory": "false",
            "isPopOverCtrl": "true",
            "isScheduledAudit": !this.isScheduledAudit,
            "userPrivileges": new UserSelectionPrivileges(false, false, false, false,
                false, false, false, false,
                false, false, false/*Task 299*/, true,
                true, true, false, false,
                false, false, false, false,
                false, false),
            "userSelectionData": this.selectionData
        }, {
                enableBackdropDismiss: false,
            });
        popover.present();
        popover.onDidDismiss((data: UserSelectionData) => {
            if (data) {
                this.selectionData = data;
                this.utilService.showLoading();
                this.auditResultsService.SubmitAudit([this.getTempAuditObjForUnSchAudit(this.selectionData)], this.selectionData,
                    this.auditStartDateTime, this.isOffline, this.auditCachedKey, this.isScheduledAudit, this.isAdhocAudit, false).subscribe((data) => {
                        this.utilService.hideLoading();
                        if (this.utilService.checkValidData(data)) {
                            this.utilService.showToast("successSubmitAudit", "");
                            this.navCtrl.pop();
                        }
                    });
            }
        });
    }
    getTempAuditObjectForScheduledAudit() {
        // this is only for the scheduled Audit
        const tempAudit = this.auditInfoDetails;
        return this.returnTempAudit(tempAudit);
    }
    private returnTempAudit(tempAudit: AcceptedAuditItem) {
        // only the auditId is used to submit the audit
        return new TempAudit(tempAudit.opId, tempAudit.opName, tempAudit.pgId,
            tempAudit.procId, tempAudit.procName, tempAudit.plantId,
            tempAudit.levelId, tempAudit.userId, this.user.roleId, this.auditResultsService.getTodaysDate(), tempAudit.startDate,// this is replaced by today's date int he service 
            tempAudit.endDate, this.user.userId.toString(), tempAudit.auditListId, tempAudit.lotNum,
            tempAudit.shift.toString(), tempAudit.machineNum, tempAudit.status, this.user.wLogin,
            this.selectionData.selLangCode, tempAudit.auditName, tempAudit.auditListId.toString(), Object.assign([], this.auditResponse), tempAudit.comments);
    }
    getTempAuditObjForUnSchAudit(data: UserSelectionData) {
        // this is only for the scheduled Audit
        /*Task 299 Disable entering Lot number for taking Audits /Scheduling the Audits from the LPA application*/
        const tempAudit = this.auditInfoDetails;
        // only the auditId is used to submit the audit
        return new TempAudit(tempAudit.opId, tempAudit.opName, tempAudit.pgId,
            tempAudit.procId, tempAudit.procName, tempAudit.plantId,
            tempAudit.levelId, tempAudit.userId, this.user.roleId, this.auditResultsService.getTodaysDate(), tempAudit.startDate,// this is replaced by today's date int he service 
            tempAudit.endDate, data.auditor.id.toString()/*Auditor Id*/, tempAudit.auditListId, "0000" /*Task 299*/,
            data.shift.name.toString(), data.machine.name, tempAudit.status, data.wLogin,
            data.selLangCode, tempAudit.auditName, tempAudit.auditListId.toString(), Object.assign([], this.auditResponse));
    }

    getQuestionsCount() {
        let count: number = 0;
        this.auditResponse.forEach((item) => {
            count += item.questions.length;
        });
        return count;
    }
    getAnsweredQuesCount() {
        let count: number = 0;
        this.auditResponse.forEach((item) => {
            const len = item.questions.filter((itm) => {
                if (itm.result !== 0) {
                    return true;
                } else {

                    return false;
                }
            }).length;
            count = count + len;
        });
        return count;
    }

    submittingAudit(isSavedAudit){
        this.utilService.showLoading();
        this.auditResultsService.SubmitAudit([this.getTempAuditObjectForScheduledAudit()], this.selectionData,
            this.auditStartDateTime, this.isOffline, this.auditCachedKey, this.isScheduledAudit, this.isAdhocAudit, isSavedAudit).subscribe((data: ResponseObject) => {
                this.utilService.hideLoading();
                if (this.utilService.checkValidData(data)) {
                    this.translate.get(["1004"]).subscribe((data) => {
                        this.utilService.showToast(data["1004"], "");
                        this.navCtrl.pop();
                    });
                }
            }, (error) => {
                this.utilService.hideLoading();
            });
    }

    saveAudit() {
        const machinename = this.isLPAAudit ? this.auditInfoDetails.machineNum : "waste walk";        
        if (this.auditInfoDetails.shift !== "select" && machinename !== "select" && this.auditInfoDetails.shift !== "" && machinename !== "") {
            if(this.isAdhocAudit){
                this.auditResultsService.callServiceToRetrieveAdhocAuditID([this.getTempAuditObjectForScheduledAudit()], this.auditStartDateTime, true).subscribe((resp:ResponseObject)=>{
                    if(this.utilService.checkValidData(resp)){
                        this.auditInfoDetails.auditListId = resp.Response[0];
                        this.submittingAudit(true);
                    }
                });
            } else{
                this.submittingAudit(true);
            }            
        /*this.utilService.showLoading();        
        this.auditResultsService.SubmitAudit([this.getTempAuditObjectForScheduledAudit()], this.selectionData,
            this.auditStartDateTime, false, this.auditCachedKey, this.isScheduledAudit, this.isAdhocAudit, true).subscribe((data: ResponseObject) => {
                this.utilService.hideLoading();
                if (this.utilService.checkValidData(data)) {
                    this.translate.get(["1024"]).subscribe((data) => {
                        this.utilService.showToast(data["1024"], "");
                        this.navCtrl.pop();
                    });
                }
            }, (error) => {
                this.utilService.hideLoading();
            });*/
        }
    }
    submitAudit() {
        const machinename = this.isLPAAudit ? this.auditInfoDetails.machineNum : "waste walk";
        if (this.auditInfoDetails.shift !== "select" && machinename !== "select" && this.auditInfoDetails.shift !== "" && machinename !== "") {
            if (this.isGuestAudit) {
                if (this.guestName !== "" && this.guestEmail !== "" && this.guestPhone !== "" && this.guestCompany !== "") {
                    // adding the Guest Auditors info to the comments of the Audit
                    this.auditInfoDetails.comments = "Audit Comments :- " + this.auditInfoDetails.comments +
                        "; Guest Auditor Name :- " + this.guestName +
                        "; Guest Auditor Email :- " + this.guestEmail +
                        "; Guest Auditor Phone :- " + this.guestPhone +
                        "; Guest Auditor Company :- " + this.guestCompany;
                } else {
                    this.utilService.showToast("", "Please enter your Name Email Phone Company for the Audit.")
                    return;
                }
            }
            if (this.getQuestionsCount() === this.getAnsweredQuesCount()) {

                if (!this.isScheduledAudit) {
                    this.presentUserSelToSubmitAudit();
                } else {
                    if(this.isAdhocAudit){
                        this.auditResultsService.callServiceToRetrieveAdhocAuditID([this.getTempAuditObjectForScheduledAudit()], this.auditStartDateTime, true).subscribe((resp:ResponseObject)=>{
                            if(this.utilService.checkValidData(resp)){
                                this.auditInfoDetails.auditListId = resp.Response[0];
                                this.submittingAudit(false);
                            }
                        });
                    } else{
                        this.submittingAudit(false);
                    }                    
                    /*this.utilService.showLoading();
                    this.auditResultsService.SubmitAudit([this.getTempAuditObjectForScheduledAudit()], this.selectionData,
                        this.auditStartDateTime, this.isOffline, this.auditCachedKey, this.isScheduledAudit, this.isAdhocAudit, false).subscribe((data: ResponseObject) => {
                            this.utilService.hideLoading();
                            if (this.utilService.checkValidData(data)) {
                                this.translate.get(["1004"]).subscribe((data) => {
                                    this.utilService.showToast(data["1004"], "");
                                    this.navCtrl.pop();
                                });
                            }
                        }, (error) => {
                            this.utilService.hideLoading();
                        }); */
                }
            } else {
                this.showUnAnsweredQue = true;
                this.utilService.showToast("completeAudit", "");
            }
        } else {
            this.utilService.showToast("", "Please select Shift and Machine/WorkStation for the Audit.")
        }
    }
    public openSWIForMachine() {

        // const machinename = this.selectionData.machine.name.toString();
        // const plantName = this.selectionData.selPltName.toString();
        // const plantId = this.selectionData.selPltId;
        // const processId = this.selectionData.selPrId;
        // this.auditResultsService.GetSWIFilePDFPathFromServer(plantName, plantId,processId,machinename).subscribe((response:ResponseObject)=>{
        //     if(this.utilService.checkValidData(response)){                
        //         this.utilService.hideLoading();
        //         //window.open(response.Response[0]);
        //         window.open(response.Response[0],"self");
        //     }
        // });
        const machinename = this.auditInfoDetails.machineNum;
        const plantName = this.selectionData.selPltName.toString();
        const plantId = this.selectionData.selPltId;
        const processId = this.selectionData.selPrId;
        if (machinename !== "select" && machinename !== "") {
            this.utilService.showLoading();
            this.auditResultsService.GetSWIFilePDFPathFromServer(plantName, plantId, processId, machinename).subscribe((response: Observable<ResponseObject>) => {
                response.subscribe((data) => {
                    this.utilService.hideLoading();
                    if (this.utilService.checkValidData(data)) {
                        if (this.utilService.isMobileApp) {
                            this.callNativeToLoad(data.Response[0]);
                        } else {
                            window.open(data.Response[0], "_blank");
                        }
                    } else {
                        //this.utilService.showToast("","Access Denied cannot open the file.")
                        this.utilService.showToast("", "Access denied cannot open the file. Contact your Plant Admin.");
                    }
                }, (error) => {
                    this.utilService.hideLoading();
                });
            }, (error) => {
                this.utilService.hideLoading();
            });
        } else {
            this.utilService.showToast("", "Please select Machine/WorkStation to check SWI.")
        }
    }
    public callNativeToLoad(swiPath: string) {
        (<any>window).location.href = "http://CallNativeIos.com?" + swiPath;
    }
}

// run this without network
// check for network conection
// Submitting the Audit store it in a Local Storage.
// Should we store the entire List of Audits data to tthe local storage for the user to take it at the end ? 