import { Component } from '@angular/core';
import { IonicPage, NavController,PopoverController, NavParams, MenuController, Events } from 'ionic-angular';
import { HomePage } from '../home/home';
import { Admin } from '../admin/admin';
import {Reports} from '../reports/reports';
import { AuditsListPage } from '../audits/audits-list';
import { User} from '../../models/User';
import { UserDetailsResponse} from '../../models/UserDetailsResponse';
import { Privileges} from '../../providers/privileges';
import { SelectionPage } from '../selection/selection';
import { UserService} from '../../providers/user-service';
import { UtilService} from '../../providers/util-service';
import { InitialDataService } from '../../providers/initial-data-service';
import { TranslateService }  from 'ng2-translate';
import { AdminManageMachineProvider } from '../resources-management/admin-manage-machine/admin-manage-machine-service';
import * as storage from "../../providers/local-Storage";
import * as _ from 'lodash';
import { AdminManagementPage  } from "../admin-management/admin-management";
import { UserSelectionData,UserSelectionPrivileges, UserObject, ResponseObject, UserPlants, PlantInfo} from '../../models/QuestionItem';
import { Lot, Machine, Shift, ProductGroup } from '../../models/Level';
import {CalendarController} from "ion2-calendar";
/**
 * Generated class for the LoginPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-login-page',
  templateUrl: 'login-page.html',
})
export class LoginPage {
  pageTitle:string;
  userNameEntered:string;
  private userNameFetched:string;
  passwordEntered:string;
  private roleEntered:string;
  private privileges:Privileges;
  private usrSelData:UserSelectionData;
  appVersion:string;
    public saveUsernameClicked:boolean;
    private showLevel:boolean; 
    private showProcess:boolean; 
    private showOperation:boolean; 
    private showProductGroup:boolean;
    private showPlant:boolean;
    private showRole:boolean;
    private showPreference:boolean;
    private selectionData:UserSelectionData;
    public showLoginFields:boolean;
    public isNotAValidUser:boolean;
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              private translate: TranslateService,
              private privilege:Privileges,
              private userService: UserService, 
              private popoverCtrl : PopoverController, 
              private utilService: UtilService,
              private menuCtrl: MenuController,
               private calendarCtrl: CalendarController,
               private adminManageMachinesService:AdminManageMachineProvider,
              private initialDataService: InitialDataService,
              private events: Events) {
                this.saveUsernameClicked = false;
                this.privileges = privilege;
                this.menuCtrl.swipeEnable(false);
                               
                if(this.userService.getUser() && this.userService.getUser().isLoggedIn){
                       //this.nav.setRoot(page.component);
                } else{
                  this.userNameEntered = "";
                  //this.passwordEntered = 'dsgsdgfdsf';
                }                           
                this.pageTitle = "";
                this.appVersion = this.utilService.getAppVersion();
                this.showLoginFields = false;
                this.isNotAValidUser = false;
  }
  
  ionViewWillEnter(){ 

    const navParams =  this.navParams.data;
    
    this.userNameEntered = "";              
    let savedData = window.localStorage.getItem("savedusername");
    if(savedData !== undefined){         
            this.userNameEntered = savedData;                  
    }  

    // below code checks  if the loginUser name passed as a Query parameter
    //   const getQueryParams = this.getParameterByName("loginId");
    //     if(getQueryParams !== undefined && getQueryParams !== null){
    //         if(getQueryParams.indexOf("corplear") === -1){
    //             this.userNameFetched = "corplear\\"+getQueryParams; 
    //         } else{
    //             this.userNameFetched = getQueryParams;
    //         }           
    //     }          
    
    const loginUserId = window.sessionStorage.getItem("loginUserId");
        if(loginUserId !== undefined && loginUserId !== null){
                // if(loginUserId.indexOf("corplear") === -1){
                //     this.userNameFetched = "corplear\\"+loginUserId; 
                // } else{
                    this.userNameFetched = loginUserId;
                //}
        }
    this.translate.get(["loginpagetitle"]).subscribe((values)=>{          
            this.pageTitle = values["loginpagetitle"];               
        });
    if(this.userNameFetched !== undefined){
        this.userNameEntered = 'flast17';//this.userNameFetched;
        this.resetShowLoginFields();
        if(navParams.isLogOut !== undefined && navParams.isLogOut === "true"){
            if(this.utilService.isMobileApp){
                (<any>window).location.href = "exitlpaapp";      
            } else{
                window.close();
            }
            return;
        } else{
                this.logIn();
        }            
    }  else{
           // (<any>window).location.href = "http://lpa.lear.com";      
            this.showLoginFields = true;
    }           
  }
  resetShowLoginFields(){
        // if((this.userNameEntered.toLowerCase().indexOf("nsaltmarche") !== -1)  || (this.userNameEntered.toLowerCase().indexOf("ndavies") !== -1) || (this.userNameEntered.toLowerCase().indexOf("dzedan") !== -1) || (this.userNameEntered.toLowerCase().indexOf("gen_lpaadm") !== -1) || (this.userNameEntered.toLowerCase().indexOf("sperkari") !== -1) || (this.userNameEntered.toLowerCase().indexOf("ktikiwala") !== -1) 
        //     || (this.userNameEntered.toLowerCase().indexOf("ddai") !== -1) || (this.userNameEntered.toLowerCase().indexOf("abandara") !== -1) ||
        //     (this.userNameEntered.toLowerCase().indexOf("adminktikiwala") !== -1)){
                this.showLoginFields = true;
          //  }
  }
  ionViewDidLoad() {
     
  }

    getParameterByName(name, url?) {
        if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
  }

logIn(){ 
    this.userService.setUser(undefined);
    //  test username validation
    if(this.userNameEntered !==''){
        // if(!(new RegExp("corplear").test(this.userNameEntered.toLowerCase()))){            
        //     this.utilService.showToast("usernameshouldcontain","");
        //     return ;
        // }
    }

    if(this.userNameEntered !==''){ //&& this.roleEntered  && this.passwordEntered !==''      
      this.utilService.showLoading();
      this.utilService.usernameEntered = this.userNameEntered;   
      this.utilService.setServiceToken(this.userNameEntered);   
      this.initialDataService.getInitialData().subscribe(
        ((data:Array<ResponseObject>) =>{
              if(this.utilService.checkValidData(data[0])){               
                  this.utilService.setLevelDescById(data[0].Response);
              } 
              if(this.utilService.checkValidData(data[1])){                            
                  this.utilService.setRoleDescById(data[1].Response);
              } 
              //if(this.utilService.checkValidData(data[2])){            
                  this.utilService.setLayerDescById([]);
              //}
              if(this.utilService.checkValidData(data[3])){
                  this.utilService.setLanguageDescByCode(data[3].Response);
              } 
              if(this.utilService.checkValidData(data[4])){             
                  this.utilService.setProductGroupById(data[4].Response);
              }
              
              if(this.utilService.checkValidData(data[5])){             
                  this.utilService.setAllAvailablePlants(data[5].Response);
              }
              if(this.utilService.checkValidData(data[6])){             
                  this.utilService.setAllFailureCodeCategories(data[6].Response);
              }
          }),
          ((err)=>{
              this.utilService.hideLoading();
              if(err.status === 0){
                this.utilService.showToast("","Please check your network connection.");
              }
              if(err.status === 401){
                this.isNotAValidUser = true;
                //this.utilService.showToast("notValidUserToLogin","");
              }
              if(err.status === 404 || err.status === 500){
                this.utilService.showToast("serviceNotAvailableDown","");
              }              
              console.log("Error"+ err);            
        }),
          (()=>
            {
              this.userService.getUserFromService(this.userNameEntered).subscribe((userDetailsData:UserDetailsResponse) => { 
                  if(userDetailsData.userId !== undefined){
                        this.utilService.setUserDetailsResponse(userDetailsData);
                    if((userDetailsData.languageCode  !== undefined && userDetailsData.languageCode !== "") &&
                        (userDetailsData.userId !== undefined && userDetailsData.userId !== 0) && 
                        (userDetailsData.levelId !== undefined ) && (userDetailsData.roleId !== undefined)){
                            // incoreect data received  // cannot login the user.
                    }
                    this.utilService.hideLoading();                    
                    this.roleEntered = userDetailsData.roleName;   
                    if(this.saveUsernameClicked) this.saveUsernameToMemory(userDetailsData.wLogin);   // saving the username to memoy                        
                    const getPageObject = this.privileges.getPageObject(userDetailsData.roleName,"login");
                    const pagePriv = getPageObject["search"];
                    this.showLevel = pagePriv["showLevel"] === "true";
                    this.showOperation = pagePriv["showOperation"] === "true";
                    this.showProcess = pagePriv["showProcess"] === "true";
                    this.showProductGroup = pagePriv["showProductGroup"] === "true";
                    this.showRole = pagePriv["showRole"] === "true";
                    this.showPlant = pagePriv["showPlant"] === "true";
                    this.showPreference = getPageObject["showPreference"] === "true"; 
                    // Setting the categories by product group from service - 
                    
                    this.initialDataService.getAllCategories(userDetailsData.pgId).subscribe((response:ResponseObject)=>{
                        if(this.utilService.checkValidData(response)){             
                            this.utilService.setAllcategories(response.Response);
                        }
                    });
                  
                    if(this.showPreference){// if we want to sho th user preference by mandatory this will never happen
                      this.presentChangePreferencePopover(userDetailsData)// this is only for testing
                    } else{
                        this.showRole = false;
                        if(!this.userService.checkValidUserPreferencesResponse(userDetailsData, true)){// check if the returned user infor has more than 1 plant.
                            // TODO check if the saved user selection matches the user details response
                            // if matches then load the saved user selection 
                            // check if the getUserDetails has multiple product groups for each plant.                                                      
                            // load the available product groups
                            // allow the user to select the product group                            
                            // load the plants for the selected product groups 
                            let plantProductGroups:Array<ProductGroup> = _.uniqBy(_.flatMap(_.map(userDetailsData.plants,"productGroups")), "pgId");
                            let userPlants:Array<UserPlants> = userDetailsData.plants;                         
                         this.presentChangePreferencePopover(userDetailsData, plantProductGroups, userPlants );
                        } else{ 
                                //selOpId
                                //selOpName
                                //selPGId
                               if(this.userService.updateUserAndUserSelData(userDetailsData,new UserSelectionData(userDetailsData.plants[0].plantId, 
                               userDetailsData.plants[0].plantName,
                               userDetailsData.plants[0].productGroups[0].pgId,userDetailsData.plants[0].productGroups[0].pgName,0,"",0,"",userDetailsData.levelId, "",userDetailsData.roleId,"",userDetailsData.languageCode,
                               "","","",userDetailsData.wLogin,new Lot(0,""),new Machine("0", "","", false), new Shift("",""),new UserObject(0, ""),"","","","","","","",))){
                                this.loadNext();         
                                }                                                                        
                        }                      
                    }
                  } else{
                        this.utilService.showToast("","User information not received from server.");
                  }                                       
                },
                (error) => { console.log("Error", error); },
                () => {});
        }));
                 
    } else{
       this.utilService.showToast("","Credentials cannot be empty");
    }  
  }
   
  private setSelData(){
       const user = this.userService.getUser();
        this.selectionData.selLevelId = user.levelId;
        this.selectionData.selLevelName  =  user.levelName;        
        this.userService.setUserSelection(this.selectionData);                
  }
  // preloading the side menu according to the user role
  private loadNext():void{    
    let that = this;
        const selData = this.userService.getUserSelection();
    this.GetPlantShiftAndMachinesList(selData.selPGId, selData.selPltId);    
    this.events.publish("userSideMenu",this.privilege.getPageObject(this.roleEntered,"SideMenu"));     
    let x = [HomePage,Admin,AuditsListPage,LoginPage, AdminManagementPage, Reports];
    let page = x[that.privileges.getStartPage(that.roleEntered)];
    if(page){
        that.navCtrl.setRoot(page);       
    } else{
            console.error("Error occurrred loading a new page")
    }  
  }
  public saveUsernameToMemory(wLogin:string=""){
        if(this.userNameEntered !== "" && wLogin !== ""){
            window.localStorage.setItem("savedusername", this.userNameEntered);
        }        
  }

  private checkPlantPGExistsInSavedSel(plantProductGroups:Array<ProductGroup>, userPlants:Array<UserPlants>, userDetailsData:UserDetailsResponse):boolean{
        let plantIdList = _.map(userPlants,"plantId");
        let pgIdList = _.map(plantProductGroups, "pgId");
        let savedData = storage.loadSavedData(userDetailsData.wLogin,"multiplePlantProductGroupSel");
        if(savedData !== undefined){
                if(plantIdList.indexOf(+savedData.selPltId) !== -1 && pgIdList.indexOf(+savedData.selPGId) !== -1){
                    if(savedData.selPGName !== undefined && savedData.selPltName !== undefined){
                        return true;
                    } else{
                        return false;
                    }                    
                }
        }
        return false;
  }
   presentChangePreferencePopover(userDetailsData:UserDetailsResponse, plantProductGroups?:Array<ProductGroup>, userPlants?:Array<UserPlants>) {
       if(!this.checkPlantPGExistsInSavedSel(plantProductGroups, userPlants,userDetailsData)){
                // Just show the plant to select nad the product group to select
                let popover = this.popoverCtrl.create(SelectionPage, {"isMandatory":"false", 
                "isFromPage":"loginPage",
                "useSelectionDataSent":"false",
                "pageTitle":"Select Plant",
                "isPopOverCtrl":"true",
                "selectPlantPG":"true",
                "productGroupList":plantProductGroups,
                "userPlantsList":userPlants,
                "useLocalStorageData":"false",         
                "userPrivileges":new UserSelectionPrivileges(this.showPlant, this.showProductGroup,this.showProcess,false,this.showLevel,this.showRole, false, 
                false,false, false, false, false, false, false,false, 
                false, false, false, false, false, false, false),
                "userSelectionData":{}},
                {
                    enableBackdropDismiss:false,
                });
                popover.present();
                popover.onDidDismiss((userSelData:UserSelectionData)=>{
                    if(userSelData !== undefined){
                        //this updates the selPGId, selPGName, selPltId, selPltId,  selPltName             
                        if(this.userService.updateUserAndUserSelData(userDetailsData,userSelData)){
                            this.loadNext();         
                        }
                    } else{
                        this.utilService.hideLoading();             
                    }                
                }); 
       } else{
           let savedData = storage.loadSavedData(userDetailsData.wLogin,"multiplePlantProductGroupSel");        
           // take the productgroup and plants id from the saved 
          const userSelData:UserSelectionData = new UserSelectionData(savedData.selPltId,savedData.selPltName, savedData.selPGId, savedData.selPGName,0,"",0,"",userDetailsData.levelId, "",userDetailsData.roleId,"",userDetailsData.languageCode,
                               "","","",userDetailsData.wLogin,new Lot(0,""),new Machine("0", "","", false), new Shift("",""),new UserObject(0, ""),"","","","","","","",);
            if(this.userService.updateUserAndUserSelData(userDetailsData,userSelData)){               
                this.loadNext();         
            }
       }
    }
private GetPlantShiftAndMachinesList(pgId:number, pltId:number){
       this.adminManageMachinesService.getShiftsForPlant(pltId).subscribe((response)=>{
        if(this.utilService.checkValidData(response)){
            this.utilService.setPlantsShiftsList(response.Response);
        }
      });
      this.adminManageMachinesService.getListOfMachines(pltId, "1",0, false,pgId).subscribe((data)=>{
        if(this.utilService.checkValidData(data)){
                this.utilService.setPlantsMachinesList(data.Response);
        }                    
     });
    this.initialDataService.getPGByPlant(pltId).subscribe((response:ResponseObject)=>{
        if(this.utilService.checkValidData(response)){             
            this.utilService.setPgByPlant(response.Response);
        }
     });
  }

    openCalendar(){
          this.calendarCtrl.openCalendar({            
            isRadio: true,
            title: "Select Week Start",                        
        //    from:stDate,
        //    to:edDate,
           // daysConfig:_daysConfig,
           // disableWeekdays: showWeekStartOnly ? [1,2,3,4,5,6] : [],
           // monthTitle:values["monthTitle"],
           // weekdaysTitle:values["weekDaysArray"],
            //canBackwardsSelected:true,
            //showYearPicker:true,
           // closeIcon:true
            //from: this.selStDate.stDate !== "" && this.selStDate.stDate !== "select" ? new Date(this.selStDate.stDate) : new Date(),
           // to  : this.selEndDate.endDate !== "" && this.selEndDate.endDate !== "select" ? new Date(this.selEndDate.endDate) : new Date()
            //defaultDate:new Date(2017,4,1),   
        }).then((res:any)=>{

        }).catch(() => {
        });
    }
}
     