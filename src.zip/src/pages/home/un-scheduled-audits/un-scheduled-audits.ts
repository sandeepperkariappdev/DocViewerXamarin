import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, PopoverController,Platform } from 'ionic-angular';
import { SelectionPage } from '../../selection/selection';
import { AuditService } from '../../audits/audit-service';
import { UserObject, UserSelectionData, UserSelectionPrivileges,AuditDetailsQuestion, AcceptedAuditItem, ResponseObject } from '../../../models/QuestionItem';
import { UtilService } from '../../../providers/util-service';
import { User} from '../../../models/User';
import { Network } from '@ionic-native/network';
import { UserService } from '../../../providers/user-service';
import { CacheDataForOfflineProvider } from '../../../providers/cache-data-for-offline';
import { AuditDetails } from '../../admin/audit-details/audit-details';
import { Lot, Machine, Shift } from '../../../models/Level';
import { SubmitScheduledAudit } from '../../../models/QuestionItem';
import { AuditStartResults } from '../../audit-start-results/audit-start-results';
import  { TranslateService }  from 'ng2-translate';
import { AuditStartResultsProvider } from '../../audit-start-results/audit-start-results-service';
import * as storage from "../../../providers/local-Storage";
import { HomePage } from '../home';
/**
 * 
 * 
 * Generated class for the UnScheduledAudits page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 * 
 * 
 */

/*TODO
    1. For the Audits schedular funcitonality load only the machines that doesn't
    have audits already defined. and have a option to load all the possible machines.
    2. Build a Calendar to load the schedules of the Auditors.
    3. Have an option to load the calendar from the selection menu.
*/


@Component({
  selector: 'page-un-scheduled-audits',
  templateUrl: 'un-scheduled-audits.html',
})
export class UnScheduledAudits  {
  private selectionData:UserSelectionData;
  private auditList:Array<AcceptedAuditItem>;  
  private initialAuditList:Array<AcceptedAuditItem>;
  private isAuditsSchedular:boolean;
  private isShowDetails:boolean;
  private isPlantAdmin:boolean;
  private pageTitle:string;
  private user:User;
  public showStDate:string;
  public showEdDate:string;
  public isOffline:boolean;
  private subscription;
  constructor(private navCtrl: NavController, 
              private navParams: NavParams,
              private utilService: UtilService,
              private network: Network, 
               public platform: Platform, 
              private userService: UserService, 
              private auditService:AuditService, 
              private cacheData:CacheDataForOfflineProvider,
              public auditResultsService:AuditStartResultsProvider, 
              private translateService: TranslateService,
              private popoverCtrl: PopoverController) {
        this.isAuditsSchedular = false;
       this.selectionData =  this.userService.getUserSelection();
       this.isShowDetails = true;
       this.isOffline = false;
       this.pageTitle = "NotAssigned Audits";
       this.user = this.userService.getUser();
       this.showStDate = "";
       this.showEdDate = "";
      this.isPlantAdmin = this.user["roleId"] === 3;     
  }

  
  public showAuditDetails(){
      this.isShowDetails = ! this.isShowDetails;
  }

 
  public onOfflineToggleChange():void{
        if(this.isOffline){                                              
            const stDate = this.selectionData.startDate; const edDate =  this.selectionData.endDate; 
            this.showStDate = this.utilService.getSearchDateToShow(stDate);
            this.showEdDate = this.utilService.getSearchDateToShow(edDate);
            const pltId = this.selectionData.selPltId; const levId =  this.selectionData.selLevelId;
            const prId = this.selectionData.selPrId;
            const langCode = this.selectionData.selLangCode;
            const auditsList:Array<AcceptedAuditItem> = this.auditList;
            if(stDate  !== "" && edDate !== "" && pltId !== 0 &&  prId !== undefined && levId !== undefined && !isNaN(prId)){
                    this.cacheData.saveUnSchAuditslistDetails(false,stDate, edDate, pltId,  levId,  prId, langCode, auditsList);
            }
        }
  }
   
   private auditSelectedForDetails(auditItem:AcceptedAuditItem):void{                   
        let selData:UserSelectionData =Object.assign({},this.selectionData); 
        selData.selPrId = auditItem.procId; 
        selData.selPrName = auditItem.procName;
        selData.selLevelId = auditItem.levelId;
        selData.machine.name = auditItem.machineNum;
        selData.shift.name = auditItem.shift.toString();                                            
        this.navCtrl.push(AuditStartResults, {"isReadOnly": this.isAuditsSchedular ? "true":"false",
                                                "isFromPage":"AuditsListUserPage", 
                                                "userSelectionData":selData,
                                                "isScheduledAudit":"false", 
                                                "isOffline":this.isOffline.toString(),
                                                "auditInfoDetails":auditItem});             
    }

  private checkDefined(item:any){
    return this.utilService.itemDefined(item);
  } 

  private loadDate(){
        const navParams = this.navParams.data;
        if(this.checkDefined(navParams) && this.checkDefined(navParams.isPageKind) && navParams.isPageKind === "schedular"){
            this.isAuditsSchedular = true;
            this.isShowDetails = false;
            this.pageTitle = "UnAssigned Audits";
        }
        this.selectionData.selLevelId = 0 ; //load only for user levels
        this.selectionData.selLevelName = "All Levels";//load only for user levels
        this.selectionData.selPrId = 0 ;
        this.selectionData.selPrName = "All Process";
        if(!this.utilService.itemDefined(this.selectionData.endDate) || !this.utilService.itemDefined(this.selectionData.startDate)){
            this.selectionData.endDate = this.utilService.getWeekEndDate();
            this.selectionData.startDate = this.utilService.getWeekStartDate();        
        }
        this.getAcceptedActiveAuditListForPlant();      
  }
    ionViewWillLeave(){
        if(this.subscription !== undefined){
            this.subscription.unsubscribe();
        }        
    }
  ionViewDidEnter(){
        if(this.platform.is("cordova")){
            this.subscription=  this.network.onchange().subscribe((data) => {
                if(data.type === "offline"){               
                    this.isOffline = true;
                    this.utilService.showToast("","Network Offline - Un Schduled Audits");
                }
                if(data.type === "online"){               
                    this.isOffline = false;
                    this.utilService.showToast("","Network Online -Un Schduled Audits");
                    this.loadDate();
                } 
            });
        }
          if(this.utilService.isNetworkConnected){
                this.isOffline = false;
                this.loadDate();
          } else{
                this.isOffline = true;
          }
  }
private getSearchItems(ev:any):void{
        let val = ev.target.value;
        if(val && val.trim() !== '' && val.length >= 3){ 
             if(this.initialAuditList !== undefined){
                 this.auditList = this.initialAuditList;  
             }
            if(this.auditList !== undefined){
                this.auditList = this.auditList.reduce((prev,item:AcceptedAuditItem,index)=>{
                        if((item.auditListId.toString().indexOf(val.toLowerCase()) > -1) ||
                        (item.comments.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                        (item.firstName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                        (item.lastName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                        (item.plantName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                        (item.pgName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                        (item.opName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                        (item.procName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                        (item.startDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                        (item.endDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1 )){
                            prev.push(item);
                        }                
                        return prev;
                    },[]);
            }                                 
        }
   }

   private searchCancelClicked():void{
      this.auditList = this.initialAuditList;
   }
  private getAcceptedActiveAuditListForPlant():void{
      /*
        @processId as int = 0,   -- 0 for all processes
        @level as int = 0		 -- 0 for all levels

        http://ahdeviis01/LPADevServices/api/UsersAccepted/getAcceptedActiveAuditListForPlant?plantId=4&processId=0&level=0&startDate=2017-06-10&endDate=2017-08-10
      */
      if(!this.isOffline){      
            const stDate = this.selectionData.startDate; const edDate =  this.selectionData.endDate; 
            this.showStDate = this.utilService.getSearchDateToShow(stDate);
            this.showEdDate = this.utilService.getSearchDateToShow(edDate);
            const pltId = this.selectionData.selPltId; 
            const levId = this.isPlantAdmin ? 0 : this.selectionData.selLevelId; // for plant admin load all the available audits
            const prId = this.selectionData.selPrId;
            const pgId = this.selectionData.selPGId;
            const langCode = this.selectionData.selLangCode;
            if(stDate  !== "" && edDate !== "" && pltId !== 0 &&  prId !== undefined && levId !== NaN && levId !== undefined && !isNaN(prId)){                
                this.auditService.getAcceptedActiveAuditListForPlant(stDate, edDate, pltId,  levId,  prId, pgId).subscribe((data:ResponseObject)=>{
                    if(this.utilService.checkValidData(data)){
                        this.auditList = data.Response;
                        this.initialAuditList = data.Response;
                        // saving data to storage
                        if(this.isOffline){
                            this.cacheData.saveUnSchAuditslistDetails(false,stDate, edDate, pltId,  levId,  prId, langCode ,data.Response);
                        }                
                    } 
                });
            } else{
                console.error("Values cannot be empty ");
            }  
        } else{
            const response:Array<AcceptedAuditItem> = storage.loadSavedData(this.user.wLogin,"unSchAuditsList");
            if(response!== undefined){
                this.auditList = response;
            }            
        }    
   }

   private startAudit():void{
      //this.navCtrl.push(AuditStartResults);
   }
   public navigateToHome():void{
        this.navCtrl.setRoot(HomePage);
   }
   private presentSearchPopover():void{     
       if(this.isPlantAdmin){// for plant admin show option to search by other levels

       } else{

       } 
       const usrPrv = new UserSelectionPrivileges(false,false, false, false, false,
                                                    false, false, true, true, false, 
                                                false, false, false, false, false, 
                                                false, false, false, false, false, false, false);

      const seldata = Object.assign({}, this.selectionData);                                          
    let popover = this.popoverCtrl.create(SelectionPage, { // this pop-up will show only the start date and end date
                                                "isMandatory":"false", 
                                                "userPrivileges":usrPrv,
                                                "isPopOverCtrl":"true",
                                                "pageTitle":"Search Audits", 
                                                "userSelectionData": seldata },
                                                {
                                                      enableBackdropDismiss:false,
                                                  });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData) => {
            if(data){
                this.selectionData.startDate = this.utilService.revertToSystemDateFormat(data.startDate);
                this.selectionData.endDate = this.utilService.revertToSystemDateFormat(data.endDate);     
                this.getAcceptedActiveAuditListForPlant();             
            }                
        });
   }

   private GetMachinesFromScheduledAudits(){

   }

   //GetMachinesFromScheduledAudits
   // private auditExistsForSelection(usrId:number, stDate:string, edDate:string, pltId:number, levId:number, prId:number, machineNum:string/*Array of Machines*/, shift:string){
     /*   let schAuditList:Array<AcceptedAuditItem> = []
       return  this.auditService.getScheduledAuditForUserByPlantId(usrId, stDate, edDate,
                pltId, levId,  prId).subscribe((response:ResponseObject)=>{// Get the past 3 months scheduled audits if they are not completed.                                  
              return this.auditService.getScheduledAuditForUserByPlantId(usrId, stDate, edDate,
                pltId, levId,  prId).subscribe((data:ResponseObject)=>{
                    if(this.utilService.checkValidData(response)){
                        schAuditList = schAuditList.concat(response.Response);
                    }
                    if(this.utilService.checkValidData(data)){
                        schAuditList = schAuditList.concat(data.Response)
                    }
                    return (_.filter(schAuditList,(item:AcceptedAuditItem)=>{ return item.userId === usrId && item.endDate === edDate &&
                    item.startDate === stDate && machineNum.indexOf(item.machineNum) > 0 && item.shift}).length > 0);
                });
      });
            
    }*/

    // Below is used for assigning the Audit
   private auditListItemClicked(auditItem:AcceptedAuditItem){
       /*Task 299 Disable entering Lot number for taking Audits /Scheduling the Audits from the LPA application*/
      if(!this.isShowDetails){      
          let popover = this.popoverCtrl.create(SelectionPage, {
                                              "isMandatory" : "false",
                                              "isPopOverCtrl":"true", 
                                              "isFromPage" : this.isAuditsSchedular ? "AuditSchedular" : "UnScheduledAudits",
                                              "pageTitle":(auditItem.procName + "- Level "+auditItem.levelId),
                                              "userPrivileges" : new UserSelectionPrivileges(false,false, false, false, false,
                                                                                          false, false, false, false, false, 
                                                                                          false/*Task 299*/, true, true, true, false, 
                                                                                          false, false, false, false, false, false, true), 
                                              "userSelectionData": this.selectionData },
                                              {
                                                    enableBackdropDismiss:false,
                                                });
          popover.present();
          popover.onDidDismiss((data:UserSelectionData) => {
              if(data !== undefined){            
                  const loggedInUserWLogin = this.user.wLogin;
                  //if(!this.auditExistsForSelection(data.auditor.id, auditItem.startDate, auditItem.endDate, auditItem.plantId, auditItem.levelId, auditItem.procId, data.machine.name, data.shift.name)){
                            this.auditService.postScheduleAcceptedAuditToUser(new SubmitScheduledAudit(auditItem.auditListId, 
                                                                    data.auditor.id, "0000"/*Task 299*/, 
                                                                  data.machine.name, data.shift.name, 
                                                                  data.selCommentsTextarea,loggedInUserWLogin)).subscribe((data:ResponseObject)=>{
                            if(this.utilService.checkValidData(data)){                               
                                if(data.Response[0] !== undefined){
                                    this.utilService.showToast(data.Response[0],"");
                                }                                                                    
                                this.getAcceptedActiveAuditListForPlant(); 
                            }
                  });
                //} else{
                //    this.utilService.showToast("","Audit already existing for the selection to the User.");
               // }
              }                
          });
      } else{
          this.auditSelectedForDetails(auditItem);
      }
   }


   private userSelectionPopOver(){
       const selData:UserSelectionData = Object.assign({},this.selectionData);
     let popover = this.popoverCtrl.create(SelectionPage, {
                                                "isMandatory":"false", 
                                                "isPopOverCtrl":"true",
                                                "userPrivileges":new UserSelectionPrivileges(false,false, true, false, true,
                                                                                            false, false, false, false, false, 
                                                                                            false, false, false, false, false, 
                                                                                            false, false, false, false, false, false, false), 
                                                "userSelectionData": selData },
                                                {
                                                      enableBackdropDismiss:false,
                                                  });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData) => {
            if(data){
                this.selectionData = data;     
                this.getAcceptedActiveAuditListForPlant();             
            }                
        });
   }
}
