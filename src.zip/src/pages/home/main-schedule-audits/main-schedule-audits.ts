import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ScheduledAudits } from '../scheduled-audits/scheduled-audits';
import {Privileges} from '../../../providers/privileges';
import {UserService} from '../../../providers/user-service';
import { User } from '../../../models/user';
import { TranslateService }  from 'ng2-translate';
/**
 * Generated class for the MainScheduleAuditsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-main-schedule-audits',
  templateUrl: 'main-schedule-audits.html',
})
export class MainScheduleAuditsPage {
  showSelf:boolean;
  showPlant:boolean;
  tab1:any;
  tab2:any;
  user:User;
  pageName:string; 
  constructor(public navCtrl: NavController, public navParams: NavParams, private translate: TranslateService, private privileges:Privileges,private userService:UserService) {
         this.pageName = "Audits";
      this.user = this.userService.getUser();
      if(navParams.data !== undefined && navParams.data.showPlant !== undefined && navParams.data.showSelf !== undefined){
          this.showPlant = navParams.data.showPlant === 'true';
          this.showSelf = navParams.data.showSelf === 'true';        
      } else{
          const pagePriv = this.privileges.getPageObject(this.user.roleName,this.pageName);    
        this.showSelf = pagePriv["selfAudits"] ? pagePriv["selfAudits"]["thisShow"] === "true": false;
        this.showPlant= pagePriv["plantAudits"] ? pagePriv["plantAudits"]["thisShow"] === "true": false;
      }
        this.tab1 = ScheduledAudits;
        this.tab2 = ScheduledAudits;               
  }

  ionViewDidLoad() {
    
  }

}
