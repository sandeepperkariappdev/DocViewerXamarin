import { Component } from '@angular/core';
import { NavController, PopoverController } from 'ionic-angular';
import {ScheduledAudits} from './scheduled-audits/scheduled-audits';

import { MainScheduleAuditsPage } from './main-schedule-audits/main-schedule-audits';
import { UnScheduledAudits} from './un-scheduled-audits/un-scheduled-audits';
import { AuditListPlantPage} from '../audits/audit-list-plant/audit-list-plant';
import { AdhocAuditsPage} from "../adhoc-audits/adhoc-audits";
import { GeneralAuditsPage} from "../general-audits/general-audits";
import { MyCorrectiveActionAssignments} from './my-corrective-action-assignments/my-corrective-action-assignments';
import { Reports } from '../reports/reports';
import { SelectionPage } from '../selection/selection';
import { UserDetailsResponse} from '../../models/UserDetailsResponse';
import { AdminAudits } from '../admin/admin-audits/admin-audits';
import { AuditsHistory } from '../side-menu/audits-history/audits-history';
import { AdminManageMachineProvider } from '../resources-management/admin-manage-machine/admin-manage-machine-service';
import { CorrectiveAssignments } from './corrective-assignments/corrective-assignments';
import { Privileges} from '../../providers/privileges';
import { UserService} from '../../providers/user-service';
import { User } from '../../models/user';
import { HomeServiceProvider} from './home-service';
import { UtilService} from '../../providers/util-service';
import { UserSelectionData,UserSelectionPrivileges, ResponseObject, UserObject } from '../../models/QuestionItem';
import { Lot, Machine, Shift } from '../../models/Level';
import { TranslateService }  from 'ng2-translate';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  private user:User;
  private pageName:string;
  private showGuestAuditsTab:boolean;
  private showMyAuditsTab:boolean;
  private showAdhocAuditsTab:boolean;
  private showMyPlantAdminTab:boolean;
  private showCorrectiveActionsTab:boolean;
  private showMyAuditsHistoryTab:boolean;
  private showWasteWalkTab:boolean;
  public SchAuditsCount: number;
  public UnSchAuditsCount: number;
  public CorrectiveActionCount: number;
  private showPlantTabCorrectiveActions:boolean; 
  private showPlantTabMyAudits:boolean; 
  private showSelfTabMyPlant:boolean;
  private usrSelData:UserSelectionData;
  private selectionData:UserSelectionData;
  public isPlantAdmin:boolean;
  public pageTitle:string;
  public adhocAudit:string;
  public userFirstLastName :string;
  public layerName :string;
  public pgName :string;
  public wloginName :string;
  constructor(public navCtrl: NavController, 
              public utilService: UtilService, 
              private popoverCtrl : PopoverController, 
              private translate: TranslateService,
               private adminManageMachinesService:AdminManageMachineProvider,
              private privileges: Privileges, 
              private homeSer:HomeServiceProvider,
              private userService: UserService) {
      this.user = this.userService.getUser();
      this.pageName = "Home";
      this.layerName = "";
      this.pgName = "";
      this.wloginName= "";
      this.isPlantAdmin = this.user.roleId === 3;
      this.selectionData = new UserSelectionData(0, "",0,"",0,"",0,"",0,"",0,"","","","","","",new Lot(0, ""),new Machine("0","","", true),new Shift("0",""), new UserObject(0, "") ,"","","","","","","");
      const pagePriv = this.privileges.getPageObject(this.user.roleName,this.pageName);
      this.showMyAuditsTab = pagePriv["MyAudits"] ? pagePriv["MyAudits"]["thisShow"] : false;
      this.showGuestAuditsTab = pagePriv["GuestAudits"] ? pagePriv["GuestAudits"]["thisShow"] : false;
      this.showAdhocAuditsTab = pagePriv["AdhocAudits"] ? pagePriv["AdhocAudits"]["thisShow"] : false; 
      this.showMyPlantAdminTab = pagePriv["PlantAdmin"] ? pagePriv["PlantAdmin"]["thisShow"] : false;
      this.showWasteWalkTab = pagePriv["WasteWalk"] ? pagePriv["WasteWalk"]["thisShow"] : false;      
      this.showCorrectiveActionsTab = pagePriv["CorrectiveActions"] ? pagePriv["CorrectiveActions"]["thisShow"] : false;
      this.showMyAuditsHistoryTab = pagePriv["AuditsHistory"] ? pagePriv["AuditsHistory"]["thisShow"] : false;
      this.showPlantTabCorrectiveActions = pagePriv["CorrectiveActions"] ? pagePriv["CorrectiveActions"]["showPlant"] : false;      
      this.showPlantTabMyAudits = pagePriv["MyAudits"] ? pagePriv["MyAudits"]["showPlant"] : "false";      
      this.showSelfTabMyPlant = pagePriv["AuditsHistory"] ? pagePriv["AuditsHistory"]["showSelf"] : false;         
      this.pageTitle = "Audits";      
  }

  ionViewDidEnter(){  
    const usrSel:UserSelectionData = this.userService.getUserSelection();
    const usrDetails = this.utilService.getUserDetailsResponse();
    if(usrSel !== undefined){
          // if(!this.checkUserPreferences()){      
          //   this.presentChangePreferencePopover();
          // } else{
            this.pageTitle = " - "+usrSel.selPltName;
            this.layerName = "" + usrSel.selLevelName;
            this.pgName = "" + usrSel.selPGName;
            this.wloginName = "" + usrDetails.wLogin;
            this.userFirstLastName = usrDetails.firstName + " " + usrDetails.lastName;
            this.selectionData = usrSel;      
            this.selectionData.startDate = this.utilService.getWeekStartDate();
            this.selectionData.endDate = this.utilService.getWeekEndDate();  
            if(this.selectionData.selPltId !== 0){
              this.userService.retrieveUsersForPlant(this.selectionData.selPltId, this.selectionData.selPGId);             
            }  
            this.GetSchUnSchCorrectActionCount();
       // }
    }              
  } 

  GetSchUnSchCorrectActionCount(){
    const usrSel:UserSelectionData = this.selectionData;    
    const levelId = this.isPlantAdmin ? 0 : usrSel.selLevelId 
    this.homeSer.GetSchUnSchCorrectActionCount(usrSel.selPltId, this.user.userId, usrSel.selLangCode,usrSel.startDate, usrSel.endDate,levelId, usrSel.selPGId).subscribe((data:ResponseObject)=>{
      if(this.utilService.checkValidData(data)){
          this.SchAuditsCount = data.Response[0]["SchAuditCount"];
          this.UnSchAuditsCount = data.Response[0]["UnSchAuditCount"];
          this.CorrectiveActionCount = data.Response[0]["CorrectiveActionCount"];
      }
    });
  }

 
  presentChangePreferencePopover() {
    // Just show the plant to select 
        let popover = this.popoverCtrl.create(SelectionPage, {"isMandatory":"true","isFromPage":"homePage",
         "useSelectionDataSent":"false",
         "isPopOverCtrl":"true",
        "userPrivileges":new UserSelectionPrivileges(true,false,false,false,false,false, false, 
        false,false, false, false, false, false, false,false, 
        false, false, false, false, true, false, false),
        "userSelectionData":""},{
            enableBackdropDismiss:false,
        });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData)=>{
            if(data){
                this.selectionData = data;               
                this.userService.setUserSelection(this.selectionData); 
                this.selectionData.startDate = this.utilService.getWeekStartDate();
                this.selectionData.endDate = this.utilService.getWeekEndDate();
                this.GetSchUnSchCorrectActionCount();
            }                
        }); 
    }
  checkUserPreferences(data:UserDetailsResponse){
    // this is available in home.ts 
   // any changes here shoudl also be done in home.ts
     // return false when there are multiple Plants for the User.
     
            let levelName = this.utilService.getLevelDescById(data.levelId);
            let roleName = this.utilService.getRoleDescById(data.roleId);
            let langName = this.utilService.getLanguageDesc(data.languageCode);
        if(data.roleId === 1){
                    const usrSelData  = new UserSelectionData(0,"", 0, "",0, "", 0, "",0, "",data.roleId,  roleName,  
                                                            data.languageCode, langName,"","",data.userId.toString(), 
                                                            new Lot(0, ""),new Machine("0","","", true),new Shift("0",""), 
                                                            new UserObject(0, ""),"","","","","","","");
                                this.userService.setUserSelection(usrSelData);                      
                                ///localStorage.saveUserSelection = JSON.stringify(usrSelData);
                                return true;
        } else if(data.roleId === 2){

                        //TODO Corp admin will not have plants so how to figure out the product group?

                        // this is available in home.ts 
                        // any changes here shoudl also be done in home.ts   
                        // if((data.plants[0].productGroups[0].pgId !== undefined && data.plants[0].productGroups[0].pgId  !== 0) &&
                        // (data.plants[0].productGroups[0].pgName !== undefined && data.plants[0].productGroups[0].pgName !== "")){
                        //         const usrSelData  = new UserSelectionData(0, "", data.plants[0].productGroups[0].pgId, data.plants[0].productGroups[0].pgName,
                        //                                                 0, "",0, "",0,"",data.roleId,  roleName,  
                        //                                                 data.languageCode, langName,"","",data.userId.toString(), 
                        //                                                 new Lot(0, ""),new Machine("0","","", true),new Shift("0",""), 
                        //                                                 new UserObject(0, ""),"","","","","","","");
                        //         this.userService.setUserSelection(usrSelData);                      
                        //         localStorage.saveUserSelection = JSON.stringify(usrSelData);
                        //         return true;
                        // } else{          
                        //         this.utilService.showToast("noValidresponsefromServer","Product Group is not set");
                        // } 


        } else {
                    // this is available in home.ts 
                    // any changes here should also be done in home.ts
                     if(data !== undefined && data.plants !== undefined){
                                if(data.plants.length > 1){
                                    return false;// need to make selection if the User has more than 1 Plant.
                                }
                                if(data.plants.length > 0 && data.plants[0].productGroups !== undefined && data.plants[0].productGroups.length > 1){
                                    return false;// need to make selection if the plant has more than 1 product group
                                }
                            if(data.plants.length > 0 &&
                                    (data.plants[0].plantId !== undefined && data.plants[0].plantId !== 0 ) &&
                                    (data.plants[0].plantName !== undefined && data.plants[0].plantName !== "")&&
                                    (data.plants[0].productGroups[0].pgId !== undefined && data.plants[0].productGroups[0].pgId  !== 0) &&
                                    (data.plants[0].productGroups[0].pgName !== undefined && data.plants[0].productGroups[0].pgName !== "")){
                                        // data.plants[0].opId = data.plants[0].opId === undefined ? 0 : data.plants[0].opId; // setting the default value for opId and opName
                                    // data.plants[0].opName = data.plants[0].opName  === undefined ? data.plants[0].pgName :  data.plants[0].opName;                                                  
                                    const usrSelData  = new UserSelectionData(+data.plants[0].plantId, data.plants[0].plantName, 
                                                                                data.plants[0].productGroups[0].pgId, data.plants[0].productGroups[0].pgName,
                                                                                0, "",
                                                                                0, "",data.levelId, levelName,data.roleId,  roleName,  
                                                                                data.languageCode, langName,"","",data.userId.toString(), 
                                                                                new Lot(0, ""),new Machine("0","","", true),new Shift("0",""), 
                                                                                new UserObject(0, ""),"","","","","","","");
                                        this.userService.setUserSelection(usrSelData);                      
                                        localStorage.saveUserSelection = JSON.stringify(usrSelData);
                                        return true;
                            } else{          
                                this.utilService.showToast("noValidresponsefromServer"," Plant Name or Product Group is not set");
                            } 
                     } else{          
                                this.utilService.showToast("noValidresponsefromServer"," Plant Name or Product Group is not set");
                    } 
        }                             
  }
  private myScheduledAuditsClicked():void{    
    this.navCtrl.push(MainScheduleAuditsPage,{"getShowTab":"0", "showPlant":this.showPlantTabMyAudits, "showSelf":"true" });
  }
  private guestAuditsClicked():void{    
    this.navCtrl.push(AdhocAuditsPage);
  }

  private myUNScheduledAuditsClicked():void{    
   // this.navCtrl.setRoot(UnScheduledAudits);
    this.navCtrl.push(AdhocAuditsPage);
  }

  private myCorrActnAssignClicked():void{    
    this.navCtrl.push(CorrectiveAssignments,{"getShowTab":"0", "showPlant":this.showPlantTabCorrectiveActions, "showSelf":"true" });
  }

  private myPlantAdminClicked():void{
    this.navCtrl.push(CorrectiveAssignments,{"getShowTab":"1", "showPlant":"true", "showSelf":this.showSelfTabMyPlant });    
  }


  private plantCorrAssgnClicked():void{    
    this.navCtrl.setRoot(AdminAudits);
  }

   private auditsHistoryTabClicked():void{    
    this.navCtrl.push(AuditsHistory);
  }

  private reports():void{
    this.navCtrl.setRoot(Reports);
  }
  private generalAuditsTabClicked():void{    
    this.navCtrl.push(GeneralAuditsPage);
  }
}
