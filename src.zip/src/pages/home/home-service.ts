import { Injectable } from '@angular/core';
import { AppSettings, MethodConstants } from '../../constants/AppSettings';
import { CallService} from '../../providers/call-service';
import 'rxjs/add/operator/map';

/*
  Generated class for the HomeServiceProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class HomeServiceProvider {

  constructor(private callService:CallService) {    
  }
  public GetSchUnSchCorrectActionCount(plantId:number, userId:number, langCode:string, startDate:string, endDate:string,level:number, pgId:number){    
    //http://ahdeviis01/LPADevServices/api/SchUnSchCorrectActionCount/getSchUnSchCorrectActionCount?plantId=4&&level=5&startDate=2017-06-11&endDate=2017-08-11&userId=0&langCode=ENG
    if(userId !== undefined && userId !== 0 && plantId !== undefined && plantId !== 0 && langCode !== "" && startDate !=="" && endDate  !==""){
          const url = (AppSettings.API_ENDPOINT + MethodConstants.GetSchUnSchCorrectActionCount+"pgId="+pgId+"&plantId="+plantId+"&level="+level+"&userId="+userId+"&startDate="+startDate+"&endDate="+endDate+"&langCode="+langCode);
          return this.callService.callServerForGet(url,"Get Failure Codes Assigned");
    }  else{
          console.error(" values cannot be null");
    }            
  }
}
