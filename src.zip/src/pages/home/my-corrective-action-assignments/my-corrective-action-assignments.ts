import { Component, OnInit } from '@angular/core';
import { IonicPage,ModalController, NavController, NavParams, ViewController, App } from 'ionic-angular';
import { CorrectiveActionAssignmentServiceProvider } from "../corrective-assignments/corrective-action-assignment-service";
import { UserSelectionData, CorrectActionAssgnItem } from '../../../models/QuestionItem';
import { UserService } from '../../../providers/user-service';
import { UtilService } from '../../../providers/util-service';
import { User } from '../../../models/User';
import { TranslateService} from 'ng2-translate';
import {CorrectiveActionAssignmentDetailsPage} from "../corrective-action-assignment-details/corrective-action-assignment-details";
/**
 * Generated class for the MyCorrectiveActionAssignments page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-my-corrective-action-assignments',
  templateUrl: 'my-corrective-action-assignments.html',
})
export class MyCorrectiveActionAssignments implements OnInit{
  public optionView:string;
  public title:string;
  private selectionData:UserSelectionData;
  private user:User;
  private userId:number;
  public isPlant:boolean;
  public isFromAnotherPage:boolean;
  public assignedFailureCodesList:Array<CorrectActionAssgnItem> = [];
  public reviewedFailureCodesList:Array<CorrectActionAssgnItem> = [];
  public completedFailureCodesList:Array<CorrectActionAssgnItem> = [];
  private initialAssignedFailureCodesList:Array<CorrectActionAssgnItem> = [];
  private initialReviewedFailureCodesList:Array<CorrectActionAssgnItem> = [];
  private initialCompletedFailureCodesList:Array<CorrectActionAssgnItem> = [];

  constructor(public navCtrl: NavController, 
  private viewCtrl:ViewController,
  private appCtrl:App,
              private translate:TranslateService,
              public modalCtrl:ModalController, 
              private userService:UserService, 
                        private utilService:UtilService, 
              public navParams: NavParams, 
              private crtveActAssgnService:CorrectiveActionAssignmentServiceProvider) {
    this.isPlant = false;
    this.translate = translate;
    this.optionView ='assigned';
    this.title = "";
    this.isFromAnotherPage = false;
  }

  ngOnInit(){
    this.selectionData = this.userService.getUserSelection();
    this.selectionData.startDate = this.utilService.getWeekStartDate();
    this.selectionData.endDate = this.utilService.getWeekEndDate();
    this.user = this.userService.getUser();
    const navParams = this.navParams.data;     
      
    if(navParams !== undefined && navParams.self !== undefined){
        this.isPlant = (navParams.self === "false");      
    }    
    this.translate.get(["myCorrectiveActionAssgn"]).subscribe((data)=>{
        this.title = data["myCorrectiveActionAssgn"];
    });  
    this.userId = this.isPlant ? 0 : this.user.userId;
     if(navParams !== undefined && navParams.isFromPage === "usersInPlant"){
        this.isFromAnotherPage = true;
        if(navParams.userId !== undefined){
            this.userId = +navParams.userId;
        }
    }
      this.loadData();      
  }
  private loadData(){
        this.getAssignedFailureCodesForUser();
        this.getReviewFailureCodesForUser();
        this.getCompletedFailureCodesForUser()
  }

  ionViewDidLoad() {    
  }

  private getAssignedFailureCodesForUser(){    
    this.utilService.showLoading();
    this.assignedFailureCodesList = Object.assign([], []);
    this.initialAssignedFailureCodesList = Object.assign([], []);
    this.crtveActAssgnService.getAssignedFailureCodesForPlant(this.selectionData.selPGId,this.selectionData.selPltId, this.userId, 1, this.selectionData.selLangCode, this.selectionData.startDate, this.selectionData.endDate).subscribe((data)=>{
        if(this.utilService.checkValidData(data)){
            this.assignedFailureCodesList = this.assignedFailureCodesList.concat(data.Response);
            this.initialAssignedFailureCodesList = this.initialAssignedFailureCodesList.concat(data.Response);
        }        
    });
    // retrieving the Corrective action for Waste Walk
    this.crtveActAssgnService.getAssignedFailureCodesForPlant(1,this.selectionData.selPltId, this.userId, 1, this.selectionData.selLangCode, this.selectionData.startDate, this.selectionData.endDate).subscribe((data)=>{
        if(this.utilService.checkValidData(data)){
            this.assignedFailureCodesList = this.assignedFailureCodesList.concat(data.Response);
            this.initialAssignedFailureCodesList = this.initialAssignedFailureCodesList.concat(data.Response);
        }
        this.utilService.hideLoading();
    });

}
private getReviewFailureCodesForUser(){      
    this.reviewedFailureCodesList  = Object.assign([],[]);
    this.initialReviewedFailureCodesList  = Object.assign([], []);
  this.crtveActAssgnService.getAssignedFailureCodesForPlant(this.selectionData.selPGId,this.selectionData.selPltId, this.userId, 2, this.selectionData.selLangCode, this.selectionData.startDate, this.selectionData.endDate).subscribe((data)=>{
      if(this.utilService.checkValidData(data)){
          this.reviewedFailureCodesList  = this.reviewedFailureCodesList.concat(data.Response);
          this.initialReviewedFailureCodesList  = this.initialReviewedFailureCodesList.concat(data.Response);
      }        
  });
    this.crtveActAssgnService.getAssignedFailureCodesForPlant(1,this.selectionData.selPltId, this.userId, 2, this.selectionData.selLangCode, this.selectionData.startDate, this.selectionData.endDate).subscribe((data)=>{
        if(this.utilService.checkValidData(data)){
            this.reviewedFailureCodesList  = this.reviewedFailureCodesList.concat(data.Response);
            this.initialReviewedFailureCodesList  = this.initialReviewedFailureCodesList.concat(data.Response);
        }        
    });
}
private getCompletedFailureCodesForUser(){   
    this.completedFailureCodesList  = Object.assign([],[]);       
    this.initialCompletedFailureCodesList  = Object.assign([], []);
  this.crtveActAssgnService.getAssignedFailureCodesForPlant(this.selectionData.selPGId,this.selectionData.selPltId, this.userId, 3, this.selectionData.selLangCode, this.selectionData.startDate, this.selectionData.endDate).subscribe((data)=>{
      if(this.utilService.checkValidData(data)){
        this.completedFailureCodesList  = this.completedFailureCodesList.concat(data.Response);
        this.initialCompletedFailureCodesList  = this.initialCompletedFailureCodesList.concat(data.Response);
      }        
  });
  this.crtveActAssgnService.getAssignedFailureCodesForPlant(1,this.selectionData.selPltId, this.userId, 3, this.selectionData.selLangCode, this.selectionData.startDate, this.selectionData.endDate).subscribe((data)=>{
    if(this.utilService.checkValidData(data)){
        this.completedFailureCodesList  = this.completedFailureCodesList.concat(data.Response);
        this.initialCompletedFailureCodesList  = this.initialCompletedFailureCodesList.concat(data.Response);
    }        
});
}

  assignedDetailsClicked(item:CorrectActionAssgnItem,type:string){
    item.image = "";
    item.imageType = "";
      let modal = this.modalCtrl.create(CorrectiveActionAssignmentDetailsPage,{
        "isFromPage" : "MyCorrectiveActionAssignments",
        "CorrectActionAssgnItemData":Object.assign({},item),
        "type" : type, // assigned, review, completed
        "isReadOnly" : this.isFromAnotherPage,
        "isPlant" : this.isPlant, 
       },{
           enableBackdropDismiss:false
       });
        modal.onDidDismiss((data)=>{ 
            this.loadData();            
        });
        modal.present();
  }
  dismiss(){
      this.viewCtrl.dismiss();
  }

  searchCancelClicked(){
    if(this.optionView === "assigned"){
        this.assignedFailureCodesList = Object.assign([],this.initialAssignedFailureCodesList);
    } else if(this.optionView === "review"){
        this.reviewedFailureCodesList = Object.assign([],this.initialReviewedFailureCodesList);
    }  else if(this.optionView === "completed"){
        this.completedFailureCodesList = Object.assign([],this.initialCompletedFailureCodesList);
    }
}
getSearchItems(ev:any){
 let val = ev.target.value;     
    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
    if(this.optionView === "assigned"){
        this.assignedFailureCodesList = Object.assign([],this.initialAssignedFailureCodesList);
        this.assignedFailureCodesList = this.assignedFailureCodesList.reduce((prev, item) => {                                                                  
          if(item.assigneeFirstName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
          item.machineNum.toString().toLowerCase().indexOf(val.toLowerCase()) > -1 ||
          item.assigneeLastName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.lastName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.procName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.failDesc.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.assigneeComments.toLowerCase().indexOf(val.toLowerCase()) > -1){

            prev.push(item);                                                
          }              
          return prev;
      }, []);

    } else if(this.optionView === "review"){
        this.reviewedFailureCodesList = Object.assign([],this.initialReviewedFailureCodesList);
    this.reviewedFailureCodesList = this.reviewedFailureCodesList.reduce((prev, item) => {                                                                  
          if(item.reviewerFirstName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
          item.machineNum.toString().toLowerCase().indexOf(val.toLowerCase()) > -1 ||
          item.reviewerLastName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.lastName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.procName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.failDesc.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.reviewerComments.toLowerCase().indexOf(val.toLowerCase()) > -1){
            prev.push(item);                                                 
          } 
          return prev;             
      }, []);
     }  else if(this.optionView ==="completed"){
        this.completedFailureCodesList = Object.assign([],this.initialCompletedFailureCodesList);
        this.completedFailureCodesList  = this.completedFailureCodesList.reduce((prev, item) => {                                                                  
          if(item.assigneeFirstName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
          item.machineNum.toString().toLowerCase().indexOf(val.toLowerCase()) > -1 ||
          item.assigneeLastName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.lastName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.procName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.failDesc.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.reviewerFirstName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.reviewerLastName.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
              item.assigneeComments.toLowerCase().indexOf(val.toLowerCase()) > -1){
            prev.push(item);                                     
          }              
          return prev;            
      }, []);
     }
    }
}
 dismissModelPopup(){
     //this.navCtrl.popToRoot();
     this.appCtrl.navPop()
   }
}
