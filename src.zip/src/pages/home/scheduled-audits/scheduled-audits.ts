import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, PopoverController, AlertController, ViewController,Platform, App } from 'ionic-angular';
import { SelectionPage } from '../../selection/selection';
import { AuditService } from '../../audits/audit-service';
import { CacheDataForOfflineProvider } from '../../../providers/cache-data-for-offline';
import { UserObject, UserSelectionData,ResponseObject, UserSelectionPrivileges, ActiveAudit, AcceptedAuditItem } from '../../../models/QuestionItem';
import { UtilService } from '../../../providers/util-service';
import { UserService } from '../../../providers/user-service';
import { AuditDetails } from '../../admin/audit-details/audit-details';
import { AuditStartResults } from '../../audit-start-results/audit-start-results';
import { AuditStartResultsProvider } from '../../audit-start-results/audit-start-results-service';
import { User} from '../../../models/User';
import { Network } from '@ionic-native/network';
import { Lot, Machine, Shift } from '../../../models/Level';
import * as _ from 'lodash';
import * as moment from  'moment';
import * as storage from "../../../providers/local-Storage";
import { SubmitScheduledAudit } from '../../../models/QuestionItem';
import { HomePage } from '../home';
import {AdhocAuditsPage} from "../../adhoc-audits/adhoc-audits";
import { OrderByPipe} from '../../../filters/order-by-pipe';
import { TranslateService }  from 'ng2-translate';
/**
 * Generated class for the ScheduledAudits page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-scheduled-audits',
  templateUrl: 'scheduled-audits.html',
})
export class ScheduledAudits {
  private selectionData:UserSelectionData;
  private auditList:Array<AcceptedAuditItem>;
  private initialAuditList:Array<AcceptedAuditItem>;
  private isAuditsSchedular:boolean;
  private isShowDetails:boolean;
  private isShowPlant:boolean;
  private isPlantAdmin:boolean;
  private pageTitle:string;
  private plantNameTitle:string;
  private user:User;
  private userId:number;
  private levelId:number;
  public isOffline:boolean;
  private isReadOnly :boolean;
  public isPopModel : boolean;
  public showStDate:string;
  public showEdDate:string;
  public missedAuditsListPlant:Array<AcceptedAuditItem> = [];
  public completedAuditsListPlant:Array<AcceptedAuditItem> = [];
  public upcomingAuditsListPlant:Array<AcceptedAuditItem> = [];
  public savedAuditsListInServerPlant:Array<AcceptedAuditItem> = [];
  public initialMissedAuditsListPlant:Array<AcceptedAuditItem> = [];
  public initialCompletedAuditsListPlant:Array<AcceptedAuditItem> = [];
  public initialUpcomingAuditsListPlant:Array<AcceptedAuditItem> = [];
  public initialSavedAuditsListInServerPlant:Array<AcceptedAuditItem> = [];
  private subscription:any;
  public optionView:string;
    constructor(private navCtrl: NavController, 
              private navParams: NavParams,
              private utilService: UtilService,
              private alertCtrl : AlertController,
              private userService: UserService,
              private translate: TranslateService,
              private appCtrl:App,
              public platform: Platform, 
              private network: Network, 
              private cacheData:CacheDataForOfflineProvider,
              private viewCtrl:ViewController, 
              private auditService:AuditService, 
              private auditStartResultService:AuditStartResultsProvider,
              private popoverCtrl: PopoverController) {
        this.isAuditsSchedular = false;
        this.selectionData = this.userService.getUserSelection();
        this.isShowDetails = true;
        this.isShowPlant = false;
        this.isReadOnly = false;
        this.isOffline = false;
        this.pageTitle = "";
        this.plantNameTitle= "";
        this.isPopModel = false;
        this.showStDate = "";
        this.showEdDate = "";
        this.auditList = [];
        this.initialAuditList = [];
        this.user = this.userService.getUser();
        this.isPlantAdmin = false;//this.user["roleId"] === 3;
        this.optionView = "upcoming";        
    }
  
    private showAuditDetails(){
            this.isShowDetails = !this.isShowDetails;
    }
 
   
    public navigateToHome():void{
            this.navCtrl.setRoot(HomePage);
    }
    private getAcceptedActiveAuditListForPlant():void{
        /*
        this will returns audits for the past scheduled 3 months and the curent week audits
            @processId as int = 0,   -- 0 for all processes
            @level as int = 0		 -- 0 for all levels
        */
        if(!this.isOffline){  
                const stDate = this.selectionData.startDate;/*2017-08-06*/ 
                const edDate =  this.selectionData.endDate; 
                this.showStDate = this.utilService.getSearchDateToShow(stDate);
                const pastStDate= this.utilService.getPastMonthStartDate(3);
                const pastEdDate= this.utilService.getPastMonthEndDate(stDate);
                this.showEdDate = this.utilService.getSearchDateToShow(edDate);
                const pltId = this.selectionData.selPltId; 
                const levId =  this.isShowPlant ? 0 : this.selectionData.selLevelId;// for plant admin load all the audits
                const prId = this.selectionData.selPrId;
                const pgId = this.selectionData.selPGId;
                const langCode = this.selectionData.selLangCode;
                this.auditList =[];
                const savedAuditsList =  this.auditStartResultService.getSubmitNotCompldAuditIds();            
                if(stDate  !== "" && edDate !== "" && pastStDate!=="" && pastEdDate !=="" && pltId !== 0 &&  prId !== undefined && levId !== undefined && !isNaN(prId)){   
                    // Since we're passign the startDate adn EndDate as empty we do not need the past 3 months Audits which are returned by default.
                //  this.auditService.getScheduledAuditForUserByPlantId(this.userId, pastStDate, pastEdDate,
                //  pltId, levId, this.isShowPlant ? 0 : prId).subscribe((response:ResponseObject)=>{// Get the past 3 months scheduled audits if they are not completed.                                  
                let initalAuditsList:Array<AcceptedAuditItem> = [];   
                this.savedAuditsListInServerPlant = [];
                this.missedAuditsListPlant = [];   
                this.upcomingAuditsListPlant = [];
                this.initialSavedAuditsListInServerPlant = [];
                this.initialMissedAuditsListPlant = [];
                this.initialUpcomingAuditsListPlant = [];

                this.utilService.showLoading();              
                this.auditService.getScheduledAuditForUserByPlantId(this.isShowPlant ? 0 :this.userId, "", "",
                    pltId, levId,  0 , pgId).subscribe((data:ResponseObject)=>{
                        this.auditService.getSavedInCompleteAuditForUserByPlantId(this.isShowPlant ? 0 :this.userId, "", "",
                            pltId, levId,  0, pgId ).subscribe((response:ResponseObject)=>{                             
                            this.auditService.getScheduledAuditForUserByPlantId(this.isShowPlant ? 0 :this.userId, "", "",
                                pltId, levId,  0 , 1).subscribe((response1:ResponseObject)=>{
                                    this.auditService.getSavedInCompleteAuditForUserByPlantId(this.isShowPlant ? 0 :this.userId, "", "",
                                        pltId, levId,  0, 1 ).subscribe((response2:ResponseObject)=>{ 
                        if(this.utilService.checkValidData(response)){// Saved Audits
                        initalAuditsList = initalAuditsList.concat(response.Response);                   
                        } 
                        if(this.utilService.checkValidData(data)){// actual audits
                        initalAuditsList = initalAuditsList.concat(data.Response);                                                                                  
                        }
                        if(this.utilService.checkValidData(response1)){// Saved Audits
                            initalAuditsList = initalAuditsList.concat(response1.Response);                   
                        } 
                        if(this.utilService.checkValidData(response2)){// actual audits
                        initalAuditsList = initalAuditsList.concat(response2.Response);                                                                                  
                        } 
                        this.utilService.hideLoading();
                    this.auditList = initalAuditsList.reduce((prev, item)=>{
                        if(savedAuditsList.length > 0){
                                // checking if the saved completed audits exists.
                                // if exists don't load those audits.
                                if(savedAuditsList.indexOf(item.auditListId) === -1){  
                                    if(!this.isShowPlant){
                                        if((!moment(item.endDate).isBefore(moment())) || (moment(item.endDate).valueOf() === moment(moment().format("YYYY-MM-DD")).valueOf())){
                                            prev.push(item);                            
                                        }
                                    } else{
                                        prev.push(item);  
                                        // if(item.status.toString() === "1"){ // Completed
                                        //     this.completedAuditsListPlant.push(item);
                                        // } 
                                        if(item.status.toString() === "2"){ // Saved                                        
                                            this.savedAuditsListInServerPlant.push(item);
                                            this.initialSavedAuditsListInServerPlant.push(item);
                                        }
                                        
                                        if(moment(item.endDate).isBefore(moment())){ // Missed                                        
                                            if((moment(item.endDate).valueOf() === moment(moment().format("YYYY-MM-DD")).valueOf())){
                                            } else{
                                                this.missedAuditsListPlant.push(item);
                                                this.initialMissedAuditsListPlant.push(item);
                                            }
                                        }                                                                        
                                        if((!moment(item.endDate).isBefore(moment())) || (moment(item.endDate).valueOf() === moment(moment().format("YYYY-MM-DD")).valueOf())){
                                            // UpComing    
                                            this.upcomingAuditsListPlant.push(item);
                                            this.initialUpcomingAuditsListPlant.push(item);    
                                        }
                                    }                                                                                             
                                }
                        } else{                        
                            if(!this.isShowPlant){
                                //To disable showing audits past the due date
                                if((!moment(item.endDate).isBefore(moment())) || (moment(item.endDate).valueOf() === moment(moment().format("YYYY-MM-DD")).valueOf())){
                                    prev.push(item);                            
                                }
                            } else{
                                prev.push(item); 
                                // if(item.status.toString() === "1"){ // Completed                                
                                //     this.completedAuditsListPlant.push(item);
                                // } 
                                if(item.status.toString() === "2"){ // Saved
                                    this.savedAuditsListInServerPlant.push(item);
                                    this.initialSavedAuditsListInServerPlant.push(item);
                                }
                                
                                if(moment(item.endDate).isBefore(moment())){ // Missed                                        
                                    if((moment(item.endDate).valueOf() === moment(moment().format("YYYY-MM-DD")).valueOf())){
                                    } else{
                                        this.missedAuditsListPlant.push(item);
                                        this.initialMissedAuditsListPlant.push(item);
                                    }
                                }                                                                        
                                if((!moment(item.endDate).isBefore(moment())) || (moment(item.endDate).valueOf() === moment(moment().format("YYYY-MM-DD")).valueOf())){ // UpComing    
                                    this.upcomingAuditsListPlant.push(item);
                                    this.initialUpcomingAuditsListPlant.push(item);                            
                                }     
                            }
                        }                           
                        return prev;                   
                    },[]);
                    const auditListConst = this.auditList;
                    this.initialAuditList = auditListConst;

                    if(this.isOffline){
                            const auditsList = this.auditList;
                            this.cacheData.saveUnSchAuditslistDetails(true,stDate, edDate, pltId,  levId,  prId, langCode, auditsList);
                    }
                    });                
                    });
                }); 
                });  
                } else{
                console.error("Values cannot be empty ");
                }     
        } else{
            
                const response:Array<AcceptedAuditItem> = storage.loadSavedData(this.user.wLogin,"schAuditsList");
                if(response!== undefined){
                    this.auditList = response;
                    this.initialAuditList = response;
                }            
            }   
    }
    private loadDataFromService():void{        
            this.selectionData.endDate = this.utilService.getNextWeekEndDate(); // TODO Add dates dynamically
            this.selectionData.startDate =  this.utilService.getWeekStartDate(); // TODO Add dates dynamically
            this.getAcceptedActiveAuditListForPlant();
    }
    public onOfflineToggleChange():void{
        if(this.isOffline){
            const stDate = this.selectionData.startDate; const edDate =  this.selectionData.endDate; 
                this.showStDate = this.utilService.getSearchDateToShow(stDate);
                this.showEdDate = this.utilService.getSearchDateToShow(edDate);
                const pltId = this.selectionData.selPltId; const levId =  this.selectionData.selLevelId;
                const prId = this.selectionData.selPrId;
                const langCode = this.selectionData.selLangCode;
                const auditsList:Array<AcceptedAuditItem> = this.auditList;
                if(stDate  !== "" && edDate !== "" && pltId !== 0 &&  prId !== undefined && levId !== undefined && !isNaN(prId)){  
                    this.cacheData.saveUnSchAuditslistDetails(true,stDate, edDate, pltId,  levId,  prId, langCode ,auditsList);
                }
        }
    }
  
    ionViewDidLoad() {  
        this.translate.get(['myaudits']).subscribe((value)=>{  
            this.pageTitle = value['myaudits'];
        });
    }
    ionViewWillLeave(){
        if(this.subscription !== undefined){
            this.subscription.unsubscribe();
        }
    }
    ionViewDidEnter(){ 
        this.initialize();
        if(this.platform.is("cordova")){
            this.subscription = this.network.onchange().subscribe((data) => {
                    if(data.type === "offline"){
                        this.isOffline = true;
                        this.utilService.showToast("","Network Offline - Schduled Audits");
                    }
                    if(data.type === "online"){
                        this.isOffline = false;
                        this.utilService.showToast("","Network Online - Schduled Audits");
                        this.loadDataFromService();
                    } 
                });          
        }   
        if(this.utilService.isNetworkConnected){
            this.isOffline = false;
            this.loadDataFromService();
        } else {
            this.isOffline = true;
        }
    }

    private initialize(){
        this.plantNameTitle = this.selectionData.selPltName;
        const navParams = this.navParams.data;    
            if(this.checkDefined(navParams) &&  this.checkDefined(navParams.self) && navParams.self === "false"){          
                this.isShowPlant = true;
                this.translate.get(['plant_audits']).subscribe((value)=>{  
                    this.pageTitle = value['plant_audits'];
                });            
            }  
            if(navParams.editAudit !== undefined && navParams.editAudit === "true"){
                this.isAuditsSchedular = true;         
                this.translate.get(['edit_assigned_audits']).subscribe((value)=>{  
                    this.pageTitle = value['edit_assigned_audits'];
                });
            }      
            if(navParams.isReadOnly !== undefined){
                this.isReadOnly = navParams.isReadOnly === "true";
            }
            this.userId = this.isShowPlant ? 0 : this.userService.getUser().userId;
            this.levelId = this.isShowPlant ? 0 :this.selectionData.selLevelId
            if(navParams.isFromPage !== undefined && navParams.isFromPage === "usersInPlant"){
                this.isPopModel = true;
                if(navParams.userId !== undefined){
                    this.userId = +navParams.userId;
                }
                if(navParams.levelId !== undefined){
                    this.levelId = +navParams.levelId;
                }
            }
    }
    private auditSelectedForDetails(auditItem:AcceptedAuditItem):void{
          const selData:UserSelectionData = Object.assign({}, this.selectionData);                                      
          selData.selPrId = auditItem.procId; 
          selData.selPrName = auditItem.procName;
          selData.selLevelId = auditItem.levelId;
          selData.machine.name = auditItem.machineNum;
          selData.shift.name = auditItem.shift.toString();

          this.navCtrl.push(AuditStartResults, { "isReadOnly":this.isReadOnly.toString(),
                                                "isFromPage":"AuditsListUserPage", 
                                                "userSelectionData":selData,
                                                "isScheduledAudit":"true", 
                                                "isOffline":this.isOffline.toString(),
                                                "auditInfoDetails":auditItem});
    }
    
    private checkDefined(item:any){
        return this.utilService.itemDefined(item);
    } 
    private presentSearchPopover():void{   
      const selData = Object.assign({},this.selectionData);    
      // this pop-up will show onyl the start date and the end date.
        let popover = this.popoverCtrl.create(SelectionPage, {
                                                "isMandatory":"false", 
                                                "pageTitle":"Load Audits",
                                                "isPopOverCtrl":"true",
                                                "userPrivileges":new UserSelectionPrivileges(false,false, false, false, false,
                                                                                            false, false, true, true, false, 
                                                                                            false, false, false, false, false, 
                                                                                            false, false, false, false, false, false, false), 
                                                "userSelectionData": selData },
                                                {
                                                      enableBackdropDismiss:false,
                                                  });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData) => {
            if(data !== undefined){
                this.selectionData.startDate = this.utilService.revertToSystemDateFormat(data.startDate);// converts date from mm/dd/yyyy to yyyy-mm-dd
                this.selectionData.endDate = this.utilService.revertToSystemDateFormat(data.endDate);// converts date from mm/dd/yyyy to yyyy-mm-dd
                this.getAcceptedActiveAuditListForPlant();             
            }                
        });
   }

    private auditListItemClicked(auditItem:AcceptedAuditItem){
       if(auditItem.status.toString() !== "2"){       
            if(!(moment().week() === moment(auditItem.startDate).week())){    
            this.utilService.showToast("","You cannot take future Audits.")
                return;
            }
            if(this.isShowPlant){
                    this.utilService.showToast("","Cannot See Audit Details for Plant Audits.")
                return;
            }
        }
      if(!this.isShowDetails){  
        let selData = Object.assign({},this.selectionData);
        selData.auditor = new UserObject(auditItem.userId, auditItem.firstName+","+auditItem.lastName);
        selData.startDate = auditItem.startDate;
        selData.endDate = auditItem.endDate;
        selData.lot = new Lot(0, auditItem.lotNum);
        selData.machine = new Machine("0", auditItem.machineNum, auditItem.procName, true);
        selData.selCommentsTextarea = auditItem.comments;
        selData.shift = new Shift("0", auditItem.shift.toString());

          let popover = this.popoverCtrl.create(SelectionPage, {
                                              "isMandatory" : "false", 
                                              "exitWithOutSave" :"true",
                                              "isFromPage" : "modifyScheduleAudits",
                                              "isPopOverCtrl":"true",
                                              "userPrivileges" : new UserSelectionPrivileges(false,false, false, false, false,
                                                                                          false, false, true, true, false, 
                                                                                          false, true, true, true, false, 
                                                                                          false, false, false, false, false, false, true), 
                                              "userSelectionData": this.selectionData },
                                              {
                                                    enableBackdropDismiss:false,
                                                });
          popover.present();
          popover.onDidDismiss((data:UserSelectionData, flag) => {
              if(data !== undefined){                                             
                if(data.auditor.id !== auditItem.userId){
                  const message = "Do you agree to Modify Scheduled Audit from"+  " \n\n\n"+
                                    "\n Name : "+ auditItem.firstName+""+auditItem.lastName+ 
                                    "\n Lot : "+auditItem.lotNum+
                                    "\n Machine : "+auditItem.machineNum+
                                    "\n Shift : "+auditItem.shift+
                                    "\n Date : "+ auditItem.startDate + " -- "+auditItem.endDate+
                                    " <Strong> To </Strong>"+  " \n\n\n"+
                                    "\n Name : "+ data.auditor.name+ 
                                    "\n Lot : "+data.lot.name+
                                    "\n Machine : "+data.machine.name+
                                    "\n Shift : "+data.shift.name+
                                    "\n Date : "+ data.startDate + " -- "+data.endDate + " ?";
                  this.showConfirmModifyScheduledAudit(data,auditItem, message, false);
                } else if(flag){
                    const message = "Do you agree to Delete Scheduled Audit from"+  " \n\n\n"+
                                    "\n Name : "+ auditItem.firstName+""+auditItem.lastName+ 
                                    "\n Lot : "+ auditItem.lotNum+
                                    "\n Machine : "+auditItem.machineNum+
                                    "\n Shift : "+auditItem.shift+
                                    "\n Date : "+ auditItem.startDate + " -- "+auditItem.endDate;
                  this.showConfirmModifyScheduledAudit(data,auditItem, message, true);
                }
              }                
          });
      } else{
          this.auditSelectedForDetails(auditItem);
      }
    }

    private showConfirmModifyScheduledAudit(data:UserSelectionData, auditItem:AcceptedAuditItem, message:string, deleteAudit:boolean ) {
        let confirm = this.alertCtrl.create({
        title: "Modify Scheduled Audit",
        message: message,
        buttons: [
            {
            text: 'Cancel',
            handler: () => {
            
            }
            },
            {
            text: 'Agree',
            handler: () => {
                if(deleteAudit){
                    this.auditService.deleteScheduleAcceptedAuditToUser(auditItem.auditListId, this.user.userId).subscribe((data)=>{
                            if(data.IsSuccess  && data.Message.length === 0 && data.Response !== undefined){   
                                this.utilService.showToast("",data.Response);
                                this.getAcceptedActiveAuditListForPlant(); 
                            }                            
                    });  
                } else{
                    this.auditService.modifyScheduleAcceptedAuditToUser(new SubmitScheduledAudit(auditItem.auditListId,data.auditor.id, data.lot.name, 
                                                                    data.machine.name, data.shift.name, data.selCommentsTextarea, data.wLogin)).subscribe((data)=>{
                            if(data.IsSuccess  && data.Message.length === 0 && data.Response !== undefined){   
                                this.utilService.showToast("",data.Response);
                                this.getAcceptedActiveAuditListForPlant(); 
                            }
                    });
                }
                
            }
            }
        ]
        });
        confirm.present();
    }
    private userSelectionPopOver(){
        let popover = this.popoverCtrl.create(SelectionPage, {
                                                    "isMandatory":"false", 
                                                    "isPopOverCtrl":"true",
                                                    "userPrivileges":new UserSelectionPrivileges(false,false, true, false, true,
                                                                                                false, false, true, true, false, 
                                                                                                false, false, false, false, false, 
                                                                                                false, false, false, false, false, false, false), 
                                                    "userSelectionData": this.selectionData },
                                                    {
                                                        enableBackdropDismiss:false,
                                                    });
            popover.present();
            popover.onDidDismiss((data:UserSelectionData) => {
                if(data){
                    this.selectionData = data;     
                    this.getAcceptedActiveAuditListForPlant();             
                }                
            });
    }

    private getSearchItems(ev:any):void{
        let val = ev.target.value;   

        if(this.optionView === "saved"){
                if(val.trim() === ''){  
                    if(this.initialSavedAuditsListInServerPlant !== undefined){
                        this.savedAuditsListInServerPlant = this.initialSavedAuditsListInServerPlant;  
                    }
                }
            if(val && val.trim() !== '' && val.length >= 3){  
                if(this.initialSavedAuditsListInServerPlant !== undefined){
                    this.savedAuditsListInServerPlant = this.initialSavedAuditsListInServerPlant;  
                }
                if(this.savedAuditsListInServerPlant !== undefined){                     
                        this.savedAuditsListInServerPlant = this.savedAuditsListInServerPlant.reduce((prev,item:AcceptedAuditItem,index)=>{                                                    
                            if((item.firstName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            (item.lastName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.plantName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            (item.pgName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||                        
                            (item.procName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.opName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.auditListId.toString().indexOf(val.toLowerCase()) > -1) ||
                        // (item.comments.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.startDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.endDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1 )||
                            (item.machineNum.toLowerCase().toString().indexOf(val.toLowerCase()) > -1)){
                                prev.push(item);
                            }                
                            return prev;
                        },[]);
                }
            }
        }
        if(this.optionView === "missed"){
                if(val.trim() === ''){  
                    if(this.initialMissedAuditsListPlant !== undefined){
                        this.missedAuditsListPlant = this.initialMissedAuditsListPlant;  
                    }
                }
            if(val && val.trim() !== '' && val.length >= 3){  
                if(this.initialMissedAuditsListPlant !== undefined){
                    this.missedAuditsListPlant = this.initialMissedAuditsListPlant;  
                }
                if(this.missedAuditsListPlant !== undefined){                     
                        this.missedAuditsListPlant = this.missedAuditsListPlant.reduce((prev,item:AcceptedAuditItem,index)=>{                                                    
                            if((item.firstName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            (item.lastName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.plantName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            (item.pgName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||                        
                            (item.procName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.opName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.auditListId.toString().indexOf(val.toLowerCase()) > -1) ||
                        // (item.comments.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.startDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.endDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1 )||
                            (item.machineNum.toLowerCase().toString().indexOf(val.toLowerCase()) > -1)){
                                prev.push(item);
                            }                
                            return prev;
                        },[]);
                }
            }
        }
        if(this.optionView === "upcoming"){
                if(val.trim() !== ''){  
                    if(this.initialUpcomingAuditsListPlant !== undefined){
                        this.upcomingAuditsListPlant = this.initialUpcomingAuditsListPlant;  
                    }
                }
            if(val && val.trim() !== '' && val.length >= 3){  
                if(this.initialUpcomingAuditsListPlant !== undefined){
                    this.upcomingAuditsListPlant = this.initialUpcomingAuditsListPlant;  
                }
                if(this.upcomingAuditsListPlant !== undefined){                     
                        this.upcomingAuditsListPlant = this.upcomingAuditsListPlant.reduce((prev,item:AcceptedAuditItem,index)=>{                                                    
                            if((item.firstName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            (item.lastName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.plantName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            (item.pgName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||                        
                            (item.procName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.opName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.auditListId.toString().indexOf(val.toLowerCase()) > -1) ||
                        // (item.comments.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.startDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.endDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1 )||
                            (item.machineNum.toLowerCase().toString().indexOf(val.toLowerCase()) > -1)){
                                prev.push(item);
                            }                
                            return prev;
                        },[]);
                }
            }
        }       
        if(!this.isShowPlant){
                if(val.trim() === ''){  
                    if(this.initialAuditList !== undefined){
                        this.auditList = this.initialAuditList;  
                    }
                }
            if(val && val.trim() !== '' && val.length >= 3){  
                if(this.initialAuditList !== undefined){
                        this.auditList = this.initialAuditList;  
                    }
                if(this.auditList !== undefined){                     
                        this.auditList = this.auditList.reduce((prev,item:AcceptedAuditItem,index)=>{                                                    
                            if((item.firstName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            (item.lastName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.plantName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            (item.pgName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||                        
                            (item.procName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.opName.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.auditListId.toString().indexOf(val.toLowerCase()) > -1) ||
                            // (item.comments.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.startDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1) ||
                            //(item.endDate.toLowerCase().toString().indexOf(val.toLowerCase()) > -1 )||
                            (item.machineNum.toLowerCase().toString().indexOf(val.toLowerCase()) > -1)){
                                prev.push(item);
                            }                
                            return prev;
                        },[]);
                }
            }
        }                
    }

    private searchCancelClicked():void{
        if(!this.isShowPlant){
        this.auditList = this.initialAuditList;
        }
        if(this.optionView === "saved"){
            this.savedAuditsListInServerPlant = this.initialSavedAuditsListInServerPlant;  
        }
        if(this.optionView === "missed"){
            this.missedAuditsListPlant = this.initialMissedAuditsListPlant;  
        }
        if(this.optionView === "upcoming"){
            this.upcomingAuditsListPlant = this.initialUpcomingAuditsListPlant;  
        }
    }
    dismissModelPopup(){
        this.appCtrl.navPop()
    }
    private adhocAuditsClicked():void{    
    // this.navCtrl.setRoot(UnScheduledAudits);
        this.navCtrl.setRoot(AdhocAuditsPage);
    // this.navCtrl.setRoot(HomePage);
    }
}


// Accept Audit by Plant Admin
// Accept Audit by Plant Admin
// Accept Audit by Plant Admin
// Audit submit successfull
// Audit submit Failure
//
// Accept Audit by Plant Admin
// Accept Audit by Plant Admin
// Accept Audit by Plant Admin
// Audit submit successfull
// Audit submit Failure
//