import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, ModalController, AlertController } from 'ionic-angular';
import { UserSelectionData, CorrectActionAssgnItem } from '../../../models/QuestionItem';
import { AnnotatePicturePage } from "../../../popup-modals/annotate-picture/annotate-picture";
import { SearchUsersInPlant } from '../../../popup-modals/search-users-in-plant/search-users-in-plant';
import { CorrectiveActionAssignmentServiceProvider } from "../corrective-assignments/corrective-action-assignment-service";
import { ResponseObject, SubmitActionAssignmentAssignee, CorrectiveActionItemHistory, 
    CorrectiveActionReassign, CorrectiveActionHistoryItemResponse, SubmitActionAssignmentReviewer, AuditFailureRouting, ReassignActionAssignmentReviewer } from "../../../models/QuestionItem";
import { TranslateService } from 'ng2-translate';
import { UserService } from "../../../providers/user-service";
import { UtilService } from "../../../providers/util-service";
import { User } from "../../../models/User";
import { Camera, CameraOptions  } from '@ionic-native/camera';
import * as moment from  'moment';
/**
 * Generated class for the CorrectiveActionAssignmentDetailsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-corrective-action-assignment-details',
  templateUrl: 'corrective-action-assignment-details.html',
})
export class CorrectiveActionAssignmentDetailsPage implements OnInit {
    private shownGroupas = null;//to show or hide used for accordion
    private shownGroupas2 = null;//to show or hide used for accordion
    public itemData:CorrectActionAssgnItem;
    public selectionData:UserSelectionData;
    public editAssignment:boolean;
    public isUserAssignee:boolean;
    public isUserReviewer:boolean;
    public oldAssigneeName:string;
    public oldReviewerName:string;
    public assigneeChangeSave:boolean;
    public reviewerChangeSave:boolean;
    public user:User;
    public isReadOnly:boolean;
    public isAssignmentChanged:boolean;
    public isPlant:boolean;
    public isAssigned:boolean;
    public isReview:boolean;
    public isCompleted:boolean;
    public submitAssigneeButtonTitle:string;
    public submitReviewerButtonTitle:string;
    public assigneeChangeDate:string;//If change date is the date from routing table, its value will never change. it will always be the date when the item was inserted to the routing table. 
    public reviewerChangeDate:string;//If change date is the date from routing table, its value will never change. it will always be the date when the item was inserted to the routing table. 
    public CorrectiveActionItemHistory:Array<CorrectiveActionItemHistory>;
    public CorrectiveActionItemHistoryIntial:Array<CorrectiveActionItemHistory>;
    public toggleItem:string;
    public isFileAdded:boolean;
  constructor(public navCtrl: NavController,
              public viewCtrl: ViewController, 
              public userService: UserService,
              public utSer: UtilService,
              private camera: Camera,
              private alertCtrl : AlertController,
              private modalCtrl:ModalController,
              private translate:TranslateService,
              public correctAssignService : CorrectiveActionAssignmentServiceProvider,
              public navParams: NavParams) {
    this.editAssignment = false;
    this.isUserAssignee = false;
    this.isUserReviewer = false;
    this.assigneeChangeSave = false;
    this.reviewerChangeSave = false;
    this.isAssignmentChanged = false;
    this.isReadOnly = false;
    this.submitAssigneeButtonTitle ="";
    this.submitReviewerButtonTitle = "";
    this.assigneeChangeDate ="";
    this.reviewerChangeDate = "";
    this.oldAssigneeName = "";
    this.oldReviewerName = "";
    this.toggleItem = "item";
    this.isAssigned= false;
    this.isReview = false;
    this.isCompleted = false;
    this.isPlant = false;
    this.isFileAdded = false;
    this.CorrectiveActionItemHistory = [];
    this.CorrectiveActionItemHistoryIntial =[];
  }
  
    ngOnInit(){
        const navParams = this.navParams.data;
        this.user = this.userService.getUser();
        this.selectionData = this.userService.getUserSelection();
        if(navParams !== undefined){
            if(navParams.isFromPage !== undefined && navParams.isFromPage === "MyCorrectiveActionAssignments"){
                if(navParams.CorrectActionAssgnItemData != undefined){
                this.itemData = Object.assign({},navParams.CorrectActionAssgnItemData);
                // Assign Full Name to Assignee, Assign Full Name to Reviewer
                this.itemData.AssigneeName = this.itemData.assigneeFirstName +" "+ this.itemData.assigneeLastName;
                this.itemData.ReviewerName = this.itemData.reviewerFirstName +" "+ this.itemData.reviewerLastName;
                if(this.itemData.assgneeId !== undefined){
                    this.isUserAssignee = (this.itemData.assgneeId === this.user.userId);
                }
                if(this.itemData.reviewerId !== undefined){
                    this.isUserReviewer = (this.itemData.reviewerId === this.user.userId);
                }
                if(this.isUserAssignee){                    
                    this.translate.get(["submit_for_review"]).subscribe((values)=>{
                        this.submitAssigneeButtonTitle = values["submit_for_review"];
                    })                    
                }
                if(this.isUserReviewer){
                    this.translate.get(["close_assignment"]).subscribe((values)=>{
                        this.submitReviewerButtonTitle = values["close_assignment"];
                    });
                }
                }
                if(navParams.isReadOnly !== undefined){ // whne the corrective assignments are from another page
                    this.isReadOnly = navParams.isReadOnly.toString() === "true";
                }          
                if(navParams.isPlant !== undefined){
                    this.isPlant = (navParams.isPlant.toString() === "true"); 
                    this.editAssignment = this.isPlant ? false : true;
                    this.isReadOnly = this.isPlant ? true: this.isReadOnly;
                }
                if(navParams.type !== undefined){
                    this.isAssigned = (navParams.type==="assigned");
                    this.isReview = (navParams.type==="review");
                    this.isCompleted = (navParams.type==="completed");
                }
            }
        }
        this.GetCorrectiveActionHistory();    
    }

    public GetCorrectiveActionHistory(){
        const langCode = this.userService.getUserSelection().selLangCode;
        this.correctAssignService.GetCorrectiveActionHistory(this.itemData.auditFailureId, langCode).subscribe((data:ResponseObject)=>{
        if(this.utSer.checkValidData(data)){
            if(data.Response.length > 0 && data.Response[0].failureHistory !== undefined){
                this.CorrectiveActionItemHistoryIntial = data.Response[0].failureHistory.map( item => new CorrectiveActionItemHistory(item.comments, item.image,item.imageType,item.changeDate, item.statusName, item.statusId, item.userId,item.userName, item.modifiedBy,item.dateModified,true, ((item.statusId.toString() === "1")?("Assigned To"):((item.statusId.toString() === "2")? ("Reviewed By") : ("Completed By")))));             
                if(this.CorrectiveActionItemHistoryIntial.length === 2 && this.isAssigned){ // if this is the initial corrective action item, then show only the assigned item and hide the review item
                    this.CorrectiveActionItemHistoryIntial.forEach((item)=>{            
                        if(item.statusId.toString() == "2"){
                            this.reviewerChangeDate = item.changeDate;
                            item.showItem = false;
                        }  
                        if(item.statusId.toString() == "1"){
                            this.assigneeChangeDate = item.changeDate;                            
                        }        
                    });
                    //this.CorrectiveActionItemHistory = this.CorrectiveActionItemHistoryIntial.map(item => {if(item.showItem){ return item;}});                
                }
                // assigning the image
                if(this.itemData.auditFailStatus.toString() === "1"){
                    let actionItemHistory= this.CorrectiveActionItemHistoryIntial;
                    for(let i = actionItemHistory.length-1; i>-1; i--){
                        if(this.itemData.image === ""){
                            this.itemData.image = ((this.CorrectiveActionItemHistoryIntial[i]["image"] !== "" && this.CorrectiveActionItemHistoryIntial[i]["image"] !== null) ? (this.CorrectiveActionItemHistoryIntial[i]["image"]) : "") 
                        }
                    }
                }
                if(this.itemData.auditFailStatus.toString() === "2"){
                    let actionItemHistory= this.CorrectiveActionItemHistoryIntial;
                    for(let j = actionItemHistory.length-1;j>-1; j--){
                        if(this.itemData.image === ""){
                            this.itemData.image = ((this.CorrectiveActionItemHistoryIntial[j]["image"] !== "" && this.CorrectiveActionItemHistoryIntial[j]["image"] !== null) ? (this.CorrectiveActionItemHistoryIntial[j]["image"]) : "") 
                        }
                    }                    
                }
                this.CorrectiveActionItemHistory = this.CorrectiveActionItemHistoryIntial.filter(item => {if(item.showItem){ return item;}});            
            }            
        }             
        });      
    }

    public editActionAssignmentButtonClicked(){
        if(this.editAssignment){
        this.dismissPopupClicked();
        } else{
            if(this.isPlant){
                this.editAssignment = !this.editAssignment;  
            }
        }            
    }
    public submitActionAssignemntAssignee(){
        const cDateTime = moment().format("MM/DD/YYYY HH:MM");
        if(this.isUserAssignee){
            //const assignComments = this.utSer.replaceSpecialCharsWithSpace(this.itemData.assigneeComments);
            let assignComments = this.itemData.assigneeComments;
        this.correctAssignService.SubmitAssignmentByAssignee(new SubmitActionAssignmentAssignee(this.itemData.auditDetailId, 
            this.itemData.failCd, cDateTime, assignComments, 
            this.user.wLogin,
            this.itemData.auditFailureId,
            this.itemData.assgneeId,
            this.itemData.reviewerId, 
            moment(this.itemData.reviewerCompDate).format("MM/DD/YYYY"),this.itemData.reviewerComments,
            moment(this.itemData.compDate).format("MM/DD/YYYY"), this.itemData.comments, this.itemData.severity,
            2, 
            this.itemData.questionId,
            this.itemData.machineNum,
            this.itemData.assigneeCompDate,
            this.itemData.comments,this.selectionData.selLangCode)).subscribe((data)=>{
                if(this.utSer.checkValidData(data)){
                    this.viewCtrl.dismiss({"success":"true"});   
                }
            });
            //1= Assigned, 2=Pending Review, 3=Complete
            // Below will add the record to the routing table for the Audit Corrective Action Item History
            assignComments = "Action: Assignment Submitted by Assignee "+ this.itemData.AssigneeName+"  to "+this.itemData.ReviewerName +" for Review :" + assignComments;
            this.correctAssignService.SubmitAssignment(new AuditFailureRouting(this.itemData.auditFailureId, 2,null,this.user.userId,this.itemData.assigneeCompDate,cDateTime,
                assignComments,this.itemData.image,this.itemData.imageType,this.user.wLogin)).subscribe((data)=>{
                if(this.utSer.checkValidData(data)){
                    //this.viewCtrl.dismiss({"success":"true"});   
                }
            }) 
        }
    }
    public searchUsers(item:CorrectActionAssgnItem, action){
        // Below code is used to disable changing the Reviewer when assignment is Assigned
        // if(action === "assignee"){
        //     if(item.auditFailStatus.toString() !== "1"){
        //         return true;
        //     }
        // }
        // Below code is used to disable changing the Assignee when assignment is under Review
        // if(action === "reviewer"){
        //     if(item.auditFailStatus.toString() !== "2"){
        //         return true;
        //     }
        // }
        var actionType = action;    
        this.oldAssigneeName = item.assigneeFirstName + " " + item.assigneeLastName;
        this.oldReviewerName = item.reviewerFirstName + " " + item.reviewerLastName;
        let modal = this.modalCtrl.create(SearchUsersInPlant);
        modal.onDidDismiss((data:User)=>{
        if(this.utSer.itemDefined(data)){
            //if(item.auditFailStatus.toString() === "1"){
             if(actionType === "assignee"){ // if assignee is changed
                item.assgneeId = data.userId;
                item.assigneeFirstName = data.firstName;
                item.assigneeLastName = data.lastName;
                item.AssigneeName = data.firstName + " " + data.lastName;
                this.assigneeChangeSave = true;
            } 
            //if(item.auditFailStatus.toString() === "2"){
            if(actionType === "reviewer"){ // if reviewer is changed
                item.reviewerId = data.userId;
                item.ReviewerName = data.firstName + " " + data.lastName;
                item.reviewerFirstName = data.firstName;
                item.reviewerLastName = data.lastName;
                this.reviewerChangeSave = true;
            }
            this.isReadOnly = true;
        }              
        });
        modal.present();
    }
    // Changing the corrective action assignment assignee to re-assign to a new Assignee
    public changeActionAssignmentAssignee(){
        // this function can be called both whne assignment is assigned or under review,
        // to change the assignee always send the status as 1
        const cDateTime = moment().format("MM/DD/YYYY HH:MM");
        this.correctAssignService.CorrectiveActionReassign(new CorrectiveActionReassign(this.itemData.questionId,this.selectionData.selLangCode, 
            this.itemData.machineNum.toString(), this.itemData.assigneeCompDate, this.itemData.reviewerCompDate,
            this.itemData.assgneeId, this.itemData.assigneeComments, 1/*to change the assignee always send the status as 1*/, 
            this.itemData.auditFailureId, this.itemData.failCd, 1, this.itemData.wlogin )).subscribe((response)=>{
            if(this.utSer.checkValidData(response)){
                this.assigneeChangeSave = false;
                //"success_change_assignee"
                this.utSer.showToast("success_change_assignee",+this.itemData.assigneeFirstName+" "+this.itemData.assigneeLastName );
            }
        });
        //"action_submit_review"
        let assigneeComments = "Action: Assignment re-assigned to "+this.itemData.assigneeFirstName+" "+this.itemData.assigneeLastName +" from "+this.oldAssigneeName + " for Assigned. " + this.itemData.assigneeComments;        
        this.translate.get(["action_assignment_reassigned_1","action_assignment_reassigned_2", "action_assignment_reassigned_3"]).subscribe((values)=>{
            assigneeComments = values["action_assignment_reassigned_1"]+this.itemData.assigneeFirstName+" "+this.itemData.assigneeLastName +values["action_assignment_reassigned_2"]+this.oldAssigneeName + values["action_assignment_reassigned_3"] + this.itemData.assigneeComments;        
        })
        this.correctAssignService.SubmitAssignment(new AuditFailureRouting(this.itemData.auditFailureId, this.itemData.auditFailStatus,null,this.itemData.assgneeId,
            this.itemData.assigneeCompDate,cDateTime,assigneeComments,this.itemData.image,this.itemData.imageType,this.user.wLogin)).subscribe((data)=>{
            if(this.utSer.checkValidData(data)){                
                //this.viewCtrl.dismiss({"success":"true"});   
            }
        });
    }    
    public changeActionAssignmentReviewer(){
        // this function can be called both whne assignment is assigned or under review,
        // to change the review always send the status as 2 
        const cDateTime = moment().format("MM/DD/YYYY HH:MM");
        this.correctAssignService.CorrectiveActionReassign(new CorrectiveActionReassign(this.itemData.questionId,this.selectionData.selLangCode, 
            this.itemData.machineNum.toString(), this.itemData.assigneeCompDate, this.itemData.reviewerCompDate,
            this.itemData.reviewerId, this.itemData.reviewerComments,2/*to change the reviewer always send the status as 2*/, 
            this.itemData.auditFailureId, this.itemData.failCd, 2, this.itemData.wlogin )).subscribe((response)=>{
            if(this.utSer.checkValidData(response)){               
               this.reviewerChangeSave = false;
               this.utSer.showToast("success_change_reviewer", this.itemData.reviewerFirstName+" "+this.itemData.reviewerLastName + " for Review.");
            }
        });
                
        let reviewComments = "Action: Assignment re-assigned to "+this.itemData.reviewerFirstName+" "+this.itemData.reviewerLastName +" from "+this.oldReviewerName + " for Review. " + this.itemData.reviewerComments;        
        this.translate.get(["action_assignment_reassigned_1","action_assignment_reassigned_2", "action_assignment_reassigned_3"]).subscribe((values)=>{
            reviewComments = values["action_assignment_reassigned_1"]+this.itemData.reviewerFirstName+" "+this.itemData.reviewerLastName +values["action_assignment_reassigned_2"]+this.oldReviewerName + values["action_assignment_reassigned_3"] + this.itemData.reviewerComments;        
        })
        
        this.correctAssignService.SubmitAssignment(new AuditFailureRouting(this.itemData.auditFailureId, this.itemData.auditFailStatus, null, this.itemData.reviewerId,
                                                    this.itemData.reviewerCompDate,cDateTime,reviewComments,this.itemData.image,
                                                    this.itemData.imageType,this.user.wLogin)).subscribe((data)=>{
                                                    if(this.utSer.checkValidData(data)){               
                                                        //this.viewCtrl.dismiss({"success":"true"});   
                                                    }
                                                });
    }
    public submitActionAssignemntReviewer(){
        const cDateTime = moment().format("MM/DD/YYYY HH:MM");
        if(this.isUserReviewer){
            // const reviewComments = this.utSer.replaceSpecialCharsWithSpace(this.itemData.reviewerComments);
            let reviewComments = this.itemData.reviewerComments;
            this.correctAssignService.SubmitAssignmentReviewer(new SubmitActionAssignmentReviewer(this.itemData.auditDetailId, 
                this.itemData.failCd,
                cDateTime,
                reviewComments, 
                this.user.wLogin,
                this.itemData.auditFailureId,
                this.itemData.assgneeId,
                moment(this.itemData.assigneeCompDate).format("MM/DD/YYYY"),
                this.itemData.assigneeComments,
                this.itemData.reviewerId,  
                this.selectionData.selLangCode,
                this.itemData.questionId,
                this.itemData.machineNum,
                this.itemData.reviewerCompDate,
                this.itemData.comments,
                moment(this.itemData.compDate).format("MM/DD/YYYY"), 
                this.itemData.comments, 
                this.itemData.severity,                    
                3)).subscribe((data)=>{
                if(this.utSer.checkValidData(data)){
                    this.viewCtrl.dismiss({"success":"true"});
                }
            });
            
            reviewComments = "Action: Reviewer "+ this.itemData.ReviewerName+" moved Assignment to Complete : "+reviewComments;
            this.translate.get(["assignment_complete_1", "assignment_complete_2"]).subscribe((values)=>{
                reviewComments = values["assignment_complete_1"]+ this.itemData.ReviewerName+" " + values["assignment_complete_2"]+"  : " +reviewComments;
            })
            this.correctAssignService.SubmitAssignment(new AuditFailureRouting(this.itemData.auditFailureId, 3,null,this.user.userId,
                this.itemData.reviewerCompDate,cDateTime,reviewComments,this.itemData.image,this.itemData.imageType,this.user.wLogin)).subscribe((data)=>{
                if(this.utSer.checkValidData(data)){
                    //this.viewCtrl.dismiss({"success":"true"});   
                }
            })
        }
    }
    public reassignActionAssignemntReviewer(){
        // this funciton is called to reject the Action Assignment byt he reviewer
        const cDateTime = moment().format("MM/DD/YYYY HH:MM");
        if(this.isUserReviewer){
            // const reviewComments = this.utSer.replaceSpecialCharsWithSpace(this.itemData.reviewerComments);
                let reviewComments = this.itemData.reviewerComments;
            this.correctAssignService.ReassignBackAssignmentByReviewer(new ReassignActionAssignmentReviewer(this.itemData.auditDetailId, 
                this.itemData.failCd,
                1,
                this.itemData.auditFailureId,
                this.itemData.reviewerCompDate,
                reviewComments,                
                this.user.wLogin,
                this.itemData.assgneeId,
                this.itemData.reviewerId,            
                this.itemData.questionId,
                this.selectionData.selLangCode,
                this.itemData.machineNum.toString(),
                this.itemData.reviewerCompDate,
                this.itemData.comments
                )).subscribe((data)=>{
                if(this.utSer.checkValidData(data)){
                    this.viewCtrl.dismiss({"success":"true"});
                }
            });
            reviewComments = "Action: Assignment Rejected By the Reviewer "+ this.itemData.ReviewerName+" Assigning back to Assignee "+ this.itemData.AssigneeName+" :" +reviewComments;
            this.translate.get(["assignment_rejected_1", "assignment_rejected_2"]).subscribe((values)=>{
                reviewComments = values["assignment_rejected_1"]+ this.itemData.ReviewerName+values["assignment_rejected_2"]+ this.itemData.AssigneeName+" :" +reviewComments;
            })
            this.correctAssignService.SubmitAssignment(new AuditFailureRouting(this.itemData.auditFailureId, 1,null,this.itemData.assgneeId,
                this.itemData.assigneeCompDate,cDateTime,reviewComments,this.itemData.image,this.itemData.imageType,this.user.wLogin)).subscribe((data)=>{
                if(this.utSer.checkValidData(data)){
                    // this.viewCtrl.dismiss({"success":"true"});   
                }
            })
        }
    }
    public saveActionAssignemntAssignee(){
        const cDateTime = moment().format("MM/DD/YYYY HH:MM");
        if(this.isUserAssignee){
            //const assignComments = this.utSer.replaceSpecialCharsWithSpace(this.itemData.assigneeComments);
            const assignComments = this.itemData.assigneeComments;
            this.correctAssignService.SubmitAssignmentByAssignee(new SubmitActionAssignmentAssignee(this.itemData.auditDetailId, this.itemData.failCd,this.itemData.assigneeCompDate, 
                                                                            assignComments, this.user.wLogin, this.itemData.auditFailureId,
                                                                            this.itemData.assgneeId,this.itemData.reviewerId,
                                                                            moment(this.itemData.reviewerCompDate).format("MM/DD/YYYY"),
                                                                            this.itemData.reviewerComments,
                                                                            moment(this.itemData.compDate).format("MM/DD/YYYY"),
                                                                            this.itemData.comments,   
                                                                            this.itemData.severity, 
                                                                            this.itemData.auditFailStatus, 
                                                                            this.itemData.questionId,
                                                                            this.itemData.machineNum,
                                                                            this.itemData.assigneeCompDate,
                                                                            this.itemData.comments,this.selectionData.selLangCode)).subscribe((data)=>{
                                                                            if(this.utSer.checkValidData(data)){
                                                                                this.viewCtrl.dismiss({"success":"true"});   
                                                                            }
                                                                        });
            //1= Assigned, 2=Pending Review, 3=Complete
            let assigneeComments = "Action: Assignment Saved by Assignee "+ this.itemData.AssigneeName+" : "+this.itemData.assigneeComments;
            this.translate.get(["assignment_saved_by_assignee"]).subscribe((values)=>{
                assigneeComments = values["assignment_saved_by_assignee"] + this.itemData.AssigneeName+" : "+this.itemData.assigneeComments;
            })
            
            this.correctAssignService.SubmitAssignment(new AuditFailureRouting(this.itemData.auditFailureId, 1,null,this.user.userId,
                moment(this.itemData.assigneeCompDate).format("MM/DD/YYYY"),cDateTime,assigneeComments,this.itemData.image,this.itemData.imageType,this.user.wLogin)).subscribe((data)=>{
                if(this.utSer.checkValidData(data)){
                   // this.viewCtrl.dismiss({"success":"true"});   
                }
            }) 
        }
    }
    public saveActionAssignemntReviewer(){
        const cDateTime = moment().format("MM/DD/YYYY HH:MM");
        if(this.isUserReviewer){
            // const reviewComments = this.utSer.replaceSpecialCharsWithSpace(this.itemData.reviewerComments);
            let reviewComments = this.itemData.reviewerComments;
            this.correctAssignService.SubmitAssignmentReviewer(new SubmitActionAssignmentReviewer(this.itemData.auditDetailId, this.itemData.failCd,this.itemData.reviewerCompDate, 
                reviewComments, this.user.wLogin, this.itemData.auditFailureId,
                this.itemData.assgneeId,
                moment(this.itemData.assigneeCompDate).format("MM/DD/YYYY"),
                this.itemData.reviewerComments,this.itemData.reviewerId,
                this.selectionData.selLangCode,
                this.itemData.questionId,
                this.itemData.machineNum,
                this.itemData.reviewerCompDate,
                this.itemData.comments,
                moment(this.itemData.compDate).format("MM/DD/YYYY"),this.itemData.comments,   
                this.itemData.severity, this.itemData.auditFailStatus)).subscribe((data)=>{
                if(this.utSer.checkValidData(data)){
                    this.viewCtrl.dismiss({"success":"true"});
                }
            });
            //TODO add additional comments to the 
            reviewComments = "Action: Assignment Saved by Reviewer " + this.itemData.ReviewerName+" : "+reviewComments;
            this.translate.get(["assignment_saved_by_reviewer"]).subscribe((values)=>{
                reviewComments = values["assignment_saved_by_reviewer"] + this.itemData.ReviewerName+" : "+reviewComments;
            })            
            this.correctAssignService.SubmitAssignment(new AuditFailureRouting(this.itemData.auditFailureId, 2,null,this.user.userId,
                moment(this.itemData.reviewerCompDate).format("MM/DD/YYYY"),cDateTime,reviewComments,this.itemData.image,this.itemData.imageType,this.user.wLogin)).subscribe((data)=>{
                if(this.utSer.checkValidData(data)){
                    this.viewCtrl.dismiss({"success":"true"});   
                }
            })
        }
    }    
    public dismissPopupClicked(){
        let msg = "You have made changes to the Corrective Assignment, Do you wish to Save/Submit the changes before exit ?";
        this.translate.get(["save_submit_asignment"]).subscribe((values)=>{
            msg = values["save_submit_asignment"];
        })
        if(this.isAssignmentChanged){      
            let confirm = this.alertCtrl.create({
                title: 'Alert',
                message: msg,
                buttons: [
                    {
                        text: 'No',
                        handler: () => {
                            this.viewCtrl.dismiss();                
                        }
                    },
                    {
                        text: 'Yes',
                        handler: () => {                        
                        }
                    }
                ]
                });
            confirm.present();     
        } else{
            this.viewCtrl.dismiss(); 
        }
    }
    public assignmentChange(){
        this.isAssignmentChanged = true;
    }
    public showPicture(item){
        if(item.image !== undefined && item.image !== ""){          
                let modal = this.modalCtrl.create(AnnotatePicturePage,{"isFromPage":"CorrectiveActionAssignments", 
                                                                "isAnnotatePicture":"false", 
                                                                "imageData":item.image});
                modal.onDidDismiss((data)=>{                  
                });
                modal.present();
        } else{
            this.translate.get(["imageNotAvailable"]).subscribe((values) => {
                    this.utSer.showToast(values["imageNotAvailable"],"")
            })          
        }   
    }
    public takePicture(item:CorrectActionAssgnItem, image:string):void{
        if(item[image] !== undefined){      
        if(item[image] !==""){ //
                let modal = this.modalCtrl.create(AnnotatePicturePage,{"isFromPage":"ShowFailureCodes", "isAnnotatePicture":"true"});
                modal.onDidDismiss((data)=>{
                    if(data.isTakePicture){
                            this.capturePicturefromCamera().then((imageData:string) => {
                                    // imageData is either a base64 encoded string or a file URI
                                    // If it's base64:
                                    this.utSer.showToast("imagedataReceived"+imageData.substring(0,20) ,"");
                                    if(imageData !== undefined && imageData !==""){
                                            let base64Image = 'data:image/png;base64,' + imageData;
                                            item[image] =  base64Image;
                                            //failCode.imageType = "data:image/png;base64";
                                    } else{
                                        this.utSer.showToast("imagedata is empty","");
                                    }                                
                                }, (err) => {            
                                });
                    }  else{
                            this.capturePicturefromCamera().then((imageData) => {
                                // imageData is either a base64 encoded string or a file URI
                                // If it's base64:
                                let base64Image = 'data:image/png;base64,' + imageData;
                                item[image] =  base64Image;                  
                            }, (err) => {            
                            });
                    }                  
                });
                modal.present();
        } 
        }
    }    
    private capturePicturefromCamera():Promise<Object>{
        const options: CameraOptions = {
            quality: 1,
            destinationType: this.camera.DestinationType.DATA_URL,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        }
        return this.camera.getPicture(options);
    }
    public annotatePicture(item:CorrectActionAssgnItem, image:string, isAnnotatePicture:boolean):void{
        if(item["image"] !== undefined && item["image"] !== ""){
            //console.log("image Data:-  "+ failCode.imageData);
                let modal = this.modalCtrl.create(AnnotatePicturePage,{"isFromPage":"ShowFailureCodes", 
                                                                "isAnnotatePicture":isAnnotatePicture.toString(), 
                                                                "imageData":item[image]});
                modal.onDidDismiss((data)=>{
                        if(data !== undefined){
                                if(data.isTakePicture !== undefined && data.isTakePicture){
                                        this.capturePicturefromCamera().then((imageData) => {
                                            // imageData is either a base64 encoded string or a file URI 
                                            // If it's base64:
                                        
                                            let base64Image = 'data:image/png;base64,' + imageData;
                                            item["image"] =  base64Image;
                                        }, (err) => {            
                                        });
                                }
                                if(data.imageData !== undefined && data.imageData !== ""){
                                    if(data.imageData.indexOf("data:image/jpeg") === -1 && data.imageData.indexOf("data:image/png") === -1){
                                            data.imageData = 'data:image/jpeg;base64,' + data.imageData;
                                    }
                                        //let base64Image = 'data:image/jpeg;base64,' + data.imageData;
                                    item["image"] =  data.imageData;
                                    // failCode.imageType = data.imageData.indexOf("image/png") === -1 ?  "data:image/jpeg;base64": "data:image/png;base64" ;
                                }
                        }
                });
                modal.present();
        } else{
            this.translate.get(["noImageToAnnotate"]).subscribe((values) => {
                    this.utSer.showToast(values["noImageToAnnotate"],"")
            })          
        }   
    }
    
    public fileInputChange(e:any, failCode:CorrectActionAssgnItem, image:string){
        const file = e.target.files[0];
        const imageType = /image.*/;        
        const fileType = file.type;
        failCode.imageFilePath = file.name;
        const _that = this;
        if (file.type.match(imageType)) {
                var reader = new FileReader();
                reader.onload = function(e) {				
                    let img = new Image();
                    let base64Image = reader.result;
                    img.src = base64Image;
                    failCode["image"] =  base64Image;
                    _that.isFileAdded = true;	
                    //failCode.imageType = "data:"+fileType+";base64";					
                }
                reader.readAsDataURL(file);	
        } else {				
        }
    }
    public toggleGroup(group) {
        if (this.isGroupShown(group)) {
            this.shownGroupas = null;
        } else {
            this.shownGroupas = group;
        }
    };

    public isGroupShown(group) {
        return this.shownGroupas === group;
    };
    public toggleGroup2(group) {
        if (this.isGroupShown2(group)) {
            this.shownGroupas2 = null;
        } else {
            this.shownGroupas2 = group;
        }
    };

    public isGroupShown2(group) {
        return this.shownGroupas2 === group;
    };
}
