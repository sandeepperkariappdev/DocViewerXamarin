import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { MyCorrectiveActionAssignments } from '../my-corrective-action-assignments/my-corrective-action-assignments';
import { TranslateService }  from 'ng2-translate';
/**
 * Generated class for the CorrectiveAssignments page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-corrective-assignments',
  templateUrl: 'corrective-assignments.html',
})
export class CorrectiveAssignments {
      showSelf:boolean;
      showPlant:boolean;
      tab1:any;
      tab2:any;
      selTabIndex:string;
  constructor(public navCtrl: NavController,private translate: TranslateService, public navParams: NavParams) {        
        this.showPlant = navParams.data.showPlant === 'true';
        this.showSelf = navParams.data.showSelf === 'true';
        this.tab1 = MyCorrectiveActionAssignments;
        this.tab2 = MyCorrectiveActionAssignments;       
        this.selTabIndex = navParams.data.getShowTab;
  }

  ionViewDidLoad() {    
  }
}
