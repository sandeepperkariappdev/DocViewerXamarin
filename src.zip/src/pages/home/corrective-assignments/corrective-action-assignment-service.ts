import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { AppSettings, MethodConstants } from '../../../constants/AppSettings';
import { CallService} from '../../../providers/call-service';
import { UserService} from '../../../providers/user-service';
import { UtilService} from '../../../providers/util-service';
import {SubmitActionAssignmentAssignee,CorrectiveActionReassign, SubmitActionAssignmentReviewer, AuditFailureRouting, ReassignActionAssignmentReviewer} from "../../../models/QuestionItem";

/*
  Generated class for the CorrectiveActionAssignmentServiceProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
@Injectable()
export class CorrectiveActionAssignmentServiceProvider {
  
  constructor(private callService:CallService, private userService:UserService, private utilService:UtilService) {
    
  }

  public getAssignedFailureCodesForPlant(pgNum:number,plantId:number, userId:number, assignee:number, langCode:string, startDate:string, endDate:string){    
    //http://ahdeviis01/LPADevServices/api/AssignedFailuresCodes/AssignedFailureCodesForPlant?plantId=10&userId=10
    if(userId !== undefined && plantId !== undefined && langCode !== ""){
      const url = (AppSettings.API_ENDPOINT + MethodConstants.AssignedFailureCodesForPlant+"plantId="+plantId+"&pgNum="+pgNum+"&userId="+userId+"&assigneeOrReviewer="+assignee+"&langCode="+langCode+"&startDate="+startDate+"&endDate="+endDate);
      return this.callService.callServerForGet(url,"Get Failure Codes Assigned");
    }  else{
      console.error("userId && plantI values cannot be null");
    }            
  }

  public CorrectiveActionReassign(corrActionReasign:CorrectiveActionReassign){
    const url = (AppSettings.API_ENDPOINT + MethodConstants.CorrectiveActionAssignmentReassign);
    return this.callService.callServerForPost(url, "",corrActionReasign);  
  }
  public SubmitAssignment(submitAssignment:AuditFailureRouting){
     const url = (AppSettings.API_ENDPOINT + MethodConstants.AuditFailureRouting);
    return this.callService.callServerForPost(url, "",submitAssignment);
  }
  public SaveAssignment(submitAssignment:AuditFailureRouting){
    const url = (AppSettings.API_ENDPOINT + MethodConstants.AuditFailureRouting);
   return this.callService.callServerForPost(url, "",submitAssignment);
 }
  public SubmitAssignmentByAssignee(submitAssignment:SubmitActionAssignmentAssignee){
    const url = (AppSettings.API_ENDPOINT + MethodConstants.SubmitAssignmentByAssignee);
   return this.callService.callServerForPost(url, "",submitAssignment);
 }

  public SubmitAssignmentReviewer(submitAssignment:SubmitActionAssignmentReviewer){
    const url = (AppSettings.API_ENDPOINT + MethodConstants.SubmitAssignmentReviewer);
    return this.callService.callServerForPost(url, "",submitAssignment);
  }
  //ReassignBackAssignmentByReviewer
  public ReassignBackAssignmentByReviewer(submitAssignment:ReassignActionAssignmentReviewer){
    const url = (AppSettings.API_ENDPOINT + MethodConstants.ReassignBackAssignmentByReviewer);
    return this.callService.callServerForPost(url, "",submitAssignment);
  }

  public GetCorrectiveActionHistory(failureCdId:number, langCd:string){
    const url = (AppSettings.API_ENDPOINT + MethodConstants.GetCorrectiveActionHistory+"?auditFailureId="+failureCdId+"&langCd="+langCd);
    return this.callService.callServerForGet(url, "");
  }



  //     { 
//   "auditDetailId": 1,
//   "failCode": 2,
//   "assigneeCompletionDate": "07/10/2017",
//   "assigneeComments": "test..",
//   "wlogin": "klou"
// }



// input:
// {
//   "auditDetailId": 4,
//   "failCode": 2,
//   "reviewerCompletion": "07-12-2017",
//   "reviewerComments": "test..",
//   "wlogin": "klou"
// }



}
