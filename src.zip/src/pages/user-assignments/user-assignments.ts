import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { MyCorrectiveActionAssignments } from '../home/my-corrective-action-assignments/my-corrective-action-assignments';
import {ScheduledAudits} from '../home/scheduled-audits/scheduled-audits';
/**
 * Generated class for the UserAssignmentsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-user-assignments',
  templateUrl: 'user-assignments.html',
})
export class UserAssignmentsPage {
      tab1:any;
      tab2:any;
      userId:string;
      levelId:string;
      selTabIndex:string;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
        this.tab1 = MyCorrectiveActionAssignments;
        this.tab2 = ScheduledAudits;       
        const nParams = navParams.data;
        if(nParams !== undefined){
          if(nParams.getShowTab !== undefined){
              this.selTabIndex = nParams.getShowTab;
          }
          if(nParams.userId !== undefined){
              this.userId = nParams.userId.toString();
          }
          if(nParams.levelId !== undefined){
              this.levelId = nParams.levelId.toString();
          }                                    
        }        
  }
  ionViewDidLoad() {
    
  }
}
