import { Component,OnInit} from '@angular/core';
import { NavController, ModalController, AlertController, PopoverController,IonicPage} from 'ionic-angular';
import { AuditService } from '../audit-service';
import { SearchAudits } from '../../search-audits/search-audits';
import { AuditStartResults } from '../../audit-start-results/audit-start-results';
import { SelectionPage } from '../../selection/selection';
import { UserSelectionData, UserSelectionPrivileges, ActiveAudit, UserObject, AcceptedAuditItem } from '../../../models/QuestionItem';
import { UserService } from '../../../providers/user-service';
import { Privileges } from '../../../providers/privileges';
import { UtilService } from '../../../providers/util-service';
import { Lot, Machine, Shift } from '../../../models/Level';
/**
 * Generated class for the AuditListPlantPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-audit-list-plant',
  templateUrl: 'audit-list-plant.html',
})
export class AuditListPlantPage {
    private selectionData:UserSelectionData;
    private auditList:Array<AcceptedAuditItem>;
    private showLevel:boolean; 
    private showProcess:boolean; 
    private showOperation:boolean; 
    private showProductGroup:boolean;
   constructor(public navCtrl: NavController,
                public utilService : UtilService, 
                private userService:UserService,
                private modalCtrl:ModalController, 
                private popoverCtrl:PopoverController, 
                private alertCtrl:AlertController, 
                private privileges:Privileges, 
                private auditService:AuditService){

                  const user = this.userService.getUser();
                  this.selectionData = this.userService.getUserSelection();

                  const pagePriv = this.privileges.getPageObject(user.roleName,"Audits")["plantAudits"]["search"];
                  this.showLevel = pagePriv["showLevel"];
                  this.showOperation = pagePriv["showOperation"];
                  this.showProcess = pagePriv["showProcess"];
                  this.showProductGroup = pagePriv["showProductGroup"];
   }
  
   ngOnInit(){
     this.selectionData.endDate = this.utilService.defaultPlantAuditEndDate();
     this.selectionData.startDate = this.utilService.defaultPlantAuditStartDate();
     this.selectionData.selPrId = 0;
     this.selectionData.selLevelId =0;
    this.getAllActiveAuditListForPlant();
   }
   private getAllActiveAuditListForPlant():void{
     	/*
	      @processId as int = 0,   -- 0 for all processes
	      @level as int = 0		 -- 0 for all levels
     */
     if(this.selectionData.startDate  !== "" &&
        this.selectionData.endDate !== "" && 
        this.selectionData.selPltId !== 0 &&  
        this.selectionData.selLevelId !== undefined && !isNaN(this.selectionData.selPrId) &&
        this.selectionData.selPrId !== undefined && !isNaN(this.selectionData.selPrId)){

        this.auditService.getAllActiveAuditListForPlant(this.selectionData.startDate, this.selectionData.endDate,
         this.selectionData.selPltId,  this.selectionData.selLevelId,  this.selectionData.selPrId, this.selectionData.selPGId).subscribe((data)=>{
           if(this.utilService.checkValidData(data)){
              this.auditList = data.Response;
           }          
        });
     } else{
       console.error("Values cannot be empty this.selectionData.startDate this.selectionData.endDate this.selectionData.selPltId  this.selectionData.selLevelId !== 0 && this.selectionData.selPrId !== 0");
     }      
   }
   
   private auditListItemClicked(item:AcceptedAuditItem):void{
       let selData:UserSelectionData = this.selectionData;           
            selData.selPrId = item.procId; 
            selData.selPrName = item.procName;
            selData.selLevelId = item.levelId;
            selData.machine.name = item.machineNum;
            selData.shift.name = item.shift.toString();
     this.navCtrl.setRoot(AuditStartResults,{"isReadOnly":"true",
                                          "isFromPage":"AuditsListPlantPage", 
                                          "userSelectionData":selData,
                                          "isScheduledAudit":"true", 
                                          "auditInfoDetails":item});
    //  let prompt = this.alertCtrl.create({
    //         title: 'Confirm',
    //         message: "You want to take the Audit or view?",            
    //         buttons: [
    //           {
    //             text: 'View',
    //             handler: data => {                  
    //               this.navCtrl.push(AuditStartResults,{"isReadOnly":"true","isFromPage":"AuditsListPage", "userSelectionData":this.selectionData});
    //             }
    //           },
    //           {
    //             text: 'Take',
    //             handler: data => {                  
    //                 this.navCtrl.push(AuditStartResults,{"isReadOnly":"false","isFromPage":"AuditsListPage", "userSelectionData":this.selectionData});        
    //              }
    //           }
    //         ]
    //       });
    //       prompt.present();
   }


   navToResults(){
     this.navCtrl.push(AuditStartResults);
   }
   private searchAudits():void{
      let modal = this.modalCtrl.create(SearchAudits);      
      modal.present();
   }
   presentPopover(){
      this.selectionData.endDate = this.utilService.defaultPlantAuditEndDate();
     this.selectionData.startDate = this.utilService.defaultPlantAuditStartDate();
    let popover = this.popoverCtrl.create(SelectionPage,{
      "isMandatory":"false",
      "useSelectionDataSent":"true",
      "isPopOverCtrl":"true",
      "userPrivileges":new UserSelectionPrivileges(false,this.showProductGroup,this.showProcess,this.showOperation,this.showLevel,false, 
                                                    false, true, true, false, false, 
                                                  false, false, false,false, false, 
                                                  false, false, false, false,false, false), 
      "userSelectionData": this.selectionData },{
            enableBackdropDismiss:false,
        });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData)=>{
            if(data){
                this.selectionData = data;
             this.getAllActiveAuditListForPlant();          
            }                
        });
   }
}
