import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, PopoverController } from 'ionic-angular';
import { SelectionPage } from '../../selection/selection';
import { UserSelectionData, UserSelectionPrivileges, ActiveAudit,UserObject, AcceptedAuditItem, ResponseObject  } from '../../../models/QuestionItem';
import { AuditService } from '../audit-service';
import { Privileges } from '../../../providers/privileges';
import { UserService} from '../../../providers/user-service';
import { UtilService} from '../../../providers/util-service';
import { Lot, Machine, Shift } from '../../../models/Level';
import { AuditStartResults } from '../../audit-start-results/audit-start-results';
/**
 * Generated class for the AuditListUserPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-audit-list-user',
  templateUrl: 'audit-list-user.html',
})
export class AuditListUserPage implements OnInit {
    private selectionData:UserSelectionData;
    private auditList:Array<AcceptedAuditItem>;
    private showLevel:boolean; 
    private showProcess:boolean; 
    private showOperation:boolean; 
    private showProductGroup:boolean;

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              private popoverCtrl:PopoverController, 
              private privileges:Privileges, 
              private auditService:AuditService, 
              private userService:UserService,private utilService:UtilService) {
                  
    this.selectionData = this.userService.getUserSelection();
    const user = this.userService.getUser();
    const pagePriv = this.privileges.getPageObject(user.roleName,"Audits")["plantAudits"]["search"];
                  this.showLevel = pagePriv["showLevel"] === "true";
                  this.showOperation = pagePriv["showOperation"] === "true";
                  this.showProcess = pagePriv["showProcess"] === "true";
                  this.showProductGroup = pagePriv["showProductGroup"] === "true";
  } 
   ngOnInit(){
        this.selectionData.endDate = this.utilService.defaultPlantAuditEndDate();
        this.selectionData.startDate = this.utilService.defaultPlantAuditStartDate();
        this.getAllActiveAuditListForUser();
   }
   getAllActiveAuditListForUser(){
       if(this.checkItemDefined(this.selectionData.startDate) &&
          this.checkItemDefined(this.selectionData.endDate) &&
          this.checkItemDefined(this.selectionData.selPltId) &&
         this.checkItemDefined(this.selectionData.selLevelId) &&
         this.checkItemDefined(this.selectionData.selPrId)){       

        this.auditService.getAllActiveAuditListForUser(this.selectionData.startDate, 
                                                    this.selectionData.endDate, 
                                                    this.selectionData.selPltId,  
                                                    this.selectionData.selLevelId,  
                                                    this.selectionData.selPrId,
                                                    this.userService.getUser().userId, this.selectionData.selPGId).subscribe((data:ResponseObject)=>{
            if(this.utilService.checkValidData(data)){
                this.auditList = data.Response;
            } else{
                this.utilService.showToast("","Audit are yet to be schduled for you, Change your selection and searcha gain.");
            } 
        });
      } else{
              console.error("Values cannot be null.  ");
            }
   }
   private auditItemClicked(item:AcceptedAuditItem):void{   

       let selData:UserSelectionData = this.selectionData;           
            selData.selPrId = item.procId; 
            selData.selPrName = item.procName;
            selData.selLevelId = item.levelId;
            selData.machine.name = item.machineNum;
            selData.shift.name = item.shift.toString();

       this.navCtrl.setRoot(AuditStartResults, { "isReadOnly":"false","isFromPage":"AuditsListUserPage", 
                                                "userSelectionData":selData,
                                                "isScheduledAudit":"true", 
                                                "auditInfoDetails":item});
   }
    
  ionViewDidLoad() {
    
  }

  checkItemDefined(item:any){
      return this.utilService.itemDefined(item);
  }
   presentPopover(){       
    let popover = this.popoverCtrl.create(SelectionPage,{
                                                "isPopOverCtrl":"true",
                                                "isMandatory":"false", 
                                                "userPrivileges":new UserSelectionPrivileges(false,this.showProductGroup,this.showProcess,this.showOperation,this.showLevel,
                                                                                            false, false, true, true, false, 
                                                                                            false, false, false, false, false, 
                                                                                            false, false, false, false, false, false, false), 
                                                "userSelectionData": this.selectionData },{
            enableBackdropDismiss:false,
        });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData)=>{
            if(data){
                this.selectionData = data;
                this.getAllActiveAuditListForUser();             
            }                
        });
   }
}
