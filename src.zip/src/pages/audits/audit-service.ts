import { Injectable } from '@angular/core';
import { CallService} from '../../providers/call-service';
import { AppSettings, MethodConstants } from '../../constants/AppSettings';
import 'rxjs/add/operator/map';
import { Observable }from 'rxjs/observable';
import { SubmitScheduledAudit, ResponseObject } from '../../models/QuestionItem';
import { UtilService} from '../../providers/util-service';
/*
  Generated class for the AuditStartService provider.
*/
@Injectable()
export class AuditService {

  constructor(public callService: CallService,public utilService:UtilService) {    
  }

  //This is used to get the list of Active Audits for a plant falling  between the passed Input date and the Audit End Data. (future Active Audits).
  public getAllActiveAuditListForPlant(startDate:string, endDate:string, plantId:number,  level:number,  processId:number, pgId:number):Observable<any>{  
    //processId ===0 to return for all the processes
    if((startDate !== undefined && startDate !=="" )&& (endDate !== undefined  && endDate!=="") && (plantId  !== undefined && plantId !==0) && (level  !== undefined) &&  (processId  !== undefined) ){
        //const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetAllActiveAuditListForPlant+"&startDate="+startDate+"&endDate="+endDate+"&plantId="+plantId+"&level="+level+"&processId="+processId);
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.AcceptedAuditsForUserOrPlantByCondition+"pgId="+pgId+"&plantId="+plantId+"&processId="+processId+"&level="+level+"&auditorId=0&startDate="+startDate+"&endDate="+endDate+"&condition=2");
        return this.callService.callServerForGet(url);
    } else{
        console.error('(startDate && startDate !=="" )&& (endDate && endDate!=="") && (plantId && plantId !==0) && (level) &&  (processId) values cannot be null.');
    }    
  }

  public getAllActiveAuditListForUser(startDate:string, endDate:string, plantId:number,  level:number,  processId:number, userId:number, pgId:number):Observable<any>{  
    // processId ===0 to return for all the processes
    if((startDate  !== undefined && startDate!=="")  && (endDate !== undefined  && endDate !=="") && (plantId !== undefined  && plantId!==0) &&  (level !== undefined) && (processId  !== undefined ) &&  (userId !== undefined)){
        //const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetAllActiveAuditListForUser+"&startDate="+startDate+"&endDate="+endDate+"&plantId="+plantId+"&level="+level+"&processId="+processId+"&userId="+userId);
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.AcceptedAuditsForUserOrPlantByCondition+"pgId="+pgId+"&plantId="+plantId+"&processId="+processId+"&level="+level+"&auditorId="+userId+"&startDate="+startDate+"&endDate="+endDate+"&condition=1");
        return this.callService.callServerForGet(url);
    } else{
      console.error('values cannot be null');
    }    
  }
  public getAcceptedScheduledAuditListForPlant(plantId:number, pgId:number):Observable<any>{  
    // processId ===0 to return for all the processes
    if(plantId !== undefined  && plantId!==0){
       // Not Using //const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetAcceptedActiveAuditListForPlant+"plantId="+plantId+"&processId="+processId+"&level="+level+"&startDate="+startDate+"&endDate="+endDate);
         const url =  (AppSettings.API_ENDPOINT + MethodConstants.AcceptedAuditsForUserOrPlantByCondition+"pgId="+pgId+"&plantId="+plantId+"&processId=0&level=0&auditorId=0&startDate=&endDate=&condition="+2);
        return this.callService.callServerForGet(url);
    } else{
      console.error(' values cannot be null');
    }    
  }

  public getAcceptedActiveAuditListForPlant(startDate:string, endDate:string, plantId:number, level:number, processId:number, pgId:number):Observable<any>{  
    // processId ===0 to return for all the processes
    if((startDate !== undefined ) && (endDate !== undefined ) && (plantId !== undefined  && plantId!==0) &&  (level !== undefined) && (processId  !== undefined )){
       // Not Using //const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetAcceptedActiveAuditListForPlant+"plantId="+plantId+"&processId="+processId+"&level="+level+"&startDate="+startDate+"&endDate="+endDate);
         const url =  (AppSettings.API_ENDPOINT + MethodConstants.AcceptedAuditsForUserOrPlantByCondition+"pgId="+pgId+"&plantId="+plantId+"&processId="+processId+"&level="+level+"&auditorId=0&startDate="+startDate+"&endDate="+endDate+"&condition="+5);
        return this.callService.callServerForGet(url);
    } else{
      console.error(' values cannot be null');
    }    
  }
//
  public getScheduledAuditForUserByPlantId(auditorId:number,startDate:string, endDate:string, plantId:number, level:number, processId:number, pgId:number):Observable<any>{  
    // processId ===0 to return for all the processes
    if((startDate !== undefined ) && (endDate !== undefined ) && (plantId !== undefined  && plantId!==0) &&  (level !== undefined) && (processId  !== undefined) && (auditorId  !== undefined)){
        //Not using //const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetScheduledAuditForUserByPlantId+"plantId="+plantId+"&processId="+processId+"&level="+level+"&auditorId="+auditorId+"&startDate="+startDate+"&endDate="+endDate);
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.AcceptedAuditsForUserOrPlantByCondition+"pgId="+pgId+"&plantId="+plantId+"&processId="+processId+"&level="+level+"&auditorId="+auditorId+"&startDate="+startDate+"&endDate="+endDate+"&condition="+1);
        return this.callService.callServerForGet(url);
        // .map((resp:ResponseObject) => {
        //   if(this.utilService.checkValidData(resp)){   
        //           resp.Response.reduce((prev, item)=>{

        //               return prev;
        //           }, []);
        //       return ;
        //   }
        // });
    } else{
      console.error('values cannot be null');
    }    
  }
    public getSavedInCompleteAuditForUserByPlantId(auditorId:number,startDate:string, endDate:string, plantId:number, level:number, processId:number, pgId:number):Observable<any>{      
    if((startDate !== undefined ) && (endDate !== undefined ) && (plantId !== undefined  && plantId!==0) &&  (level !== undefined) && (processId  !== undefined) && (auditorId  !== undefined)){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.AcceptedAuditsForUserOrPlantByCondition+"pgId="+pgId+"&plantId="+plantId+"&processId="+processId+"&level="+level+"&auditorId="+auditorId+"&startDate="+startDate+"&endDate="+endDate+"&condition="+6);
        return this.callService.callServerForGet(url);        
    } else{
      console.error('values cannot be null');
    }    
  }


  public postScheduleAcceptedAuditToUser(submitScheduledAudit:SubmitScheduledAudit):Observable<any>{     
    if(submitScheduledAudit !== undefined){
        const url =  (AppSettings.API_ENDPOINT + MethodConstants.ScheduleAcceptedAuditToUser);
        return this.callService.callServerForPost(url, "" ,[submitScheduledAudit]);
    } else{
      console.error('data values cannot be null');
    }    
  }

    public modifyScheduleAcceptedAuditToUser(submitScheduledAudit:SubmitScheduledAudit):Observable<any>{     
        if(submitScheduledAudit !== undefined){
          //sau.auditId, sau.auditorId, sau.lotNum, sau.shift, sau.machineNum, sau.comments, sau.wlogin 
            const url =  (AppSettings.API_ENDPOINT + MethodConstants.ModifyAcceptedAuditForUser);
            return this.callService.callServerForPost(url, "" ,submitScheduledAudit);
        } else{
          console.error('data values cannot be null');
        }    
  }

  public deleteScheduleAcceptedAuditToUser(auditId:number,auditorId:number):Observable<any>{     
        if(auditId !== undefined && auditorId !== undefined && auditId !== 0 && auditorId !== 0){
            //http://ahdeviis01/LPADevServices/api/ScheduleAcceptedAudits/deleteScheduleAcceptedAuditForUser?auditId=0&auditorId=0
            const url =  (AppSettings.API_ENDPOINT + MethodConstants.DeleteScheduleAcceptedAuditForUser+"auditId="+auditId+"&auditorId="+auditorId);
            return this.callService.callServerForDelete(url, "");
        } else{
          console.error('data values cannot be null');
        }    
  }
  public getMachinesFromScheduledAudits(plantId:number, processId:number, levelId:number, startDate:string, endDate:string){
      if(plantId!== 0 && processId!== undefined && levelId!== 0 && startDate!=="" && endDate!==""){
          //http://ahdeviis01/LPADevServices/api/ScheduledMachines/getMachinesFromScheduledAudits?plantId=1&processId=1&levelId=1&startDate=01/01/2000&endDate=12/30/2017
           const url =  (AppSettings.API_ENDPOINT + MethodConstants.GetMachinesFromScheduledAudits+"plantId="+plantId+"&processId="+processId+"&levelId="+levelId+"&startDate="+startDate+"&endDate="+endDate);
            return this.callService.callServerForGet(url, "");
      }    
  } 
}