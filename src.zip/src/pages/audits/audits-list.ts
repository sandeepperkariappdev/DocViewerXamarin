import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import * as moment from  'moment';

import {AuditListPlantPage} from './audit-list-plant/audit-list-plant';
import {AuditListUserPage} from './audit-list-user/audit-list-user';
import {Privileges} from '../../providers/privileges';
import {UserService} from '../../providers/user-service';
import { User } from '../../models/user';
// import { ScheduledAudits} from '../home/scheduled-audits/scheduled-audits';
// import { UnScheduledAudits} from '../home/un-scheduled-audits/un-scheduled-audits';
/**
 * Generated class for the AuditsListPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-audits-list',
  templateUrl: 'audits-list.html',
})
export class AuditsListPage {
      showSelf:boolean;
      showPlant:boolean;
      tab1:any;
      tab2:any;
      user:User;
       pageName:string; 
      selTabIndex:string;
  constructor(public navCtrl: NavController, public navParams: NavParams, private privileges:Privileges, private userService:UserService) {
        this.pageName = "Audits";
        this.user = this.userService.getUser();
        const pagePriv = this.privileges.getPageObject(this.user.roleName,this.pageName);    
        this.showSelf = pagePriv["selfAudits"] ? pagePriv["selfAudits"]["thisShow"] === "true": false;
        this.showPlant= pagePriv["plantAudits"] ? pagePriv["plantAudits"]["thisShow"] === "true": false;
        this.tab1 = AuditListUserPage;
        this.tab2 = AuditListPlantPage;       
        this.selTabIndex = '0';        
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AuditsListPage');
  }

}
