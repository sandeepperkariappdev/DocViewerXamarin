import { Component,OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import {FailureCodeTemp} from '../../models/failureCode';
import {QuestionItem, Questions} from '../../models/QuestionItem';
/**
 * Generated class for the EditAuditQuestion page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */



@Component({
  selector: 'page-edit-audit-question',
  templateUrl: 'edit-audit-question.html',
})
export class EditAuditQuestion implements OnInit{
  questionObject:Questions;
  constructor(public navCtrl: NavController, public navParams: NavParams, private viewCtrl:ViewController) {    
  }
  ngOnInit(){
    if(this.navParams.data &&  this.navParams.data.Q){
        this.questionObject = this.navParams.data.Q; 
    }
  }
  addNewFailureCode(){
    //this.questionObject.questions.failureCodes.push({failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true});
  }
  private removeNewFailureCode(index:number):void{
    //this.questionObject.FailureCodes.splice(index, 1);
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad EditAuditQuestion');
  }
  submit(){
    let data = {'data':'data'}
    this.viewCtrl.dismiss(data);
  }
  dismiss(){
    this.viewCtrl.dismiss();
  }
}


      