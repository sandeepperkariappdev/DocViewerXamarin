import { Component } from '@angular/core';
import { IonicPage, ModalController, NavController, NavParams, AlertController  } from 'ionic-angular';
import {OrderByPipe} from '../../../filters/order-by-pipe';


import {QuestionItem} from '../../../models/QuestionItem';
import {QuestionsList} from '../../../models/QuestionsList';
import {QuestionFailureCodeDetails} from '../question-failure-code-details/question-failure-code-details';
import { UpdateQuesFailureCodeModals } from '../../../popup-modals/update-ques-failure-code-modals/update-ques-failure-code-modals';

import * as _ from 'lodash';
/**
 * Generated class for the AdminCreateAudit page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-admin-create-audit',
  templateUrl: 'admin-create-audit.html',
  providers:[OrderByPipe],
})
export class AdminCreateAudit {
    categoryList:Array<any>;
    selLanguage:String;
    selCategory:String;   
    languagesList:Array<any>;


    quesRespFromServer:Array<QuestionsList>;
    createAuditQueArray:Array<QuestionsList>;
    questionsresponse:Array<QuestionsList>;
    tempSelandUNSelList:Array<QuestionsList>;
    tempSelList:Array<QuestionsList>;
    tempUnSelList:Array<QuestionsList>;
    tempQuestList:Array<QuestionsList>;
    count:number = 0;
    isMandate:boolean;
    isEdit:boolean;
    buttonSel:string;
    orderSel:boolean;
    orderCount: number = 0;
    isDetails:boolean;
    showFailureCodesForQues:boolean;
    showCreateAuditButton:string;
    showItemDetails:string;


  constructor(public navCtrl: NavController, public navParams: NavParams,  public modalCtrl:ModalController, private orderByPipe:OrderByPipe, private alertCtrl: AlertController) {
     this.categoryList = ["All",
         "Specific Work Instructions (SWIs)",
         "Operator and Process - (for 3 Consecutive Jobs)",
         "Work Station and Equipment",
         "Process Controls:  Quality Alerts, Error Proofing & Gaging"];
        this.languagesList = ["English","Spanish","Chinese", "Portuguese","Thai","Hungarian"];   

/*
this.quesRespFromServer = [{
       questionSectionName :"Specific Work Instructions ",
      questionsArray: [{ queDesc:'3', QUESTIONS_DESC:' The SWIs are present, visible and readable.', sequence:'2',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'1', QUESTIONS_DESC:'The SWIs contain set-up instructions, operator instructions, tools needed and Personal Protective Equipment (PPE) or other Safety requirements', sequence:'12',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'2', QUESTIONS_DESC:'All documents and pictures are current, display the same part number and revision (rev) level', sequence:'3',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'4', QUESTIONS_DESC:'All set-up sheets and log sheets are completed accurately', sequence:'24',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'5', QUESTIONS_DESC:'Are they in the language of the operator using them', sequence:'5',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'6', QUESTIONS_DESC:'Is the operator following the process steps on the SWI', sequence:'6',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'7', QUESTIONS_DESC:'When SWI requires checks by operators i.e. Red Rabbit, are there instructions or SWI\'s on how to complete the check', sequence:'7',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'8', QUESTIONS_DESC:'Do SWI requirement include how to perform the process step', sequence:'8',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'9', QUESTIONS_DESC:'When part numbers are listed on the SWI, do they match parts used in the process', sequence:'9',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'10', QUESTIONS_DESC:'When part numbers are listed on the SWI are the containers labeled with those part numbers', sequence:'10',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'11', QUESTIONS_DESC:'Visual checks on SWI are included on Process Control Check Sheet', sequence:'11',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]}] 
    }, 
    { 
      questionSectionName:"OperatorAndProcess",
      questionsArray:[{queDesc:'3', QUESTIONS_DESC:'The starting Build sequence Number is: ', sequence:'1',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'12', QUESTIONS_DESC:'Operator has been trained on/for this operation/job', sequence:'2',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'13', QUESTIONS_DESC:'They are wearing the PPE per the SWIs', sequence:'3',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'14', QUESTIONS_DESC:'Component parts are safely accessible & reached ergonomically', sequence:'4',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'15', QUESTIONS_DESC:'They follow the SWI and process flow in sequence', sequence:'5',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'16', QUESTIONS_DESC:'They use the required hand tooling as specified', sequence:'6',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'17', QUESTIONS_DESC:'They use ergonomic assist devices as specified', sequence:'7',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'18', QUESTIONS_DESC:'Safety, gage and error proof checks are performed at correct frequency', sequence:'8',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'19', QUESTIONS_DESC:'Are parts are packed correctly, in the proper clean/undamaged container with old labels removed and tagged correctly', sequence:'9',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'20', QUESTIONS_DESC:'Electric cables are not knotted or endanger operators', sequence:'10',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'21', QUESTIONS_DESC:'Identification of materials used for production and products', sequence:'11',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]}]     
    },
    { 
      questionSectionName:"Work Station and Equipment",
      questionsArray:[{queDesc:'3', QUESTIONS_DESC:'Area is clean, clear of obstacles, organized to prevent hazards and contains no unidentified parts ', sequence:'1',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'12', QUESTIONS_DESC:'Safety equipment and guards are in place and functioning properly', sequence:'2',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'13', QUESTIONS_DESC:'Components and materials are in correct containers and clearly identified', sequence:'3',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'14', QUESTIONS_DESC:'Containers are in satisfactory condition', sequence:'4',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'15', QUESTIONS_DESC:'Scrap is clearly identified and placed in appropriate area', sequence:'5',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'16', QUESTIONS_DESC:'Work In Process (WIP) levels are acceptable within min/max levels', sequence:'6',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'17', QUESTIONS_DESC:"The tools used in the work station are identical to those identified in the SWI's and in acceptable condition", sequence:'7',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'18', QUESTIONS_DESC:'Safety and Significant Product Characteristics signage present and in good condition', sequence:'8',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'19', QUESTIONS_DESC:'Documents that require signatures have all required signatures present', sequence:'9',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'20', QUESTIONS_DESC:"There is a designated labeled area for Master Sample, First Off and Red Rabbit's", sequence:'10',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'21', QUESTIONS_DESC:'Machine lockouts are identified, E-Stop buttons are accessible and functioning properly', sequence:'11',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]}]     
    },
    { 
      questionSectionName:"Process Controls:  Quality Alerts, Error Proofing & Gaging",
      questionsArray:[{queDesc:'3', QUESTIONS_DESC:'Quality Alerts are posted, current and followed', sequence:'1',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'12', QUESTIONS_DESC:'Error proofing, if present, is identified, functioning per specification and documented', sequence:'2',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'13', QUESTIONS_DESC:'Torque calibrations (Cal) are current.', sequence:'3',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'14', QUESTIONS_DESC:'Gage is clean and functioning.', sequence:'4',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'15', QUESTIONS_DESC:'If gage present/required, gage instructions are present & accurate to process', sequence:'5',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'16', QUESTIONS_DESC:'Gage process is followed as specified', sequence:'6',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'17', QUESTIONS_DESC:"If gage present, parts pass gage check and results documented", sequence:'7',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'18', QUESTIONS_DESC:'Requirements on Process Control Check Sheet include characteristic inspection method', sequence:'8',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'19', QUESTIONS_DESC:'If specified, are traceability requirements being documented', sequence:'9',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'20', QUESTIONS_DESC:"Have a Quality Inspector Inspect parts on the gage, does the part(s) fit the gage", sequence:'10',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]},
      { queDesc:'21', QUESTIONS_DESC:'Have all inspection been completed, documented correctly and 1st part present, tagged and acceptable (dimensional, weld integrity, visual)', sequence:'11',isAlloted:false, isMandatory:false, Pass:true, Fail:true, NA:true, FailureCodes:[{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true},{failCodeId:"",failCodeHelp:"",failDesc:"",seqId:"",isActive:true}]}]     
    }];*/
      this.questionsresponse = this.quesRespFromServer;
     this.tempQuestList = _.cloneDeep(this.questionsresponse);
      this.tempSelandUNSelList = _.cloneDeep(this.questionsresponse);
      this.isMandate = false;
      this.isEdit = false;
      this.buttonSel = '';
      this.orderSel = false;
      this.showFailureCodesForQues = false;
      this.isDetails = false;
      this.showCreateAuditButton = '';
      this.showItemDetails='';

     
  }
    onCategoryChange(event:Event):void{
        this.questionsresponse = this.quesRespFromServer.reduce((prev, item)=>{ if(item.questionSectionName === this.selCategory){ prev.push(item);  } return prev;},[]);
    }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AdminCreateAudit');
  }
 private sortSelectionClicked($event:any):void{
       this.buttonSel = 'sortSel';
       this.questionsresponse = this.questionsresponse.reduce((prevItem, currItem,index, array) => {
         let obj = {questionSectionName: currItem.questionSectionName ,questionsArray : []}
         this.orderByPipe.transform(currItem.questionsArray,'sequence');      
         obj.questionsArray =  this.orderByPipe.value
         prevItem.push(obj);
         return prevItem;
       }, []);
       //this.orderByPipe.transform(this.questionsresponse[0].questionsArray,'sequence');      
      // this.questionsresponse[0].questionsArray =  this.orderByPipe.value;
       this.buttonSel = '';
      console.log("showSelectedClicked")
    }
    private showAllClicked($event):void{
       this.buttonSel = 'showAll';
      if(this.tempSelandUNSelList.length > 0){
          this.questionsresponse = this.tempSelandUNSelList;
      } else{
        this.questionsresponse = this.tempQuestList;
      }      
    }
    private selEditClicked($event:any):void{
        this.isEdit = true;
        this.buttonSel='showEdit';
    }
    private selDetailsClicked():void{
        this.isDetails = true;
        this.showItemDetails = 'showSelDetails';
    }
    private showSelectedClicked($event:any):void{
         this.buttonSel = 'showSel';
         this.questionsresponse = this.doSelectionUnSel(this.tempSelandUNSelList ,true);      
         this.showCreateAuditButton = 'showSaveButtons';
    }
    private doSelectionUnSel(allQueSelUnSelList:Array<QuestionsList>, returnSel:boolean):Array<QuestionsList>{
              let queRespSelUnSel = allQueSelUnSelList.reduce((x,item) =>{ 
              let obj = {objSel:{questionSectionName:'',questionsArray:[] }, objUnSel : {questionSectionName:'',questionsArray:[] }};
                                                            obj.objSel.questionSectionName = item.questionSectionName;
                                                            obj.objUnSel.questionSectionName = item.questionSectionName;
                                                            let reducedQuesArray = item.questionsArray.reduce((y,i) =>{ 
                                                                                                      if(i.isAlloted == true){                                                                                                  
                                                                                                        y.selectedItems.push(i)
                                                                                                    } else{
                                                                                                        y.unSelectedItems.push(i)
                                                                                                    }; 
                                                                                                    return y;
                                                                                                },{selectedItems:[],unSelectedItems:[]});
                                                            obj.objSel.questionsArray = reducedQuesArray.selectedItems;
                                                            obj.objUnSel.questionsArray = reducedQuesArray.unSelectedItems
                                                            x.push(obj); 
                                                            return x;
                                                          },[]);
                                                                
            this.tempSelList = queRespSelUnSel.reduce((prev, item)=>{ prev.push( item.objSel); return prev; },[]);
            /*this.tempSelandUNSelList = queRespSelUnSel.reduce((prev, item)=>{ 
                                        let obj= {questionSectionName:'',questionsArray:[] }; 
                                        obj.questionsArray = obj.questionsArray.concat(item.objSel.questionsArray);  
                                        obj.questionsArray = obj.questionsArray.concat(item.objUnSel.questionsArray);
                                        prev.push(obj);
                                        return prev; 
                                      },[]);*/
            this.tempUnSelList = queRespSelUnSel.reduce((prev, item)=>{ prev.push( item.objUnSel); return prev; },[]);;
      return returnSel? this.tempSelList:this.tempUnSelList;
    }

    private unDoAllSelectionClicked():void{
       this.buttonSel = 'showUnDoAll';
       this.questionsresponse = _.cloneDeep(this.tempQuestList);
       this.tempSelandUNSelList = _.cloneDeep(this.questionsresponse);       
    }
    private createNewQuestion():void{
        let modal = this.modalCtrl.create(UpdateQuesFailureCodeModals);
        modal.present();
    }
    private selFailureCodesClicked():void{
        this.showFailureCodesForQues = !this.showFailureCodesForQues;
    }

    private showUnSelectionClicked($event:any):void{ 
        this.buttonSel = 'showUnSel';
        this.questionsresponse = this.doSelectionUnSel(this.tempSelandUNSelList, false);       
    }
    private orderSelectionClicked($event:any):void{
          this.buttonSel = 'showOrderSel';
          this.questionsresponse = this.doSelectionUnSel(this.tempSelandUNSelList ,true);   
          this.orderSel = true;
          this.orderCount = 0;
    }
    isHighlighted( queIt){
        var xx = queIt;// [class.selected]="isHighlighted(que)" 
    }
    private selectQue(e:any ,qitem : QuestionItem,index:number): void{
      // this.tempSelandUNSelList = _.cloneDeep(this.questionsresponse);
   // _.filter
    /*const classList= e.target.parentElement.parentElement.classList;
    const classListArray = e.target.parentElement.parentElement.classList.value.split(' ');
    if(classListArray.indexOf('selected') != -1){
        classList.remove('selected');
    } else{
        classList.add('selected');
    } */   
      if(this.orderSel){
          this.orderCount ++;
          qitem.sequence =  this.orderCount.toString();
      } else if (this.isDetails){
  
        this.navCtrl.push(QuestionFailureCodeDetails,qitem);
      } else{      
          this.count ++;
          qitem.sequence =  this.count.toString();
          qitem.isAlloted = !qitem.isAlloted;    
        //   if(this.isMandate){
        //     qitem.isMandatory = true;
        //   }
          this.tempSelandUNSelList  =this.tempSelandUNSelList.reduce((prev, item) =>{
                                          item.questionsArray.reduce((prev, i)=> { 
                                            if(i.queDesc === qitem.queDesc){
                                                  i.isAlloted = qitem.isAlloted;
                                                  i.isMandatory = qitem.isMandatory;
                                                  i.sequence = qitem.sequence;
                                              }   
                                              prev.push(i);
                                              return prev;
                                            },[]);
                                      prev.push(item); 
                                      return prev;
                                      },[]);

          }   
     }


     reorderItems(indexes, queItem, index) {
        //let element = this.questionsresponse[index].questionsArray[indexes.from];
        const queArrConst = this.questionsresponse[index].questionsArray;
        let movFrmEle = queArrConst[indexes.from-1];
        let movToEle = queArrConst[indexes.to-1];
        
        let seqFrmEle = movFrmEle.sequence;
        movFrmEle.sequence = movToEle.sequence;      
        movToEle.sequence =  seqFrmEle;    
        queArrConst[indexes.to-1] =  movToEle;
        let movEle = queArrConst.splice(indexes.from -1, 1)[0];
        queArrConst.splice(indexes.to-1, 0, movEle);
        
        this.tempSelandUNSelList  = this.questionsresponse;
        //| orderBy : 'sequence'
    }
    cancelAdtsFrmSelQues():void{
          this.showCreateAuditButton = '';
    }
    createAdtsFrmSelQues():void{
      const that = this;
      let prompt = this.alertCtrl.create({
            title: 'Create Audit',
            message: "Enter a name to create Audit for Questions Selection",
            inputs: [
              {
                id:'audit-name-id',
                name: 'audit-name',
                placeholder: 'Audit Name'
              },
            ],
            buttons: [
              {
                text: 'Cancel',
                handler: data => {
                  console.log('Cancel clicked');
                  prompt.dismiss();
                }
              },
              {
                text: 'Save',
                handler: data => {
                  console.log('Saved clicked');
                  that.createAuditQueArray = that.questionsresponse;                
                  prompt.dismiss();
                  // get the question selection in to an Array to pass it to the server.    
                 }
              }
            ]
          });
          prompt.present();
    }

}
/*

"Process Specific JIT",
         "Process Specific Foam",
         "Process Specific Structures",
         "Process Specific Electrical",
         "Process Specific Electronics",
         "Process Specific Trim",
         "Process Specific Fabric",
         "Process Specific Leather",
         "Process Specific Terminals and Connectors",
         "Process Specific Wiring",
        "Logistics, Warehouse, Material Handling, Incoming inspection and Expedition",
        "Customer Specific Daimler",
        "Customer Specific FCA",
        "Customer Specific Ford",
        "Customer Specific GM",
        "Customer Specific Hyundai",
        "Customer Specific JLR",
        "Customer Specific Mahindra",
        "Customer Specific PSA",
        "Customer Specific VW/Skoda/Audi/Porsche",
        "Visual Management"*/