import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { Questions, CreateAudit,AuditDetailsFailureCode, CreateActiveAuditRequest, ScheduleAuditToUser, AssignRevAssigneeFailureCodes, FailCodeCategoryAssigningList, AssignFailCodeCategoryRequest } from '../../../models/QuestionItem';
import { CallService} from '../../../providers/call-service';
import { UserService} from '../../../providers/user-service';
import { UtilService} from '../../../providers/util-service';
import { Observable }from 'rxjs/observable';
import 'rxjs/add/operator/map';
import { AppSettings, MethodConstants } from '../../../constants/AppSettings';

/*
  Generated class for the AuditDetailsServiceProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class AuditDetailsServiceProvider {

  constructor(public http : Http, 
              private userService : UserService,
              private callService : CallService,
              private utilService : UtilService) {
    
  }
  public getAuditDetailsByPrcIdLngLevelId(prcId:number, langCode:string, levelId:number, plantId:number, viewPlantQues:number){
    if((prcId !== undefined  && prcId !== 0) && (langCode !== undefined  && langCode !=="") && (levelId !== undefined  && levelId !==0) && (plantId !== undefined  && plantId !==0)){
        const url =  (AppSettings.API_ENDPOINT+ MethodConstants.GetAuditQuesFailCode+"processId="+prcId+"&langCode="+langCode+"&level="+levelId+"&plantId="+plantId+"&viewPlantQues="+2)
        return this.callService.callServerForGet(url);
    } else{
      console.error('values cannot be null');
    }   
  }

  public scheduleAuditToUser(scheduleAuditToUserRequest:Array<ScheduleAuditToUser>){
      const url =  (AppSettings.API_ENDPOINT+ MethodConstants.ScheduleAuditToUser);
      return this.callService.callServerForPost(url,"", scheduleAuditToUserRequest);
  }
  public createActiveAuditsByDateAndPlant(pltId:number, startDate:string, endDate:string,  prcId:number, levelId:number, wLogin:string){
    //http://ahdeviis01/LPAServices/api/AuditLevels/createActiveAudits?plant_id=1&startDate=05/19/2017&endDate=05/25/2017&processId=2&level=1&user=DDAI
    if((pltId !== undefined  && pltId !==0) && (startDate !== undefined  && startDate !=="") && (endDate !== undefined && endDate !== "") && (prcId !== undefined  && prcId !==0) && (levelId !== undefined  && levelId !==0)  && (wLogin !== undefined && wLogin!=="")){
      const url =  (AppSettings.API_ENDPOINT+ MethodConstants.CreateActiveAudits);
//"plantId="+pltId+"&startDate="+startDate+"&endDate="+endDate+"&processId="+prcId+"&level="+levelId+"&wLogin="+wLogin

      return this.callService.callServerForPost(url,"",new CreateActiveAuditRequest(pltId,startDate,endDate, prcId, levelId, wLogin));
    } else{
      console.error('values cannot be null.');
    }
  }
  private  buildAssignRevAsgneFailCodesReq(data:Array<AuditDetailsFailureCode>){
        const plantId = this.userService.getUserSelection()["selPltId"];
        const wLogin = this.userService.getUser()["wLogin"];
        if(this.utilService.itemDefined(plantId) && this.utilService.itemDefined(wLogin) && plantId!== 0 ){
            return data.reduce((prev, item) => {
                  const resp:Array<AssignRevAssigneeFailureCodes> = item.question.reduce((p, i) => {
                      p.push(new AssignRevAssigneeFailureCodes(plantId, 
                                                              item.failCode,
                                                              item.assigneeId,
                                                              item.reviewerId,
                                                              item.severity,
                                                              wLogin));
                      return p;
                  },[])
                  prev = prev.concat(resp);
                return prev;
              },[]);
        } else{
          console.error("values cannot be null");
        }      
  }

 private  buildAssignRevAsgneFailCodesCategory(data:Array<FailCodeCategoryAssigningList>){
        const plantId = this.userService.getUserSelection()["selPltId"];
        const wLogin = this.userService.getUser()["wLogin"];
        if(this.utilService.itemDefined(plantId) && this.utilService.itemDefined(wLogin) && plantId!== 0 ){
            return data.reduce((prev, item) => {                  
                      prev.push(new AssignFailCodeCategoryRequest(plantId,wLogin,item.failureCdCatId,item.severity,item.assigneeId,item.reviewerId));
                  return prev;
              },[]);
        } else{
          console.error("values cannot be null");
        }      
  }

  public assignReviewerAssigneeToFailureCode(data:Array<AuditDetailsFailureCode>){        
      const url =  (AppSettings.API_ENDPOINT+ MethodConstants.AssignReviewerAssigneeToFailureCode);
      return this.callService.callServerForPost(url,"",this.buildAssignRevAsgneFailCodesReq(data));    
  }
  public assignPlantAssigneeReviewerToFailCodeCategory(data:Array<FailCodeCategoryAssigningList>){        
      const url =  (AppSettings.API_ENDPOINT+ MethodConstants.AssignAssigneeToPlantFailCodeCategory);
      return this.callService.callServerForPost(url,"",this.buildAssignRevAsgneFailCodesCategory(data));    
  }
  
}
