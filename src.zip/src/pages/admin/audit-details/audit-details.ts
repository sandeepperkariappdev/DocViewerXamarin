import { Component, OnInit, ElementRef, ChangeDetectorRef, } from '@angular/core';
import { IonicPage, ModalController, NavController, NavParams, ViewController, AlertController, PopoverController } from 'ionic-angular';
import { EditAuditQuestion } from '../../edit-audit-question/edit-audit-question';
import { AssignFailureCodesPage } from '../../assign-failure-codes/assign-failure-codes';
import { AssignToFailureCodesCategoriesPage } from '../../assign-to-failure-codes-categories/assign-to-failure-codes-categories';
import { AdminQuestions } from '../admin-manage-questions/admin-manage-questions';
import { AuditDetailsServiceProvider } from './audit-details-service';
import { OrderByPipe } from '../../../filters/order-by-pipe';
import * as _ from 'lodash';
import { AdminManageQuesServiceProvider } from '../admin-manage-questions/admin-manage-ques-service';
import { Search } from '../../../popup-modals/search/search';
import {
    ResponseObject, AuditQuestion, AuditQuestions, FailCodeCategoryAssigningList, AuditFailureCode, ReqFCAssgneRvwerChange, QuestionItem, UsersInPlant, Questions, Question, AuditDetailsFailureCode, AuditDetailsQuestion,
    AuditDetailsFailureCodeQuestion, CreateAudit, FailCodeCategoryList, CreateAuditQuestion, UserSelectionPrivileges, UserSelectionData
} from '../../../models/QuestionItem';
import { QuestionsList } from '../../../models/QuestionsList';
import { AdminManageFailureCodesService } from "../../admin-manage-failure-codes/admin-manage-failure-codes-service";
import { I18n } from '../../../constants/AppSettings';
import { QuestionFailureCodeDetails } from '../question-failure-code-details/question-failure-code-details';
import { UpdateQuesFailureCodeModals } from '../../../popup-modals/update-ques-failure-code-modals/update-ques-failure-code-modals';
import { Privileges } from '../../../providers/privileges';
import { UtilService } from '../../../providers/util-service';
import { InitialDataService } from '../../../providers/initial-data-service';
import { SearchUsersInPlant } from '../../../popup-modals/search-users-in-plant/search-users-in-plant';
import { UserService } from '../../../providers/user-service';
import { User } from '../../../models/user';
import { Level, Layer, Category, Role, Language, ProductGroup, Lot, Machine, Shift, Process } from '../../../models/Level';
import { SelectionPage } from '../../selection/selection';
import { TranslateService } from 'ng2-translate';
/**
 * Generated class for the AuditDetails page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
    selector: 'page-audit-details',
    templateUrl: 'audit-details.html',
    providers: [OrderByPipe],
})
export class AuditDetails implements OnInit {
    public failCodesCatList: Array<FailCodeCategoryAssigningList>;
    private shownGroupas = null;//to show or hide used for accordion
    private editQue: boolean;
    private selectionData: UserSelectionData;
    private categoryList: Array<any>;
    private selLanguage: String;
    private selCategory: String;
    private languagesList: Array<any>;
    private zeroSequenceSel: Array<AuditQuestions>
    private questionsresponse: Array<AuditQuestions>;
    private tempSelandUNSelList: Array<AuditQuestions>;
    private tempSelList: Array<AuditQuestions>;
    private tempUnSelList: Array<AuditQuestions>;
    private tempQuestList: Array<AuditQuestions>;
    private count: number = 0;
    private isMandate: boolean;
    private isEdit: boolean;
    private buttonSel: string;
    private orderSel: boolean;
    private orderCount: number = 0;
    private isDetails: boolean;
    private showFailureCodesForQues: boolean;
    private showAddNewQues: string;
    private user: User;
    private pageName: string;
    private isFromAuditDetails: boolean;
    private pageTitle: string;
    private showAuditDetailsAddNewQues: boolean;
    private reqAuditDtsAddNewQues: string;
    private showAcceptAuditButton: boolean;
    private selPgName: string;
    private selOpName: string;
    private selProcName: string;
    private selPrcId: number;
    private selLevelId: number;
    private selLangCode: string;
    private title: string;
    showAllQue: boolean;
    public deleteQues: boolean;
    private isCorpLogin: boolean;
    private isActivePage: boolean;
    private showAddNewQueToQueMaster: boolean;
    private showPlantAudits: boolean;
    private addPGSpecfcQuestions: boolean;
    private assignedFailureCodes: boolean;
    private auditDetailsQuestionFailureCode: Array<AuditDetailsFailureCode>;
    private isReadOnly: boolean;
    public isLPAAudits: boolean;
    constructor(public navCtrl: NavController,
        private viewCtrl: ViewController,
        private adminManageFCService: AdminManageFailureCodesService,
        private alertCtrl: AlertController,
        private navParams: NavParams,
        public elRef: ElementRef,
        private privileges: Privileges,
        private userService: UserService,
        private changeDetref: ChangeDetectorRef,
        public modalCtrl: ModalController,
        private orderByPipe: OrderByPipe,
        private utilService: UtilService,
        private popoverCtrl: PopoverController,
        private translate: TranslateService,
        private initialDataService: InitialDataService,
        private auditDetailsService: AuditDetailsServiceProvider,
        private adminManQuesService: AdminManageQuesServiceProvider) {
        this.isActivePage = true;
        this.questionsresponse = [];
        this.pageTitle = '';
        this.pageName = "QuestionsTab";
        this.title = "";
        this.deleteQues = false;
        this.assignedFailureCodes = false;
        this.user = this.userService.getUser();
        // get the categories and languages 
        this.categoryList = this.utilService.getAllcategories();
        this.languagesList = this.utilService.getAllLanguages();
        this.showPlantAudits = false;
        this.isMandate = false;
        this.isEdit = false;
        this.buttonSel = 'showAll';
        this.orderSel = false;
        this.showFailureCodesForQues = false;
        this.isDetails = false;
        this.showAllQue = false;
        this.isCorpLogin = false;
        this.isReadOnly = false;
        this.showAddNewQueToQueMaster = false;
        this.isLPAAudits = true;
    }
    ngOnInit() {
        const navParamsData = this.navParams.data;
        if (navParamsData !== undefined && navParamsData.isFromPage !== undefined && (navParamsData.isFromPage === "AuditsList" || navParamsData.isFromPage === "ScheduleAudits")) {
            this.selectionData = navParamsData.userSelectionData;
            this.showPlantAudits = (navParamsData.showPlantAudits);    // If plant admin show audits by plant id IF CQA show all the Audits 
            //get the privileges to show addNewQuestion button
            this.showAuditDetailsAddNewQues = (navParamsData.showAuditDetailsAddNewQues.toString() === "true");
            this.reqAuditDtsAddNewQues = (navParamsData.reqAuditDtsAddNewQues);
            this.showAcceptAuditButton = (navParamsData.showAcceptAuditButton.toString() === "true"); // if this is true then it is a Plant Admin Login
            this.addPGSpecfcQuestions = (navParamsData.addPGSpecfcQuestions.toString() === "true");
            this.showAddNewQueToQueMaster = (navParamsData.showAddNewQueToQueMaster.toString() === "true");
            this.isLPAAudits = (navParamsData.isLPAAudits !== undefined && navParamsData.isLPAAudits.toString() === "true");
            this.selPgName = this.selectionData.selPGName;
            this.selOpName = this.selectionData.selOpName;
            this.selProcName = this.selectionData.selPrName;
            //TODO uncomment the below lines after multi language support for all the processes
            /*if(this.selPgName && this.selOpName && this.selProcName){
                this.translate.get([this.selPgName, this.selOpName, this.selProcName]).subscribe((value)=>{
                    this.title = value[this.selPgName] +  value[this.selOpName] + value[this.selProcName];
                });
            }*/
            this.title = this.selProcName + " Audit  - " + (this.selectionData.selLevelName || "");
            this.selPrcId = +this.selectionData.selPrId;
            this.selLevelId = this.selectionData.selLevelId;
            this.selLangCode = this.selectionData.selLangCode;
            this.loadQuestionForAudit();
        }
        if (navParamsData.isReadOnly !== undefined) {
            this.isReadOnly = (navParamsData.isReadOnly.toString() === "true");
        }
    };

    ionViewWillEnter() {
        this.isCorpLogin = (this.userService.getUserSelection().selRoleId === 2) ? true : false//
        if (!this.isActivePage) {
            this.isActivePage = true;
            this.loadQuestionForAudit();
        }
        // Below will get the failure code categories for the plant
        this.adminManageFCService.getPlantFailureCodeCateories(this.selectionData.selPltId).subscribe((data: ResponseObject) => {
            if (this.utilService.checkValidData(data)) {
                this.failCodesCatList = data.Response;
                this.utilService.setFailCodeCategoryAssigningList(data.Response);
            }
        });
    }

    // This loads questions created by CQA assigned to Audit
    private loadQuestionForAudit() {
        if (this.showPlantAudits) {
            this.loadQuestionForAuditForPlant();
        } else {
            this.loadQuestionForAuditForCQA();
        }
    }

    // This loads questions created by CQA assigned to Audit
    private loadQuestionForAuditForCQA() {
        this.utilService.showLoading();
        this.adminManQuesService.getAuditDetailsByPrcIdLngLevelId(this.selPrcId, this.selLangCode, this.selLevelId, 0, 0/* Corp Level Question */).subscribe((response1: AuditDetailsQuestion) => {
            this.utilService.hideLoading();
            let data = [];
            if (response1 !== undefined && response1["data"] !== undefined && response1["data"].length > 0) {
                data = response1["data"];
                this.questionsresponse = data;
                this.pageTitle = data["auditName"];
                this.tempQuestList = _.cloneDeep(this.questionsresponse);
                this.tempSelandUNSelList = _.cloneDeep(this.questionsresponse);
                this.zeroSequenceSel = [];// why do we need this?
            } else {
                this.utilService.showToast("AuditsYetCreated", this.title);
            }

        });
    }


    // This loads questions of both CQA assigned and Plant Admin assigned to Audit
    private loadQuestionForAuditForPlant() {
        this.utilService.showLoading();
        this.adminManQuesService.getAuditDetailsByPrcIdLngLevelId(this.selPrcId, this.selLangCode, this.selLevelId, this.showPlantAudits ? this.selectionData.selPltId : 0, 2/* All Questions Both Corp Level Question and Plant Level */).subscribe((response1: AuditDetailsQuestion) => {
            //this.adminManQuesService.getAuditDetailsByPrcIdLngLevelId(this.selPrcId,this.selLangCode, this.selLevelId, this.showPlantAudits ?  this.selectionData.selPltId : 0, 1/* Plant level Question*/).subscribe((response2:AuditDetailsQuestion)=>{                          
            this.utilService.hideLoading();
            let data = [];
                           /* if(response1 !== undefined && response2 !== undefined){
                                const resp1Data = response1["data"];
                                const resp2Data = response2["data"];
                                if(resp1Data !== undefined && resp1Data.length > 0){
                                        data = resp1Data;
                                        if(resp2Data !== undefined && resp2Data.length > 0){                                        
                                            data = data.concat(resp2Data);
                                        }
                                }                                
                            } else */if (response1 !== undefined) {
                data = response1["data"];
            } /*else if(response2 !== undefined){
                                data = response2["data"]; 
                            }*/
            if (data !== undefined && data.length > 0) {
                this.questionsresponse = data;
                this.pageTitle = response1["auditName"];
                this.tempQuestList = _.cloneDeep(this.questionsresponse);
                this.tempSelandUNSelList = _.cloneDeep(this.questionsresponse);
                this.zeroSequenceSel = [];
            } else {
                this.utilService.showToast("AuditsYetCreated", this.title);
            }
        });
        //}); -- calling all the question both CQA and PA
    }
    editAudit() {
        this.editQue = !this.editQue;
    }
    toggleGroup(group) {
        if (this.isGroupShown(group)) {
            this.shownGroupas = null;
        } else {
            this.shownGroupas = group;
        }
    };

    isGroupShown(group) {
        if (this.showAllQue) {
            return true;
        } else {
            return this.shownGroupas === group;
        }
    };

    private sortSelectionClicked(): void {
        if (this.questionsresponse !== undefined && this.questionsresponse.length > 0) {
            this.resetButtonFlag();
            this.buttonSel = 'sortSel';
            this.questionsresponse = this.questionsresponse.reduce((prevItem, currItem, index, array) => {
                let obj = { catName: currItem.catName, questions: [] }
                this.orderByPipe.transform(currItem.questions, 'sequence');
                obj.questions = this.orderByPipe.value
                prevItem.push(obj);
                return prevItem;
            }, []);
            //this.orderByPipe.transform(this.questionsresponse[0].questions,'SEQUENCE');      
            // this.questionsresponse[0].questions =  this.orderByPipe.value;
            this.buttonSel = '';
        }
    }
    private showAllClicked(): void {
        if (this.questionsresponse !== undefined && this.questionsresponse.length > 0) {
            this.resetButtonFlag();
            this.buttonSel = 'showAll';
            if (this.tempSelandUNSelList.length > 0) {
                this.questionsresponse = this.tempSelandUNSelList;
            } else {
                this.questionsresponse = this.tempQuestList;
            }
        }
    }
    private selEditClicked(): void {
        this.resetButtonFlag();
        this.isEdit = true;
        this.buttonSel = 'showSelEdit';
    }
    private selDetailsClicked(): void {
        if (this.questionsresponse !== undefined && this.questionsresponse.length > 0) {
            this.resetButtonFlag();
            this.isDetails = true;
            this.buttonSel = 'showSelDetails';
        }
    }
    //Show selected clicked
    private showSelectedClicked(): void {
        if (this.questionsresponse !== undefined && this.questionsresponse.length > 0) {
            this.resetButtonFlag();
            this.buttonSel = 'showSel';
            this.questionsresponse = this.doSelectionUnSel(this.tempSelandUNSelList, true);
        }
    }
    private doSelectionUnSel(allQueSelUnSelList: Array<AuditQuestions>, returnSel: boolean): Array<AuditQuestions> {
        this.resetButtonFlag(); // reset the selection button
        let queRespSelUnSel = allQueSelUnSelList.reduce((x, item) => {
            let obj = {
                objSel: { catName: '', questions: [] },
                objUnSel: { catName: '', questions: [] }
            };

            obj.objSel.catName = item.catName;
            obj.objUnSel.catName = item.catName;
            let reducedQuesArray = item.questions.reduce((y, i) => {
                if (i.isAlloted == true) {
                    y.selectedItems.push(i)
                } else {
                    y.unSelectedItems.push(i)
                };
                return y;
            }, { selectedItems: [], unSelectedItems: [] });
            obj.objSel.questions = reducedQuesArray.selectedItems;
            obj.objUnSel.questions = reducedQuesArray.unSelectedItems
            x.push(obj);
            return x;
        }, []);

        this.tempSelList = queRespSelUnSel.reduce((prev, item) => {
            if (item.objSel.questions.length > 0) {
                prev.push(item.objSel);
            }
            return prev;
        }, []);
        /*this.tempSelandUNSelList = queRespSelUnSel.reduce((prev, item)=>{ 
                                    let obj= {catName:'',questionsArray:[] }; 
                                    obj.questionsArray = obj.questionsArray.concat(item.objSel.questionsArray);  
                                    obj.questionsArray = obj.questionsArray.concat(item.objUnSel.questionsArray);
                                    prev.push(obj);
                                    return prev; 
                                  },[]);*/
        this.tempUnSelList = queRespSelUnSel.reduce((prev, item) => {
            if (item.objUnSel.questions.length > 0) {
                prev.push(item.objUnSel);
            }
            return prev;
        }, []);;
        return returnSel ? this.tempSelList : this.tempUnSelList;
    }

    private unDoAllSelectionClicked(): void {
        if (this.questionsresponse !== undefined && this.questionsresponse.length > 0) {
            this.resetButtonFlag();
            this.buttonSel = 'showUnDoAll';
            this.questionsresponse = _.cloneDeep(this.tempQuestList);
            this.tempSelandUNSelList = _.cloneDeep(this.questionsresponse);
        }
    }

    /*This is called on click of Add new question Button
     on successfull submission of the question in the model window the question is sent to the server.*/
    // this is never used
    // private createNewQuestion():void{
    //     let modal = this.modalCtrl.create(UpdateQuesFailureCodeModals);
    //     modal.onDidDismiss((data)=>{ // question object is returned from the model window.
    //         if(data){
    //             this.adminManQuesService.createQuestionFailCodesByLangCat(data.submitedData);// Calling the service method.
    //         }            
    //     });
    //     modal.present();
    // }

    private selFailureCodesClicked(): void {
        if (this.questionsresponse !== undefined && this.questionsresponse.length > 0) {
            this.resetButtonFlag();
            this.showAllQue = true;
            // this.showFailureCodesForQues = !this.showFailureCodesForQues;
            this.buttonSel = 'showSelFailureCode';
        }
    }
    private showAllQuesClicked() {
        //this.showAllQue = !this.showAllQue;
        this.buttonSel = 'showAllQue';
    }
    private showUnSelectionClicked(): void {
        if (this.questionsresponse !== undefined && this.questionsresponse.length > 0) {
            this.resetButtonFlag();
            this.buttonSel = 'showUnSel';
            this.questionsresponse = this.doSelectionUnSel(this.tempSelandUNSelList, false);
        }
    }

    private orderSelectionClicked(): void {
        if (this.questionsresponse !== undefined && this.questionsresponse.length > 0) {

            this.resetButtonFlag();
            this.buttonSel = 'showOrderSel';
            this.questionsresponse = this.doSelectionUnSel(this.tempSelandUNSelList, true);
            this.orderSel = true;
            this.orderCount = 0;
        }
    }
    /**
     * name
     */
    public assignNewUser(item: AuditFailureCode, itemId, itemName) {
        let modal = this.modalCtrl.create(SearchUsersInPlant, {}, { enableBackdropDismiss: false });
        modal.onDidDismiss((data: User) => {
            if (this.utilService.itemDefined(data)) {
                item[itemId] = data.userId;
                item[itemName] = data.firstName + "," + data.lastName;
                item.isEdited = true;
            }
        });
        modal.present();
    }
    public assignCategory(item: AuditFailureCode, itemId, itemName) {
        let modal = this.modalCtrl.create(SearchUsersInPlant, {
            isFromPage: 'AuditDetailsCategoryChange'
        }, { enableBackdropDismiss: false });
        modal.onDidDismiss((data: FailCodeCategoryList) => {
            if (this.utilService.itemDefined(data)) {
                const fcCatItem: FailCodeCategoryAssigningList = this.failCodesCatList.filter(item => item.failureCdCatId.toString() === data.failureCdCatId.toString())[0];
                item.assigneeId = fcCatItem.assigneeId;
                item.reviewerId = fcCatItem.reviewerId;
                item.assigneeName = fcCatItem.assigneeName;
                item.reviewerName = fcCatItem.reviewerName;
                item.failureCdCatId = fcCatItem.failureCdCatId;
                item.failureCdCatDesc = fcCatItem.failureCdCatDesc;
                item.isEdited = true;
            }
        });
        modal.present();
    }
    private resetButtonFlag(): void {
        this.orderSel = false;
        this.isDetails = false;
        this.isEdit = false;
    }
    private isHighlighted(queIt): void {
        var xx = queIt;// [class.selected]="isHighlighted(que)" 
    }

    private selectQue(e: any, qitem: Question, index: number, catName: string, catId: number): void {
        // this.tempSelandUNSelList = _.cloneDeep(this.questionsresponse);
        // _.filter
        /*const classList= e.target.parentElement.parentElement.classList;
        const classListArray = e.target.parentElement.parentElement.classList.value.split(' ');
        if(classListArray.indexOf('selected') != -1){
            classList.remove('selected');
        } else{
            classList.add('selected');
        } */
        if (this.orderSel) {
            this.orderCount++;
            qitem.sequence = this.orderCount.toString();
        } else if (this.isDetails) {
            let queItem: Questions = new Questions(catName, catId, [qitem]);
            this.isActivePage = false;
            this.navCtrl.push(QuestionFailureCodeDetails, { "isFromPage": "AuditDetails", "queItem": queItem, "viewQuestionDetails": "true" });
        } else {
            this.count++;
            qitem.sequence = this.count.toString();
            qitem.isAlloted = !qitem.isAlloted;
            //   if(this.isMandate){
            //     qitem.IS_MANDATORY = true;
            //   }
            this.tempSelandUNSelList = this.tempSelandUNSelList.reduce((prev, item) => {
                item.questions.reduce((prev, i) => {
                    if (i.queId === qitem.queId) {
                        i.isAlloted = qitem.isAlloted;
                        i.isMandatory = qitem.isMandatory;
                        i.sequence = qitem.sequence;
                    }
                    prev.push(i);
                    return prev;
                }, []);
                prev.push(item);
                return prev;
            }, []);
        }
    }


    private reorderItems(indexes, queItem, index): void {
        const queArrConst = this.questionsresponse[index].questions;
        let movFrmEle = queArrConst[indexes.from - 1];
        let movToEle = queArrConst[indexes.to - 1];

        let seqFrmEle = movFrmEle.sequence;
        movFrmEle.sequence = movToEle.sequence;
        movToEle.sequence = seqFrmEle;
        queArrConst[indexes.to - 1] = movToEle;
        let movEle = queArrConst.splice(indexes.from - 1, 1)[0];
        queArrConst.splice(indexes.to - 1, 0, movEle);

        this.tempSelandUNSelList = this.questionsresponse;
    }

    //Called on click of search icon on the opt of the header
    private search(): void {

    }
    private addSelQues(): void {
        // TODO Make a service call to request for addition of question  to the Audit by the Corporate Quality admin.
        this.viewCtrl.dismiss();
    }
    private dismissModal(): void {
        this.viewCtrl.dismiss();
    }
    private getAssignedFailureCodes() {
        //const usersList:Array<UsersInPlant> = this.userService.getUsersInPlant();
        return this.questionsresponse.reduce((prev, item) => {
            prev = item.questions.reduce((prv, itm) => {
                prv = itm.failCodes.reduce((p, i) => {
                    p = (i.assigneeId !== 0 && i.reviewerId !== 0) ? true : false
                    //this.assignedFailureCodes = true; // this is not needed there
                    // this.auditDetailsQuestionFailureCode.push(
                    // if(i.failCode !== 0){
                    //const assignee = i.assigneeId !== 0 ? _.filter(usersList, (usr) => usr.userId === i.assigneeId )[0] : undefined;
                    //const reviewer = i.reviewerId !== 0 ? _.filter(usersList, (usr) => usr.userId === i.reviewerId )[0] : undefined;                             
                    //assignee !== undefined ? (assignee["firstName"] + assignee["lastName"]) : "",
                    //reviewer !== undefined ? (reviewer["firstName"] + reviewer["lastName"]) : "",
                    //TODO assignee id reviewer ID retrive them from the object and assign them
                    // const fc = new AuditDetailsFailureCode(i.failCode, i.failDesc, i.assigneeId, i.reviewerId, 
                    //                                                     (assignee !== undefined ? (assignee["firstName"] + assignee["lastName"]) : ""), 
                    //                                                     (reviewer !== undefined ? (reviewer["firstName"] + reviewer["lastName"]) : ""), 
                    //                                                     false, 
                    //                                                     i.severity,false, i.failCodeHelp, i.failActive,[],
                    //                         [new AuditDetailsFailureCodeQuestion(itm.lngCode, itm.lngDesc, itm.queId, itm.queHelp, itm.queDesc, itm.sequence, false, itm.isAlloted, itm.isMandatory, 0, itm.na)]);
                    //        p.push(fc);             
                    //}                                                                                                                                                           
                    return p;
                }, false);
                return prv;
            }, false);
            return prev;
        }, false);
    }
    private acceptAuditPresentPopOver() {
        // This Accept Audit Button shows up for Users of Plant admin to accept an Audit for his Plant
        const selDat: UserSelectionData = this.selectionData;
        //TODO call service to assign the Audit to some one       
        this.presentAcceptAuditPopover(new UserSelectionPrivileges(false, false, false, false, false, false, false, true, true, false, false, false,
            false, false, false, false, false, false,
            false, false, false, false), selDat);
    }
    private acceptAuditButtonClicked() {
        // TODO integrate the getPlantFailCodeCat web service
        const assignedFCodes = this.getAssignedFailureCodes();
        if (assignedFCodes) {
            this.acceptAuditPresentPopOver();
        } else {
            this.utilService.showToast("", "Assign Non Compliance before Scheduling the Audit.")
        }
    };
    //     if(assignedFCodes){
    //         // Task 261 - Comment out assigning the failure codes
    //          this.acceptAuditPresentPopOver();
    //     } else{
    // TODO write code to assign Assignee reviewer to the FailUre Code Categories
    /*   let modal = this.modalCtrl.create(AssignToFailureCodesCategoriesPage, {"isFromPage":"AuditDetails",                                                                     
                                                                   "userSelectionData":this.selectionData,
                                                                  });
                           modal.onDidDismiss(data =>{
                               if(data !== undefined ){
                                   if(data.length > 0){
                                           this.auditDetailsService.assignPlantAssigneeReviewerToFailCodeCategory(data).subscribe((response)=>{
                                               if(this.utilService.checkValidData(response)){
                                                       // Reload the questions with new Failure Codes
                                                       // this.loadQuestionForAudit();  
                                                       this.acceptAuditPresentPopOver();
                                                   }
                                           });
                                       } else{
                                       if(assignedFCodes){
                                               this.acceptAuditPresentPopOver();
                                               // Task 261 - Comment out assigning the failure codes
                                           } else{
                                               this.acceptAuditButtonClicked();
                                           }
                                   }                                                 
                               } 
                           });
    modal.present(); */
    //}        


    // Belwo code is used to assign Assignee Reviewer to each Failure Code
    /* let failureCodesList:Array<AuditDetailsFailureCode> = this.getAssignedFailureCodes();
        if((failureCodesList.length > 0) && failureCodesList[0]["failCode"] !== 0){
                    let modal = this.modalCtrl.create( AssignFailureCodesPage, {"isFromPage":"AuditDetails",                                                                     
                                                                "userSelectionData":this.selectionData,
                                                                "assignFailureCodesToQuestions":failureCodesList});
                        modal.onDidDismiss(data =>{
                            if(data){
                                this.auditDetailsService.assignReviewerAssigneeToFailureCode(data).subscribe((data)=>{
                                    if(this.utilService.checkValidData(data)){
                                        //  this.assignedFailureCodes = true;
                                        // Reload the questions with new Failure Codes
                                            this.loadQuestionForAudit();                                                
                                        //  this.acceptAuditPresentPopOver();
                                    }                                 
                                });
                            } else{
                                this.assignedFailureCodes = false
                            }
                        });
                        modal.present();   
            } else{
                    this.utilService.showToast("NoFailureCodesForQuestions","");
            }   */


    callServerSubmitAudit() {
        const data: Array<CreateAuditQuestion> = this.questionsresponse.reduce((prev, item) => {
            const catId = item.catId;
            const catName = item.catName;
            let questions: Array<CreateAuditQuestion> = new Array();
            questions = item.questions.reduce((prev, item) => {
                if (item.sequence !== '0') {
                    prev.push(new CreateAuditQuestion(+item.queId, +item.sequence));
                } else {
                    this.zeroSequenceSel.push(new AuditQuestions(catName, catId, [item]));
                }
                return prev;
            }, questions);
            prev.concat(questions);
            return prev;
        }, [])

        let selPrId: number = +this.selectionData.selPrId;
        let selLevelId: number = +this.selectionData.selLevelId
        this.adminManQuesService.createAuditbyProcOpPG(new CreateAudit(selPrId, selLevelId, this.userService.getUser()["wLogin"], data));
    }


    presentAcceptAuditPopover(userSelPrv: UserSelectionPrivileges, selData: UserSelectionData) {
        //new UserSelectionPrivileges(this.userService.getUser()["roleId"] !== 2, true,true,true,true,false, true, false,false, false)
        let popover = this.popoverCtrl.create(SelectionPage, { "useSelectionDataSent": true, "isPopOverCtrl": "true", "isMandatory": "false", "pageTitle": "Assign Dates", "userPrivileges": userSelPrv, "userSelectionData": selData }, {
            enableBackdropDismiss: false,
        });
        popover.present();
        popover.onDidDismiss((data: UserSelectionData) => {
            if (data) {
                this.auditDetailsService.createActiveAuditsByDateAndPlant(selData.selPltId, data.startDate, data.endDate, selData.selPrId, selData.selLevelId, this.user.wLogin).subscribe((dat: ResponseObject) => {
                    if (dat.ResponseCode && dat.ResponseCode.length > 0) {
                        this.utilService.showToast(dat.ResponseCode, " - StartDate : " + data.startDate + " - EndDate : " + data.endDate);
                        if (dat.ResponseCode === "1003") { // success accepting the audit
                            this.assignedFailureCodes = true;
                            this.navCtrl.pop();
                        }
                    }
                }, (error) => {
                    this.utilService.showToast("ErrorConnectServer", "");
                }, () => {

                });
            }
        });
    }

    // Assigning the Audit
    // private auditListItemClicked(auditItem){//:AcceptedAuditItem
    /*Task 299 Disable entering Lot number for taking Audits /Scheduling the Audits from the LPA application*/
    /*  
      let popover = this.popoverCtrl.create(SelectionPage, {
                                          "isMandatory" : "false",
                                          "isPopOverCtrl":"true", 
                                          "isFromPage" : this.isAuditsSchedular ? "AuditSchedular" : "UnScheduledAudits",
                                          "pageTitle":(auditItem.procName + "- Level "+auditItem.levelId),
                                          "userPrivileges" : new UserSelectionPrivileges(false,false, false, false, false,
                                                                                      false, false, false, false, false, 
                                                                                      false, true, true, true, false, /*Task 299*/
    /* false, false, false, false, false, false, true), 
"userSelectionData": this.selectionData },
{
enableBackdropDismiss:false,
});
popover.present();
popover.onDidDismiss((data:UserSelectionData) => {
if(data !== undefined){            
const loggedInUserWLogin = this.user.wLogin;
//if(!this.auditExistsForSelection(data.auditor.id, auditItem.startDate, auditItem.endDate, auditItem.plantId, auditItem.levelId, auditItem.procId, data.machine.name, data.shift.name)){
this.auditService.postScheduleAcceptedAuditToUser(new SubmitScheduledAudit(auditItem.auditListId, 
data.auditor.id, "0000", /*Task 299*/
    /*  data.machine.name, data.shift.name, 
      data.selCommentsTextarea,loggedInUserWLogin)).subscribe((data:ResponseObject)=>{
if(this.utilService.checkValidData(data)){                               
if(data.Response[0] !== undefined){
this.utilService.showToast(data.Response[0],"");
}                                                                    
 
}
});
}                
});*/
    //}
    // Searching the quesions and failure code on the inputs entered.
    private getSearchItems(ev: any) {
        let val = ev.target.value;
        if (val && val.trim() !== '' && val.length >= 3) {
            this.questionsresponse = this.questionsresponse.reduce((prev, catItem: AuditQuestions) => {
                let itm: Array<AuditQuestion> = catItem.questions.reduce((prv: Array<AuditQuestion>, i: AuditQuestion) => {
                    if (i.queDesc.length > 0) {
                        if (i.queDesc.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
                            _.findIndex(i.failCodes, (d => d.failDesc.toLowerCase().indexOf(val.toLowerCase()) > -1)) > -1) {
                            prv.push(i);
                        }
                    }
                    return prv;
                }, []);
                if (itm.length > 0) {
                    let x: AuditQuestions = { catName: catItem.catName, catId: catItem.catId, questions: itm };
                    prev.push(x);
                }
                return prev;
            }, [])
        }
    }
    private searchQueCancelClicked() {
        switch (this.buttonSel) {
            case 'showAll':
                this.showAllClicked();
                break;
            case 'showSel':
                this.showSelectedClicked();
                break;
            case 'showUnSel':
                this.showUnSelectionClicked();
                break;
            case 'sortSel':
                this.sortSelectionClicked();
                break;
            case 'showOrderSel':
                this.orderSelectionClicked();
                break;
            case 'showUnDoAll':
                this.unDoAllSelectionClicked();
                break;
            default:
                this.showAllClicked();
                break;
        }
    }
    // This returns selected Question in Array of objects of the queId's and seqId's
    // since this page doesn't have an option to select questions this returns questionId of the exisitng questions.
    private getSelectedQuestionsIdSeqId(questionsArray: Array<AuditQuestions>, isPlant: boolean): Array<CreateAuditQuestion> {
        if (questionsArray.length > 0) {
            return questionsArray.reduce((prev, item) => {
                const catId = item.catId;
                const catName = item.catName;
                let ques: Array<CreateAuditQuestion> = new Array();
                ques = item.questions.reduce((p, i) => {
                    //if (i.sequence !== '0'){
                    if (isPlant) {// for plant not return corp questions                                    
                        if (!i.isCorpQue) {
                            p.push(new CreateAuditQuestion(+i.queId, 0));
                        }
                    } else {
                        p.push(new CreateAuditQuestion(+i.queId, 0));
                    }
                    //} 
                    //else{ // not used any where
                    //    this.zeroSequenceSel.push(new Questions(catName, catId,[i]));
                    // }                         
                    return p;
                }, []);
                prev = prev.concat(ques);
                return prev;
            }, []);
        } else {
            return [];
        }
    }
    private getOtherLevelsObjects() {
        let levels = this.utilService.getAllLevels();
        return levels.reduce((prev, item) => {
            if (item.id.toString() !== this.selLevelId.toString()) {
                prev.push({ label: item.desc, value: item, type: "checkbox" });
            }
            return prev;
        }, []);
    }
    private applyToOtherLevels(selectedQues: Array<CreateAuditQuestion>, isPlant: boolean, pgId: number) {
        let selQues: Array<CreateAuditQuestion> = [];
        let isCancel = false;
        if (pgId === undefined) {
            pgId = this.selectionData.selPGId;
        }
        if (selectedQues === undefined) {
            isCancel = true;
            isPlant = this.showAcceptAuditButton;
            selQues = this.getSelectedQuestionsIdSeqId(this.questionsresponse, isPlant);
            selQues = _.uniqBy(selQues, 'queId'); // remove the dulicate questions
        } else {
            selQues = selectedQues;
        }

        let messageToShow = "";
        this.translate.get(["applyQuesToOtherLevels"]).subscribe((values) => {
            messageToShow = values["applyQuesToOtherLevels"];
        });
        if (pgId.toString() === "1") {
            this.callServerToCreateAuditByProcOpPG(selQues, this.selLevelId, isPlant);
        } else {
            let alert = this.alertCtrl.create({
                title: '',
                message: messageToShow,
                inputs: this.getOtherLevelsObjects(),
                buttons: [
                    {
                        text: 'No',
                        role: 'cancel',
                        handler: data => {
                            if (!isCancel) {
                                this.callServerToCreateAuditByProcOpPG(selQues, this.selLevelId, isPlant);
                            }
                        }
                    },
                    {
                        text: 'Yes',
                        handler: (data: Array<Level>) => {
                            if (data !== undefined && data.length > 0) {
                                data.forEach(item => {
                                    if (item.id !== this.selLevelId.toString()) {
                                        this.callServerToCreateAuditByProcOpPG(selQues, +item.id, isPlant);
                                    }
                                });
                                if (selectedQues !== undefined) {
                                    this.callServerToCreateAuditByProcOpPG(selQues, this.selLevelId, isPlant);
                                }
                            } else {
                                // Apply to single level.
                                this.callServerToCreateAuditByProcOpPG(selQues, this.selLevelId, isPlant);
                            }
                        }
                    }
                ]
            });
            alert.present();
        }
    }
    // To addnew questions to the existing Questions
    private addNewQuestion() {
        this.buttonSel = 'showAddNewQues';
        this.deleteQues = false;
        let selQues: Array<CreateAuditQuestion> = [];
        selQues = this.getSelectedQuestionsIdSeqId(this.questionsresponse, false);
        let selQuesId = _.map(selQues, "queId");
        const selData = Object.assign({}, this.selectionData);
        if (this.reqAuditDtsAddNewQues && selData) {
            let modal = this.modalCtrl.create(AdminQuestions, {
                "isFromPage": "AuditDetails",
                "pageTitle": "Select Question(s)",
                "showAddNewQueToQueMaster": this.showAddNewQueToQueMaster,
                "reqAuditDtsAddNewQues": this.reqAuditDtsAddNewQues,
                "userSelectionData": selData,
                "selectedQuestions": selQuesId,
                "addPGSpecfcQuestions": this.addPGSpecfcQuestions
            },
                {
                    enableBackdropDismiss: false
                });
            modal.onDidDismiss(newAddedQuesObj => {
                if (newAddedQuesObj !== undefined) {
                    this.processQuestionsFromSelection(newAddedQuesObj, false);
                }
                this.buttonSel = "";
            });
            modal.present();
        } else {
            console.error("this.reqAuditDtsAddNewQues && this.selectionData is undefined");
        }
    }





    private processQuestionsFromSelection(newAddedQuesObj, modifiedQues: boolean) {
        let isPlantAudit = newAddedQuesObj.isPlantAudit.toString() === "true";

        const pgId = this.selectionData.selPGId;
        // This will make a servive call to reload the data.
        let selQues: Array<CreateAuditQuestion> = [];
        if (!isPlantAudit) {
            // since this page doesn't have an option to select questions this returns questionId of the exisitng questions.
            // for the CQA/PlantAdmin we need to send both the Old and new questions, so concating the new questions witht he old questions                                                
            selQues = this.getSelectedQuestionsIdSeqId(this.questionsresponse, false);

            let newAddedQuesList: Array<CreateAuditQuestion> = newAddedQuesObj.selectedQuesIdSeqId !== undefined ? newAddedQuesObj.selectedQuesIdSeqId : [];
            if (newAddedQuesList !== undefined && newAddedQuesList.length > 0) {
                // calling the below to avoid newly selected questions is already available for the Audit
                let newSelQues = this.filterDuplicatesFromFirstAray(newAddedQuesList, selQues);
                selQues = selQues.concat(newAddedQuesObj.selectedQuesIdSeqId);
                selQues = _.uniqBy(selQues, 'queId'); // remove the dulicate questions    
                this.applyToOtherLevels(selQues, false, pgId);
            } else if (modifiedQues) {
                this.applyToOtherLevels(selQues, false, pgId);
            }

        } else {
            // TODO remove the duplicates selected questions 
            // For the Plant level Audit we are required to send only the newly added questions to the Audit . Old questions are not required.
            // the questions are  shown up in the sequence order submitted to the server. 
            // the newly added questions at the plant level would be lower sequence compared to the old questions already available.

            // for Plant Admin don't send the Corp questions.
            // only send Plant exisitng and newly added questions.
            let allSelQues = this.getSelectedQuestionsIdSeqId(this.questionsresponse, false); // this will return all the available quesitnos for the Audit
            selQues = this.getSelectedQuestionsIdSeqId(this.questionsresponse, true); // this will return questions avoiding the corp questions.
            //const selQuesIds = _.map(selQues,"queId");

            let newAddedQuesList: Array<CreateAuditQuestion> = newAddedQuesObj.selectedQuesIdSeqId !== undefined ? newAddedQuesObj.selectedQuesIdSeqId : [];
            if (newAddedQuesList !== undefined && newAddedQuesList.length > 0) {
                // calling the below to avoid newly selected questions is already available for the Audit
                let newSelQues = this.filterDuplicatesFromFirstAray(newAddedQuesList, allSelQues);
                selQues = selQues.concat(newSelQues);
                selQues = _.uniqBy(selQues, 'queId'); // remove the dulicate questions
                this.applyToOtherLevels(selQues, true, pgId);
            } else if (modifiedQues) {
                this.applyToOtherLevels(selQues, true, pgId);       // deleted questions                                                                                                                                                             
            }
        }
    }
    private filterDuplicatesFromFirstAray(newAddedQuesList: Array<CreateAuditQuestion>, selQuesSeqIds: Array<CreateAuditQuestion>): Array<any> {
        if (newAddedQuesList !== undefined) {
            let selQuesIds = _.map(selQuesSeqIds, "queId");
            // filtering the questions to remove duplicates
            return newAddedQuesList.filter((item) => {
                return selQuesIds.indexOf(item.queId) === -1;
            });
        } else {
            return selQuesSeqIds;
        }
    }

    private addNewQuesToList(data: QuestionItem): void {
        // This will make a servive call to reload the data.
    }
    private makeServiceCallToCreateAuditByProcOpPG(selQues: Array<CreateAuditQuestion>, levelId: number, isPlant: boolean) {
        //if(selQues.length > 0){ // plant questions can be empty after deleting the existing questions
        // we need to send both the Old and new questions                                
        this.adminManQuesService.requestAddExistingQueFailCodeToAudit(selQues, this.selPrcId, levelId, (isPlant ? this.selectionData.selPltId : 0), this.user.wLogin).subscribe((response: ResponseObject) => {
            if (isPlant) {
                if (this.utilService.checkValidData(response) && response.ResponseCode !== "1013") {
                    this.utilService.showToast("", "Successfully Modifying the Audit.");
                    this.deleteQues = false;
                    this.buttonSel = 'showDelQues';
                    // modify message for dlete question and add question to the audit         
                    if (levelId === this.selLevelId) {
                        this.loadQuestionForAudit();// load question only for the selected level int he page.
                    }
                }
            } else if (this.utilService.checkValidData(response)) {
                this.utilService.showToast("", "Successfully Created the Audit.");
                if (levelId === this.selLevelId) {
                    this.loadQuestionForAudit();// load question only for the selected level int he page.
                }
            }
            this.buttonSel = "";
        }, (error) => {
            this.utilService.showToast("", "Error occurred. Please try again.");
        }, () => {

        });
        //  }
    }
    private callServerToCreateAuditByProcOpPG(selQues: Array<CreateAuditQuestion>, levelId: number, isPlant: boolean) {
        if (levelId === this.selLevelId) {
            this.makeServiceCallToCreateAuditByProcOpPG(selQues, levelId, isPlant);
        } else {
            this.adminManQuesService.getAuditDetailsByPrcIdLngLevelId(this.selPrcId, this.selLangCode, levelId, 0, 0/* Corp Level Question */).subscribe((response1: AuditDetailsQuestion) => {
                let procQues: Array<AuditQuestions> = [];
                if (response1 !== undefined && response1["data"] !== undefined && response1["data"].length > 0) {
                    let questionId: Array<CreateAuditQuestion> = this.getSelectedQuestionsIdSeqId(response1["data"], isPlant);
                    let questionsToAdd = selQues.concat(this.filterDuplicatesFromFirstAray(selQues, questionId));
                    this.makeServiceCallToCreateAuditByProcOpPG(questionsToAdd, levelId, isPlant);
                } else {
                    // if there are no already exisitng questions to the level add the new  questions
                    this.makeServiceCallToCreateAuditByProcOpPG(selQues, levelId, isPlant);
                }
            });
        }
    }
    private deleteQueFromAudit(que: Question, queIndex: string, quesInd: number) {
        // delete only plant question is the logged-in user is a Plant Admin
        if (this.isCorpLogin && que.isCorpQue) {
            this.buttonSel = "save_changes";
            //let quesResp = Object.assign([],this.questionsresponse);
            //delete quesResp[quesInd]["questions"][queIndex];
            this.questionsresponse = this.removeSelQues(que.queId);
        } else if (!this.isCorpLogin && !que.isCorpQue) {
            this.buttonSel = "save_changes";
            //let quesResp = Object.assign([],this.questionsresponse);
            //delete quesResp[quesInd]["questions"][queIndex];
            //this.questionsresponse = Object.assign([],quesResp);
            this.questionsresponse = this.removeSelQues(que.queId);
        } else {
            this.utilService.showToast("", "Cannot delete the Mandatory Question in the Audit");
        }
    }
    private removeSelQues(queIndex) {
        return this.questionsresponse.reduce((prev, item) => {
            item.questions = item.questions.reduce((p, i) => {
                if (i.queId.toString() !== queIndex.toString()) {
                    p.push(i);
                }
                return p;
            }, []);
            prev.push(item);
            return prev;
        }, []);
    }
    private saveChangesButtonClicked() {
        let newAddedQuesObj = {
            isPlantAudit: !this.isCorpLogin,
            selectedQuesIdSeqId: undefined
        };
        this.processQuestionsFromSelection(newAddedQuesObj, true);
    }
    private deleteQuesButtonClicked() {
        this.deleteQues = !this.deleteQues;
        if (this.deleteQues) {
            this.buttonSel = 'showDelQues';
        } else {
            this.buttonSel = '';
        }
    }

    private saveEditFailureCodeButtonClicked(failItem: AuditFailureCode) {
        const plantId = this.selectionData.selPltId;
        const processId = this.selectionData.selPrId;
        const pgId = this.selectionData.selPGId;
        const wLogin = this.selectionData.wLogin;
        this.adminManQuesService.ReqFCAssgneRvwerChange(new ReqFCAssgneRvwerChange(plantId, processId, failItem.failCode, failItem.failureCdCatId, failItem.assigneeId, failItem.reviewerId, wLogin, pgId)).subscribe((data: ResponseObject) => {
            if (this.utilService.checkValidData(data)) {
                failItem.isEdited = false;
            }
        })
    }

    private saveAndApplyAllEditFailureCodeButtonClicked(failItem: AuditFailureCode) {
        const plantId = this.selectionData.selPltId;
        const pgId = this.selectionData.selPGId;
        const wLogin = this.selectionData.wLogin;
        this.initialDataService.getProcessByProductGroup(+pgId, plantId).subscribe((data: ResponseObject) => {
            if (this.utilService.checkValidData(data)) {
                if (data.Response.length > 0) {
                    let processList: Array<Process> = data.Response;
                    processList.forEach((item, index) => {
                        this.adminManQuesService.ReqFCAssgneRvwerChange(new ReqFCAssgneRvwerChange(plantId, item.prcId, failItem.failCode, failItem.failureCdCatId, failItem.assigneeId, failItem.reviewerId, wLogin, pgId)).subscribe((data: ResponseObject) => {
                            if (this.utilService.checkValidData(data)) {
                                failItem.isEdited = false;
                            }
                        });
                    })
                }
            }
        });
    }

}





//------------------------------------------------

