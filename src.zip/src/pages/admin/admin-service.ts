import { Injectable } from '@angular/core';
import { CallService} from '../../providers/call-service';
import { UserService} from '../../providers/user-service';
import { UtilService} from '../../providers/util-service';
import { Observable }from 'rxjs/observable';
import 'rxjs/add/operator/map';
import { AppSettings, MethodConstants } from '../../constants/AppSettings';


/*
  Generated class for the AdminServiceProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class AdminServiceProvider {

  constructor(private callService:CallService, private userService:UserService, private utilService:UtilService) {
    console.log('Hello AdminServiceProvider Provider');
  }


   public GetAddNewQueToAuditReqList(questionId:number, catId:number, langCode:string, all:number, requested:boolean, plantId:number){
    if(questionId !== undefined && catId  !== undefined  && (langCode && langCode !== "") && plantId !== undefined){
      const url =  (AppSettings.API_ENDPOINT+ MethodConstants.GetAddNewQueToAuditReqLis+"questionId="+questionId+"&catId="+catId+"&langCode="+langCode+"&all="+all+"&requested="+requested+"&plantId="+plantId);
      return this.callService.callServerForGet(url);
    } else{
      console.error(' values cannot be null.');
    }    
  }
}
