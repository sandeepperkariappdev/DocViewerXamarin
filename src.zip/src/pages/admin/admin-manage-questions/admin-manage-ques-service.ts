import { Injectable } from '@angular/core';
import { User} from '../../../models/User';
import * as _ from 'lodash';
import{Events } from 'ionic-angular';
import { AddAdditionalQuesToPlantAuditRequest,AuditQuestions,ResponseAuditDetailsQuestion, ReqFCAssgneRvwerChange, AuditFailureCode, Questions,UpdateFailureCode,UpdateQuestion,RequestUpdateQuestion, ApproveQuestion,AuditDetailsQuestion,ResponseObject, ApproveQuestionObject, ApproveFailureCodeObject, CreateAudit,CreateAuditQuestion, RequestQuestion, Question,ReqQuestion,FailureCodeList,FailureCode } from '../../../models/QuestionItem';
import { CallService} from '../../../providers/call-service';
import { UserService} from '../../../providers/user-service';
import { UtilService} from '../../../providers/util-service';
import { Observable }from 'rxjs/observable';
import 'rxjs/add/operator/map';
//import { TranslateDataService} from '../../../providers/google-translate/translate-data-service';
import { AppSettings, MethodConstants } from '../../../constants/AppSettings';
/*
  Generated class for the AdminManageQuesServiceProvider provider.  
*/
@Injectable()
export class AdminManageQuesServiceProvider {
    wLogin:string;
    user:User;
  constructor(private callService:CallService,/* private translateDataService: TranslateDataService,*/
   private userService:UserService, private utilService:UtilService, private events: Events) {
    this.user = this.userService.getUser();
    this.wLogin = this.user.wLogin;
  };
  public getQuestionFailCodesByLangCat(quesId:number, catId:number,lngCode:string, allActInAct:number, req:boolean, plantId:number){
     /* all == 2 -- return all the ACTIVE and INACTIVE questions
        all == 1 -- return all the ACTIVE  questions
        all == 0 -- return all the INACTIVE  questions
        requested == 0 -- false
        requested == 1 -- true
        questionId == 0 -- all the question
        categoryId ==0 -- all the categories*/
      if(quesId !== undefined && catId !== undefined && (lngCode!== undefined && lngCode!=="") && allActInAct !== undefined){
            const url = (AppSettings.API_ENDPOINT + MethodConstants.GetQuesFailCodesByLangCat+"questionId="+quesId+"&CatId="+catId+"&langCode="+lngCode+"&all="+allActInAct+"&requested="+req+"&plantId="+plantId);
            return this.callService.callServerForGet(url," Get Question FailCodes By Language Category");
      }  else{
            console.error('quesId && catId && lngCode !=="" && allActInAct values cannot be null');
      }      
      //.map((data) => { return data.quesArrays.map((item)=>{item.isAlloted = false; item.sequence = 0; item.isMandatory = false;})})      
  }

  public markQuestionsAvailableInAudits(response:Array<Questions>, selectedQueId:Array<number>){
      if(selectedQueId.length > 0){
            return response.reduce((prev, item)=>{
                                        let questions = item.questions.reduce((pv, itm)=>{
                                            if(selectedQueId.indexOf(+itm.queId) !== -1){
                                                    itm.isAlloted = true;
                                            }
                                            pv.push(itm);
                                                return pv;
                                        },[]);
                        prev.push(new Questions(item.catName, item.catId, questions, item.isCorpQue));
                        return prev;
                    },[]);     
      } else{
          return response;
      }   
  }

  public getQuestionFailCodesByLangPg(lngCode:string, allActInAct:number, req:boolean, pgNum:number, processSpecificQue:Boolean){
     /* all == 2 -- return all the ACTIVE and INACTIVE questions
        all == 1 -- return all the ACTIVE  questions
        all == 0 -- return all the INACTIVE  questions
        requested == 0 -- false
        requested == 1 -- true
        questionId == 0 -- all the question
        categoryId ==0 -- all the categories*/
      if(req !== undefined && pgNum !== undefined && (lngCode!== undefined && lngCode!=="") && allActInAct !== undefined){
            const url = (AppSettings.API_ENDPOINT + MethodConstants.GetQuestFailCodeByLangPg+"langCode="+lngCode+"&all="+allActInAct+"&requested="+req+"&pgNum="+pgNum+"&processSpecificQue="+processSpecificQue);
            return this.callService.callServerForGet(url," Get Question FailCodes By Language Category");
      }  else{
            console.error('quesId && catId && lngCode !=="" && allActInAct values cannot be null');
      }      
      //.map((data) => { return data.quesArrays.map((item)=>{item.isAlloted = false; item.sequence = 0; item.isMandatory = false;})})      
  }
  
  public createQuestionFailCodesByLangCat(data:Questions){
        //let plantId = this.userService.getUserSelection().selPltId; 
        let requestData:RequestQuestion;
        let reqData : Array<ReqQuestion> = this.formRequestQuestionsRequestFormat([data], false);
        requestData = new RequestQuestion(this.wLogin, 0 ,reqData);       
        this.reqAddQueCallServer(requestData);


     // const url = (AppSettings.API_ENDPOINT + MethodConstants.CreateQuesFailCodesByLangCat);
     // return this.callService.callServerForPost(url," Post Question FailCodes By Language Category",data);      
  }
  public createAuditbyProcOpPG(data:CreateAudit){
      const url = (AppSettings.API_ENDPOINT + MethodConstants.CreateAuditbyProcOpPG);
      return this.callService.callServerForPost(url," Post Question FailCodes By Language Category",data);      
  }
  //http://ahdeviis01/LPADevServices/api/Categories/insertCategory?catDesc=Testing Pg 2&pgNum=5&wlogin=ddai
  public createNewCategory(catDesc:string,pgNum:number,wlogin:string){
      const url = (AppSettings.API_ENDPOINT + MethodConstants.InsertCategory+"catDesc="+catDesc+"&pgNum="+pgNum+"&wlogin="+wlogin);
      return this.callService.callServerForPost(url," Post Question FailCodes By Language Category","");      
  }
  private assignIsCorpQuesToResponse(respObject:Array<ResponseAuditDetailsQuestion>,viewPlantQues:number){
      //getAuditDetailsByPrcIdLngLevelId
      const isCorpLogin = this.userService.getUser().roleId.toString() === "2" ? true : false;
      const isCorpQue = viewPlantQues === 0 ? true :false;
      return respObject.reduce((p, i)=>{
                        i.data = i.data.reduce((prev, item)=>{                   
                                        item.isCorpQue =  isCorpQue;   
                                      //item.questions.reduce    //this.isCorpLogin && que.isCorpQue  
                                       const quets = item.questions.reduce((prv, itm)=>{
                                                itm.isQueDeletable = ((isCorpLogin && isCorpQue) || (isCorpLogin && isCorpQue));                                                    
                                                const failCodes = itm.failCodes; 
                                                itm.failCodes = failCodes.reduce((pr, it)=>{                                                            
                                                    it.assigneeId = it.assigneeIdFCLevel || it.assigneeId;
                                                    it.assigneeName = it.assigneeNameFCLevel || it.assigneeName;
                                                    it.reviewerId = it.reviewerIdFCLevel || it.reviewerId;
                                                    it.reviewerName = it.reviewerNameFCLevel || it.reviewerName;
                                                    let failureCdCatId = it.failureCdCatIdFCProcessLevel || it.failureCdCatId;
                                                    let failureCdCatDesc = it.failureCdCatDescFCProcessLevel || it.failureCdCatDesc;
                                                    let failureCompletionDays = it.failureCompletionDaysFCProcessLevel || it.failureCompletionDays;
                                                    let reviewerCompletionDays = it.reviewerCompletionDaysFCProcessLevel || it.reviewerCompletionDays;
                                                    let assigneeCompletionDays = it.assigneeCompletionDaysFCProcessLevel || it.assigneeCompletionDays;
                                                    pr.push(new AuditFailureCode(it.assigneeId,it.reviewerId, it.severity, it.failCode, failureCdCatId, it.failDesc,
                                                    it.failCodeHelp, it.failActive, failureCdCatDesc, failureCompletionDays,
                                                    reviewerCompletionDays, assigneeCompletionDays, it.assigneeName, it.reviewerName, false));
                                                        return pr;
                                                },[])
                                                prv.push(itm);
                                                return prv;
                                            },[])           
                                        prev.push(new AuditQuestions(item.catName,item.catId,quets,item.isCorpQue));
                                        return prev;
                                    }, []);
                            p = i;
                            return p;
                        }, {});        
  }
  public getAuditDetailsByPrcIdLngLevelId(prcId:number, langCode:string, levelId:number, plantId:number, viewPlantQues:number){
      /*viewPlantQues === 0 Corp Level Questions
       viewPlantQues === 1 Plant Level Questions
       viewPlantQues === 2 Plant Level Questions + Corp Level Questions
    */
    if((prcId !== undefined && prcId !==0) && (langCode !== undefined && langCode !=="") && (levelId !== undefined && levelId !==0) && (plantId !== undefined)){      
    const url =  (AppSettings.API_ENDPOINT+ MethodConstants.GetAuditQuesFailCode+"processId="+prcId+"&langCode="+langCode+"&level="+levelId+"&plantId="+plantId+"&viewPlantQues="+viewPlantQues)
     return this.callService.callServerForGet(url).map((resp:ResponseObject) => {
          if(this.utilService.checkValidData(resp)){                           
                    let respObject = resp.Response;
                    if(viewPlantQues !== 2){
                            if(respObject !== undefined && respObject.length > 0 && respObject[0].data!== undefined && _.isArray(respObject[0].data) && respObject[0].data.length > 0){                        
                                return this.assignIsCorpQuesToResponse(respObject, viewPlantQues);
                            } else{                                    
                                if(respObject !== undefined && respObject.length > 0){
                                     return this.assignIsCorpQuesToResponse(respObject, viewPlantQues);
                                        //return respObject[0];
                                } else{
                                        return undefined;
                                }
                            }
                    } else{                            
                           if(respObject !== undefined && respObject.length > 0){
                                         return this.assignIsCorpQuesToResponse(respObject, viewPlantQues);
                               //         return respObject[0];
                                } else{
                                        return undefined;
                                }
                    }                         
            } 
        });
    } else{
        console.error(' values cannot be null');
    }            
  }

  // This is called by the Plant Admin for adding the New Question
  public requestAddNewQueFailCodeToAudit(data:Questions){
      let plantId = this.userService.getUserSelection().selPltId;         
      let requestData:RequestQuestion;
    let reqData : Array<ReqQuestion> = this.formRequestQuestionsRequestFormat([data], true);
    requestData = new RequestQuestion(this.wLogin, plantId, reqData);       
    this.reqAddQueCallServer(requestData);
  };
  
  public approveReqAddNewQueFailCodeToQuestion(data:Questions){    
    let reqData : Array<ApproveQuestion> = this.formApproveReqQuesFailCodeRequestFormat([data], true);    
     const url = (AppSettings.API_ENDPOINT + MethodConstants.ApproveRequestedQues);
      return this.callService.callServerForPost(url," Post Question FailCodes By Language Category",reqData[0]).subscribe((data)=>{
            this.utilService.showToast("", data[0]);
      }); 
  }

  public updateExistingQueFailCodeInQuesTab(data:Array<Questions>){
    let requestData:RequestUpdateQuestion;
    // if it is a Corp then plant id is zero other wise plant id
    let plantId = this.user.roleId === 2 ? 0 :  this.userService.getUserSelection().selPltId;
    let reqData : Array<UpdateQuestion> = this.formUpdateQuestionsRequestFormat(data, false);
    requestData = new RequestUpdateQuestion(this.wLogin, plantId ,reqData);       
    const url = (AppSettings.API_ENDPOINT + MethodConstants.UpdateQuesFailCodeByLangCat);
      return this.callService.callServerForPut(url," Post Question FailCodes By Language Category",requestData);           
  };

public ReqFCAssgneRvwerChange(requestData:ReqFCAssgneRvwerChange):Observable<ResponseObject>{
      const url = (AppSettings.API_ENDPOINT + MethodConstants.InsertPlantFailCodeAssignee);
      return this.callService.callServerForPost(url,"",requestData);           
}
  /*{
  "plantId": 250,
  "failureCd": 1,
  "failureCdCatId": 6,
  "assigneeId": 2,
  "reviewerId": 3,
  "wLogin": "corplear\\ddai"
}*/

  // This is called by the Plant Admin for adding the Existing Question
  public requestAddExistingQueFailCodeToAudit(data:Array<CreateAuditQuestion>,procId:number,levelId:number,plantId:number, wLogin:string){
    if(data.length > 0){
            let queIds = _.map(data, "queId");
            let questionIds = queIds[0] !== undefined ? _.uniq(queIds) : data;            
            if(questionIds.length >0){
                    if((wLogin !== undefined && wLogin !== "") &&(procId !== undefined && procId !== 0) && (levelId !== undefined &&  levelId !==0) && (questionIds.length > 0) && (plantId !== undefined)){
                        // Add the questions directly to the Plant Audit no need to request the CQA to add the question.
                        const url = (AppSettings.API_ENDPOINT + MethodConstants.addAdditionalQuesToPlantAudit);
                        return this.callService.callServerForPost(url,"",new AddAdditionalQuesToPlantAuditRequest(procId,questionIds.join(),levelId,plantId,wLogin));      
                    } else{
                       return  Observable.create((observer)=>{
                        // "1013":"Selected Questions are already available in the Audit",
                            observer.next(new ResponseObject(true, "", [], ""));
                        });
                    }
            } else {
                return  Observable.create((observer)=>{
                        // "1013":"Selected Questions are already available in the Audit",
                        observer.next(new ResponseObject(true, "", ["1013"], "1013"));
                    });
            }
    } else{// Incase if the questions are empty
            if((wLogin !== undefined && wLogin !== "") &&(procId !== undefined && procId !== 0) && (levelId !== undefined &&  levelId !==0) && (plantId !== undefined)){
                        // Add the questions directly to the Plant Audit no need to request the CQA to add the question.
                        const url = (AppSettings.API_ENDPOINT + MethodConstants.addAdditionalQuesToPlantAudit);
                        return this.callService.callServerForPost(url,"",new AddAdditionalQuesToPlantAuditRequest(procId,"",levelId,plantId,wLogin));      
                    } else{
                       return  Observable.create((observer)=>{
                                // "1013":"Selected Questions are already available in the Audit",
                                observer.next(new ResponseObject(true, "", [], ""));
                            });
                    }
    }                    
  };
  private reqAddQueCallServer(reqQuesData:RequestQuestion){
      //if requested -- 1 - requested question, 0 - approved question
      const url = (AppSettings.API_ENDPOINT + MethodConstants.RequestAddNewQueFailCode);
      return this.callService.callServerForPost(url," Post Question FailCodes By Language Category",reqQuesData).subscribe((data)=>{
          if(this.utilService.checkValidData(data)){
                this.utilService.showToast("", "Successfully Added the Question.");
                this.events.publish("loadQuestionFailureCodes","")
          }            
      });      
  };

  private formUpdateQuestionsRequestFormat(data:Array<Questions>, isNewQue:boolean):Array<UpdateQuestion>{        
        //let reqQue:Array<ReqQuestion>;
        return data.reduce((prev,item, index)=>{
            let catId:number = item.catId;                
            let reqQues:Array<UpdateQuestion> = [];
            reqQues = item.questions.reduce((pv, itm: Question, i)=>{
                let failCodeList:Array<UpdateFailureCode> = []; 
                itm.failCodes.forEach((im:FailureCode, idx)=>{
                    failCodeList.push(new UpdateFailureCode(im.failCode,
                                                        im.failureCdCatId,
                                                        im.failDesc,
                                                        im.failCodeHelp,
                                                        im.failActive,
                                                        (im.failCode === 0)));
                });
                pv.push(new UpdateQuestion(itm.lngCode,catId,
                                            itm.queId, itm.queHelp, 
                                            itm.queDesc, itm.na,itm.queActive,isNewQue,
                                                this.user.userId, 
                                            failCodeList));                                                    
                return pv;
            }, []);
           prev = prev.concat(reqQues);
            return prev;
        }, []);                
  };

  private formRequestQuestionsRequestFormat(data:Array<Questions>, isNewQue:boolean):Array<ReqQuestion>{        
        let reqQue:Array<ReqQuestion>;
        reqQue = data.reduce((prev,item, index)=>{
            let catId:number = item.catId;                
            let reqQues:Array<ReqQuestion> = [];
            reqQues = item.questions.reduce((pv, itm: Question, i)=>{
                let failCodeList:Array<FailureCodeList> = []; 
                itm.failCodes.forEach((im:FailureCode, idx)=>{
                    failCodeList.push(new FailureCodeList(idx + 1,// sequence Id shoudl nevre be 0
                                                        im.failDesc,
                                                        im.failCodeHelp,
                                                        im.failCode,
                                                        im.failureCdCatId,
                                                        im.failActive));
                });
                pv.push(new ReqQuestion(itm.lngCode,catId,
                                            itm.queId, itm.queHelp, 
                                            itm.queDesc, true, false,isNewQue,
                                                this.user.userId, 
                                            failCodeList));                                                    
                return pv;
            }, []);
           prev = prev.concat(reqQues);
            return prev;
        }, []);        
        return reqQue;
  };

   private formApproveReqQuesFailCodeRequestFormat(data:Array<Questions>, isNewQue:boolean):Array<ApproveQuestion>{        
     
         let reqQue:Array<ApproveQuestion>;
        reqQue = data.reduce((prev,item, index)=>{
            let catId:number = item.catId; 
            let queId:number = 0; 
            let langCode:string = ""; 

            let reqQues:Array<ApproveQuestionObject> = [];
            reqQues = item.questions.reduce((pv, itm: Question, i)=>{
                let failCodeList:Array<ApproveFailureCodeObject> = []; 
                    itm.failCodes.forEach((im:FailureCode, idx)=>{
                                    failCodeList.push(new ApproveFailureCodeObject(im.failDesc,
                                                                        im.failCodeHelp,
                                                                        im.failActive,idx + 1,// sequence Id should never be 0
                                                                        ));
                                });
                queId = +itm.queId;
                langCode = itm.lngCode;
                pv.push(new ApproveQuestionObject(itm.queDesc, itm.queHelp, itm.na, catId,                                            
                                            failCodeList));                                                    
                return pv;
            }, []);
           prev.push(new ApproveQuestion( this.user.wLogin, queId, langCode, reqQues));
            return prev;
        }, []);        
        return reqQue;
  };
    

  callServerToCreateAuditByProcOpPG(data:Array<CreateAuditQuestion>, selPrId:number,selLevelId:number,selPGName:string,
                                                                                selOpName:string,
                                                                                selPrName:string){
       if(data.length > 0 && selPrId && selLevelId && selPGName && selOpName && selPrName){       
          return  this.createAuditbyProcOpPG(new CreateAudit(selPrId,selLevelId,this.userService.getUser()["wLogin"], data))
        } else {
            console.error("data.length > 0 && selPrId && selLevelId && selPGName && selOpName && selPrName values cannot be null or empty");
        }
    }

    public checkQuesHaveFailureCodesdefines(questionsresponse:Array<Questions>, isCorp:boolean):Observable<Array<String>>{
        const emptyFCLen = isCorp ? 1 : 2;
        return Observable.create((observer)=>{
                observer.next(questionsresponse.reduce((prev, item)=>{
                                    //const catId = item.catId;
                                    //const catName = item.catName;
                                    let ques:Array<CreateAuditQuestion>= new Array();
                                            ques = item.questions.reduce((prv, itm)=>{
                                                                const fcLen = itm.failCodes.length;
                                                                // question response will have one empty failure code item returned in 
                                                                // the question response each for corp login and plant login                                                                        
                                                                if(fcLen === emptyFCLen){
                                                                    if(isCorp){
                                                                        if(itm.failCodes[0].failCode ===0 && !itm.failCodes[0].failActive){
                                                                            prv.push(1);
                                                                        }                                                                    
                                                                    } else{
                                                                        if(!itm.failCodes[0].failActive && itm.failCodes[0].failCode === 0){
                                                                            if(!itm.failCodes[1].failActive && itm.failCodes[1].failCode === 0){
                                                                                    prv.push(1);
                                                                            }                                                                            
                                                                        }
                                                                    }                                                                   
                                                                }                                                                
                                                                return prv;            
                                                        }, []);
                                    prev = prev.concat(ques);
                                    return prev;
                                },[]).length > 0 ? false :  true); 
            });
    }
// This returns the queId and seqId
    public getSelectedQuestionsIdSeqId(questionsresponse:Array<Questions>):Observable<CreateAuditQuestion>{
        return Observable.create((observer)=>{
                observer.next(questionsresponse.reduce((prev, item)=>{
                                    //const catId = item.catId;
                                    //const catName = item.catName;
                                    let ques:Array<CreateAuditQuestion>= new Array();
                                            ques = item.questions.reduce((p, i)=>{
                                                                if (i.sequence !== '0'){
                                                                    p.push(new CreateAuditQuestion(+i.queId,+i.sequence));
                                                                } else{
                                                                // this.zeroSequenceSel.push(new Questions(catName, catId,[i]));
                                                                }                         
                                                                return p;            
                                                        }, []);
                                    prev = prev.concat(ques);
                                    return prev;
                                },[]));                                
                });

    }

     deleteFailureCodeInAllLang(failureCode:number){
     //http://localhost/LPAServices/api/FailureCodes/DeleteAFailureCode?failureCode=0
    const url = (AppSettings.API_ENDPOINT + MethodConstants.DeleteAFailureCode+"failureCode="+failureCode);
      return this.callService.callServerForDelete(url);
  }
  
  deleteQuestionInAllLang(id:number){
     //http://localhost/LPAServices/api/FailureCodes/DeleteAFailureCode?failureCode=0
    const url = (AppSettings.API_ENDPOINT + MethodConstants.DeleteAQuestion+"id="+id);
      return this.callService.callServerForDelete(url);
  }
   inactiveQuestionInAllLang(queId:number, active:boolean){     
    const url = (AppSettings.API_ENDPOINT + MethodConstants.InactivateQuestion+"queId="+queId+"&active="+active+"&wLogin="+this.user.wLogin);
      return this.callService.callServerForPost(url,"","");
  }


  private formUpdateQuestions(data:Array<Questions>){
 
  }

   public getTraslatedData(translateText:string = "", fromLanguage:string = "", toLanguage:string = ""){
        //  if(this.utilService.itemDefined(translateText) && this.utilService.itemDefined(fromLanguage) && this.utilService.itemDefined(toLanguage)){
        //    const response = this.translateDataService.getTranslatedText(translateText, fromLanguage, toLanguage);
        //    console.log(response);
        // }
   } 

}
