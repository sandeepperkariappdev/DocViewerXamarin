import { Component, ElementRef, ChangeDetectorRef} from '@angular/core';
import { NavController, ModalController, NavParams, ViewController, AlertController, PopoverController  } from 'ionic-angular';
import { OrderByPipe} from '../../../filters/order-by-pipe';
import * as _ from 'lodash';
import { Lot, Machine, Shift } from '../../../models/Level';
import { AdminManageQuesServiceProvider} from './admin-manage-ques-service';
import { EditAuditQuestion } from '../../edit-audit-question/edit-audit-question';
import { Search } from '../../../popup-modals/search/search';
import { QuestionItem,ResponseObject, Questions, Question,RequestQuestion,AuditList, CreateAudit, CreateAuditQuestion,UserSelectionPrivileges,UserSelectionData, UserObject} from '../../../models/QuestionItem';
import { QuestionsList } from '../../../models/QuestionsList';
import { I18n } from '../../../constants/AppSettings';
import { QuestionFailureCodeDetails} from '../question-failure-code-details/question-failure-code-details';
import { UpdateQuesFailureCodeModals } from '../../../popup-modals/update-ques-failure-code-modals/update-ques-failure-code-modals';
import { Privileges } from '../../../providers/privileges';
import { UtilService } from '../../../providers/util-service';
import { UserService } from '../../../providers/user-service';
import { User } from '../../../models/user';
import { SelectionPage } from '../../selection/selection';
import { Observable }from 'rxjs/observable';
import { TranslateService} from 'ng2-translate';
import{Events } from 'ionic-angular';

@Component({
  selector: 'admin-manage-questions-page',
  templateUrl: 'admin-manage-questions.html',
  providers:[OrderByPipe],
})
//TODO add a search box to search for questions.

export class AdminQuestions{

     shownGroupas = null;//to show or hide used for accordion
     userSelectionPrivileges:UserSelectionPrivileges;
     showAllQue:boolean;
     selectionData:UserSelectionData;
    queResp:Questions;
    categoryList:Array<any>;
    selLanguage:String;
    selCategory:String;   
    languagesList:Array<any>;
    zeroSequenceSel:Array<Questions>
    questionsresponse:Array<Questions>;
    tempSelandUNSelList:Array<Questions>;
    tempSelList:Array<Questions>;
    tempUnSelList:Array<Questions>;
    tempQuestList:Array<Questions>;
    count:number = 0;
    isMandate:boolean;
    isEdit:boolean;
    buttonSel:string;
    orderSel:boolean;
    orderCount: number = 0;
    isDetails:boolean;
    showFailureCodesForQues:boolean;
    showAddNewQues:boolean;
    user:User;
    pageName:string;
    isFromAuditDetails:boolean;
    isFromAnotherPage:boolean;
    pageTitle:string;
    reqAuditDtsAddNewQues:boolean;
    availableAuditsList:Array<AuditList>;
    reqAddNewQuesToAudit:boolean;
    private addQuesToexistingAudit:boolean;
     private addPGSpecfcQuestions:boolean;
     private isCorpLogin : boolean;
     private isEditExistingQue : boolean;
     private previousSelectedQuestions:Array<number>;
    constructor(public navCtrl: NavController,
                private viewCtrl:ViewController, 
                private alertCtrl: AlertController,
                private navParams: NavParams, 
                public elRef:ElementRef,
                private privileges:Privileges, 
                private userService:UserService, 
                private changeDetref:ChangeDetectorRef, 
                public modalCtrl:ModalController, 
                private translate:TranslateService,
                private orderByPipe:OrderByPipe,
                private utilService:UtilService,
                private popoverCtrl:PopoverController, 
                private events: Events,
                private adminManQuesService:AdminManageQuesServiceProvider){

                    this.translate = translate; // Used for I18n
                    
                    this.userSelectionPrivileges = new UserSelectionPrivileges(false,true,true,true,true,false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false);
                   
                    this.questionsresponse =[];
                    this.pageTitle = "Manage Questions";
                    this.pageName = "QuestionsTab";
                    this.isMandate = false;
                    this.isEdit = false;
                    this.buttonSel = 'showAll';
                    this.orderSel = false;
                    this.showFailureCodesForQues = false;
                    this.isDetails = false;
                    this.showAllQue = false;
                    this.addPGSpecfcQuestions = false;
                    this.user = this.userService.getUser();//setting the user for this page
                    this.categoryList = this.utilService.getAllcategories();
                    this.languagesList = this.utilService.getAllLanguages();                           
                      this.previousSelectedQuestions = [];
                    //TODO: CQA will only see the Create Audit button.
                    const privPage = this.privileges.getPageObject(this.user.roleName,"Admin")[this.pageName];
                    this.showAddNewQues = privPage["showAddNewQues"] === "true";
                    this.reqAddNewQuesToAudit = (privPage["reqAddNewQuesToAudit"] === "true");
                    this.addQuesToexistingAudit = (privPage["addQuesToexistingAudit"] === "true");
                    this.isEditExistingQue = (privPage["isEditExistingQue"] === "true")
                    this.isFromAuditDetails = false; 
                    this.isFromAnotherPage = false;        
                    this.events.subscribe("loadQuestionFailureCodes",(data:Object) => {
                            this.loadQuestionFailureCodes();
                    });                       
        }



    ionViewWillEnter(){
      
        this.isCorpLogin = (this.user.roleId === 2) ? true: false;
        switch(this.navParams.data.isFromPage){
            case "AuditDetails":
                    this.pageTitle = "Available Questions";
                    this.fromAuditDetailsPage();
                break;
            case "AuditsList":
                    this.pageTitle = "Available Questions";
                    this.fromAuditListsPage();
                    break;            
            default:
                this.loadQuestionFailureCodes();
                 break;        
        }
    }

    private fromAuditDetailsPage():void{
            this.isFromAuditDetails = true;
            this.showAddNewQues =  true;
            this.isFromAnotherPage = true;  
            const navParams = this.navParams.data;
            // To request adding new questions to the Audit
            this.reqAuditDtsAddNewQues = (navParams.reqAuditDtsAddNewQues.toString() === "true");
            this.reqAuditDtsAddNewQues = this.reqAddNewQuesToAudit;// Both should be equal
            this.showAddNewQues = (navParams.showAddNewQueToQueMaster.toString() === "true");
            if(navParams.userSelectionData !== undefined){
                this.selectionData = navParams.userSelectionData;
            } 
            if(navParams.addPGSpecfcQuestions !== undefined){
                this.addPGSpecfcQuestions = navParams.addPGSpecfcQuestions;
            }
            if(navParams.selectedQuestions !== undefined){
                this.previousSelectedQuestions = navParams.selectedQuestions;
            }

            
            // if(this.addPGSpecfcQuestions){                
            //     this.loadQuestionFailureCodes(this.utilService.getCatByPG(this.selectionData.selPGId));
            // } else{
                this.loadQuestionFailureCodes();
            //}            
            
            // TODO CQA can add the questions directly to the Audits
            // Other can only request the questions
    };
    private fromAuditListsPage():void{
        const navParams = this.navParams.data;
        this.isFromAnotherPage = true; 
        // get the available audits from the previous screen - Audits lists ascreen
        if(navParams  !== undefined && navParams.auditsList !== undefined){
            this.availableAuditsList = navParams.auditsList;// assign the audits lsit to the local value
            this.createNewAuditButtonClicked(false);
        }
        this.loadQuestionFailureCodes();
    };

    private loadQuestionFailureCodes(catIds:Array<number> = []){ 
        const usrSel = this.userService.getUserSelection();    
            const langCde = usrSel.selLangCode;
           //const catIdQues = this.userService.getUserSelection()["selPGId"];// TODO show quetions by product group
           const pgId = usrSel.selPGId;  
           // If the log-in user is a CorpAdmin then load only Corp questions otherwise load both Corp and Plant Questions
           let processSpecificQuestions = !this.isFromAnotherPage;
            // below is code is to show only process specific questions for the plant admin to add
            //    if(!this.isCorpLogin && this.isFromAnotherPage){
            //        processSpecificQuestions = true;
            //    } 
            let allQuestion = 2;
            if(!this.isCorpLogin){
                allQuestion = 1
            }

        this.adminManQuesService.getQuestionFailCodesByLangPg(langCde,allQuestion,false, pgId,  processSpecificQuestions).subscribe((data:ResponseObject)=>{      
                if(this.utilService.checkValidData(data)){                
                    const response  = data.Response;
                    if(response !== undefined && response.length > 0  &&  response[0].data){
                        this.questionsresponse = this.adminManQuesService.markQuestionsAvailableInAudits(response[0].data,this.previousSelectedQuestions);
                        if(catIds.length > 0){
                            this.questionsresponse = this.questionsresponse.filter((item)=>{
                                return catIds.indexOf(item.catId) !== -1;
                            });
                        }                        
                       
                    }                
                }
            }, (error)=>{

            }, ()=>{
                    this.tempQuestList = _.cloneDeep(this.questionsresponse);
                    this.tempSelandUNSelList = _.cloneDeep(this.questionsresponse);
                    this.zeroSequenceSel = [];
        });
    }
    private toggleGroup(group) {
      if (this.isGroupShown(group)) {
          this.shownGroupas = null;
      } else {
          this.shownGroupas = group;
      }
    };

    private isGroupShown(group) {
        if(this.showAllQue){
            return true;
        } else{
            return this.shownGroupas === group;
        }        
    };

    private sortSelectionClicked():void{
        if(this.questionsresponse !== undefined && this.questionsresponse.length > 0){        
                this.resetButtonFlag();
                this.buttonSel = 'sortSel';
                this.questionsresponse = this.questionsresponse.reduce((prevItem, currItem,index, array) => {
                    let obj = {catName: currItem.catName ,questions : []}
                    this.orderByPipe.transform(currItem.questions,'sequence');      
                    obj.questions =  this.orderByPipe.value
                    prevItem.push(obj);
                    return prevItem;
                }, []);
                //this.orderByPipe.transform(this.questionsresponse[0].questions,'SEQUENCE');      
                // this.questionsresponse[0].questions =  this.orderByPipe.value;
                this.buttonSel = '';      
        }
    }
    private showAllClicked():void{
          if(this.questionsresponse !== undefined && this.questionsresponse.length > 0){ 
                this.resetButtonFlag();
                this.buttonSel = 'showAll';
                if(this.tempSelandUNSelList.length > 0){
                    this.questionsresponse = this.tempSelandUNSelList;
                } else{
                    this.questionsresponse = this.tempQuestList;
                }      
        }
    }
    private selEditClicked():void{
        this.resetButtonFlag();
        this.isEdit = true;
        this.buttonSel = 'showSelEdit';
    }
    private selDetailsClicked():void{
        if(this.questionsresponse !== undefined && this.questionsresponse.length > 0){           
            this.resetButtonFlag();
            this.isDetails = true;
            this.buttonSel = 'showSelDetails';
        }        
    }
    //Show selected clicked
    private showSelectedClicked():void{
        if(this.questionsresponse !== undefined && this.questionsresponse.length > 0){           
            this.resetButtonFlag();
            this.buttonSel = 'showSel';
            this.questionsresponse = this.doSelectionUnSel(this.tempSelandUNSelList ,true);   
        }    
    }
    private doSelectionUnSel(allQueSelUnSelList:Array<Questions>, returnSel:boolean):Array<Questions>{
            this.resetButtonFlag(); // reset the selection button
              let queRespSelUnSel = allQueSelUnSelList.reduce((x,item) =>
              { 
                            let obj = {objSel:{catName:'',catId: 0, questions:[] }, 
                                objUnSel : {catName:'', catId: 0, questions:[] }};

                                                            obj.objSel.catName = item.catName;
                                                            obj.objUnSel.catName = item.catName;

                                                            obj.objSel.catId = item.catId;
                                                            obj.objUnSel.catId = item.catId;

                                                            let reducedQuesArray = item.questions.reduce((y,i) =>{ 
                                                                                                      if(i.isAlloted == true){                                                                                                  
                                                                                                        y.selectedItems.push(i)
                                                                                                    } else{
                                                                                                        y.unSelectedItems.push(i)
                                                                                                    }; 
                                                                                                    return y;
                                                                                                },{selectedItems:[],unSelectedItems:[]});
                                                            obj.objSel.questions = reducedQuesArray.selectedItems;
                                                            obj.objUnSel.questions = reducedQuesArray.unSelectedItems
                                                            x.push(obj); 
                                                            return x;
                                                          },[]);
                                                                
            this.tempSelList = queRespSelUnSel.reduce((prev, item) => { 
                                                                        if(item.objSel.questions.length > 0){
                                                                                prev.push( item.objSel);  
                                                                            } 
                                                                            return prev;                                                                       
                                                                    },[]);
            /*this.tempSelandUNSelList = queRespSelUnSel.reduce((prev, item)=>{ 
                                        let obj= {catName:'',questionsArray:[] }; 
                                        obj.questionsArray = obj.questionsArray.concat(item.objSel.questionsArray);  
                                        obj.questionsArray = obj.questionsArray.concat(item.objUnSel.questionsArray);
                                        prev.push(obj);
                                        return prev; 
                                      },[]);*/
            this.tempUnSelList = queRespSelUnSel.reduce((prev, item) => { 
                                                                    if(item.objUnSel.questions.length > 0){
                                                                        prev.push(item.objUnSel);                                                                       
                                                                    } 
                                                                      return prev;                                                                    
                                                                },[]);;
      return returnSel? this.tempSelList:this.tempUnSelList;
    }

    private unDoAllSelectionClicked():void{
        if(this.questionsresponse !== undefined && this.questionsresponse.length > 0){                   
                this.resetButtonFlag();
                this.buttonSel = 'showUnDoAll';
                this.questionsresponse = _.cloneDeep(this.tempQuestList);
                this.tempSelandUNSelList = _.cloneDeep(this.questionsresponse);
        }
      //this.changeDetref.detectChanges(); //o immedialtely run change detection for the current component and it's childrend $scope.$digest()
      //this.changeDetref.markForCheck(); // include the current component the next time Angular runs change detection
      //Applicationref.tick(); // run change detection for the entire application. $rootScope.$digest()
     //NgZone.run //$rootScope.$apply(callback)  
    }

    /*This is called on click of Add new question Button
     on successfull submission of the question in the model window the question is sent to the server.*/
    private createNewQuestion():void{
        this.buttonSel = 'showAddNewQues';
        let modal = this.modalCtrl.create(UpdateQuesFailureCodeModals,{ "isFromAuditDetails": this.isFromAuditDetails, 
                                                                        "reqAuditDtsAddNewQues":this.reqAuditDtsAddNewQues},{
                                                            enableBackdropDismiss:false,
                                                        });
        modal.onDidDismiss((data)=>{ // question object is returned from the model window.
            if(data!== undefined){                
                if(!this.isCorpLogin){// this is for the Plant Admin to add a new question to the Audit
                    // TODO make a service call to request addition of new question to the question master
                    this.adminManQuesService.requestAddNewQueFailCodeToAudit(data.submitedData);
                    //this.loadQuestionFailureCodes();// reload the questions this is done througth the subscriber in the constructor
                    this.viewCtrl.dismiss();
                } else {
                    // this is called by CQA to add new Question and failure codes to the question master 
                    this.adminManQuesService.createQuestionFailCodesByLangCat(data.submitedData);// Calling the service method.
                    //this.loadQuestionFailureCodes();// reload the questions this is done througth the subscriber in the constructor
                }                
            }
            this.buttonSel = '';            
        });
        modal.present();
    }

    private selFailureCodesClicked():void{
        if(this.questionsresponse !== undefined && this.questionsresponse.length > 0){       
            this.resetButtonFlag();
            this.showAllQue = true;
            //this.showFailureCodesForQues = !this.showFailureCodesForQues;
        }                        
    }
     private selShowAllQuesClicked():void{
        if(this.questionsresponse !== undefined && this.questionsresponse.length > 0){       
            this.resetButtonFlag();
            //this.showAllQue = !this.showAllQue; 
        }                        
    }

    private showUnSelectionClicked():void{ 
                if(this.questionsresponse !== undefined && this.questionsresponse.length > 0){       
                        this.resetButtonFlag();
                        this.buttonSel = 'showUnSel';
                        this.questionsresponse = this.doSelectionUnSel(this.tempSelandUNSelList, false);       
                 }                
    }

    private orderSelectionClicked():void{
                if(this.questionsresponse !== undefined && this.questionsresponse.length > 0){       
                    this.resetButtonFlag();
                    this.buttonSel = 'showOrderSel';
                    this.questionsresponse = this.doSelectionUnSel(this.tempSelandUNSelList ,true);   
                    this.orderSel = true;
                    this.orderCount = 0;
                }        
    }
    private resetButtonFlag():void{
        this.orderSel = false;
        this.isDetails = false;
        this.isEdit = false;
    }
    private isHighlighted( queIt):void{
        var xx = queIt;// [class.selected]="isHighlighted(que)" 
    }

  
    // Called on click of a question
    private selectQue(e:any ,qitem: Question,index:number, catName:string, catId:number): void{
      // this.tempSelandUNSelList = _.cloneDeep(this.questionsresponse);
   // _.filter
    /*const classList= e.target.parentElement.parentElement.classList;
    const classListArray = e.target.parentElement.parentElement.classList.value.split(' ');
    if(classListArray.indexOf('selected') != -1){
        classList.remove('selected');
    } else{
        classList.add('selected');
    } */   
      if(this.orderSel){
          this.orderCount ++;
          qitem.sequence =  this.orderCount.toString();
      } else if (this.isDetails){          
         let queItem:Questions= new Questions(catName, catId,  [qitem]);         
         this.navCtrl.push(QuestionFailureCodeDetails,{"queItem":queItem,"isFromPage":"AdminQuestions","isEditExistingQue":this.isEditExistingQue,"viewQuestionDetails":true.toString()});                
      } else{     
        if(this.isFromAuditDetails){       
          this.count ++;
          qitem.sequence =  this.count.toString();
          qitem.isAlloted = !qitem.isAlloted;    
        //   if(this.isMandate){
        //     qitem.IS_MANDATORY = true;
        //   }
          this.tempSelandUNSelList  =this.tempSelandUNSelList.reduce((prev, item) =>{
                                          item.questions.reduce((prev, i)=> { 
                                            if(i.queId === qitem.queId){
                                                  i.isAlloted = qitem.isAlloted;
                                                  i.isMandatory = qitem.isMandatory;
                                                  i.sequence = qitem.sequence;
                                              }   
                                              prev.push(i);
                                              return prev;
                                            },[]);
                                      prev.push(item); 
                                      return prev;
                                    },[]);
             } else{ 
                    let queItem:Questions= new Questions(catName, catId,  [qitem]);         
                    this.navCtrl.push(QuestionFailureCodeDetails,{"queItem":queItem,"isFromPage":"AdminQuestions","isEditExistingQue":this.isEditExistingQue,"viewQuestionDetails":true.toString()});                
             }
          }   
     }

     // This is called on click of the dashed lines on each question 
     //to drag and drop to re order he position of the question
     private reorderItems(indexes, queItem, index):void {
        //let element = this.questionsresponse[index].questionsArray[indexes.from];
        const queArrConst = this.questionsresponse[index].questions;
        let movFrmEle = queArrConst[indexes.from-1];
        let movToEle = queArrConst[indexes.to-1];
        
        let seqFrmEle = movFrmEle.sequence;
        movFrmEle.sequence = movToEle.sequence;      
        movToEle.sequence =  seqFrmEle;    
        queArrConst[indexes.to-1] =  movToEle;
        let movEle = queArrConst.splice(indexes.from -1, 1)[0];
        queArrConst.splice(indexes.to-1, 0, movEle);        
        this.tempSelandUNSelList  = this.questionsresponse;        
    }
    
    //Called on click of search icon on the top of the header
    private searchSelection():void{
            if(this.availableAuditsList){
                this.showUserSelectionPopUp(true,this.selectionData,this.userSelectionPrivileges,this.availableAuditsList).subscribe(()=>{});
            } else{
                this.showUserSelectionPopUp(true,this.selectionData,this.userSelectionPrivileges).subscribe(()=>{});
            }
            
    }

    // This is used by the Plant Admin on Click of the Request Button
    // in the header to request adddition of selected questoin to the Audit
    private addSelQuesToAudit():void{
        // calling this to set the sequence for the questions
        this.showSelectedClicked();

        // TODO Make a service call to request for addition of question
        //  to the Audit by the Corporate Quality admin.
    if(this.buttonSel === 'showSel'){
        // if the user is a CQA, Call Server to directly 
        //add the question to the Audit.
        if(!this.reqAuditDtsAddNewQues){     
            // Always send the exisitng questions plus new questions to be added  
            // in the sequence it has to show up  . 
            // the exisitng questions will be deleted and re-inserted again   
            // Check if the Selected Question have failure code defined
            // question response will have one empty failure code item returned in the question response each for corp login and plant login
                this.adminManQuesService.checkQuesHaveFailureCodesdefines(this.questionsresponse,  this.isCorpLogin).subscribe((failCodesDefinedforQues)=>{                              
                    if(failCodesDefinedforQues){                    
                        this.adminManQuesService.getSelectedQuestionsIdSeqId(this.questionsresponse).subscribe((data)=>{
                            this.viewCtrl.dismiss({"selectedQuesIdSeqId": data, "isPlantAudit": (!this.isCorpLogin).toString()});          
                        }); 
                    } else{
                        this.utilService.showToast("NoFailCodesToSelectQues","");        //console.error("no failure codes defined for selected questions");
                    }
                });                                 
        } else{
            //If Plant Admin request the questions to CQA to add it to the Audit.
            //const data:Array<Questions> = this.getSelectedQuestionsObjects();
            this.adminManQuesService.checkQuesHaveFailureCodesdefines(this.questionsresponse,  this.isCorpLogin).subscribe((failCodesDefinedforQues)=>{                              
                    if(failCodesDefinedforQues){                                    
                        this.adminManQuesService.getSelectedQuestionsIdSeqId(this.questionsresponse).subscribe((data)=>{
                            this.viewCtrl.dismiss({"selectedQuesIdSeqId": data,"isPlantAudit":(!this.isCorpLogin).toString()});          
                        });    
                    } else{
                        this.utilService.showToast("NoFailCodesToSelectQues","");        
                        //console.error("no failure codes defined for selected questions");
                    }
                });                    
        }  
     } else {
                this.utilService.showToast("selectShowSelected","");
            }       
    }


    private dismissModal():void{
        this.viewCtrl.dismiss();
    }

    private searchAuditExitsForUserSelection(selData:UserSelectionData):boolean{  
        
            return _.findIndex(this.availableAuditsList,(item)=>{return item.pgId === selData.selPGId && 
                                                                        item.opId === selData.selOpId &&
                                                                        item.procId === selData.selPrId &&
                                                                        item.levelId === selData.selLevelId}) === -1;

        
    }
    
// Called on click of the Save Button 
//to create an Audit after selecting the list of questions
    private createNewAuditButtonClicked(submitToServer:boolean){
        const navParamsData = this.navParams.data;
        const useSel:boolean = navParamsData.useSel ? (navParamsData.useSel) : (navParamsData.useSelectionDataSent ? (navParamsData.useSelectionDataSent) : false);        
        const userSelectionData:UserSelectionData = navParamsData.userSelectionData  !== undefined ? navParamsData.userSelectionData : this.selectionData;
        let userPrivileges:UserSelectionPrivileges = navParamsData.userPrivileges   !== undefined ? navParamsData.userPrivileges :  this.userSelectionPrivileges;
        
        this.showUserSelectionPopUp(useSel,userSelectionData,userPrivileges, this.availableAuditsList).subscribe((data:UserSelectionData)=>{
            const sel = this.searchAuditExitsForUserSelection(data);
            if(!sel){
                this.translate.get(['Alert','isAuditAvailable']).subscribe((data) => {                
                let prompt = this.alertCtrl.create({
                                        title: data['Alert'],
                                        message: data['isAuditAvailable'],
                                        buttons: [{
                                                    text: 'Cancel',
                                                    handler: data => {                                                        
                                                            prompt.dismiss().catch((error)=>{
                                                                console.log(error);
                                                            });
                                                        }
                                            }, {
                                                text: 'Okay',
                                                handler: data => {
                                                    this.createNewAuditButtonClicked(false);
                                                    prompt.dismiss().catch();

                                                }
                                            }
                                        ]
                                        });
                                prompt.present();
                            });
                
            };
            if(submitToServer){
                    this.adminManQuesService.callServerToCreateAuditByProcOpPG(this.getSelectedQuestionsIdSeqId(),
                                                                                +this.selectionData.selPrId, 
                                                                                +this.selectionData.selLevelId,
                                                                                this.selectionData.selPGName,
                                                                                this.selectionData.selOpName,
                                                                                this.selectionData.selPrName);
                     this.viewCtrl.dismiss();
            }
            
        });
        
                     
    }

    // This returns selected Question in Array of objects of the queId's and seqId's
    private getSelectedQuestionsIdSeqId():Array<CreateAuditQuestion>{
        return this.questionsresponse.reduce((prev, item)=>{
                const catId = item.catId;
                const catName = item.catName;
                let ques:Array<CreateAuditQuestion>= new Array();
                  ques =item.questions.reduce((p, i)=>{
                     if (i.sequence !== '0'){
                        p.push(new CreateAuditQuestion(+i.queId,+i.sequence));
                     } else{
                        this.zeroSequenceSel.push(new Questions(catName, catId,[i]));
                     }                         
                     return p;            
                }, []);
                prev = prev.concat(ques);
                return prev;
         },[]);
    }

    private getSelectedQuestionsObjects():Array<Questions>{
        return this.questionsresponse.reduce((prev, item)=>{
                const catId = item.catId;
                const catName = item.catName;
                let ques:Array<Question>= new Array();
                  ques =item.questions.reduce((p, i)=>{
                     if (i.sequence !== '0'){
                        p.push(i);
                     } else{
                        this.zeroSequenceSel.push(new Questions(catName, catId,[i]));
                     }                         
                     return p;            
                }, []);
                prev = prev.concat(new Questions(catName, catId,ques));
                return prev;
         },[]);
    }
    cancelCreateNewAudit(){
        this.unDoAllSelectionClicked();
    }
    


     showUserSelectionPopUp(useSel:boolean, userSelectionData?:UserSelectionData,userPrivileges?:UserSelectionPrivileges, availableAuditsList?:Array<any>):Observable<any> {
            let popover = this.popoverCtrl.create(SelectionPage,{ "useSelectionDataSent":useSel,"isPopOverCtrl":"true", "isMandatory": false, "userPrivileges":userPrivileges, "pageTitle":"Create Audit For",
            "userSelectionData":userSelectionData, "availableAuditsList":availableAuditsList},{
                enableBackdropDismiss:false,
            });
            popover.present();
            return  Observable.create(observer =>{
                        popover.onDidDismiss((data:UserSelectionData)=>{
                        if(data){
                                this.selectionData = data;                                                                
                                observer.next(this.selectionData);
                                observer.complete();                               
                                } else{
                                    this.navCtrl.pop();
                                }
                                
                        });             
                        
                    });    
            }



    // Searching the quesions and failure code on the inputs entered.
    private getSearchItems(ev:any){
        let val = ev.target.value;
        if(val && val.trim() !== '' && val.length >= 3){                        
               this.questionsresponse  = this.questionsresponse.reduce((prev, catItem:Questions) =>{                   
                let itm:Array<Question> = catItem.questions.reduce((prv:Array<Question>, i:Question) => {
                     if(i.queDesc.length > 0){
                        if(i.queDesc.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
                            _.findIndex(i.failCodes,(d => d.failDesc.toLowerCase().indexOf(val.toLowerCase()) > -1)) > -1){
                            prv.push(i);
                        }
                     }
                     return prv;
                }, []);
                if(itm.length > 0){
                    let x:Questions = {catName:catItem.catName, catId:catItem.catId,questions:itm};                                     
                    prev.push(x);
                }                                
                return prev;
            },[])             
        }        
    }
    private searchQueCancelClicked(){
        switch(this.buttonSel){
            case 'showAll':
                this.showAllClicked();
                break;
            case 'showSel':
                this.showSelectedClicked();
                break;
            case 'showUnSel':
                this.showUnSelectionClicked();
                break;
            case 'sortSel':
                this.sortSelectionClicked();
                break;
            case 'showOrderSel':
                this.orderSelectionClicked();
                break;
            case 'showUnDoAll':
                this.unDoAllSelectionClicked();
                break;
            default :
                this.showAllClicked();
                break;
        }
    }

    presentPromptForLevel() {
            let alert = this.alertCtrl.create({
                title: 'Create Audit',
                message:'Please select the level to assign this Audit',
                inputs: [
                    {
                        type:'radio',
                        name: 'level',
                        value:"1",
                        label:'level 1'

                    }],
                buttons: [
                {
                    text: 'Cancel',
                    role: 'cancel',
                    handler: data => {
                    console.log('Cancel clicked');
                    }
                },
                {
                    text: 'Select',
                    handler: data => {
                        console.log(data);
                    }
                }
                ]
            });
            alert.present();
            }
}