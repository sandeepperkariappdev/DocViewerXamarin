import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ActionSheetController,ViewController, AlertController, ModalController } from 'ionic-angular';
import { Language } from '../../../models/Level';
import { Category } from '../../../models/Level';
import * as _ from 'lodash';
import {UtilService} from '../../../providers/util-service';
import {UserService} from '../../../providers/user-service';
import {InitialDataService} from '../../../providers/initial-data-service';
import { AdminManageFailureCodesPage } from '../../admin-manage-failure-codes/admin-manage-failure-codes';
import {AdminManageQuesServiceProvider} from '../admin-manage-questions/admin-manage-ques-service';
import { Questions, Question, FailureCode, ResponseObject , FailCodeCategoryList} from '../../../models/QuestionItem';
/**
 * Generated class for the QuestionFailureCodeDetails page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-question-failure-code-details',
  templateUrl: 'question-failure-code-details.html',
})
export class QuestionFailureCodeDetails {

  editQue:boolean;
  onLanguageSelected:boolean;
  selLangQue:string = 'all';
  
  public questionList:Array<Question>;
  public newQuestionsList:Questions;
  public initialQuestionsList:Questions;
 public failCodeCatList:Array<FailCodeCategoryList>;
  shownGroupas = null;//to show or hide used for accordion
  showCatTextInput:boolean;
  selLanguage = {id:'all'};// for language checkbox modal
  selCategories = {id:'select'};// for categories checkbox modal
  isRequestedQue:boolean;
  createCategories = {name:''};
  languagesList:Array<Language>;// for language checkbox List
  catList:Array<Category>;// for categories checkbox List
  public selectOptions:any;
  private isEditExistingQue:boolean;

  isViewQuestionDetails:boolean;

  constructor(public navCtrl: NavController,public alertCtrl: AlertController,
            public userService: UserService, public navParams: NavParams, 
            private adminManQuesService: AdminManageQuesServiceProvider, 
            public actionSheet:ActionSheetController, 
            public viewCtrl: ViewController, public modalCtrl:ModalController,
            public initialDataService: InitialDataService,
            private utilService:UtilService) {    
        this.languagesList = this.utilService.getAllLanguages();
        this.catList = this.utilService.getAllcategories();      
        this.isRequestedQue = false;
        this.showCatTextInput = false;
        this.isViewQuestionDetails = false;
        this.questionList = [];
        this.isEditExistingQue = false;
      this.failCodeCatList = this.utilService.getAllFailureCodeCategories(); 
      this.selectOptions = {
            
        };
    }
 ionViewDidLoad(){
        this.selCategories.id ="select";
        this.editQue = false;
        let dataObj:Questions;
        const navParams =  this.navParams.data;
        
        if(navParams.isFromPage === "RequestsList"){
            this.isRequestedQue = true;
        }
        if(navParams !== undefined && navParams.isEditExistingQue !== undefined){
            this.isEditExistingQue = (navParams.isEditExistingQue.toString() === "true");
            this.editQue = this.isEditExistingQue;
        }        
        if(this.utilService.itemDefined(navParams.viewQuestionDetails)){
            this.isViewQuestionDetails = (navParams.viewQuestionDetails.toString() === "true");             
        }
                    
        if(this.utilService.itemDefined(navParams.queItem)){
            dataObj = navParams.queItem;
            const usrSel = this.userService.getUserSelection();
            const plantId = this.userService.getUser().roleId === 2 ? 0 : this.userService.getUserSelection().selPltId;
            this.isViewQuestionDetails ? this.editQue = true : this.editQue = true; // setting the edit question flag
             const obj:Question = dataObj.questions[0];
                                  
                    this.adminManQuesService.getQuestionFailCodesByLangCat(+obj.queId/*convert to number from string*/, 
                                                                         +dataObj.catId/*convert to number from string*/,
                                                                         "0"/*0 string to retrieve all languages*/,
                                                                         2, this.isRequestedQue, plantId).subscribe((response:ResponseObject) => {                       
                            if(this.utilService.checkValidData(response)){
                                let responseObj = response.Response;
                                if(responseObj.length > 0){
                                            this.questionList = responseObj.reduce((prev, item)=>{                                                                    
                                                                    let ques= item.data[0].questions.reduce((prv, v)=>{                                                                        
                                                                        prv.push(new Question(v.lngCode, this.utilService.getLanguageDesc(v.lngCode),v.queId,v.queHelp,v.queDesc,obj.sequence,obj.isAlloted, obj.queActive,obj.isMandatory,v.isCorpQues,v.na,v.failCodes.filter(fcItem=> fcItem.failCode !== 0)));
                                                                        return prv;
                                                                    },[]);
                                                                    prev = prev.concat(ques);
                                                                    return prev;
                                                                },[]);                                                                                                                                    
                                                this.newQuestionsList = new Questions( dataObj.catName,dataObj.catId, this.questionList.filter(item => item.lngCode === obj.lngCode));
                                                this.initialQuestionsList = new Questions( dataObj.catName,dataObj.catId, this.questionList);
                                                this.selCategories.id = dataObj.catId.toString() === "0" ? "select" : dataObj.catId.toString();
                                                this.selLanguage.id = usrSel.selLangCode;
                                } else{
                                        // if the failure codes are empty for the Question, the response from service will be empty, so loading the question from the previous request.
                                        let fc:Array<FailureCode> = [];
                                        obj.failCodes.forEach((v:FailureCode, i) => {
                                            fc.push(new FailureCode(v.assigneeId, v.reviewerId, v.severity,v.failCode,v.failureCdCatId, v.failDesc,v.failCodeHelp,true, v.failureCdCatDesc));
                                        });              
                                        let ques:Question = new Question(obj.lngCode, this.utilService.getLanguageDesc(obj.lngCode),obj.queId,obj.queHelp,obj.queDesc,obj.sequence,obj.isAlloted, obj.queActive,obj.isMandatory,obj.isCorpQue,true,fc);                     
                                        this.questionList = new Array(ques);
                                        this.newQuestionsList = new Questions( dataObj.catName,dataObj.catId, this.questionList);
                                        this.initialQuestionsList = new Questions( dataObj.catName,dataObj.catId, this.questionList);
                                        this.selCategories.id = dataObj.catId.toString() === "0" ? "select" : dataObj.catId.toString();
                                        this.selLanguage.id =  usrSel.selLangCode;
                                }                            
                            }                                                                            
                        },() => {                            
                        },() => {                        
                        });                    
        }
  }
  onLanguageChange(flag:boolean = true){                                
        this.newQuestionsList.questions = this.initialQuestionsList.questions.reduce((prev, item)=>{
            if(this.selLanguage.id !== "all" && item.lngCode === this.selLanguage.id){
                prev.push(item);
            } else if(this.selLanguage.id === "all") {
                prev.push(item);
            }
            return prev;
        }, []);
    }
 onCategoryChange(item){    
        if(this.selCategories.id !== "" && this.selCategories.id !=="select" && this.selCategories.id !=="create"){
            if(this.newQuestionsList.catId !== +this.selCategories.id){                
                this.newQuestionsList = new Questions(this.initialQuestionsList.catName, this.initialQuestionsList.catId, []);
            } else{
               this.newQuestionsList = new Questions(this.initialQuestionsList.catName, this.initialQuestionsList.catId, this.initialQuestionsList.questions);             
            }
        }
         if(this.selCategories.id ==="create"){
             this.showCatTextInput = true;
         }
    }
    
    createCategory(){
        const pgNum = this.userService.getUserSelection().selPGId;
        if(this.createCategories.name !== "" && pgNum !== undefined){
            this.adminManQuesService.createNewCategory(this.createCategories.name,pgNum,this.userService.getUser().wLogin).subscribe((data)=>{
                this.utilService.showToast("","Successfully create new category.");
                this.initialDataService.getAllCategories(pgNum).subscribe((response)=>{
                        if(this.utilService.checkValidData(response)){
                                this.catList = response.Response;
                                this.utilService.setAllcategories(response.Response);
                        }                        
               });       
            });
        }        
    }

    removeCreateCategory(){
        this.showCatTextInput = false;
        this.selCategories.id ="select";
    }
private checkQuestionFailureCodesNotInComplete(){
    return this.newQuestionsList.questions.reduce((prev, item)=>{
            const fcList = item.failCodes.filter(itm => (itm.failDesc !== "" && itm.failureCdCatId !== 0));
            if(fcList.length === item.failCodes.length && item.queDesc && item.queDesc != ""){
                    prev.push(item);
            }
        return prev;
    },[])
  }
    private editQueButton():void{        
        if(this.isEditExistingQue){
            //this.editQue = !this.editQue;              
            
                //if(!this.editQue){
                    // const quesLen = this.newQuestionsList.questions.reduce((prev, item) => {
                    //                 if(item.queDesc != ""){
                    //                         const len = item.failCodes.filter((itm)=>{
                    //                                 if(itm.failDesc !== "" && itm.failureCdCatId !== 0){
                    //                                     return true;
                    //                                 }
                    //                         }); 
                    //                         if(len.length >0){
                    //                             return true;
                    //                         }
                    //                 }
                    //         });
                       if(this.checkQuestionFailureCodesNotInComplete().length > 0){
                                    let alert = this.alertCtrl.create({
                                                    title: 'Confirm',
                                                    message:"Have you updated the Question, Click yes to save the changes.",
                                                    buttons: [
                                                    {
                                                        text: 'No',
                                                        role: 'cancel',
                                                        handler: data => {
                                                            if(!this.isRequestedQue){                                                                                                
                                                                this.navCtrl.pop();
                                                            } else{
                                                                alert.dismiss();                                 
                                                            }                                
                                                        }
                                                    },
                                                    {
                                                        text: 'Yes',
                                                        handler: data => {
                                                                // returning the date to submit to the server from the controller            
                                                                this.adminManQuesService.updateExistingQueFailCodeInQuesTab([this.newQuestionsList]).subscribe((data)=>{
                                                                                if(this.utilService.checkValidData(data)){
                                                                                    this.utilService.showToast(data.ResponseCode,"");
                                                                                    this.viewCtrl.dismiss();
                                                                                }            
                                                                        });  
                                                        }
                                                    }
                                                    ]
                                                });
                                                alert.present();
                                        
                                } else{
                                    this.utilService.showToast("EmptyQuesFailCodes","");
                                }           
                //}
       }     else{
             this.utilService.showToast("NoPrivilegesAvailable","");
        } 
    }
   
 
 
  addNewFailureCode(item){
      this.newQuestionsList.questions.forEach((v,i)=>{
        v.failCodes.push(new FailureCode(0,0,0,0,1,"","",true, ""));
    });
  };

    private addFailureCodeClick(item:Question){
        let modal = this.modalCtrl.create(AdminManageFailureCodesPage, {"isFromPage": "UpdateQuestions"});
        modal.onDidDismiss((data:Array<FailureCode>)=>{ // question object is returned from the model window.
            if(data!== undefined){// return the array of Failure Code Objects
                //this.newQuestionsList.questions.forEach((v,i)=>{
                    //v.failCodes = v.failCodes.concat(data);
                ///});
                 item.failCodes = item.failCodes.reduce((prev, itm)=>{
                    if(itm.failDesc !== ""){
                        prev.push(itm);
                    }                                        
                    return prev;
                },[]);  // updating the new add failure codes
                item.failCodes= item.failCodes.concat(data);
            }            
        });
        modal.present();
    }

  private deleteQuestion(item){
    this.adminManQuesService.deleteQuestionInAllLang(item).subscribe((data)=>{       
        this.navCtrl.pop();
    }, (error)=>{
        console.log(error);
    }, ()=>{

    });
  };

  private inActiveQuestion(item:Question){
    this.adminManQuesService.inactiveQuestionInAllLang(+item.queId, item.queActive).subscribe((data)=>{ 
        if(this.utilService.checkValidData(data)){
                this.utilService.showToast("","Sucessfully "+ (item.queActive ?  "Activated":"Inactivated ") + " the Question.");
        }              
    }, (error)=>{
        console.error(error);
    }, ()=>{

    });
  }
  private removeNewFailureCode(index, item){    
      // below service to delete failure code form the question.
    //this.adminManQuesService.deleteFailureCodeInAllLang(item).subscribe((data)=>{   
        if(item.toString() === "0"){
                this.newQuestionsList.questions.forEach((v,i)=>{
                    v.failCodes.splice(index,1);
                });
        }  else{
            this.utilService.showToast("","You cannot delete the existing failure codes");
            // we cannot delete the already present Failure Codes to the Question because
            // we already have Audits taken where these Question and Failure Codes are used. 
            //Audits History is broken if we delete the Failure Codes linked to the Question.
        }      
            
    // }, (error)=>{
    //     console.log(error);
    // },()=>{

    // });
  }
  toggleGroup(group) {
      if (this.isGroupShown(group)) {
          this.shownGroupas = null;
      } else {
          this.shownGroupas = group;
      }
    };
    isGroupShown(group) {
        if(this.selLanguage.id === "all"){
            return this.shownGroupas === group;
        } else{
            return true;
        }        
    };

    
   
    approveRequestedQuestion(){
        if(this.newQuestionsList){
            if(this.newQuestionsList.catId !== 0 ) {
                //TODO check if the values are non-empty
                this.adminManQuesService.approveReqAddNewQueFailCodeToQuestion(this.newQuestionsList);
                this.navCtrl.pop();
            } else{
                this.utilService.showToast("","Please select a Category for the Quetion");
            }            
        }        
    }
  cancelRequestedQuestion(){

  }


}
