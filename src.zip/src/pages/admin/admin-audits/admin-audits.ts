import { Component } from '@angular/core';
import { NavController, ModalController, NavParams, PopoverController, ViewController} from 'ionic-angular';
import { AdminCreateAudit } from '../admin-create-audit/admin-create-audit';
import { AuditDetails } from '../audit-details/audit-details';
import { Privileges } from '../../../providers/privileges';
import { UserService } from '../../../providers/user-service';
import { User } from '../../../models/user';
import { Lot, Machine, Shift } from '../../../models/Level';
import { UserObject, UserSelectionData,UserSelectionPrivileges,AuditList, AuditDetailsQuestion, AuditQuestions, ResponseObject } from '../../../models/QuestionItem';
import { UtilService} from '../../../providers/util-service';
import { SelectionPage } from '../../selection/selection';
import { AdminAuditProvider } from './admin-audits-service';
import { AdminQuestions } from '../admin-manage-questions/admin-manage-questions';
import { TranslateService} from 'ng2-translate';
import * as _ from 'lodash';
import { AdminManagementPage } from '../../admin-management/admin-management';
import { AuditDetailsServiceProvider } from '../audit-details/audit-details-service';
import { AdminManageQuesServiceProvider} from '../admin-manage-questions/admin-manage-ques-service';
import { ScheduleAuditsToGroupPage } from '../../schedule-audits-to-group/schedule-audits-to-group';
import { Level } from '../../../models/Level';
@Component({
  selector: 'admin-audits-page',
  templateUrl: 'admin-audits.html'
})
export class AdminAudits {

    private auditListInitialLevel1:Array<AuditList>;
    private auditListLevel1:Array<AuditList>;

    private auditListInitialLevel2:Array<AuditList>;
    private auditListLevel2:Array<AuditList>;

    private auditListInitialLevel3:Array<AuditList>;
    private auditListLevel3:Array<AuditList>;

    private auditListInitialLevel4:Array<AuditList>;
    private auditListLevel4:Array<AuditList>;

    private auditListInitialLevel:Array<AuditList>;
    private auditListLevel:Array<AuditList>;

    private pageName:string;
    private operationsList:Array<any>;
    private facilityList:Array<any>;
    private processList:Array<any>;
    private levelList:Array<Level>;
    private showAddnewAudit:boolean;
    private showAuditDetails:string;
    private showAuditDetailsAddNewQues:boolean;
    private reqAuditDtsAddNewQues:boolean;
    private showAcceptAuditButton:boolean;
    private showAddNewQueToQueMaster:boolean;
    private showPlantAudits:boolean;
    private languagesList:Array<any>;
    private user:User;
    private process: string;
    private selData:UserSelectionData;
    private adminAuditUserSelPrivileges:UserSelectionPrivileges;
    private addPGSpecfcQuestions:boolean;
    private isPlantAdmin:boolean;
    public isLPAAudits:boolean;
    private isCropAdmin:boolean;
    private optionView :string;
    private pageTitle:string;
    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                private adminAuditService:AdminAuditProvider,
                private popoverCtrl:PopoverController, 
                private viewCtrl:ViewController,
                private modalCtrl:ModalController, 
                private privileges:Privileges, 
                private utilService:UtilService,
                private translate:TranslateService,
                private auditDetailsService:AuditDetailsServiceProvider,
                private adminManQuesService:AdminManageQuesServiceProvider,
                private userService:UserService){
                    this.isPlantAdmin  = false;
                    this.isCropAdmin = false;
                    this.translate = translate; // Used for I18n
                    this.pageName = "AuditTab";
                    //setting the user for this page
                    this.user = this.userService.getUser();
                    this.optionView = "1";
                   // this.selData= new UserSelectionData(0,"select",0,"select",0,"select",0,"select",0,"select",0,"select","ENG","English","","","",new Lot(0, ""),new Machine("0","",""),new Shift("0",""), new UserObject(0, ""),"","","","","","","" );
                    this.adminAuditUserSelPrivileges = new UserSelectionPrivileges(false,false,false,false,true,false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false);
                    //Get the privileges for the User
                    const thisPage = this.privileges.getPageObject(this.user.roleName,"Admin")[this.pageName];
                    this.levelList = [];
                    this.showAddnewAudit = thisPage["showAddnewAudit"];
                    this.showAuditDetails = thisPage["AuditDetails"]["thisShow"];
                    this.showAuditDetailsAddNewQues = (thisPage["AuditDetails"]["showAddnewQues"] === "true");
                    this.reqAuditDtsAddNewQues = (thisPage["AuditDetails"]["addnewQueRequest"] === "true");
                    this.showAcceptAuditButton = (thisPage["AuditDetails"]["showAcceptAuditButton"] === "true");
                    this.showPlantAudits = (thisPage["AuditDetails"]["showPlantAudits"] === "true");
                    this.addPGSpecfcQuestions = (thisPage["AuditDetails"]["addProductGroupSpecificQuestions"] === "true");
                    this.showAddNewQueToQueMaster = (thisPage["AuditDetails"]["showAddNewQueToQueMaster"] === "true");
                    this.isPlantAdmin = (this.userService.getUser()["roleId"] === 3);
                    this.isCropAdmin = (this.userService.getUser()["roleId"] === 2);
                    this.pageTitle = "";
                    this.isLPAAudits = true;
                    //TODO: CQA will only see the Create Audit button.
    }   
    
   
    ionViewWillEnter(){
        const navParams = this.navParams.data;
        if(navParams.isLPAAudits !== undefined){
            this.isLPAAudits = (navParams.isLPAAudits === "true");
            if(this.isCropAdmin){   
                this.isLPAAudits = true; 
            }
        }        
        this.levelList = this.utilService.getAllLevels();
        this.selData = ((this.selData === undefined) ? this.userService.getUserSelection() : this.selData);        
        this.pageTitle = (this.isLPAAudits ? " Audits Management - " : " Waste Walk - ") + this.selData.selPGName; 
                 
        if(this.isCropAdmin){                    
            if(this.selData === undefined){
                this.presentSelectionPopover(true);
            }   else{                
                this.getAuditList(this.selData.selPGId, this.selData.selOpId, this.selData.selLevelId, 0);                
            }         
        } else{            
            this.getAuditList(this.selData.selPGId, this.selData.selOpId, this.selData.selLevelId,  this.selData.selPltId);                       
        }        
    }
    
   private presentSelectionPopover(isMandatory:boolean) {
       const priv = Object.assign({},this.adminAuditUserSelPrivileges);
       const selDat = this.selData;
        let popover = this.popoverCtrl.create(SelectionPage, {"isMandatory":isMandatory, 
                                                            "userPrivileges": priv,
                                                            "isPopOverCtrl":"true",
                                                            "pageTitle":"Select Level", 
                                                            "userSelectionData": selDat },
                                                            {
                                                                enableBackdropDismiss:false,
                                                            });
        popover.present();
        popover.onDidDismiss((data:UserSelectionData)=>{
            if(data){
                this.selData = data;
                this.getAuditList(data.selPGId, data.selOpId, data.selLevelId, data.selPltId);
            }                
        }); 
    }

    private getAuditList(pgId:number,opId:number, levelId:number, plantId:number){
        if(this.isLPAAudits){
                if(pgId !== 1 && pgId !== 0 && levelId !== undefined && opId !== undefined && opId.toString() !== ""){            
                        this.adminAuditService.getAuditsListByOpPg(pgId, opId, 1, this.isPlantAdmin,plantId ).subscribe((data)=>{
                            if(this.utilService.checkValidData(data)){                
                                if(data !== undefined && data.Response !== undefined && data.Response.length > 0){
                                    this.auditListLevel1 = data.Response;
                                    this.auditListInitialLevel1 = data.Response;
                                } else{                                    
                                    this.utilService.showToast("AuditsListNotAvailable","");                        
                                }           
                            } 
                        });

                        this.adminAuditService.getAuditsListByOpPg(pgId, opId, 2, this.isPlantAdmin, plantId).subscribe((data)=>{
                            if(this.utilService.checkValidData(data)){                
                                if(data !== undefined && data.Response !== undefined && data.Response.length > 0){
                                    this.auditListLevel2 = data.Response;
                                    this.auditListInitialLevel2 = data.Response;
                                } else{                                    
                                    this.utilService.showToast("AuditsListNotAvailable","");                        
                                }           
                            } 
                        });
                        this.adminAuditService.getAuditsListByOpPg(pgId, opId, 3, this.isPlantAdmin, plantId).subscribe((data)=>{
                            if(this.utilService.checkValidData(data)){                
                                if(data !== undefined && data.Response !== undefined && data.Response.length > 0){
                                    this.auditListLevel3 = data.Response;
                                    this.auditListInitialLevel3 = data.Response;
                                } else{                                    
                                    this.utilService.showToast("AuditsListNotAvailable","");                        
                                }           
                            } 
                        });
                        this.adminAuditService.getAuditsListByOpPg(pgId, opId, 4, this.isPlantAdmin, plantId).subscribe((data)=>{
                            if(this.utilService.checkValidData(data)){                
                                if(data !== undefined && data.Response !== undefined && data.Response.length > 0){
                                    this.auditListLevel4 = data.Response;
                                    this.auditListInitialLevel4 = data.Response;
                                } else{                                    
                                    this.utilService.showToast("AuditsListNotAvailable","");                        
                                }           
                            } 
                        });
                    } else if(pgId === 1){ // General Audits
                          this.isLPAAudits = false;  
                    } else{
                        console.error("Values cannot be null.");
                    }
        } 

        if(!this.isLPAAudits){
                this.adminAuditService.getAuditsListByOpPg(1,0, 11, this.isPlantAdmin, plantId).subscribe((data)=>{
                            if(this.utilService.checkValidData(data)){                
                                if(data !== undefined && data.Response !== undefined && data.Response.length > 0){
                                    this.auditListLevel = data.Response;
                                    this.auditListInitialLevel = data.Response;
                                } else{                                    
                                    this.utilService.showToast("AuditsListNotAvailable","");                        
                                }           
                            } 
                        });
        }              
    }
    public navigateToHome():void{
        this.navCtrl.setRoot(AdminManagementPage);
   }
    private auditSelectedForDetails(item:AuditList):void{
        if(this.showAuditDetails === 'true'){
            let selDat = Object.assign({},this.selData);
            selDat.selPGId = item.pgId; selDat.selOpName = item.opName;
            selDat.selOpId = item.opId; selDat.selPrId = item.procId;
            selDat.selPGName = item.pgName; selDat.selPrName = item.procName;
            selDat.selLevelId = item.levelId; 
            selDat.selLevelName = item.auditLevelDesc;
            this.navCtrl.push(AuditDetails, {
                showAuditDetailsAddNewQues:this.showAuditDetailsAddNewQues,
                reqAuditDtsAddNewQues:this.reqAuditDtsAddNewQues,
                showAcceptAuditButton:this.showAcceptAuditButton,
                "userSelectionData": selDat,
                "showPlantAudits": this.isCropAdmin ? false : this.showPlantAudits,// For corp admin no need to Show plant Audits
                "isFromPage":'AuditsList',
                "isLPAAudits":this.isLPAAudits,
                "showAddNewQueToQueMaster":this.showAddNewQueToQueMaster,
                "addPGSpecfcQuestions":this.addPGSpecfcQuestions});  
        }       
    }
   
    private addNewAudit():void{ 
        let priv = Object.assign({},this.adminAuditUserSelPrivileges);
        const selDat = Object.assign({},this.selData);

        let adList;
        if(this.optionView === "1"){
           adList =  this.auditListLevel1 === undefined ? [] : this.auditListLevel1;
        }
        if(this.optionView === "2"){
           adList =  this.auditListLevel2 === undefined ? [] : this.auditListLevel2;
        }
        if(this.optionView === "3"){
           adList =  this.auditListLevel3 === undefined ? [] : this.auditListLevel3;
        }
        if(this.optionView === "4"){
           adList =  this.auditListLevel4 === undefined ? [] : this.auditListLevel4;
        }
        
        if(adList !== undefined && selDat !== undefined && priv !== undefined){
          
           priv.prc = true;// to show process in the pop-up
           priv.level = false; // not to show level in the pop-up.

          this.navCtrl.push(AdminQuestions, { "isFromPage":"AuditsList",
                                                "useSelectionDataSent":true, 
                                                "auditsList":adList, 
                                                "userSelectionData":selDat,
                                                "userPrivileges":priv});
        }               
    }
    private getSearchItems(ev:any){
        let val = ev.target.value;

         if(this.optionView === "1"){
           if(val && val.trim() !== '' && val.length >= 3){                        
               this.auditListLevel1  = this.auditListLevel1.filter((item) => {
                    return (item.auditName.toLowerCase().indexOf(val.toLowerCase()) > -1);
                });
            }
        }
        if(this.optionView === "2"){
           if(val && val.trim() !== '' && val.length >= 3){                        
               this.auditListLevel2  = this.auditListLevel2.filter((item) => {
                    return (item.auditName.toLowerCase().indexOf(val.toLowerCase()) > -1);
                });
            }
        }
        if(this.optionView === "3"){
           if(val && val.trim() !== '' && val.length >= 3){                        
               this.auditListLevel3  = this.auditListLevel3.filter((item) => {
                    return (item.auditName.toLowerCase().indexOf(val.toLowerCase()) > -1);
                });
            }
        }
        if(this.optionView === "4"){
            if(val && val.trim() !== '' && val.length >= 3){                        
               this.auditListLevel4  = this.auditListLevel4.filter((item) => {
                    return (item.auditName.toLowerCase().indexOf(val.toLowerCase()) > -1);
                });
            }
        }
         
    }
    private searchCancelClicked():void{
        
        if(this.optionView === "1"){
            this.auditListLevel1 = this.auditListInitialLevel1;
        }
        if(this.optionView === "2"){
           this.auditListLevel2 = this.auditListInitialLevel2;
        }
        if(this.optionView === "3"){
           this.auditListLevel3 = this.auditListInitialLevel3;
        }
        if(this.optionView === "4"){
            this.auditListLevel4 = this.auditListInitialLevel4;
        }        
    }


 public scheduleAuditButtonClicked(item:AuditList){    
     const selProcId = item.procId;
         this.adminManQuesService.getAuditDetailsByPrcIdLngLevelId(item.procId,this.selData.selLangCode, 
         this.selData.selLevelId, this.isPlantAdmin ? this.selData.selPltId : 0, 2).subscribe((response1:AuditDetailsQuestion)=>{
                let data= [];                             
                            if(response1 !== undefined && response1["data"] !== undefined && response1["data"].length > 0){
                                    data = response1["data"];                                                        
                                         //const assignedFCodes = ;
                                    if(this.getAssignedFailureCodes(data)){
                                            this.acceptAuditPresentPopOver(selProcId);
                                        } else{
                                            this.utilService.showToast("","Assign Non Compliance before Scheduling the Audit.")
                                        }
                            } else{
                                this.utilService.showToast("","Audit has no questions, Please add the question to Audit to Schedule.");
                            }                             
         });    
    }


presentAcceptAuditPopover(userSelPrv:UserSelectionPrivileges, selData:UserSelectionData) {
         //new UserSelectionPrivileges(this.userService.getUser()["roleId"] !== 2, true,true,true,true,false, true, false,false, false)
            userSelPrv.endDate = false;/// we'll be showing only the start date fo the week.
            let popover = this.popoverCtrl.create(SelectionPage,{"useSelectionDataSent":true,
            "isPopOverCtrl":"true",
            "isMandatory":"false",
            "pageTitle":"Assign Dates",
            "isFromPage":"scheduleAuditForWeek",
            "showWeekStartOnly":"true",
            "userPrivileges":userSelPrv,
            "userSelectionData":selData} ,{
                enableBackdropDismiss:false,
            });
            popover.present();
            popover.onDidDismiss((data:UserSelectionData)=>{
                if(data!== undefined){
                     this.auditDetailsService.createActiveAuditsByDateAndPlant(selData.selPltId,data.startDate,data.endDate, selData.selPrId, selData.selLevelId,this.user.wLogin).subscribe((dat:ResponseObject)=>{
                            if(this.utilService.checkValidData(dat)){
                                    this.utilService.showToast(dat.ResponseCode," - StartDate : "+ data.startDate + " - EndDate : " + data.endDate);                            
                                if(dat.ResponseCode === "1003"){ // success accepting the audit                                                                     
                                     this.assignAuditToAuditors(dat.Response[0]);                                  
                                }                                 
                            }                            
                        }, (error) => {
                                this.utilService.showToast("ErrorConnectServer","");
                        }, () =>{

                        });      
                }                
            }); 
    }
    private assignAuditToAuditors(plantAuditListId:number){
            let modalCtrl = this.modalCtrl.create(ScheduleAuditsToGroupPage,{"plantAuditListId":plantAuditListId});
            modalCtrl.present();            
    }

      private getAssignedFailureCodes(auditQuestions:Array<AuditQuestions>){
         //const usersList:Array<UsersInPlant> = this.userService.getUsersInPlant();
         return auditQuestions.reduce((prev,item)=>{
            prev =  item.questions.reduce((prv, itm)=>{
               prv = itm.failCodes.reduce((p,i)=>{
                   p = (i.assigneeId !== 0 && i.reviewerId !== 0) ? true :false                                                                                                                                                                              
                      return p;
                },false);                
                return prv;
            },false);                
            return prev;
        },false);
    }
    private acceptAuditPresentPopOver(selProcId:number){
        // This Accept Audit Button shows up for Users of Plant admin to accept an Audit for his Plant
        let selDat : UserSelectionData = Object.assign({},this.selData);
        selDat.selPrId = selProcId;
        //TODO call service to assign the Audit to some one       
        this.presentAcceptAuditPopover(new UserSelectionPrivileges(false, false,false,false,false,false,                                                                        false, true,true, false, false, false,
                                                                        false, false, false, false, false, false,
                                                                        false, false, false, false), selDat);   
    }


}