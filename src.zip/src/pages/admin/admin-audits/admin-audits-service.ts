import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { Questions, CreateAudit } from '../../../models/QuestionItem';
import { CallService} from '../../../providers/call-service';
import { UtilService} from '../../../providers/util-service';
import { Observable }from 'rxjs/observable';
import 'rxjs/add/operator/map';
import { AppSettings, MethodConstants } from '../../../constants/AppSettings';

/*
  Generated class for the AdminAuditProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class AdminAuditProvider {

  constructor(public http: Http, private callService:CallService, private utilService:UtilService) {
    
  }
  public getAuditsListByOpPg(pgId:number, opId:number, levelId:number, isPlantAdmin:boolean, plantId:number){
    if((pgId !== undefined && pgId !==0) && (opId !== undefined && opId.toString() !=="") && (levelId !==undefined)){
      const url = (AppSettings.API_ENDPOINT + MethodConstants.GetAuditListByOpPg+"pgNum="+pgId+"&operationNum="+opId+"&auditLevel="+levelId+"&isPlantAdmin="+(isPlantAdmin ? "1" :"0")+"&plantId="+plantId);
      return this.callService.callServerForGet(url);
    } else{
      console.error("values cannot be empty");
    }     
  }

  
}
