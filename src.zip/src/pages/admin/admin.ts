import { Component } from '@angular/core';
import { NavController, NavParams} from 'ionic-angular';
import { AdminAudits } from './admin-audits/admin-audits';
import { AdminMachines } from '../resources-management/admin-manage-machine/admin-manage-machine';
import { AdminManageFailureCodesPage } from '../admin-manage-failure-codes/admin-manage-failure-codes';
import { AdminQuestions } from './admin-manage-questions/admin-manage-questions';
import { AdminManageUser } from '../resources-management/admin-manage-user/admin-manage-user';
import { RequestsListPage } from './requests-list/requests-list';
import { Privileges } from '../../providers/privileges';
import { UserService } from '../../providers/user-service';
import { User } from '../../models/user';

@Component({
  selector: 'admin-page',
  templateUrl: 'admin.html'
})


export class Admin{
    private pageName:string;
    private tab1:any;
    private tab2:any;
    private tab3:any;
    private tab4:any;
    private tab5:any;
    private tab6:any;
    private user:User;
    public isLPAAudits:boolean;
    private showAuditsTab:boolean;
    private showMachinesTab:boolean;
    private showUsersTab:boolean;
    private showQuestionsTab:boolean;
    private showRequestsListTab:boolean;
    private showFailureCodeListTab:boolean;
    constructor( private privileges:Privileges,public navCtrl: NavController,private userService:UserService, private navParam:NavParams){
        this.tab1 = AdminAudits;
        this.tab2 = AdminMachines;
        this.tab3 = AdminQuestions;
        this.tab4 = AdminManageUser;
        this.tab5 = RequestsListPage;
        this.tab6 = AdminManageFailureCodesPage;
        this.pageName = "Admin";
        this.isLPAAudits = true;
        const navParams = this.navParam.data;
        if(navParams.isLPAAudits !== undefined){
           this.isLPAAudits = navParams.isLPAAudits;
       }
        this.user = this.userService.getUser();//setting the user for this page
        const page = this.privileges.getPageObject(this.user.roleName,"Admin");
        this.showAuditsTab = page["AuditTab"]["thisShow"];
        this.showMachinesTab = page["MachinesTab"]["thisShow"];//TODO: CQA will only see the Create Audit button.
        this.showUsersTab = page["UsersTab"]["thisShow"];
        this.showQuestionsTab = page["QuestionsTab"]["thisShow"];
        this.showRequestsListTab = page["RequestsListTab"]["thisShow"];// this Tab will be seen by only CQA
        this.showFailureCodeListTab = page["showFailureCodeListTab"]["thisShow"];// this Tab will be seen by only CQA
    }
}