import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {AdminServiceProvider} from '../admin-service';
import { Language } from '../../../models/Level';
import { QuestionFailureCodeDetails } from '../question-failure-code-details/question-failure-code-details';
import * as _ from 'lodash';
import { Privileges } from '../../../providers/privileges';
import {UserService} from '../../../providers/user-service';
import {UtilService} from '../../../providers/util-service';
import { QuestionItem,ReqQuestionResponse, ReqQuestions, RequestedFailureCode, RequestedQuestion,  Questions, Question,RequestQuestion,AuditList, CreateAudit, CreateAuditQuestion,UserSelectionPrivileges,UserSelectionData} from '../../../models/QuestionItem';
/**
 * Generated class for the RequestsListPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-requests-list',
  templateUrl: 'requests-list.html',
})
export class RequestsListPage implements OnInit {
  shownGroupas = null;//to show or hide used for accordion
 selLanguage = {id:"all"};// for language checkbox modal
  selLangQue:string = "all";
  languagesList:Array<Language>;// for language checkbox List
  reqList:Array<ReqQuestionResponse>;
  initialReqList:Array<ReqQuestionResponse>;
  searchReqList:Array<ReqQuestionResponse>;
    private isEditExistingQue: boolean;

  constructor(public navCtrl: NavController,  private privileges:Privileges,private userService: UserService, private utilService:UtilService, public navParams: NavParams, 
              private adminService:AdminServiceProvider) {
                  this.isEditExistingQue = false;
  }

  ionViewDidLoad() {
       const user = this.userService.getUser();//setting the user for this page
                  
      const privPage = this.privileges.getPageObject(user.roleName,"Admin")["RequestsListTab"];
      this.isEditExistingQue = (privPage["isEditExistingQue"] === "true")
                   
  }


  ngOnInit(){
      this.languagesList = this.utilService.getAllLanguages();
      this.GetAddNewQueToAuditReqList();
  }
  GetAddNewQueToAuditReqList(){
    this.adminService.GetAddNewQueToAuditReqList(0,0,'0',1, true,0).subscribe((data)=>{
              if(this.utilService.checkValidData(data)){                    
                    this.initialReqList = data.Response;
                    this.reqList = data.Response;                    
              }
    });
  }
  toggleGroup(group) {
      if (this.isGroupShown(group)) {
          this.shownGroupas = null;
      } else {
          this.shownGroupas = group;
      }
    };

    isGroupShown(group) {
        return this.shownGroupas === group;
    };
  queItemClicked(item, catId, catName){  
        let queItem:Questions= new Questions( catName, catId,  [item]); 
         this.navCtrl.push(QuestionFailureCodeDetails, {"isFromPage":"RequestsList", "isEditExistingQue":this.isEditExistingQue ,"queItem":queItem,"viewQuestionDetails":"false"});
  }

  onLanguageChange(){
    if(this.selLanguage.id !== "all"){
        this.reqList =  this.initialReqList.filter(item=>{
          return item.lngCode === this.selLanguage.id;
        });
    } else{
      this.reqList = this.initialReqList;
    }     
  }
  searchQueCancelClicked(){
    this.reqList  = this.searchReqList;
  }
// Searching the quesions and failure code on the inputs entered.
    private getSearchItems(ev:any){
        let val = ev.target.value;
        if(val && val.trim() !== '' && val.length >= 3){   
           this.searchReqList =  this.reqList;
               this.reqList  = this.reqList.reduce((prev, item:ReqQuestionResponse) =>{                   
//-----------------------------------------
                let itm:Array<ReqQuestions> = item.data.reduce((prv:Array<ReqQuestions>, itemData:ReqQuestions) => {
//------------------------------------------------------------
                     let it:Array<RequestedQuestion>  =   itemData.questions.reduce((pr:Array<RequestedQuestion>, itemQue:RequestedQuestion)=>{
                             if(itemQue.queDesc.length > 0){
                                if(itemQue.queDesc.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
                                    _.findIndex(itemQue.failureCodeList,(d => d.failDesc.toLowerCase().indexOf(val.toLowerCase()) > -1)) > -1){
                                    pr.push(itemQue);
                                }
                            }
                            return pr;
                        }, []);                    
//-----------------------------------------------------------------
                        prv.push(new ReqQuestions(itemData.catName, itemData.catId, it));
                      return prv;
                }, []);
//--------------------------------------------
                if(itm.length > 0){
                    let x:ReqQuestionResponse = new ReqQuestionResponse( item.lngCode ,item.lngName,itm);                                     
                    prev.push(x);
                }                                
                return prev;
            },[])             
        }        
    }
  

}
